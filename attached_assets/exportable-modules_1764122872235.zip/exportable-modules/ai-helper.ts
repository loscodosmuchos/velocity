import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";

// Initialize AI clients based on environment variables
const openaiKey1 = process.env.OPENAI_API_KEY;
const openaiKey2 = process.env.OPENAI_API_KEY2;
const anthropicKey = process.env.ANTHROPIC_API_KEY;

const openai1 = openaiKey1 ? new OpenAI({ apiKey: openaiKey1 }) : null;
const openai2 = openaiKey2 ? new OpenAI({ apiKey: openaiKey2 }) : null;
const anthropic = anthropicKey ? new Anthropic({ apiKey: anthropicKey }) : null;

/**
 * Call AI with automatic fallback between Claude and OpenAI
 * Tries Claude first, then OpenAI with primary key, then OpenAI with secondary key
 * 
 * @param systemPrompt - System instructions for the AI
 * @param userPrompt - User's request
 * @returns AI response as string, or null if all providers fail
 */
export async function callAI(systemPrompt: string, userPrompt: string): Promise<string | null> {
  const errors: string[] = [];

  // Try Claude first if available (claude-sonnet-4-20250514 is the latest model)
  if (anthropic) {
    try {
      console.log("Attempting generation with Claude");
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4096,
        system: systemPrompt,
        messages: [{ role: "user", content: userPrompt }]
      });

      const firstBlock = response.content[0];
      if (firstBlock.type === 'text') {
        console.log("Claude generation successful");
        return firstBlock.text;
      }
    } catch (error) {
      const errorMsg = `Claude failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      console.error(errorMsg);
      errors.push(errorMsg);
    }
  }

  // Try OpenAI with primary key
  if (openai1) {
    try {
      console.log("Attempting generation with OpenAI (primary key)");
      const response = await openai1.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        response_format: { type: "json_object" },
      });

      const content = response.choices[0].message.content;
      if (content) {
        console.log("OpenAI (primary key) generation successful");
        return content;
      }
    } catch (error) {
      const errorMsg = `OpenAI (primary key) failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      console.error(errorMsg);
      errors.push(errorMsg);
    }
  }

  // Try OpenAI with secondary key (if available)
  if (openai2) {
    try {
      console.log("Attempting generation with OpenAI (secondary key)");
      const response = await openai2.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        response_format: { type: "json_object" },
      });

      const content = response.choices[0].message.content;
      if (content) {
        console.log("OpenAI (secondary key) generation successful");
        return content;
      }
    } catch (error) {
      const errorMsg = `OpenAI (secondary key) failed: ${error instanceof Error ? error.message : 'Unknown error'}`;
      console.error(errorMsg);
      errors.push(errorMsg);
    }
  }

  // All providers failed
  console.error("All AI providers failed:", errors);
  return null;
}
