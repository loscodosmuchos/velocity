import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Upload, FileText, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import JourneyCanvas from "@/components/journey-canvas";
import type { AIJourneyExtraction } from "@shared/schema";

export default function WorkJourney() {
  const [resumeText, setResumeText] = useState("");
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [currentJourney, setCurrentJourney] = useState<AIJourneyExtraction | null>(null);
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/work-journey/generate", {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to generate work journey");
      }
      
      return res.json() as Promise<AIJourneyExtraction>;
    },
    onSuccess: (data) => {
      setCurrentJourney(data);
      toast({
        title: "Work Journey Generated",
        description: "Your work journey map has been generated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate work journey",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setResumeFile(file);
    }
  };

  const handleGenerateFromFile = () => {
    if (!resumeFile) {
      toast({
        title: "File Required",
        description: "Please select a resume file to upload.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("resume", resumeFile);
    generateMutation.mutate(formData);
  };

  const handleGenerateFromText = () => {
    if (!resumeText.trim()) {
      toast({
        title: "Text Required",
        description: "Please paste your resume text.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("text", resumeText);
    generateMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto p-6 max-w-7xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Work Journey Mapper
          </h1>
          <p className="text-gray-600">
            Upload your resume or paste your work history to visualize your career journey
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Upload Resume
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="file" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="file" data-testid="tab-file">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload File
                    </TabsTrigger>
                    <TabsTrigger value="text" data-testid="tab-text">
                      <FileText className="w-4 h-4 mr-2" />
                      Paste Text
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="file" className="space-y-4">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <input
                        type="file"
                        accept=".pdf,.docx,.md,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/markdown,text/plain"
                        onChange={handleFileChange}
                        className="hidden"
                        id="resume-upload"
                        data-testid="input-file"
                      />
                      <label htmlFor="resume-upload" className="cursor-pointer">
                        <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-sm text-gray-600 mb-2">
                          Click to upload or drag and drop
                        </p>
                        <p className="text-xs text-gray-500">
                          PDF, DOCX, MD, or TXT (max 10MB)
                        </p>
                      </label>
                      {resumeFile && (
                        <p className="mt-4 text-sm font-medium text-indigo-600">
                          Selected: {resumeFile.name}
                        </p>
                      )}
                    </div>

                    <Button
                      onClick={handleGenerateFromFile}
                      disabled={generateMutation.isPending || !resumeFile}
                      className="w-full"
                      size="lg"
                      data-testid="button-generate-file"
                    >
                      {generateMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing Resume...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Work Journey
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  <TabsContent value="text" className="space-y-4">
                    <Textarea
                      placeholder="Paste your resume or work history here..."
                      value={resumeText}
                      onChange={(e) => setResumeText(e.target.value)}
                      className="min-h-[300px] font-mono text-sm"
                      data-testid="input-resume-text"
                    />

                    <Button
                      onClick={handleGenerateFromText}
                      disabled={generateMutation.isPending || !resumeText.trim()}
                      className="w-full"
                      size="lg"
                      data-testid="button-generate-text"
                    >
                      {generateMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing Resume...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Work Journey
                        </>
                      )}
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-sm">What to Include</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-gray-700 space-y-2">
                <p>• Job titles and companies</p>
                <p>• Employment dates and duration</p>
                <p>• Key responsibilities and achievements</p>
                <p>• Skills developed and technologies used</p>
                <p>• Education and certifications</p>
              </CardContent>
            </Card>
          </div>

          <div>
            {currentJourney && (
              <Card>
                <CardHeader>
                  <CardTitle>{currentJourney.title}</CardTitle>
                  <p className="text-sm text-gray-600">{currentJourney.description}</p>
                </CardHeader>
                <CardContent>
                  <JourneyCanvas journey={currentJourney} />
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
