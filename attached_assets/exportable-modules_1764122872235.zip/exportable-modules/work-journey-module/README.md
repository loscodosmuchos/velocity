# Work Journey Module
## Resume-to-Career Journey Visualization System

**Version:** 1.0.0  
**License:** MIT  
**Author:** Velocity AI Platform

---

## 🎯 What This Module Does

A **production-ready** AI-powered system that transforms resumes into beautiful career journey visualizations:

- ✅ **Multi-Format Resume Parsing** - PDF, DOCX, Markdown, Plain Text
- ✅ **AI Career Stage Extraction** - Identifies roles, achievements, skills
- ✅ **Visual Timeline Generation** - Creates interactive career journey maps
- ✅ **Achievement Highlighting** - Extracts key accomplishments and metrics
- ✅ **Skills Tracking** - Maps technical and soft skill development
- ✅ **Career Insights** - AI-generated career progression analysis

---

## 🚀 Quick Start (5 Minutes)

### Installation

```bash
npm install pdf-parse-new mammoth @anthropic-ai/sdk openai multer express
```

### Environment Variables

```bash
# Required (at least one)
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
```

### Backend Integration

```typescript
import express from 'express';
import multer from 'multer';
import { registerWorkJourneyRoutes } from './work-journey-routes';

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(express.json());
registerWorkJourneyRoutes(app, upload);

app.listen(5000);
```

### Frontend Integration

```typescript
import WorkJourney from './components/WorkJourney';

function App() {
  return <WorkJourney />;
}
```

---

## 📚 API Reference

### Generate Work Journey

```typescript
POST /api/work-journey/generate
Content-Type: multipart/form-data
```

**Option 1: File Upload**
```bash
curl -X POST http://localhost:5000/api/work-journey/generate \
  -F "file=@resume.pdf"
```

**Option 2: Text Input**
```bash
curl -X POST http://localhost:5000/api/work-journey/generate \
  -H "Content-Type: application/json" \
  -d '{"text": "John Doe\nSoftware Engineer at Company X..."}'
```

**Response:**
```json
{
  "title": "John Doe - Work Journey",
  "description": "Senior Software Engineer with 10+ years experience in full-stack development",
  "stages": [
    {
      "id": "stage1",
      "name": "Software Engineer - Company X",
      "description": "Led development of microservices architecture serving 1M+ users",
      "emotion": "accomplished",
      "emotionIcon": "🎯",
      "color": "#10b981",
      "touchpoints": [
        "Led team of 5 engineers",
        "Increased system performance by 40%",
        "Migrated monolith to microservices"
      ],
      "painPoints": [
        {
          "point": "Legacy system complexity",
          "opportunity": "Modernized tech stack with React and Node.js"
        }
      ]
    }
  ],
  "insights": [
    {
      "type": "success",
      "title": "Strong Technical Leadership",
      "description": "Demonstrated ability to lead teams and drive technical initiatives"
    },
    {
      "type": "opportunity",
      "title": "Cloud Architecture Expertise",
      "description": "Consider AWS/Azure certifications to formalize cloud skills"
    }
  ]
}
```

---

## 📋 Supported File Formats

### PDF (.pdf)
- **Library:** pdf-parse-new (latest, most reliable)
- **Supported:** All standard PDF versions
- **Features:** Text extraction, layout preservation
- **Max Size:** 10MB recommended

### Microsoft Word (.docx)
- **Library:** mammoth
- **Supported:** Word 2007+
- **Features:** Formatting preservation, rich text
- **Max Size:** 5MB recommended

### Markdown (.md)
- **Direct parsing:** No additional library needed
- **Supported:** All Markdown flavors
- **Features:** Preserves structure and formatting

### Plain Text (.txt)
- **Direct parsing:** No additional library needed
- **Supported:** UTF-8, ASCII
- **Features:** Fast, simple processing

---

## 🎨 What Gets Extracted

### Career Stages
- Company/Organization name
- Job title/role
- Duration (start/end dates)
- Key responsibilities
- Major achievements
- Technologies used
- Team size (if mentioned)

### Emotions & Tone
The AI identifies the emotional tone of each career stage:
- 🎯 **Accomplished** - Major achievements, leadership roles
- 📈 **Growth** - Learning, skill development
- 💡 **Innovative** - New technologies, creative solutions
- 🏆 **Success** - Awards, recognition, promotions
- 🤝 **Collaborative** - Team work, mentorship

### Achievements & Metrics
- Quantifiable results (40% performance improvement)
- Leadership experience (led team of 5)
- Project outcomes (launched product to 1M users)
- Technical migrations (monolith to microservices)
- Cost savings/revenue generation

### Skills Progression
- Technical skills (programming languages, frameworks)
- Soft skills (leadership, communication)
- Certifications and education
- Tools and platforms

### Career Insights

**Success Factors:**
- Patterns of achievement
- Growth trajectory
- Leadership capabilities

**Opportunities:**
- Skill gaps to address
- Certification recommendations
- Career advancement paths

**Action Items:**
- Next career moves
- Skill development priorities
- Network building opportunities

**Benchmark:**
- Industry standards comparison
- Salary expectations
- Market positioning

---

## 🔧 Architecture

```
Resume Upload (PDF/DOCX/MD/TXT)
        ↓
File Parsing & Text Extraction
        ↓
AI Processing (Claude/OpenAI)
   • Career stage identification
   • Achievement extraction
   • Skills mapping
   • Insight generation
        ↓
Structured Work Journey Data
        ↓
Visual Timeline Rendering
        ↓
Shareable Career Journey
```

---

## 💡 Use Cases

1. **Job Applications** - Generate visual resume for portfolios
2. **Career Counseling** - Identify growth patterns and opportunities
3. **Hiring/Recruiting** - Quick candidate evaluation
4. **Personal Branding** - Create engaging LinkedIn content
5. **Performance Reviews** - Track career progression over time
6. **Talent Analytics** - Aggregate skills across organization

---

## 📦 Dependencies

```json
{
  "dependencies": {
    "pdf-parse-new": "^1.1.2",
    "mammoth": "^1.8.0",
    "@anthropic-ai/sdk": "^0.34.0",
    "openai": "^4.73.0",
    "multer": "^1.4.5-lts.1",
    "express": "^4.21.2",
    "zod": "^3.24.1"
  },
  "devDependencies": {
    "@types/express": "^5.0.0",
    "@types/multer": "^1.4.12",
    "@types/node": "^22.10.2",
    "typescript": "^5.7.3"
  }
}
```

---

## 🛠️ Integration Examples

### Express.js with File Upload

```typescript
import express from 'express';
import multer from 'multer';
import { registerWorkJourneyRoutes } from './work-journey-routes';

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(express.json());
registerWorkJourneyRoutes(app, upload);

app.listen(5000);
```

### Custom File Size Limits

```typescript
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
    files: 1
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/markdown'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});
```

---

## 🔐 Security & Privacy

### Best Practices

1. **File Size Limits** - Prevent DOS attacks
2. **File Type Validation** - Only accept resume formats
3. **Virus Scanning** - Integrate antivirus for uploads
4. **Data Retention** - Delete processed files after use
5. **PII Protection** - Handle sensitive data carefully
6. **API Rate Limiting** - Prevent abuse

### Privacy Considerations

- Resumes contain Personally Identifiable Information (PII)
- Store securely with encryption at rest
- Implement data deletion policies (GDPR compliance)
- Obtain user consent before processing
- Never share resume data with third parties

---

## 📊 Example Output

### Input Resume (PDF):
```
JOHN DOE
Senior Software Engineer

EXPERIENCE

Software Engineer | Tech Corp | 2020-2023
- Led development of microservices architecture serving 1M+ users
- Increased system performance by 40% through optimization
- Mentored team of 5 junior engineers

Junior Developer | StartupCo | 2018-2020
- Built full-stack web applications using React and Node.js
- Implemented CI/CD pipeline reducing deployment time by 60%
- Contributed to open-source projects

EDUCATION
B.S. Computer Science | University | 2014-2018

SKILLS
JavaScript, TypeScript, React, Node.js, Python, AWS, Docker
```

### Output Work Journey:

**Title:** John Doe - Work Journey  
**Description:** Senior Software Engineer with 5+ years experience

**Stages:**
1. **Education Phase** (2014-2018)
   - 🎓 Building foundation in computer science
   - Achievements: Graduated B.S. Computer Science

2. **Junior Developer - StartupCo** (2018-2020)
   - 📈 Rapid skill development and hands-on experience
   - Achievements:
     * Built full-stack apps with React/Node
     * Reduced deployment time 60% with CI/CD
     * Open-source contributions

3. **Software Engineer - Tech Corp** (2020-2023)
   - 🎯 Leadership and large-scale systems
   - Achievements:
     * Architected microservices for 1M+ users
     * Improved performance 40%
     * Led team of 5 engineers

**Insights:**
- ✅ **Success:** Strong technical leadership trajectory
- 💡 **Opportunity:** Consider cloud architecture certifications
- 🎯 **Action:** Target senior/staff engineer roles
- 📊 **Benchmark:** On track for $150-200K salary range

---

## 🤝 Support

- 📧 Email: support@velocity.ai
- 💬 Discord: https://discord.gg/velocity
- 📖 Docs: https://docs.velocity.ai/work-journey

---

## 📄 License

MIT License - See LICENSE file

---

**Built with ❤️ by the Velocity AI Platform team**
