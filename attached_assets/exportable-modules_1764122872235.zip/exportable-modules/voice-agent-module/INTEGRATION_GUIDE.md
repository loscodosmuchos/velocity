# Voice Agent Module - Integration Guide

## Step-by-Step Integration

### Step 1: Install Dependencies

```bash
npm install twilio express
# or
yarn add twilio express
```

### Step 2: Copy Files to Your Project

```
your-project/
├── server/
│   └── voice-agent-routes.ts      ← Copy this
├── client/
│   └── components/
│       └── VoiceAgentTest.tsx     ← Copy this (if using frontend)
└── .env                            ← Add Twilio credentials
```

### Step 3: Set Up Environment Variables

Create or update `.env`:

```bash
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE_NUMBER=+1...
REPLIT_DOMAINS=your-domain.replit.app
```

### Step 4: Register Routes (Backend)

**Express.js:**

```typescript
import express from 'express';
import { registerVoiceAgentRoutes } from './server/voice-agent-routes';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Register voice agent routes
registerVoiceAgentRoutes(app);

app.listen(5000);
```

**Fastify:**

```typescript
import Fastify from 'fastify';
import { registerVoiceAgentRoutes } from './server/voice-agent-routes';

const fastify = Fastify();

// Convert to Express-compatible middleware
import fastifyExpress from '@fastify/express';
await fastify.register(fastifyExpress);

registerVoiceAgentRoutes(fastify as any);

await fastify.listen({ port: 5000 });
```

**NestJS:**

```typescript
// app.module.ts
import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { registerVoiceAgentRoutes } from './voice-agent-routes';

@Module({})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    const express = require('express');
    const app = express();
    registerVoiceAgentRoutes(app);
    consumer.apply(app).forRoutes('*');
  }
}
```

### Step 5: Add Frontend Component (Optional)

**React:**

```typescript
import VoiceAgentTest from './components/VoiceAgentTest';

function App() {
  return (
    <div>
      <VoiceAgentTest />
    </div>
  );
}
```

**Vue:**

```vue
<template>
  <voice-agent-test />
</template>

<script>
import VoiceAgentTest from './components/VoiceAgentTest.vue';

export default {
  components: { VoiceAgentTest }
};
</script>
```

### Step 6: Configure Twilio Webhooks

1. Go to [Twilio Console](https://console.twilio.com/)
2. Navigate to Phone Numbers → Active Numbers
3. Click your phone number
4. Scroll to "Messaging" section:
   - **Webhook URL:** `https://your-domain.com/api/voice/sms-trigger`
   - **HTTP Method:** POST
5. Click "Save"

### Step 7: Test Integration

**Test Connection:**

```bash
curl https://your-domain.com/api/voice/test
```

**Test Call:**

```bash
curl -X POST https://your-domain.com/api/voice/test-call \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+15551234567", "message": "Test"}'
```

**Test SMS Trigger:**

Send SMS to your Twilio number:
```
create project intake
```

---

## Framework-Specific Examples

### Next.js (App Router)

```typescript
// app/api/voice/[...path]/route.ts
import { registerVoiceAgentRoutes } from '@/lib/voice-agent-routes';
import express from 'express';

const app = express();
registerVoiceAgentRoutes(app);

export async function GET(request: Request) {
  // Handle Next.js request → Express
  const url = new URL(request.url);
  const path = url.pathname.replace('/api', '');
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'GET', headers: request.headers } as any,
      {
        json: (data) => resolve(Response.json(data)),
        status: (code) => ({ json: (data) => resolve(Response.json(data, { status: code })) })
      } as any,
      () => {}
    );
  });
}

export async function POST(request: Request) {
  const body = await request.json();
  const url = new URL(request.url);
  const path = url.pathname.replace('/api', '');
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'POST', body, headers: request.headers } as any,
      {
        json: (data) => resolve(Response.json(data)),
        status: (code) => ({ json: (data) => resolve(Response.json(data, { status: code })) })
      } as any,
      () => {}
    );
  });
}
```

### Remix

```typescript
// app/routes/api.voice.$.ts
import { json } from '@remix-run/node';
import { registerVoiceAgentRoutes } from '~/lib/voice-agent-routes';
import express from 'express';

const app = express();
registerVoiceAgentRoutes(app);

export async function loader({ request, params }) {
  const url = new URL(request.url);
  const path = `/api/voice/${params['*']}`;
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'GET', headers: request.headers } as any,
      {
        json: (data) => resolve(json(data))
      } as any,
      () => {}
    );
  });
}

export async function action({ request, params }) {
  const body = await request.json();
  const url = new URL(request.url);
  const path = `/api/voice/${params['*']}`;
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'POST', body, headers: request.headers } as any,
      {
        json: (data) => resolve(json(data))
      } as any,
      () => {}
    );
  });
}
```

### SvelteKit

```typescript
// src/routes/api/voice/[...path]/+server.ts
import { registerVoiceAgentRoutes } from '$lib/voice-agent-routes';
import express from 'express';
import { json } from '@sveltejs/kit';

const app = express();
registerVoiceAgentRoutes(app);

export async function GET({ request, params }) {
  const path = `/api/voice/${params.path}`;
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'GET', headers: request.headers } as any,
      {
        json: (data) => resolve(json(data))
      } as any,
      () => {}
    );
  });
}

export async function POST({ request, params }) {
  const body = await request.json();
  const path = `/api/voice/${params.path}`;
  
  return new Promise((resolve) => {
    app(
      { url: path, method: 'POST', body, headers: request.headers } as any,
      {
        json: (data) => resolve(json(data))
      } as any,
      () => {}
    );
  });
}
```

---

## Database Integration (Optional)

### Save Call Logs

```typescript
import { db } from './database';

// Extend voice-agent-routes.ts
app.post("/api/voice/test-call", async (req, res) => {
  // ... existing code ...
  
  // Save to database
  await db.insert('call_logs').values({
    callSid: call.sid,
    toNumber: phoneNumber,
    fromNumber: twilioPhoneNumber,
    message: options.message,
    voice: options.voice,
    status: 'initiated',
    createdAt: new Date()
  });
  
  res.json({ success: true, callSid: call.sid });
});
```

### Track Call Status

```typescript
// Add status callback webhook
app.post("/api/voice/status-callback", async (req, res) => {
  const { CallSid, CallStatus, CallDuration } = req.body;
  
  await db.update('call_logs')
    .set({ status: CallStatus, duration: CallDuration })
    .where({ callSid: CallSid });
  
  res.send('<Response></Response>');
});

// Update call creation to include status callback
const call = await twilioClient.calls.create({
  // ... existing options ...
  statusCallback: `${baseUrl}/api/voice/status-callback`,
  statusCallbackMethod: 'POST',
  statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed']
});
```

---

## Production Checklist

- [ ] Environment variables set in production
- [ ] HTTPS enabled (Twilio requires HTTPS)
- [ ] Webhook signature validation enabled
- [ ] Rate limiting configured
- [ ] Call duration limits set
- [ ] Cost monitoring alerts set up
- [ ] Error logging configured (Sentry, Datadog)
- [ ] Phone number verified (if using trial account)
- [ ] Geographic permissions configured
- [ ] Compliance requirements met (TCPA, GDPR)

---

## Monitoring & Observability

### Add Logging

```typescript
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'voice-agent.log' })
  ]
});

// Use in routes
logger.info('Test call initiated', {
  callSid: call.sid,
  to: phoneNumber,
  from: twilioPhoneNumber
});
```

### Add Metrics

```typescript
import { Counter, Histogram } from 'prom-client';

const callsInitiated = new Counter({
  name: 'voice_calls_initiated_total',
  help: 'Total number of voice calls initiated'
});

const callDuration = new Histogram({
  name: 'voice_call_duration_seconds',
  help: 'Voice call duration in seconds',
  buckets: [5, 10, 30, 60, 120, 300]
});

// Increment metrics
callsInitiated.inc();
callDuration.observe(duration);
```

---

## Support

For integration help:
- 📧 Email: support@velocity.ai
- 💬 Discord: https://discord.gg/velocity
- 📖 Docs: https://docs.velocity.ai/voice-agent-module
