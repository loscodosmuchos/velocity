import type { Express } from "express";
import twilio from "twilio";

// Initialize Twilio client with validation
const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID;
const twilioAuthToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

if (!twilioAccountSid || !twilioAuthToken || !twilioPhoneNumber) {
  console.error("❌ Missing Twilio credentials. Voice agent features disabled.");
  console.error(`  TWILIO_ACCOUNT_SID: ${twilioAccountSid ? '✓' : '✗'}`);
  console.error(`  TWILIO_AUTH_TOKEN: ${twilioAuthToken ? '✓' : '✗'}`);
  console.error(`  TWILIO_PHONE_NUMBER: ${twilioPhoneNumber ? '✓' : '✗'}`);
}

// Validate Account SID format
const isValidAccountSid = twilioAccountSid?.startsWith('AC');

if (twilioAccountSid && !isValidAccountSid) {
  console.error("❌ TWILIO_ACCOUNT_SID must start with 'AC' (Account SID), not 'SK' (API Key)");
  console.error(`   Current value starts with: ${twilioAccountSid.substring(0, 2)}`);
  console.error(`   ℹ️  Find your Account SID at: https://console.twilio.com/`);
}

const twilioClient = (isValidAccountSid && twilioAuthToken) 
  ? twilio(twilioAccountSid!, twilioAuthToken)
  : null;

export function registerVoiceAgentRoutes(app: Express) {
  // Test endpoint - verify Twilio connection
  app.get("/api/voice/test", async (req, res) => {
    if (!twilioClient || !twilioAccountSid) {
      return res.status(500).json({
        success: false,
        message: "Twilio not configured",
        configured: {
          accountSid: !!twilioAccountSid,
          authToken: !!twilioAuthToken,
          phoneNumber: !!twilioPhoneNumber
        }
      });
    }

    try {
      // Test Twilio connection by fetching account info
      const account = await twilioClient.api.accounts(twilioAccountSid).fetch();
      
      res.json({
        success: true,
        message: "Twilio connected successfully",
        accountSid: account.sid,
        phoneNumber: twilioPhoneNumber
      });
    } catch (error) {
      console.error("Twilio connection test failed:", error);
      res.status(500).json({
        success: false,
        message: "Twilio connection failed - check that Account SID and Auth Token match",
        error: error instanceof Error ? error.message : "Unknown error",
        hint: "Verify both credentials are from the same Twilio account at https://console.twilio.com/"
      });
    }
  });

  // Test call endpoint - initiate a test call to verify integration
  app.post("/api/voice/test-call", async (req, res) => {
    if (!twilioClient || !twilioPhoneNumber) {
      res.status(500).json({ error: "Twilio not configured" });
      return;
    }

    const { 
      phoneNumber, 
      message = "Hello! This is a test call from the Velocity Voice Agent system.",
      voice = "alice",
      language = "en-US",
      speedRate = 1.0,
      pauseLength = 1,
      recordCall = false,
      machineDetection = false,
      timeout = 60,
      answerOnBridge = false,
      voiceEffect = "none"
    } = req.body;

    if (!phoneNumber) {
      res.status(400).json({ error: "Phone number is required" });
      return;
    }

    try {
      // Build TwiML with custom options
      let twiml = '<Response>';
      
      // Add pause if needed
      if (pauseLength > 0) {
        twiml += `<Pause length="${pauseLength}"/>`;
      }

      // Build Say tag with voice options
      const sayAttributes = [
        `voice="${voice}"`,
        `language="${language}"`,
      ];

      // Add prosody for speed control (for Polly/Google voices)
      if (voice.startsWith('Polly.') || voice.startsWith('Google.')) {
        twiml += `<Say ${sayAttributes.join(' ')}><prosody rate="${speedRate * 100}%">${message}</prosody></Say>`;
      } else {
        twiml += `<Say ${sayAttributes.join(' ')}>${message}</Say>`;
      }

      twiml += '</Response>';

      // Prepare call options
      const callOptions: any = {
        to: phoneNumber,
        from: twilioPhoneNumber,
        twiml: twiml,
        timeout: timeout,
      };

      // Add recording if enabled
      if (recordCall) {
        callOptions.record = true;
        callOptions.recordingStatusCallback = `${process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : ''}/api/voice/recording-callback`;
      }

      // Add machine detection if enabled
      if (machineDetection) {
        callOptions.machineDetection = 'DetectMessageEnd';
      }

      // Add answer on bridge if enabled
      if (answerOnBridge) {
        callOptions.answerOnBridge = true;
      }

      const call = await twilioClient.calls.create(callOptions);

      console.log(`✅ Test call initiated to ${phoneNumber}, Call SID: ${call.sid}`);
      console.log(`   Voice: ${voice}, Language: ${language}, Speed: ${speedRate}x`);
      
      res.json({
        success: true,
        message: "Test call initiated successfully",
        callSid: call.sid,
        to: phoneNumber,
        from: twilioPhoneNumber,
        options: {
          voice,
          language,
          speedRate,
          recording: recordCall,
          machineDetection
        }
      });
    } catch (error) {
      console.error("Test call failed:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to initiate call"
      });
    }
  });

  // Recording callback endpoint
  app.post("/api/voice/recording-callback", async (req, res) => {
    console.log("📹 Recording callback received:", req.body);
    res.send('<Response></Response>');
  });

  // Helper function to detect agent type from SMS
  function detectAgentType(message: string): string | null {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('project') && (lowerMessage.includes('intake') || lowerMessage.includes('assistant'))) {
      return 'project-intake';
    }
    if (lowerMessage.includes('procurement') || lowerMessage.includes('purchase')) {
      return 'procurement-assistant';
    }
    if (lowerMessage.includes('hr') || lowerMessage.includes('human resource')) {
      return 'hr-support';
    }
    
    return null;
  }

  // Helper function to create agent and trigger callback
  async function createAgentAndCallback(agentType: string, phoneNumber: string) {
    if (!twilioClient || !twilioPhoneNumber) {
      throw new Error('Twilio not configured');
    }

    console.log(`🤖 Creating ${agentType} agent for ${phoneNumber}...`);

    // For now, simulate agent creation (will implement ElevenLabs later)
    // This creates a Twilio-only test call
    const agentName = agentType === 'project-intake' ? 'VINessa' :
                     agentType === 'procurement-assistant' ? 'Procurement Assistant' :
                     'HR Support';

    // Wait a few seconds to simulate agent creation
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Make callback with test script
    const baseUrl = process.env.REPLIT_DEV_DOMAIN 
      ? `https://${process.env.REPLIT_DEV_DOMAIN}` 
      : 'http://localhost:5000';

    const call = await twilioClient.calls.create({
      to: phoneNumber,
      from: twilioPhoneNumber,
      url: `${baseUrl}/api/voice/agent-callback?type=${agentType}`
    });

    console.log(`✅ Agent created and calling back: ${call.sid}`);
  }

  // SMS webhook - receives text messages
  app.post("/api/voice/sms-trigger", async (req, res) => {
    if (!twilioClient || !twilioPhoneNumber) {
      return res.status(500).send('Twilio not configured');
    }

    const { From: phoneNumber, Body: message } = req.body;
    
    console.log(`📱 SMS received from ${phoneNumber}: "${message}"`);
    
    try {
      // Parse message to detect agent creation request
      const agentType = detectAgentType(message);
      
      if (agentType) {
        // Send immediate confirmation
        await twilioClient.messages.create({
          to: phoneNumber,
          from: twilioPhoneNumber,
          body: `🤖 Creating your ${agentType.replace('-', ' ')} agent now! You'll get a call in ~30 seconds to test it out.`
        });

        // Trigger agent creation and callback asynchronously
        createAgentAndCallback(agentType, phoneNumber).catch(error => {
          console.error('Agent creation failed:', error);
          twilioClient!.messages.create({
            to: phoneNumber,
            from: twilioPhoneNumber!,
            body: `❌ Sorry, agent creation failed: ${error.message}. Please try again.`
          });
        });

        res.status(200).send('OK');
      } else {
        // No agent detected - show help message
        await twilioClient.messages.create({
          to: phoneNumber,
          from: twilioPhoneNumber,
          body: `👋 Welcome to Velocity Voice Agents! Text one of these to create an agent:

📋 "project intake" - VINessa assistant
🛒 "procurement" - Purchase helper  
👥 "HR support" - HR assistant

Example: "create project intake bot"`
        });

        res.status(200).send('OK');
      }
    } catch (error) {
      console.error("SMS processing error:", error);
      res.status(500).json({ error: "Failed to process SMS" });
    }
  });

  // Test voice call endpoint
  app.post("/api/voice/test-call", async (req, res) => {
    if (!twilioClient) {
      return res.status(500).json({ error: "Twilio not configured" });
    }

    const { phoneNumber } = req.body;
    
    if (!phoneNumber) {
      return res.status(400).json({ error: "phoneNumber required" });
    }

    try {
      const baseUrl = process.env.REPLIT_DEV_DOMAIN 
        ? `https://${process.env.REPLIT_DEV_DOMAIN}` 
        : 'http://localhost:5000';

      const call = await twilioClient.calls.create({
        to: phoneNumber,
        from: twilioPhoneNumber!,
        url: `${baseUrl}/api/voice/test-twiml`
      });

      res.json({
        success: true,
        message: "Test call initiated",
        callSid: call.sid
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // TwiML for test call
  app.post("/api/voice/test-twiml", (req, res) => {
    const twiml = new twilio.twiml.VoiceResponse();
    
    twiml.say({
      voice: 'Polly.Joanna'
    }, 'Hello! This is a test call from Velocity Voice Agent system. The integration is working perfectly. Goodbye!');
    
    res.type('text/xml');
    res.send(twiml.toString());
  });

  // TwiML for agent callback
  app.post("/api/voice/agent-callback", (req, res) => {
    const agentType = req.query.type as string;
    const twiml = new twilio.twiml.VoiceResponse();
    
    // Agent scripts based on type
    const scripts: Record<string, string> = {
      'project-intake': `Hello! I'm VINessa, your AI project information specialist. 
        I just got created from your text message in under 30 seconds! 
        Normally I would ask you about your project details, but for this demo, 
        I'll just confirm that the SMS-triggered agent deployment system is working perfectly. 
        You can now create any type of conversational agent just by sending a text message. 
        Pretty cool, right? Have a great day!`,
      
      'procurement-assistant': `Hi! I'm your new Procurement Assistant, auto-deployed from your SMS. 
        In a real conversation, I would help you submit purchase requests and track orders. 
        But right now, I'm just here to show you that the system works! 
        Agent created and deployed in seconds. Amazing!`,
      
      'hr-support': `Hello! I'm your HR Support Assistant, created instantly from your text. 
        I would normally help with time-off requests and benefits questions, 
        but this is just a demo call to prove the SMS-to-agent pipeline is live. 
        The future of voice AI is here!`
    };

    const script = scripts[agentType] || 'Hello! Your agent was created successfully!';
    
    twiml.say({
      voice: 'Polly.Joanna'
    }, script);
    
    res.type('text/xml');
    res.send(twiml.toString());
  });

  console.log("✅ Voice agent routes registered");
}
