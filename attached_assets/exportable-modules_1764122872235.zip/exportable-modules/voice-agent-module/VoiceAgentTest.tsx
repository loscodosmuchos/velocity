import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Phone, Check, X, Loader2, AlertCircle, Zap, Settings, Info, Play, Mic } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CallOptions {
  phoneNumber: string;
  message: string;
  voice: string;
  language: string;
  speedRate: number;
  pauseLength: number;
  recordCall: boolean;
  machineDetection: boolean;
  timeout: number;
  answerOnBridge: boolean;
  voiceEffect: string;
}

interface TwilioStatus {
  success: boolean;
  message?: string;
  accountSid?: string;
  phoneNumber?: string;
  error?: string;
  hint?: string;
}

export default function VoiceAgentTest() {
  const { toast } = useToast();
  
  const [options, setOptions] = useState<CallOptions>({
    phoneNumber: '',
    message: 'Hello! This is a test call from the Velocity Voice Agent system. The integration is working perfectly.',
    voice: 'alice',
    language: 'en-US',
    speedRate: 1.0,
    pauseLength: 1,
    recordCall: false,
    machineDetection: false,
    timeout: 60,
    answerOnBridge: false,
    voiceEffect: 'none'
  });

  // Test Twilio connection
  const { data: twilioStatus, isLoading: statusLoading } = useQuery<TwilioStatus>({
    queryKey: ['/api/voice/test'],
  });

  // Test call mutation
  const testCallMutation = useMutation({
    mutationFn: async (callOptions: CallOptions) => {
      const res = await apiRequest('POST', '/api/voice/test-call', callOptions);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test Call Initiated!",
        description: `Calling ${options.phoneNumber}... You should receive a call shortly.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Call Failed",
        description: error instanceof Error ? error.message : "Failed to initiate call",
        variant: "destructive",
      });
    }
  });

  const handleTestCall = () => {
    if (!options.phoneNumber) {
      toast({
        title: "Phone Number Required",
        description: "Please enter a phone number to test",
        variant: "destructive",
      });
      return;
    }
    testCallMutation.mutate(options);
  };

  const presetMessages = [
    "Hello! This is a test call from the Velocity Voice Agent system.",
    "Good morning! I'm calling to confirm your appointment scheduled for today at 2 PM.",
    "This is an automated reminder about your upcoming project deadline on Friday.",
    "Thank you for your interest! We'll be sending you more information shortly."
  ];

  const voices = [
    { value: 'alice', label: 'Alice (Female, US)', description: 'Natural, friendly American female voice' },
    { value: 'man', label: 'Man (Male, US)', description: 'Professional American male voice' },
    { value: 'woman', label: 'Woman (Female, US)', description: 'Professional American female voice' },
    { value: 'Polly.Joanna', label: 'Polly Joanna', description: 'Amazon Polly - Natural female' },
    { value: 'Polly.Matthew', label: 'Polly Matthew', description: 'Amazon Polly - Natural male' },
    { value: 'Google.en-US-Neural2-A', label: 'Google Neural (Female)', description: 'Google Cloud TTS - Neural voice' },
  ];

  const languages = [
    { value: 'en-US', label: 'English (US)' },
    { value: 'en-GB', label: 'English (UK)' },
    { value: 'es-ES', label: 'Spanish (Spain)' },
    { value: 'es-MX', label: 'Spanish (Mexico)' },
    { value: 'fr-FR', label: 'French' },
    { value: 'de-DE', label: 'German' },
    { value: 'it-IT', label: 'Italian' },
    { value: 'ja-JP', label: 'Japanese' },
    { value: 'zh-CN', label: 'Chinese (Mandarin)' },
  ];

  const voiceEffects = [
    { value: 'none', label: 'None', description: 'Natural voice without effects' },
    { value: 'robot', label: 'Robot', description: 'Robotic/mechanical effect' },
    { value: 'echo', label: 'Echo', description: 'Echo chamber effect' },
    { value: 'whisper', label: 'Whisper', description: 'Soft whisper effect' },
  ];

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Twilio Voice API Testing Center</h1>
          <p className="text-muted-foreground">Comprehensive testing interface for all Twilio voice capabilities</p>
        </div>

        {/* Twilio Status Card */}
        <Card className="border-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Twilio Connection Status</CardTitle>
                <CardDescription>Verify your Twilio integration is working</CardDescription>
              </div>
              {statusLoading ? (
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              ) : twilioStatus?.success ? (
                <Badge className="bg-green-500 text-white">
                  <Check className="w-4 h-4 mr-1" />
                  Connected
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <X className="w-4 h-4 mr-1" />
                  Disconnected
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {twilioStatus && twilioStatus.success && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Account SID</p>
                  <p className="font-mono text-sm">{twilioStatus.accountSid}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Phone Number</p>
                  <p className="font-mono text-sm">{twilioStatus.phoneNumber}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Call Configuration
                </CardTitle>
                <CardDescription>Configure all call parameters and options</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="basic">Basic</TabsTrigger>
                    <TabsTrigger value="voice">Voice</TabsTrigger>
                    <TabsTrigger value="advanced">Advanced</TabsTrigger>
                    <TabsTrigger value="features">Features</TabsTrigger>
                  </TabsList>

                  {/* Basic Tab */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+1 (555) 123-4567"
                        value={options.phoneNumber}
                        onChange={(e) => setOptions({ ...options, phoneNumber: e.target.value })}
                        data-testid="input-phone-number"
                      />
                      <p className="text-xs text-muted-foreground">Include country code (e.g., +1 for US)</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message to Speak</Label>
                      <Textarea
                        id="message"
                        placeholder="Enter your custom message..."
                        value={options.message}
                        onChange={(e) => setOptions({ ...options, message: e.target.value })}
                        rows={4}
                        data-testid="input-message"
                      />
                      <p className="text-xs text-muted-foreground">
                        {options.message.length} characters - Estimated {Math.ceil(options.message.length / 150)} seconds
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label>Quick Message Templates</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {presetMessages.map((msg, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            onClick={() => setOptions({ ...options, message: msg })}
                            className="text-left justify-start h-auto py-2"
                          >
                            <Play className="w-3 h-3 mr-2 flex-shrink-0" />
                            <span className="text-xs line-clamp-2">{msg}</span>
                          </Button>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  {/* Voice Tab */}
                  <TabsContent value="voice" className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="voice">Voice Selection</Label>
                      <Select value={options.voice} onValueChange={(v) => setOptions({ ...options, voice: v })}>
                        <SelectTrigger id="voice">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {voices.map(v => (
                            <SelectItem key={v.value} value={v.value}>
                              {v.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        {voices.find(v => v.value === options.voice)?.description}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="language">Language</Label>
                      <Select value={options.language} onValueChange={(v) => setOptions({ ...options, language: v })}>
                        <SelectTrigger id="language">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {languages.map(l => (
                            <SelectItem key={l.value} value={l.value}>
                              {l.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Speech Speed: {options.speedRate.toFixed(1)}x</Label>
                      <Slider
                        value={[options.speedRate]}
                        onValueChange={([v]) => setOptions({ ...options, speedRate: v })}
                        min={0.5}
                        max={2.0}
                        step={0.1}
                        className="py-4"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>0.5x (Slow)</span>
                        <span>1.0x (Normal)</span>
                        <span>2.0x (Fast)</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Pause Between Sentences: {options.pauseLength}s</Label>
                      <Slider
                        value={[options.pauseLength]}
                        onValueChange={([v]) => setOptions({ ...options, pauseLength: v })}
                        min={0}
                        max={5}
                        step={0.5}
                        className="py-4"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="effect">Voice Effect</Label>
                      <Select value={options.voiceEffect} onValueChange={(v) => setOptions({ ...options, voiceEffect: v })}>
                        <SelectTrigger id="effect">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {voiceEffects.map(e => (
                            <SelectItem key={e.value} value={e.value}>
                              {e.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        {voiceEffects.find(e => e.value === options.voiceEffect)?.description}
                      </p>
                    </div>
                  </TabsContent>

                  {/* Advanced Tab */}
                  <TabsContent value="advanced" className="space-y-4">
                    <div className="space-y-2">
                      <Label>Call Timeout: {options.timeout}s</Label>
                      <Slider
                        value={[options.timeout]}
                        onValueChange={([v]) => setOptions({ ...options, timeout: v })}
                        min={10}
                        max={600}
                        step={10}
                        className="py-4"
                      />
                      <p className="text-xs text-muted-foreground">
                        Maximum time to wait for call to be answered before hanging up
                      </p>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-0.5">
                        <Label htmlFor="answer-bridge">Answer on Bridge</Label>
                        <p className="text-xs text-muted-foreground">
                          Only start call when recipient answers (prevents voicemail billing)
                        </p>
                      </div>
                      <Switch
                        id="answer-bridge"
                        checked={options.answerOnBridge}
                        onCheckedChange={(v) => setOptions({ ...options, answerOnBridge: v })}
                      />
                    </div>

                    <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <Info className="w-5 h-5 text-blue-500 mt-0.5" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">TwiML Customization</p>
                          <p className="text-xs text-muted-foreground">
                            Advanced users can modify TwiML XML in the backend to add features like:
                            call forwarding, conference calls, IVR menus, DTMF input, and more
                          </p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Features Tab */}
                  <TabsContent value="features" className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-0.5">
                        <Label htmlFor="record">Record Call</Label>
                        <p className="text-xs text-muted-foreground">
                          Save audio recording of the entire call
                        </p>
                      </div>
                      <Switch
                        id="record"
                        checked={options.recordCall}
                        onCheckedChange={(v) => setOptions({ ...options, recordCall: v })}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-0.5">
                        <Label htmlFor="machine">Machine Detection</Label>
                        <p className="text-xs text-muted-foreground">
                          Detect if call is answered by voicemail/machine
                        </p>
                      </div>
                      <Switch
                        id="machine"
                        checked={options.machineDetection}
                        onCheckedChange={(v) => setOptions({ ...options, machineDetection: v })}
                      />
                    </div>

                    <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Additional Twilio Features</p>
                          <ul className="text-xs text-muted-foreground space-y-1 ml-4 list-disc">
                            <li>Status callbacks - Track call progress in real-time</li>
                            <li>Recording callbacks - Get notified when recordings are ready</li>
                            <li>Transcription - Convert call audio to text</li>
                            <li>Call screening - Play message before connecting</li>
                            <li>Call whisper - Private message before call connects</li>
                            <li>Geographic permissions - Restrict calling regions</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions Sidebar */}
          <div className="space-y-6">
            <Card className="border-2 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Quick Test
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={handleTestCall}
                  disabled={!twilioStatus?.success || testCallMutation.isPending}
                  className="w-full h-14 text-lg"
                  size="lg"
                  data-testid="button-test-call"
                >
                  {testCallMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Calling...
                    </>
                  ) : (
                    <>
                      <Phone className="w-5 h-5 mr-2" />
                      Make Test Call
                    </>
                  )}
                </Button>

                {testCallMutation.isSuccess && (
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-medium text-green-700 dark:text-green-300 text-sm">Call Initiated!</p>
                        <p className="text-xs text-muted-foreground font-mono">
                          {testCallMutation.data?.callSid}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Demo Scenarios</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => setOptions({
                    ...options,
                    message: "This is a slow, calm voice test with extended pauses between sentences.",
                    voice: 'alice',
                    speedRate: 0.8,
                    pauseLength: 2
                  })}
                >
                  <Mic className="w-4 h-4 mr-2" />
                  Slow & Calm
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => setOptions({
                    ...options,
                    message: "This is a fast urgent message for time sensitive notifications!",
                    voice: 'man',
                    speedRate: 1.5,
                    pauseLength: 0.5
                  })}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Fast & Urgent
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => setOptions({
                    ...options,
                    message: "Professional business call with natural pacing and clear enunciation.",
                    voice: 'Polly.Joanna',
                    speedRate: 1.0,
                    pauseLength: 1,
                    recordCall: true
                  })}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Professional
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Call Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Estimated Duration</span>
                    <span className="font-medium">{Math.ceil(options.message.length / 150 / options.speedRate)}s</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Character Count</span>
                    <span className="font-medium">{options.message.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Approx. Cost</span>
                    <span className="font-medium">$0.013/min</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-500/20 bg-green-500/5">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className="w-4 h-4 text-green-500" />
                  SMS Agent Deploy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-background rounded-lg p-3 border">
                  <p className="font-medium text-sm mb-2">🚀 Try it now:</p>
                  <ol className="space-y-1.5 text-xs list-decimal ml-4">
                    <li>Text <span className="font-mono bg-muted px-1 rounded">{twilioStatus?.phoneNumber}</span></li>
                    <li>Say "project intake"</li>
                    <li>Get instant callback!</li>
                  </ol>
                </div>
                
                <div className="space-y-1.5">
                  <p className="text-xs font-medium">Available:</p>
                  <div className="flex flex-wrap gap-1.5">
                    <Badge variant="secondary" className="text-xs">project intake</Badge>
                    <Badge variant="secondary" className="text-xs">procurement</Badge>
                    <Badge variant="secondary" className="text-xs">HR support</Badge>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground">
                  Agents deploy in ~30 seconds. Check server logs for real-time updates.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
