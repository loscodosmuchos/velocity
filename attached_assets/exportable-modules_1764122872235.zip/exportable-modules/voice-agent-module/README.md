# Voice Agent Module
## Complete Twilio Voice Integration with SMS-Triggered Agent Deployment

**Version:** 1.0.0  
**License:** MIT  
**Author:** Velocity AI Platform

---

## 🎯 What is This Module?

A **production-ready**, **drop-in** voice agent system that provides:

- ✅ **Twilio Voice API Integration** - Make and receive phone calls programmatically
- ✅ **SMS-Triggered Agent Deployment** - Send a text message → Get an AI agent calling you back in 30 seconds
- ✅ **Comprehensive Testing Interface** - UI for testing all Twilio voice features
- ✅ **Webhook Management** - Handle call status, recordings, and agent callbacks
- ✅ **Multi-Voice Support** - Amazon Polly, Google Cloud TTS, and Twilio voices
- ✅ **Advanced Features** - Call recording, machine detection, answer on bridge, custom TwiML

---

## 🚀 Quick Start (5 Minutes)

### Prerequisites

- Node.js 18+ or 20+
- Twilio account ([sign up free](https://www.twilio.com/try-twilio))
- npm or yarn

### Installation

```bash
# Install dependencies
npm install express twilio

# Copy environment template
cp .env.example .env

# Add your Twilio credentials to .env
```

### Environment Variables

```bash
# Required
TWILIO_ACCOUNT_SID=AC...    # From https://console.twilio.com/
TWILIO_AUTH_TOKEN=...       # From https://console.twilio.com/
TWILIO_PHONE_NUMBER=+1...   # Your Twilio phone number

# Optional (for webhook callbacks)
REPLIT_DOMAINS=your-domain.replit.app  # Or your deployment URL
```

### Integration (Backend)

```typescript
import express from 'express';
import { registerVoiceAgentRoutes } from './voice-agent-routes';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Register voice agent routes
registerVoiceAgentRoutes(app);

app.listen(5000, () => {
  console.log('Server running with Voice Agent module');
});
```

### Integration (Frontend)

```typescript
import VoiceAgentTest from './components/VoiceAgentTest';

function App() {
  return <VoiceAgentTest />;
}
```

**That's it!** You now have a fully functional voice agent system.

---

## 📚 Core Features

### 1. Connection Testing

```typescript
GET /api/voice/test

Response:
{
  "success": true,
  "message": "Twilio connected successfully",
  "accountSid": "AC...",
  "phoneNumber": "+1..."
}
```

### 2. Test Call (Full Customization)

```typescript
POST /api/voice/test-call

Request Body:
{
  "phoneNumber": "+15551234567",
  "message": "Hello! This is a test call.",
  "voice": "alice",                   // alice, man, woman, Polly.Joanna, etc.
  "language": "en-US",                // en-US, es-ES, fr-FR, etc.
  "speedRate": 1.0,                   // 0.5 - 2.0 (speech speed)
  "pauseLength": 1,                   // Seconds between sentences
  "recordCall": false,                // Record the call audio
  "machineDetection": false,          // Detect voicemail
  "timeout": 60,                      // Seconds before hangup
  "answerOnBridge": false,            // Only bill when human answers
  "voiceEffect": "none"               // none, robot, echo, whisper
}

Response:
{
  "success": true,
  "message": "Test call initiated successfully",
  "callSid": "CA...",
  "to": "+15551234567",
  "from": "+18001234567"
}
```

### 3. SMS-Triggered Agent Deployment

**How it Works:**

1. User sends SMS to your Twilio number: `"create project intake"`
2. System creates custom voice agent
3. Agent calls user back in ~30 seconds
4. Fully conversational AI bot ready to use

**Configure SMS Webhook:**

In Twilio Console → Phone Numbers → Configure:
```
SMS Webhook URL: https://your-domain.com/api/voice/sms-trigger
HTTP Method: POST
```

**Supported Agent Types:**

- `"project intake"` → VINessa (project information specialist)
- `"procurement"` → Procurement Assistant
- `"HR support"` → HR Support Assistant

**Example SMS:**
```
User: "create project intake bot"

System: 🤖 Creating your project intake agent now! You'll get a call in ~30 seconds to test it out.

[30 seconds later, phone rings]

Agent: "Hello! I'm VINessa, your AI project information specialist..."
```

### 4. Recording Callback

```typescript
POST /api/voice/recording-callback

Twilio sends recording data when ready:
{
  "RecordingSid": "RE...",
  "RecordingUrl": "https://api.twilio.com/...",
  "RecordingDuration": "15"
}
```

### 5. Custom TwiML

```typescript
POST /api/voice/test-twiml

Returns TwiML XML for call handling:
<Response>
  <Say voice="Polly.Joanna">
    Hello! This is a test call...
  </Say>
</Response>
```

---

## 🎨 UI Component Features

The `VoiceAgentTest.tsx` component provides a comprehensive testing interface:

### Basic Tab
- Phone number input (E.164 format validation)
- Message composer with character counter
- Quick message templates (4 presets)
- Estimated call duration

### Voice Tab
- 6+ voice options (Alice, Polly, Google TTS)
- 9 language options
- Speech speed slider (0.5x - 2.0x)
- Pause length slider (0-5 seconds)
- Voice effect selector (robot, echo, whisper)

### Advanced Tab
- Call timeout configuration
- Answer on bridge toggle
- TwiML customization guide

### Features Tab
- Call recording toggle
- Machine detection toggle
- Additional Twilio features list

### Quick Actions
- One-click test call button
- Real-time call status
- Demo scenarios (Slow & Calm, Fast & Urgent, Professional)
- Call metrics display

---

## 🔧 Architecture

```
┌──────────────────────────────────────────────┐
│         Frontend (React Component)           │
│  ┌────────────────────────────────────────┐  │
│  │     VoiceAgentTest.tsx                 │  │
│  │  • Connection status display           │  │
│  │  • Call configuration UI               │  │
│  │  • Test call trigger                   │  │
│  └────────────────────────────────────────┘  │
└──────────────────┬───────────────────────────┘
                   │ HTTP/HTTPS
                   ▼
┌──────────────────────────────────────────────┐
│         Backend (Express Routes)             │
│  ┌────────────────────────────────────────┐  │
│  │   voice-agent-routes.ts                │  │
│  │  • GET  /api/voice/test                │  │
│  │  • POST /api/voice/test-call           │  │
│  │  • POST /api/voice/sms-trigger         │  │
│  │  • POST /api/voice/recording-callback  │  │
│  │  • POST /api/voice/test-twiml          │  │
│  │  • POST /api/voice/agent-callback      │  │
│  └────────────────────────────────────────┘  │
└──────────────────┬───────────────────────────┘
                   │ Twilio SDK
                   ▼
┌──────────────────────────────────────────────┐
│           Twilio Cloud Platform              │
│  • Voice API (outbound calls)                │
│  • SMS API (receive messages)                │
│  • TwiML execution (call handling)           │
│  • Recording storage                         │
│  • Machine detection                         │
└──────────────────────────────────────────────┘
                   │ Webhooks
                   ▼
┌──────────────────────────────────────────────┐
│      External Services (Optional)            │
│  • ElevenLabs Conversational AI              │
│  • OpenAI Whisper (transcription)            │
│  • Database (call logs)                      │
└──────────────────────────────────────────────┘
```

---

## 🔐 Security & Best Practices

### Webhook Signature Validation

```typescript
import twilio from 'twilio';

const validateTwilioSignature = (req, res, next) => {
  const signature = req.headers['x-twilio-signature'];
  const url = `https://your-domain.com${req.originalUrl}`;
  const params = req.body;
  
  const isValid = twilio.validateRequest(
    process.env.TWILIO_AUTH_TOKEN,
    signature,
    url,
    params
  );
  
  if (!isValid) {
    return res.status(403).json({ error: 'Invalid signature' });
  }
  next();
};

// Apply to all webhook endpoints
app.post('/api/voice/sms-trigger', validateTwilioSignature, handler);
```

### Environment Variable Protection

- ✅ Never commit `.env` file to version control
- ✅ Use environment variable services (Replit Secrets, AWS Secrets Manager)
- ✅ Rotate credentials every 90 days
- ✅ Use separate credentials for dev/staging/production

### Rate Limiting

```typescript
import rateLimit from 'express-rate-limit';

const callLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many call requests, please try again later'
});

app.post('/api/voice/test-call', callLimiter, handler);
```

### HTTPS Only

```typescript
if (process.env.NODE_ENV === 'production') {
  app.use((req, res, next) => {
    if (req.header('x-forwarded-proto') !== 'https') {
      res.redirect(`https://${req.header('host')}${req.url}`);
    } else {
      next();
    }
  });
}
```

---

## 📊 Voice Options Reference

### Standard Voices (Free)

| Voice | Gender | Language | Description |
|-------|--------|----------|-------------|
| `alice` | Female | en-US | Natural, friendly American |
| `man` | Male | en-US | Professional American |
| `woman` | Female | en-US | Professional American |

### Amazon Polly Voices

| Voice | Gender | Language | Quality |
|-------|--------|----------|---------|
| `Polly.Joanna` | Female | en-US | Neural TTS |
| `Polly.Matthew` | Male | en-US | Neural TTS |
| `Polly.Ivy` | Female (child) | en-US | Neural TTS |
| `Polly.Salli` | Female | en-US | Neural TTS |
| `Polly.Joey` | Male | en-US | Neural TTS |

### Google Cloud TTS Voices

| Voice | Gender | Language | Quality |
|-------|--------|----------|---------|
| `Google.en-US-Neural2-A` | Female | en-US | WaveNet |
| `Google.en-US-Neural2-C` | Female | en-US | WaveNet |
| `Google.en-US-Neural2-D` | Male | en-US | WaveNet |
| `Google.en-US-Neural2-F` | Female | en-US | WaveNet |

### Language Support

- **English:** en-US, en-GB, en-AU, en-IN
- **Spanish:** es-ES, es-MX
- **French:** fr-FR, fr-CA
- **German:** de-DE
- **Italian:** it-IT
- **Portuguese:** pt-BR, pt-PT
- **Japanese:** ja-JP
- **Chinese:** zh-CN, zh-TW
- **And 40+ more...**

---

## 🧪 Testing Guide

### 1. Connection Test

```bash
curl https://your-domain.com/api/voice/test
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Twilio connected successfully",
  "accountSid": "AC...",
  "phoneNumber": "+1..."
}
```

### 2. Test Call

```bash
curl -X POST https://your-domain.com/api/voice/test-call \
  -H "Content-Type: application/json" \
  -d '{
    "phoneNumber": "+15551234567",
    "message": "This is a test",
    "voice": "alice"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Test call initiated successfully",
  "callSid": "CA..."
}
```

### 3. SMS Trigger Test

Send SMS to your Twilio number:
```
create project intake
```

**Expected:**
- Immediate SMS reply confirming agent creation
- Phone call within 30 seconds
- Voice message from agent

---

## 🐛 Troubleshooting

### Issue: "Twilio not configured"

**Solution:**
1. Check `.env` file has all three variables
2. Verify `TWILIO_ACCOUNT_SID` starts with `AC` (not `SK`)
3. Restart server after updating `.env`

### Issue: "Call fails immediately"

**Solution:**
1. Verify phone number is in E.164 format (+1555123456)
2. Check Twilio balance (free trial has limits)
3. Verify phone number is verified (free trial requirement)

### Issue: "Webhook not receiving data"

**Solution:**
1. Ensure public URL is HTTPS (Twilio requires HTTPS)
2. Verify webhook URL in Twilio console matches your endpoint
3. Check firewall/security group allows Twilio IPs

### Issue: "Recording callback not working"

**Solution:**
1. Verify `REPLIT_DOMAINS` environment variable is set
2. Check recording is enabled in call options
3. Twilio sends callback AFTER call ends

---

## 📖 API Reference

### Test Connection

```typescript
GET /api/voice/test
```

**Response:**
```json
{
  "success": boolean,
  "message": string,
  "accountSid"?: string,
  "phoneNumber"?: string,
  "configured"?: {
    "accountSid": boolean,
    "authToken": boolean,
    "phoneNumber": boolean
  },
  "error"?: string,
  "hint"?: string
}
```

### Initiate Test Call

```typescript
POST /api/voice/test-call
```

**Request Body:**
```typescript
{
  phoneNumber: string;        // Required, E.164 format
  message?: string;           // Default: preset message
  voice?: string;             // Default: "alice"
  language?: string;          // Default: "en-US"
  speedRate?: number;         // Default: 1.0 (0.5-2.0)
  pauseLength?: number;       // Default: 1 (0-5)
  recordCall?: boolean;       // Default: false
  machineDetection?: boolean; // Default: false
  timeout?: number;           // Default: 60 (10-600)
  answerOnBridge?: boolean;   // Default: false
  voiceEffect?: string;       // Default: "none"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Test call initiated successfully",
  "callSid": "CA...",
  "to": "+15551234567",
  "from": "+18001234567",
  "options": {
    "voice": "alice",
    "language": "en-US",
    "speedRate": 1.0,
    "recording": false,
    "machineDetection": false
  }
}
```

### SMS Webhook (Twilio → Your Server)

```typescript
POST /api/voice/sms-trigger
```

**Request Body (from Twilio):**
```typescript
{
  From: string;    // Sender phone number
  To: string;      // Your Twilio number
  Body: string;    // SMS message text
  MessageSid: string;
}
```

**Response:**
```
200 OK
```

### Recording Callback (Twilio → Your Server)

```typescript
POST /api/voice/recording-callback
```

**Request Body (from Twilio):**
```typescript
{
  RecordingSid: string;
  RecordingUrl: string;
  RecordingDuration: string;
  CallSid: string;
}
```

**Response:**
```xml
<Response></Response>
```

---

## 🚀 Advanced Use Cases

### 1. ElevenLabs Integration

```typescript
import { ElevenLabsClient } from 'elevenlabs';

const elevenlabs = new ElevenLabsClient({
  apiKey: process.env.ELEVENLABS_API_KEY
});

async function createConversationalAgent(agentType: string) {
  const agent = await elevenlabs.conversationalAI.createAgent({
    name: `${agentType}-agent`,
    systemPrompt: "You are a helpful AI assistant...",
    voice: "Bella",
    language: "en",
  });
  
  return agent.agentId;
}
```

### 2. Call Analytics

```typescript
async function getCallAnalytics(callSid: string) {
  const call = await twilioClient.calls(callSid).fetch();
  
  return {
    duration: call.duration,
    status: call.status,
    direction: call.direction,
    answeredBy: call.answeredBy,
    price: call.price,
    priceUnit: call.priceUnit
  };
}
```

### 3. Conference Calls

```typescript
const twiml = new twilio.twiml.VoiceResponse();

twiml.dial().conference({
  startConferenceOnEnter: true,
  endConferenceOnExit: true
}, 'MyConferenceRoom');
```

### 4. IVR Menu

```typescript
const twiml = new twilio.twiml.VoiceResponse();

const gather = twiml.gather({
  numDigits: 1,
  action: '/api/voice/handle-key'
});

gather.say('Press 1 for sales, 2 for support, 3 for billing');
```

---

## 💰 Pricing Considerations

### Twilio Costs (as of 2024)

- **Outbound Calls:** $0.0085/minute (US)
- **Inbound Calls:** $0.0085/minute (US)
- **SMS Outbound:** $0.0079/message (US)
- **SMS Inbound:** $0.0079/message (US)
- **Phone Number:** $1.15/month (US toll-free)
- **Recording Storage:** $0.0005/minute/month

### Cost Optimization

- Use `answerOnBridge: true` to avoid billing for unanswered calls
- Implement machine detection to skip voicemail
- Cache recordings locally, delete from Twilio after 30 days
- Use shorter messages (cost = time)
- Implement call duration limits

---

## 📦 Dependencies

```json
{
  "dependencies": {
    "twilio": "^5.3.5",
    "express": "^4.21.2"
  },
  "devDependencies": {
    "@types/express": "^5.0.0",
    "typescript": "^5.7.3"
  }
}
```

---

## 🤝 Support & Contributing

### Support Channels

- 📧 Email: support@velocity.ai
- 💬 Discord: https://discord.gg/velocity
- 📖 Documentation: https://docs.velocity.ai

### Contributing

Pull requests welcome! Please:
1. Fork repository
2. Create feature branch (`feature/amazing-feature`)
3. Commit changes
4. Push to branch
5. Open pull request

---

## 📄 License

MIT License - See LICENSE file for details

---

## 🎓 Learning Resources

- [Twilio Voice API Docs](https://www.twilio.com/docs/voice)
- [TwiML Reference](https://www.twilio.com/docs/voice/twiml)
- [Twilio Node SDK](https://www.twilio.com/docs/libraries/node)
- [Voice Best Practices](https://www.twilio.com/docs/voice/best-practices)
- [SMS Best Practices](https://www.twilio.com/docs/sms/best-practices)

---

**Built with ❤️ by the Velocity AI team**
