# Request Fulfillment Watchdog System
**Version:** 1.0  
**Date:** November 7, 2025  
**Authors:** Human + AI Collaboration  
**Status:** Active Quality Assurance Process  
**Purpose:** Systematic verification that no user requests are dropped or forgotten during development

---

## The Core Principle

> **"Nothing gets dropped. Everything gets acknowledged. Priority or back burner - but never forgotten."**

**The worst failure in AI-human collaboration:** User asks for something, AI says "yes," then forgets to do it.

**This system prevents that.**

---

## The Problem

### Communication Breakdown Pattern

**Common scenario:**
```
Turn 1: User: "Can you add feature X?"
Turn 2: AI: "Great idea! Let me also do Y and Z first..."
Turn 3: User: "Also, remember to implement feature A"
Turn 4: AI: "Working on Y now..."
Turn 5: User: "How's it going?"
Turn 6: AI: "Y is done! What's next?"

Result: Features X and A were discussed but never implemented
User frustration: "I specifically asked for X..."
```

**Why it happens:**
- Multiple requests in parallel
- Priorities shift during conversation
- Context window gets long
- AI focuses on current task, forgets earlier requests
- No systematic verification

**The gap:** No automated checkpoint asking "Did we address everything?"

---

## The Solution: Request Fulfillment Watchdog

### System Overview

**Automated checkpoint every 3-5 prompts:**
1. Pause current work
2. Review last 3-5 conversation turns
3. Extract all user requests/asks
4. Verify each one was addressed OR acknowledged
5. Categorize: Completed / In Progress / Back Burner / Dropped
6. Log the check
7. Alert user if anything was dropped
8. Resume work

**Result:** Nothing gets forgotten, user has confidence

---

## How It Works

### Trigger Mechanism

**Every 3-5 prompts (configurable):**
```typescript
let promptCounter = 0;
const WATCHDOG_INTERVAL = 4; // Check every 4 prompts

async function onUserPrompt(prompt: string) {
  promptCounter++;
  
  // Process the prompt normally
  await handleUserRequest(prompt);
  
  // Trigger watchdog check
  if (promptCounter % WATCHDOG_INTERVAL === 0) {
    await runRequestFulfillmentCheck();
  }
}
```

### Review Process

**Step 1: Extract Recent Conversation**
```typescript
async function runRequestFulfillmentCheck() {
  // Get last N prompts
  const recentTurns = await getLastNConversationTurns(5);
  
  // Parse for user requests
  const requests = extractUserRequests(recentTurns);
  
  return requests;
}

function extractUserRequests(turns: ConversationTurn[]): Request[] {
  const requests: Request[] = [];
  
  for (const turn of turns) {
    // Look for request patterns
    const patterns = [
      /can you (add|implement|create|build)/i,
      /please (add|implement|create|build)/i,
      /we should (add|implement|create|build)/i,
      /don't forget to/i,
      /make sure to/i,
      /also,? (add|implement|create)/i,
      /I would like/i,
      /let's (add|implement|create)/i,
    ];
    
    for (const pattern of patterns) {
      if (pattern.test(turn.userMessage)) {
        requests.push({
          turn: turn.number,
          timestamp: turn.timestamp,
          request: extractRequestDescription(turn.userMessage),
          userQuote: turn.userMessage,
        });
      }
    }
  }
  
  return requests;
}
```

**Step 2: Verify Status of Each Request**
```typescript
function categorizeRequests(requests: Request[]): RequestStatus {
  return {
    completed: requests.filter(r => wasCompleted(r)),
    inProgress: requests.filter(r => isInProgress(r)),
    backBurner: requests.filter(r => isAcknowledgedButDeferred(r)),
    dropped: requests.filter(r => !wasAddressed(r)),
  };
}

function wasCompleted(request: Request): boolean {
  // Check task list for completion
  // Check subsequent AI messages for "done" or "implemented"
  // Check code diffs for related changes
  return /* logic */;
}

function isInProgress(request: Request): boolean {
  // Check if in current task list as in_progress
  // Check if AI mentioned starting work on it
  return /* logic */;
}

function isAcknowledgedButDeferred(request: Request): boolean {
  // Check if AI said "I'll add that to the list"
  // Check if user said "let's do that later"
  // Check back burner list
  return /* logic */;
}

function wasAddressed(request: Request): boolean {
  return wasCompleted(request) || 
         isInProgress(request) || 
         isAcknowledgedButDeferred(request);
}
```

**Step 3: Log the Check**
```typescript
interface WatchdogCheck {
  id: number;
  timestamp: Date;
  promptRange: string;           // "Turns 45-50"
  totalRequests: number;
  completedCount: number;
  inProgressCount: number;
  backBurnerCount: number;
  droppedCount: number;
  droppedRequests: Request[];    // Details of what was missed
  actionTaken: string;           // What AI did in response
  status: 'clean' | 'found_issues';
}

async function logWatchdogCheck(check: WatchdogCheck) {
  await db.insert(watchdogChecks).values(check);
  
  // Also append to watchdog-fulfillment-log.md
  await appendToLog(`
### Check #${check.id} - ${check.timestamp}
**Reviewed:** ${check.promptRange}
**Found:** ${check.totalRequests} requests
- ✅ Completed: ${check.completedCount}
- 🔄 In Progress: ${check.inProgressCount}
- 📋 Back Burner: ${check.backBurnerCount}
- ❌ Dropped: ${check.droppedCount}

${check.droppedCount > 0 ? `
**Dropped Requests:**
${check.droppedRequests.map(r => `- "${r.userQuote}" (Turn ${r.turn})`).join('\n')}

**Action Taken:** ${check.actionTaken}
` : '**Status:** All requests addressed ✅'}
---
  `);
}
```

**Step 4: User Notification (If Issues Found)**
```typescript
async function notifyUserOfDroppedRequests(dropped: Request[]) {
  if (dropped.length === 0) {
    // Silent success - don't interrupt user
    return;
  }
  
  // Proactive communication
  const message = `
**📋 Watchdog Check-In:**

I reviewed our last few messages and noticed ${dropped.length} request(s) that I haven't addressed yet:

${dropped.map((r, i) => `
${i + 1}. **"${r.request}"** (from earlier conversation)
   You said: "${r.userQuote.substring(0, 100)}..."
`).join('\n')}

**Options:**
- Want me to tackle ${dropped.length === 1 ? 'this' : 'these'} now?
- Add to the back burner list for later?
- Already handled and I missed it? (Let me know)

What would you prefer?
  `;
  
  return message;
}
```

---

## The Two Lists System

### Priority List (Active Work)

**What it is:** Current task list being actively worked on

**Contents:**
- Tasks currently in progress
- Tasks queued up next
- High-priority items

**Visibility:**
```typescript
interface PriorityList {
  tasks: Task[];
  currentlyWorking: Task | null;
  nextUp: Task[];
  status: 'active' | 'blocked' | 'completed';
}

// Displayed in:
// 1. Active task list (write_task_list tool)
// 2. Admin dashboard (Priority tab)
// 3. User-facing status updates
```

### Back Burner List (Deferred Work)

**What it is:** Acknowledged requests that are important but not urgent

**Contents:**
- Features requested but deferred by user
- Good ideas to implement later
- Enhancement suggestions
- Non-blocking improvements

**Visibility:**
```typescript
interface BackBurnerList {
  items: BackBurnerItem[];
  acknowledgedDate: Date;
  reason: string;              // Why deferred
  priority: 'high' | 'medium' | 'low';
  estimatedEffort: string;     // "30 min", "2 hours", etc.
}

interface BackBurnerItem {
  id: number;
  request: string;
  userQuote: string;
  acknowledgedDate: Date;
  reason: string;
  retrievedDate?: Date;        // When brought back to priority list
  status: 'deferred' | 'retrieved' | 'cancelled';
}

// Stored in:
// 1. Database table
// 2. back-burner-list.md (markdown log)
// 3. Admin dashboard (Back Burner tab)
```

**Process for adding to back burner:**
```
AI: "That's a great feature idea! Since we're currently focused on 
     the batch session work, can I add this to the back burner list 
     so we don't forget it? We can revisit after the current priority 
     work is done."

User: "Yes, put it on the back burner"

AI: ✅ Added to back burner: "Admin dashboard for Post-it Notes"
    Reason: Focusing on batch sessions first
    Estimated effort: 2-3 hours
    
    I'll bring this up again when we finish the current priorities.
```

**Process for retrieving from back burner:**
```
AI: "We've completed the batch session work! 🎉
     
     Looking at the back burner list, we have:
     1. Admin dashboard for Post-it Notes (2-3 hours)
     2. Startup health check system (1-2 hours)
     3. Export to Excel feature (1 hour)
     
     Want to tackle any of these now?"
```

---

## Admin Dashboard Integration

### Watchdog Checks Log View

**Route:** `/admin/watchdog-checks`

**Interface:**
```typescript
<WatchdogDashboard>
  <MetricsSummary>
    <Metric label="Total Checks Run" value={totalChecks} />
    <Metric label="Issues Found" value={issuesCount} />
    <Metric label="Clean Checks" value={cleanCount} />
    <Metric label="Success Rate" value={`${successRate}%`} />
  </MetricsSummary>
  
  <ChecksList>
    {checks.map(check => (
      <CheckCard
        key={check.id}
        timestamp={check.timestamp}
        promptRange={check.promptRange}
        status={check.status}
        droppedCount={check.droppedCount}
        droppedRequests={check.droppedRequests}
        actionTaken={check.actionTaken}
      />
    ))}
  </ChecksList>
</WatchdogDashboard>
```

**Example log entries:**
```markdown
### Check #042 - 2025-11-07 14:32:15
**Reviewed:** Turns 162-167
**Found:** 3 requests
- ✅ Completed: 2
- 🔄 In Progress: 1
- 📋 Back Burner: 0
- ❌ Dropped: 0

**Status:** All requests addressed ✅
---

### Check #043 - 2025-11-07 14:55:22
**Reviewed:** Turns 168-173
**Found:** 4 requests
- ✅ Completed: 1
- 🔄 In Progress: 1
- 📋 Back Burner: 1
- ❌ Dropped: 1

**Dropped Requests:**
- "Add startup health check" (Turn 169)

**Action Taken:** Notified user about dropped request. User chose to add to back burner list.
---
```

### Back Burner List View

**Route:** `/admin/back-burner`

**Interface:**
```typescript
<BackBurnerDashboard>
  <MetricsSummary>
    <Metric label="Items on Back Burner" value={itemCount} />
    <Metric label="Total Est. Effort" value={`${totalHours}h`} />
    <Metric label="High Priority Items" value={highPriorityCount} />
  </MetricsSummary>
  
  <BackBurnerList>
    {items.map(item => (
      <BackBurnerCard
        key={item.id}
        request={item.request}
        userQuote={item.userQuote}
        acknowledgedDate={item.acknowledgedDate}
        reason={item.reason}
        priority={item.priority}
        estimatedEffort={item.estimatedEffort}
        onRetrieve={() => moveToActiveList(item)}
        onCancel={() => cancelItem(item)}
      />
    ))}
  </BackBurnerList>
</BackBurnerDashboard>
```

---

## Implementation Workflow

### During Active Development

**Every 3-5 prompts:**
```
1. [Automatic Trigger]
   ↓
2. Review last N conversation turns
   ↓
3. Extract user requests
   ↓
4. Check status of each:
   - ✅ Completed (marked in task list)
   - 🔄 In Progress (in current task list)
   - 📋 Back Burner (in deferred list)
   - ❌ Dropped (not addressed at all)
   ↓
5. If dropped requests found:
   → Notify user proactively
   → Offer options (do now / back burner / clarify)
   → Log the check and action taken
   ↓
6. If all clean:
   → Silent success (log only, don't interrupt)
   → Continue normal work
   ↓
7. Update admin dashboard with check results
```

### User Communication Protocol

**When issues found:**
```markdown
**Watchdog Alert Template:**

📋 **Quick check-in:**

Reviewed our last [N] messages and found [X] request(s) I haven't 
addressed yet:

1. **[Request description]**
   You mentioned: "[user quote]"
   
2. **[Request description]**
   You mentioned: "[user quote]"

**What would you like me to do?**
- [ ] Handle these now (I'll add to priority list)
- [ ] Put on back burner for later
- [ ] Already done (I missed marking it)
- [ ] Not needed anymore

Let me know!
```

**When all clean:**
```
[No interruption - silent success]
[Log entry created in admin dashboard]
[Continue working on current tasks]
```

---

## Database Schema

```typescript
// Watchdog checks log
export const watchdogChecks = pgTable('watchdog_checks', {
  id: serial('id').primaryKey(),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
  promptRange: text('prompt_range').notNull(),        // "Turns 45-50"
  totalRequests: integer('total_requests').notNull(),
  completedCount: integer('completed_count').notNull(),
  inProgressCount: integer('in_progress_count').notNull(),
  backBurnerCount: integer('back_burner_count').notNull(),
  droppedCount: integer('dropped_count').notNull(),
  droppedRequests: jsonb('dropped_requests'),         // Array of Request objects
  actionTaken: text('action_taken'),
  status: text('status').notNull(),                    // 'clean' | 'found_issues'
});

// Back burner list
export const backBurnerItems = pgTable('back_burner_items', {
  id: serial('id').primaryKey(),
  request: text('request').notNull(),
  userQuote: text('user_quote').notNull(),
  acknowledgedDate: timestamp('acknowledged_date').defaultNow().notNull(),
  reason: text('reason').notNull(),
  priority: text('priority').notNull(),                // 'high' | 'medium' | 'low'
  estimatedEffort: text('estimated_effort'),
  retrievedDate: timestamp('retrieved_date'),
  status: text('status').notNull(),                    // 'deferred' | 'retrieved' | 'cancelled'
  notes: text('notes'),
});
```

---

## Success Metrics

### Leading Indicators
- ✅ Watchdog runs every 3-5 prompts (100% compliance)
- ✅ All requests categorized within 1 minute
- ✅ User notified of dropped requests within same turn
- ✅ Back burner items logged immediately

### Lagging Indicators
- ✅ Zero requests lost over 30 days
- ✅ User confidence increases (feedback)
- ✅ Back burner items eventually completed
- ✅ Clean check rate >80%

### Warning Signs
- ⚠️ Watchdog not running (counter broken)
- ⚠️ High dropped request rate (>20%)
- ⚠️ Back burner items never retrieved
- ⚠️ User repeatedly mentions forgotten requests

---

## Example Scenarios

### Scenario 1: Clean Check (Success)

**Conversation:**
```
Turn 45: User: "Add batch indicator to header"
Turn 46: AI: "Added! Screenshot shows it working"
Turn 47: User: "Perfect, now add cancel button"
Turn 48: AI: "Implemented cancel with confirmation dialog"
Turn 49: User: "Great work!"

[Watchdog triggers at Turn 50]
```

**Watchdog analysis:**
- Request 1 (Turn 45): ✅ Completed (batch indicator added)
- Request 2 (Turn 47): ✅ Completed (cancel button added)
- Total: 2 requests, 2 completed
- Status: Clean ✅

**Action:** Silent success, log only, continue

**Log entry:**
```
Check #042 - 2025-11-07 14:32:15
Reviewed: Turns 45-50
Found: 2 requests
- ✅ Completed: 2
Status: All requests addressed ✅
```

### Scenario 2: Dropped Request (Alert)

**Conversation:**
```
Turn 60: User: "Add export to Excel feature"
Turn 61: AI: "Great idea! Let me first finish this batch work..."
Turn 62: User: "Also, can you add a search filter?"
Turn 63: AI: "Added search filter with debouncing"
Turn 64: User: "Nice!"

[Watchdog triggers at Turn 65]
```

**Watchdog analysis:**
- Request 1 (Turn 60): ❌ Dropped (Excel export not implemented)
- Request 2 (Turn 62): ✅ Completed (search filter added)
- Total: 2 requests, 1 completed, 1 dropped
- Status: Issues found ⚠️

**Action:** Notify user immediately

**AI response:**
```
📋 Quick check-in:

Reviewed our last 5 messages and found 1 request I haven't 
addressed yet:

1. **Add export to Excel feature**
   You mentioned: "Add export to Excel feature" (Turn 60)

**What would you like me to do?**
- Handle this now?
- Put on back burner for later?
- Not needed anymore?
```

**User:** "Put it on back burner, we'll do it later"

**AI:** "✅ Added to back burner: 'Export to Excel feature'
Estimated effort: 1-2 hours. I'll bring this up when we finish current work."

**Log entry:**
```
Check #043 - 2025-11-07 14:55:22
Reviewed: Turns 60-65
Found: 2 requests
- ✅ Completed: 1
- 📋 Back Burner: 1
Dropped Requests: "Excel export" (Turn 60)
Action Taken: Added to back burner per user request
```

### Scenario 3: Multiple Classifications

**Conversation:**
```
Turn 80: User: "Add these 4 features: A, B, C, D"
Turn 81: AI: "Starting with A..."
Turn 82: AI: "A is done, working on B..."
Turn 83: User: "Actually, hold off on C for now"
Turn 84: AI: "B is complete!"

[Watchdog triggers at Turn 85]
```

**Watchdog analysis:**
- Request A: ✅ Completed
- Request B: ✅ Completed  
- Request C: 📋 Back Burner (user deferred)
- Request D: 🔄 In Progress (next up)
- Total: 4 requests, 2 completed, 1 deferred, 1 in progress
- Status: Clean ✅ (all addressed)

**Action:** Silent success (all accounted for)

---

## Integration with Existing Systems

### Post-it Notes Watchdog
**Synergy:** 
- Post-it Notes captures insights
- Request Fulfillment ensures requests are honored
- Both run on same timer (every 3-5 prompts)
- Can be combined into single checkpoint

**Combined workflow:**
```
Every 3-5 prompts:
1. Run Post-it Notes watchdog (capture insights)
2. Run Request Fulfillment watchdog (verify requests)
3. Log both to admin dashboard
4. Alert user only if issues found in either
```

### Task List System
**Synergy:**
- Dropped requests → Added to task list
- Back burner items → Stored separately
- Completed tasks → Verified against requests
- In-progress tasks → Cross-referenced

### Admin Dashboard
**Synergy:**
- All watchdog checks visible in one place
- Post-it Notes effectiveness tab
- Request fulfillment success rate tab
- Back burner management interface
- Health metrics at a glance

---

## Best Practices

### DO:
- ✅ Run watchdog consistently (every 3-5 prompts)
- ✅ Be proactive (tell user about dropped requests)
- ✅ Offer options (now / later / clarify)
- ✅ Log every check (creates audit trail)
- ✅ Maintain back burner list (nothing forgotten)
- ✅ Silent success when clean (don't interrupt)

### DON'T:
- ❌ Skip watchdog checks (defeats the purpose)
- ❌ Assume requests are remembered (verify)
- ❌ Drop requests without acknowledging
- ❌ Interrupt user when everything is clean
- ❌ Let back burner become a graveyard
- ❌ Lose context on why something was deferred

---

## Conclusion

**The Request Fulfillment Watchdog ensures one critical thing:**

> **Nothing the user asks for is ever forgotten.**

**It may be:**
- ✅ Completed immediately
- 🔄 In progress now
- 📋 On the back burner for later

**But it is NEVER:**
- ❌ Dropped silently
- ❌ Lost in conversation
- ❌ Forgotten without acknowledgment

**This builds trust:**
- User knows requests are tracked
- AI proactively catches its own gaps
- Communication is transparent
- Work is systematically verified

**The outcome:**
- Zero requests lost
- User confidence high
- Priority vs back burner clearly managed
- Quality assurance built into the process

**"Nothing gets dropped. Everything gets acknowledged. Priority or back burner - but never forgotten."**

---

## Document Changelog

**v1.0** (November 7, 2025)
- Initial creation from user's request
- Defined watchdog process and triggers
- Created two-list system (priority + back burner)
- Designed admin dashboard integration
- Provided implementation examples and scenarios

---

## License & Usage

**License:** Open System - freely shareable  
**Attribution:** AssetGenius Project  
**Usage:** Apply to any AI-human collaborative development workflow
