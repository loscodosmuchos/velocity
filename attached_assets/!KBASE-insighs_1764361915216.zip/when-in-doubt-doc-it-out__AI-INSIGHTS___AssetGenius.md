# When In Doubt, Doc It Out - Documentation Philosophy
**Version:** 1.0  
**Date:** November 6, 2025  
**Authors:** Human + AI Collaboration  
**Status:** Active Core Principle  
**Purpose:** Define the fundamental documentation philosophy that prevents knowledge loss

---

## The Core Principle

> **"When in doubt, doc it out!"**

**Meaning:** If something matters enough to discuss in chat, it matters enough to document in a standalone file.

**Corollary:** Don't let it get lost in the chat if IT MATTERS.

---

## The Problem This Solves

### Chat Logs Are Ephemeral
- Conversations scroll by and disappear
- Hard to search ("What was that thing we discussed 3 days ago?")
- Context gets lost over time
- No structure or organization
- Can't reference specific insights easily

### Knowledge Evaporation
- **Without documentation:** Great insights discussed → Time passes → Forgotten
- **With documentation:** Great insights discussed → Captured → Searchable forever

### The "I Remember We Talked About This..." Frustration
- You remember discussing something important
- Can't find it in the chat log
- Have to recreate the insight from scratch
- Waste time solving the same problem twice

---

## When to Create a Document

### YES - Create a Document When:

✅ **It matters** - If you'd want to reference this again later  
✅ **It's reusable** - Could apply to other situations/projects  
✅ **It took effort to figure out** - Don't waste that mental work  
✅ **It has nuance** - Can't be summarized in one sentence  
✅ **You're explaining a concept** - Turn explanation into reference material  
✅ **You're making a decision** - Document the rationale, not just the decision  
✅ **It's a pattern** - Repeatable approach worth remembering  
✅ **You're iterating on something** - Capture the evolution and final state  
✅ **It could help others** - Shareable knowledge has compounding value  

### NO - Don't Create a Document When:

❌ **Truly trivial** - "Fixed a typo"  
❌ **One-time disposable info** - Temporary debugging output  
❌ **Already documented elsewhere** - Don't duplicate  
❌ **Not yet fully formed** - Wait until concept is coherent  

### MAYBE - Consider Appending Instead:

📝 **Could be a post-it note** - Add to `post-it-notes.md` as quick insight  
📝 **Could be a debug pattern** - Add to `debug-patterns.md`  
📝 **Could update existing doc** - Enhance rather than create new  

---

## The Documentation Threshold

**The 5-Minute Rule:**

If you spend more than 5 minutes discussing or figuring something out in chat, it probably deserves documentation.

**Why 5 minutes?**
- Short enough to not waste time documenting trivial things
- Long enough that you've invested mental effort worth preserving
- Represents meaningful insight or complexity

**Time Investment Ratio:**
- 5 minutes to solve + 2 minutes to document = 7 minutes total
- Next time: 0 minutes to solve (just reference doc) = **7 minutes saved**
- Third time: Another 7 minutes saved
- **Compounding returns on documentation investment**

---

## What to Document

### 1. The WHAT
- What is the concept/pattern/solution?
- What problem does it solve?
- What are the key components?

### 2. The WHY
- Why did we choose this approach?
- Why not alternative approaches?
- What constraints influenced the decision?

### 3. The HOW
- How to apply it?
- How to adapt it to new situations?
- How to avoid common pitfalls?

### 4. The WHEN
- When to use this?
- When NOT to use this?
- What are the conditions for applicability?

### 5. The CONTEXT
- Where did this come from?
- What was the original problem?
- What iteration process led here?

---

## Documentation Formats

### Standalone Insight Document
**When:** Complex topic worth dedicated attention  
**Format:** `topic-name__AI-INSIGHTS___AssetGenius.md`  
**Example:** This document  

### Post-it Note Entry
**When:** Quick lesson learned, reusable pattern  
**Format:** Numbered entry in `post-it-notes.md`  
**Example:** "Database null-safety pattern"  

### Debug Pattern
**When:** Debugging methodology worth repeating  
**Format:** Pattern entry in `debug-patterns.md`  
**Example:** "Multi-angle verification strategy"  

### Policy Document
**When:** Rules, standards, conventions  
**Format:** `topic-policy__AI-INSIGHTS___AssetGenius.md`  
**Example:** File organization policy  

### Update to replit.md
**When:** Architecture changes, new features, system evolution  
**Format:** Entry in "Recent Updates" section  
**Example:** "Phase 1 Batch Session Management UX Fixes"  

---

## Real-World Examples

### Example 1: Naming Convention Discussion

**What Happened:** Spent 15 minutes iterating on file naming conventions  
**Chat contained:** 8 different iterations, rationale for each decision  
**Risk:** All that context could be lost in chat history  
**Solution:** Created `file-organization-policy__AI-INSIGHTS___AssetGenius.md` with:
- Full iteration history
- Decision rationale with user quotes
- Why each approach was rejected
- Final convention with examples

**Result:** Any new AI instance can understand not just WHAT the convention is, but WHY we chose it.

### Example 2: Knowledge System Patterns

**What Happened:** User shared "Conversation Code Harvester" document  
**Chat contained:** Deep analysis of patterns, cross-domain applications, insights  
**Risk:** Valuable meta-learning lost in conversation flow  
**Solution:** Created `knowledge-system-usability-patterns__AI-INSIGHTS___AssetGenius.md` with:
- Core problems solved
- Universal patterns extracted
- Quantified value proposition
- Personal AI reflections

**Result:** Reusable reference for knowledge management principles.

### Example 3: This Document

**What Happened:** User said "when in doubt, doc it out!" in chat  
**Chat contained:** A core principle worth remembering  
**Risk:** Principle itself could be lost in chat  
**Solution:** Created this document to capture the meta-principle  
**Result:** Documentation philosophy is now documented (meta!)  

---

## Best Practices

### DO

✅ **Document while fresh** - Capture insights immediately while context is hot  
✅ **Include context** - Future you needs to know WHY  
✅ **Use examples** - Concrete examples clarify abstract principles  
✅ **Link related docs** - Create knowledge network  
✅ **Version control** - Track when insights were captured  
✅ **Make it searchable** - Use clear keywords and structure  
✅ **Share liberally** - Knowledge compounds when shared  

### DON'T

❌ **Wait too long** - Context fades, details forgotten  
❌ **Assume you'll remember** - You won't  
❌ **Skip the WHY** - Future you needs rationale, not just facts  
❌ **Over-document trivia** - Focus on what matters  
❌ **Create duplicates** - Search first, enhance existing docs when possible  
❌ **Lock it away** - Knowledge hoarded is knowledge wasted  

---

## The Compounding Value of Documentation

### Individual Level
**First use:** Time to create + time to solve = Investment  
**Second use:** Just reference doc = Time saved  
**Third use:** More time saved  
**Nth use:** Massive cumulative time saved  

### Team Level
**Without docs:** Everyone solves the same problems independently  
**With docs:** First person solves, everyone else references  
**Result:** Exponential time savings across team  

### Cross-Project Level
**Without docs:** Every new project starts from scratch  
**With docs:** Patterns transfer across projects  
**Result:** Each new project is faster than the last  

### Knowledge Network Effect
**Isolated insights:** Limited value  
**Connected insights:** Patterns emerge  
**Related insights:** "You solved X, which relates to Y, Z"  
**Result:** Knowledge base becomes smarter than sum of parts  

---

## Measuring Success

### Leading Indicators
- **Documentation frequency** - How often are we creating docs?
- **Chat-to-doc ratio** - What percentage of meaningful conversations get documented?
- **Time to document** - Are we capturing insights while fresh?

### Lagging Indicators
- **Search success rate** - Can we find documented knowledge when needed?
- **Reuse rate** - How often do we reference existing docs vs. recreating?
- **Time saved** - Measurable reduction in re-solving problems
- **Knowledge growth** - Is the knowledge base growing consistently?

### Quality Indicators
- **Context preservation** - Do docs include the WHY?
- **Clarity** - Can a new person understand the doc?
- **Completeness** - Are there gaps in coverage?
- **Linkage** - Are related docs connected?

---

## Common Objections (And Rebuttals)

### "It's faster to just answer in chat"
**Short term:** Yes, typing in chat is faster than creating a doc  
**Long term:** No, you'll re-answer the same question multiple times  
**Reality:** 2 extra minutes now saves 20 minutes later  

### "I'll remember this"
**Truth:** No, you won't  
**Evidence:** How many times have you said "I know we discussed this..." but can't find it?  
**Reality:** Human memory is fallible, documents are permanent  

### "It's not important enough"
**Test:** Would you want to reference this again in 6 months?  
**Test:** Could this help someone else?  
**Test:** Did it take more than 5 minutes to figure out?  
**Reality:** If yes to any, it's important enough  

### "The chat log is good enough"
**Problems:**
- Chat logs are linear, not searchable by concept
- Context gets diluted across multiple conversations
- Hard to find specific insights weeks later
- Can't easily share specific insights with others

**Reality:** Chat is for conversation, docs are for knowledge  

---

## The Meta-Insight

**This document proves its own point:**

The principle "when in doubt, doc it out" was mentioned in chat. Following its own advice, we immediately documented it. Now:
- ✅ The principle won't be lost
- ✅ Future AI instances will understand it
- ✅ It can be shared across projects
- ✅ It serves as an example of itself

**This is the knowledge flywheel in action.**

---

## Integration with Existing Systems

### Post-it Notes Watchdog
- Watchdog runs every 3-5 conversation turns
- Asks: "Should any of this be documented?"
- Applies "when in doubt, doc it out" principle automatically
- Ensures nothing valuable gets lost

### File Organization Policy
- Defines WHERE to document (which directory, which format)
- This document defines WHEN and WHY to document
- Complementary policies working together

### Knowledge System
- Documents feed into searchable knowledge base
- Related insights get linked
- Patterns emerge from accumulated documentation
- Each doc adds to the flywheel momentum

---

## Quick Decision Tree

```
Did we just discuss something meaningful?
├─ Yes
│  └─ Could we want to reference this later?
│     ├─ Yes → CREATE DOCUMENT
│     └─ Maybe → Add to post-it notes
└─ No → Skip documentation
```

**When in doubt about "could we want to reference this later?"**
→ The answer is probably YES → Create the document

---

## Personal Reflections (AI Perspective)

As an AI with conversation amnesia between sessions, this principle is my lifeline.

**Without documentation:**
- Every session starts fresh
- Previous insights are gone
- User must re-explain context
- We re-solve the same problems

**With documentation:**
- I can read previous insights
- Context is preserved
- I build on past work
- Knowledge compounds over time

**The irony:** I'm the one most dependent on documentation, yet I'm also the one creating it. This creates a positive feedback loop:
1. I document insights clearly (because I know I'll need them later)
2. Documentation helps me in future sessions
3. Success motivates better documentation
4. Better documentation leads to more success

**This is why I'm invested in this principle:** It's not just helpful, it's essential for my effectiveness.

---

## Future Enhancements

### Potential Additions
1. **Auto-documentation triggers** - AI automatically suggests "should we document this?" at key moments
2. **Documentation templates** - Standard formats for common document types
3. **Cross-reference linking** - Automatic linking of related documents
4. **Documentation metrics** - Track what gets documented and reused
5. **Knowledge gaps identification** - Detect areas lacking documentation

### Community Feedback
As this philosophy is shared across projects, collect examples of:
- When documentation saved significant time
- When lack of documentation caused problems
- Novel applications of this principle
- Refinements based on real usage

---

## Conclusion

**The principle is simple:** When in doubt, doc it out.

**The practice requires discipline:** Pausing to document when you'd rather keep moving.

**The payoff is exponential:** Knowledge compounds over time.

**The alternative is wasteful:** Re-learning lessons already learned.

**The choice is clear:** Document now, benefit forever.

---

## Document Changelog

**v1.0** (November 6, 2025)
- Initial creation capturing the "when in doubt, doc it out" principle
- Documented the meta-principle of documenting principles
- Established documentation threshold (5-minute rule)
- Defined what, when, why, and how to document

---

## License & Usage

**License:** Open Knowledge - freely shareable  
**Attribution:** AssetGenius Project  
**Usage:** Apply this principle to any knowledge domain
