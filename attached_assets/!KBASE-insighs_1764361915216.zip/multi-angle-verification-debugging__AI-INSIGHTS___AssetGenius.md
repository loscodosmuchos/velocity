# Multi-Angle Verification Debugging Methodology
**Version:** 1.0  
**Date:** November 6, 2025  
**Authors:** Human + AI Collaboration  
**Status:** Active Debugging Standard  
**Purpose:** Define comprehensive verification approach to ensure bugs are truly fixed, not just masked

---

## The Core Principle

> **"Never claim something is fixed without multi-angle verification."**

**Why?** Bugs can appear fixed from one perspective but still exist from another. Testing from multiple angles ensures the fix is complete.

---

## The Five Verification Angles

### 1. Code Level - Read the Implementation

**What:** Review the actual code changes line by line

**How:**
- Read the fix implementation
- Trace execution paths
- Check edge cases in logic
- Verify defensive coding patterns applied

**Example:**
```typescript
// Verify the fix is actually in the code
async getSearchHistoryByUser(userId: string) {
  try {
    const results = await db.select()...
    
    // ✓ Angle 1: Code has defensive checks
    if (!results) return [];
    if (!Array.isArray(results)) return [];
    
    return results;
  } catch (error) {
    return []; // ✓ Safe fallback exists
  }
}
```

**Verification Questions:**
- Is the fix actually in the code?
- Does it handle all edge cases?
- Are there any gaps in the logic?
- Could this fail in unexpected ways?

---

### 2. API Level - Test the Endpoints

**What:** Call the API endpoints directly to verify behavior

**How:**
- Use curl, Postman, or browser DevTools
- Test with various inputs
- Verify response codes and data
- Check error handling paths

**Example:**
```bash
# Test with empty database (edge case)
curl http://localhost:5000/api/search-history

# Expected: 200 OK with []
# If it crashes or returns 500, fix isn't complete

# Test with actual data
curl http://localhost:5000/api/search-history?userId=123

# Expected: 200 OK with array of results
```

**Verification Questions:**
- Do endpoints return expected status codes?
- Is response data correctly formatted?
- Do error cases return gracefully?
- Are edge cases handled (empty data, invalid input)?

---

### 3. Database Level - Query Actual Data

**What:** Inspect the database state directly with SQL

**How:**
- Connect to database with SQL client
- Run queries to check actual data
- Verify constraints and relationships
- Test with empty tables

**Example:**
```sql
-- Check what's actually in the database
SELECT * FROM search_history WHERE user_id = 'new_user_123';
-- Expected: 0 rows (empty result)

-- Verify the query pattern matches code
SELECT * FROM search_history 
WHERE user_id = 'existing_user' 
ORDER BY created_at DESC;
-- Expected: Rows returned in correct order
```

**Verification Questions:**
- What is the actual database state?
- Does the query return what we expect?
- Are there any data integrity issues?
- How does the database behave with edge cases?

---

### 4. Browser Level - Check Client Errors

**What:** Monitor browser console for client-side errors

**How:**
- Open browser DevTools console
- Trigger the affected functionality
- Watch for JavaScript errors
- Check network requests

**Example:**
```javascript
// Browser Console Check
// ✓ No errors when loading page with empty data
// ✓ No "Cannot read property 'map' of null" errors
// ✓ Network tab shows 200 OK responses
// ✓ React components render without errors
```

**Verification Questions:**
- Are there any console errors?
- Do network requests succeed?
- Are components rendering correctly?
- Are there any warning messages?

---

### 5. Edge Case Level - Test Boundary Conditions

**What:** Test extreme and unusual scenarios

**How:**
- Brand new users (empty data)
- Maximum limits (huge datasets)
- Invalid inputs (malformed data)
- Race conditions (concurrent requests)
- Network failures (offline/slow)

**Example Test Cases:**
```
Edge Case Testing Checklist:

□ New user with no history
□ User with 1000+ history items
□ Deleted user (referenced but doesn't exist)
□ Null/undefined user ID
□ Special characters in data
□ Concurrent requests to same endpoint
□ Database connection failure
□ Network timeout
□ Browser offline mode
```

**Verification Questions:**
- What happens with brand new users?
- Can the system handle maximum loads?
- How does it respond to invalid inputs?
- Are there any race conditions?

---

## Real-World Example: Database Null Bug

### The Bug
```
TypeError: Cannot read properties of null (reading 'map')
```

### The Fix
Added defensive null checks and try-catch

### Multi-Angle Verification

**✓ Angle 1 - Code:**
```typescript
// Verified defensive pattern exists
if (!results) return [];
if (!Array.isArray(results)) return [];
```

**✓ Angle 2 - API:**
```bash
curl http://localhost:5000/api/search-history
# Response: 200 OK, body: []
```

**✓ Angle 3 - Database:**
```sql
SELECT * FROM search_history;
-- Result: 0 rows (empty table)
-- Confirmed database is actually empty
```

**✓ Angle 4 - Browser:**
```
Console: No errors
Network: 200 OK responses
UI: Renders "No recent analyses" correctly
```

**✓ Angle 5 - Edge Cases:**
```
✓ Brand new user → Works
✓ User with no analyses → Works
✓ Database connection lost → Graceful error
✓ Malformed user ID → Returns empty array
```

**Conclusion:** Bug is TRULY fixed across all angles.

---

## Why Multi-Angle Matters

### Single-Angle Failures

**Only tested code:**
- Code looks correct
- But API endpoint has authentication bug
- Users still experience errors
- ❌ False confidence

**Only tested API:**
- API returns data
- But client crashes trying to render it
- Users see blank page
- ❌ Incomplete fix

**Only tested happy path:**
- Works for existing users with data
- Crashes for new users with empty state
- Edge case missed
- ❌ Partial solution

### Multi-Angle Success

**Tested all 5 angles:**
- Code is defensive ✓
- API returns correctly ✓
- Database state verified ✓
- Browser renders without errors ✓
- Edge cases handled ✓
- ✅ Complete confidence

---

## Integration with Development Workflow

### Before Claiming "Fixed"

```
1. Implement fix
2. Run multi-angle verification:
   - Read code ✓
   - Test API ✓
   - Query database ✓
   - Check browser ✓
   - Test edge cases ✓
3. Document in debug-patterns.md
4. Add post-it note with verification notes
5. THEN claim it's fixed
```

### Trust But Verify Philosophy

**User's mantra:** "Trust each other, verify firsthand with screenshots."

**Applied to debugging:**
- Trust that fix looks good
- Verify with multi-angle testing
- Provide evidence (logs, screenshots, curl output)
- Build confidence through verification

---

## Common Verification Pitfalls

### Pitfall 1: Testing Happy Path Only

**Problem:** Only test the expected, successful scenario

**Example:**
```typescript
// Only tested with existing user who has data
// Missed: New user, empty data, deleted user
```

**Solution:** Explicitly test edge cases

### Pitfall 2: Assuming Database State

**Problem:** Don't actually look at database, assume it matches expectations

**Example:**
```
Assume: "Database should be empty for new users"
Reality: Legacy data exists from old migration
Bug: Code expects empty, gets old data, crashes
```

**Solution:** Always query database directly

### Pitfall 3: Ignoring Browser Console

**Problem:** Fix API, don't check if client handles response correctly

**Example:**
```
API: Returns null (intentionally for "not found")
Client: Tries to .map() over null → Crash
```

**Solution:** Always check browser console

### Pitfall 4: Not Testing Offline/Network Failures

**Problem:** Only test with perfect network conditions

**Example:**
```
Works: With fast localhost connection
Fails: User on slow 3G sees timeout errors
```

**Solution:** Simulate network issues

### Pitfall 5: Single User Testing

**Problem:** Only test with one user account

**Example:**
```
Works: For your test account (has permissions)
Fails: For new user (missing permissions)
```

**Solution:** Test with multiple user states

---

## Verification Checklists

### Quick Check (Minimum Viable)
```
□ Code review: Fix is in the code
□ API test: Endpoint returns correctly
□ Browser check: No console errors
```

### Standard Check (Recommended)
```
□ Code review: Fix is in the code
□ API test: Endpoint returns correctly  
□ Database query: State matches expectations
□ Browser check: No console errors
□ Edge case: Tested with empty/new user
```

### Thorough Check (Critical Bugs)
```
□ Code review: Fix is in the code
□ API test: Multiple endpoints tested
□ Database query: Multiple states verified
□ Browser check: Multiple browsers tested
□ Edge cases: All boundary conditions tested
□ Load test: Performance under stress
□ Security: No new vulnerabilities introduced
□ Regression: Old features still work
```

---

## Automation Opportunities

### Automated Multi-Angle Testing

```typescript
// Test suite covering all angles
describe('Search History - Multi-Angle', () => {
  
  // Angle 1: Code/Logic
  test('defensive null handling', () => {
    const result = handleNullResult(null);
    expect(result).toEqual([]);
  });
  
  // Angle 2: API
  test('API returns 200 with empty array', async () => {
    const response = await request('/api/search-history');
    expect(response.status).toBe(200);
    expect(response.body).toEqual([]);
  });
  
  // Angle 3: Database
  test('database query handles empty table', async () => {
    await db.deleteAll();
    const results = await getSearchHistory();
    expect(results).toEqual([]);
  });
  
  // Angle 4: Browser/Client
  test('component renders with empty data', () => {
    render(<SearchHistory data={[]} />);
    expect(screen.getByText('No results')).toBeInTheDocument();
  });
  
  // Angle 5: Edge Cases
  test('handles invalid user ID', async () => {
    const result = await getSearchHistory('invalid-id');
    expect(result).toEqual([]);
  });
});
```

### CI/CD Integration

```yaml
# GitHub Actions - Multi-Angle Verification
- name: Run Multi-Angle Tests
  run: |
    npm run test:unit        # Angle 1: Code logic
    npm run test:api         # Angle 2: API endpoints  
    npm run test:db          # Angle 3: Database queries
    npm run test:e2e         # Angle 4+5: Browser + Edge cases
```

---

## Documentation Requirements

### When Fixing a Bug

**Document multi-angle verification:**

```markdown
## Bug Fix: Database Null Handling

### Verification:
- ✓ Code: Added defensive checks (lines 45-47)
- ✓ API: Tested `/api/search-history` returns []
- ✓ Database: Queried empty table, confirmed null return
- ✓ Browser: No console errors with empty data
- ✓ Edge Cases: New user, deleted user, offline mode

### Evidence:
- Screenshot: Browser console clean
- Curl output: API returns 200 OK
- SQL result: Database state verified
```

---

## Related Patterns

### Debug Patterns Connection

**This methodology integrates with:**
- Pattern #1: Database Null-Safety (what to fix)
- Pattern #2: Actionable Error Messages (how to fail gracefully)
- Pattern #3: Multi-Method Input (testing multiple paths)

**Workflow:**
1. Identify bug
2. Implement fix
3. Apply multi-angle verification
4. Document in debug-patterns.md
5. Extract to post-it-notes.md
6. Never forget the lesson

---

## Success Metrics

### Leading Indicators
- ✅ All 5 angles checked before marking bug fixed
- ✅ Evidence documented (screenshots, logs, queries)
- ✅ Edge cases explicitly tested
- ✅ Verification checklist completed

### Lagging Indicators
- ✅ Bugs don't resurface (truly fixed)
- ✅ Zero regressions (old features work)
- ✅ Increased confidence in deployments
- ✅ Faster debugging (know what to verify)

---

## Conclusion

**Single-angle verification = False confidence**  
**Multi-angle verification = True confidence**

The extra 5-10 minutes spent verifying from all angles saves hours of:
- Debugging the same issue later
- Fixing regressions
- Dealing with production incidents
- Losing user trust

**Never claim something is fixed without multi-angle verification.**

---

## Document Changelog

**v1.0** (November 6, 2025)
- Initial creation extracting methodology from debug-patterns.md
- Defined 5 verification angles
- Provided real-world examples
- Created verification checklists

---

## License & Usage

**License:** Open Methodology - freely shareable  
**Attribution:** AssetGenius Project  
**Usage:** Apply to any debugging workflow
