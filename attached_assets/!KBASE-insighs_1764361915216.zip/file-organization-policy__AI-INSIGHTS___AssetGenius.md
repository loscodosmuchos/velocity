# File Organization Policy & Directory Structure
**Version:** 1.0  
**Date:** November 6, 2025  
**Status:** Active Policy Document  
**Purpose:** Define standard directory structure and file naming conventions for knowledge management

---

## 🎓 FOR NEW AI INSTANCES: Context & Decision History

**If you're a new AI reading this for the first time**, this section explains the full conversation context and reasoning behind these conventions. Understanding the WHY helps you apply these rules correctly.

### The Problem We Solved

**Context:** User and AI collaborate to generate insight documents from conversations. These documents need to be:
1. **Easily identifiable** as AI-generated vs. user-provided
2. **Shareable across Replit instances** while maintaining context
3. **Removable app name** for universal sharing
4. **Organized systematically** so knowledge doesn't get lost

### The Iteration Process (How We Got Here)

**Iteration 1:** All caps filenames
- **Tried:** `KNOWLEDGE-SYSTEM-USABILITY-PATTERNS.MD`
- **Problem:** Hard to read, looks like screaming
- **Rejected**

**Iteration 2:** Suffix tag
- **Tried:** `knowledge-system-usability-patterns-AI-INSIGHTS.md`
- **Problem:** Separator was single dash (same as topic hyphens), hard to parse
- **Improved but not final**

**Iteration 3:** App name in middle
- **Tried:** `AI-INSIGHTS--AssetGenius--knowledge-system-usability-patterns.md`
- **Problem:** App name buried in middle, topic not immediately visible
- **Rejected**

**Iteration 4:** App name at end with double dash
- **Tried:** `AI-INSIGHTS--knowledge-system-usability-patterns--AssetGenius.md`
- **Problem:** Still using dashes which conflict with topic name hyphens
- **Getting closer**

**Iteration 5:** Double underscore separator
- **Tried:** `knowledge-system-usability-patterns-AI-INSIGHTS__AssetGenius.md`
- **Problem:** Single dash before AI-INSIGHTS conflicts with topic hyphens
- **User feedback:** "Make it a different character besides dash"

**Iteration 6:** Double underscore before AI-INSIGHTS
- **Tried:** `knowledge-system-usability-patterns__AI-INSIGHTS__AssetGenius.md`
- **Problem:** Same separator for both boundaries - can't distinguish app name
- **User feedback:** "Maybe double __ vs triple for app name?"

**Iteration 7:** Triple underscore for app name
- **Tried:** `knowledge-system-usability-patterns__AI-INSIGHTS___AssetGenius.md`
- **User:** "Yes, though keep separator between name of app different so it can be removed if needed later"
- **Perfect!** This became our final convention

**Iteration 8:** Brief confusion about AI-INSIGHTS position
- **Tried:** `__AI-INSIGHTS__knowledge-system-usability-patterns___AssetGenius.md`
- **User clarified:** "before to separate from title/topic" (meaning separator before topic, not AI-INSIGHTS at start)
- **Clarified:** Topic comes first, then `__AI-INSIGHTS`, then `___AssetGenius`

**Final Decision:** `topic-name__AI-INSIGHTS___AssetGenius.md`

### Why This Specific Convention?

**Topic First (`knowledge-system-usability-patterns`)**
- **Reason:** Most important part - what the document is about
- **Benefit:** Easy to scan filenames alphabetically by topic
- **User quote:** "You were right the first time, topic first"

**Double Underscore Before AI-INSIGHTS (`__`)**
- **Reason:** Clearly separates topic from metadata
- **Benefit:** Different from topic hyphens, easy to parse
- **Why not single dash:** Would conflict with hyphens in topic name
- **Why not triple:** Reserve triple for app name boundary

**AI-INSIGHTS Tag**
- **Reason:** Immediately identifies AI-generated vs. user-provided files
- **Benefit:** User can quickly see which files are AI insights
- **User quote:** "I want to make sure we capture and bring into the central knowledge base"

**Triple Underscore Before App Name (`___`)**
- **Reason:** Unique separator that's easy to strip programmatically
- **Benefit:** `filename.split('___')[0]` removes app name for sharing
- **User quote:** "Keep separator between name of app different so it can be removed if needed later"
- **Why triple:** Visually distinct from double underscore, clearly marks final boundary

**App Name at End (`AssetGenius`)**
- **Reason:** Provides project context but doesn't interfere with topic
- **Benefit:** Can be removed when sharing across projects
- **User insight:** Some knowledge is universal and shouldn't be tied to one app

### Key Design Principles Learned

1. **Separators Matter**
   - Use different separators for different boundaries
   - Hyphens for topic words (`knowledge-system`)
   - Double underscore for metadata boundary (`__AI-INSIGHTS`)
   - Triple underscore for app boundary (`___AssetGenius`)

2. **Topic First, Context Last**
   - Put what matters most (topic) at the start
   - Put what's removable (app name) at the end
   - Put what's identifying (AI-INSIGHTS) in the middle

3. **Design for Sharing**
   - Easy to strip app name: `${filename.split('___')[0]}.md`
   - Easy to add app name: `${baseFilename}___NewAppName.md`
   - Easy to identify: All AI insights have `__AI-INSIGHTS___` pattern

4. **Iterate Based on Feedback**
   - User knows their workflow best
   - Test different approaches
   - Refine based on actual usage needs

### How to Apply This Convention

**When creating new AI-generated insight documents:**

```bash
# Pattern
topic-name__AI-INSIGHTS___AssetGenius.md

# Real examples
knowledge-system-usability-patterns__AI-INSIGHTS___AssetGenius.md
deployment-patterns-analysis__AI-INSIGHTS___AssetGenius.md
ux-friction-reduction-methods__AI-INSIGHTS___AssetGenius.md
```

**When sharing to another project:**

```bash
# Original
knowledge-system-usability-patterns__AI-INSIGHTS___AssetGenius.md

# Remove app name for universal sharing
knowledge-system-usability-patterns__AI-INSIGHTS.md

# Or add new app name
knowledge-system-usability-patterns__AI-INSIGHTS___NewProjectName.md
```

**When in doubt:**
- Topic = hyphens between words
- Metadata boundary = double underscore (`__`)
- App boundary = triple underscore (`___`)
- Topic always comes first

---

## Directory Structure

```
/
├── knowledge-base/
│   ├── insights/           # AI-generated analysis and insights
│   ├── operations/         # Living operational documents (updated frequently)
│   ├── evaluations/        # UX evaluations, assessments, reviews
│   └── policies/          # Rules, conventions, standards
│
├── client/                # Frontend application code
├── server/                # Backend application code
├── shared/                # Shared types and schemas
├── attached_assets/       # User-provided files and attachments
└── [root files]          # Config files (package.json, tsconfig.json, etc.)
```

---

## File Naming Conventions

### AI-Generated Insight Documents
**Pattern:** `topic-name__AI-INSIGHTS___AssetGenius.md`

**Examples:**
- `knowledge-system-usability-patterns__AI-INSIGHTS___AssetGenius.md`
- `batch-session-ux-analysis__AI-INSIGHTS___AssetGenius.md`
- `deployment-patterns__AI-INSIGHTS___AssetGenius.md`

**Separators:**
- `__` (double underscore) before `AI-INSIGHTS`
- `___` (triple underscore) before app name
- Hyphens within topic name for readability

**Purpose:** Easily identify AI-generated insights, strip app name if needed

### Operational Documents
**Pattern:** `document-name.md` (no special suffix)

**Examples:**
- `post-it-notes.md`
- `debug-patterns.md`
- `watchdog-process.md`

**Purpose:** Living documents that are frequently updated and referenced

### User-Provided Files
**Pattern:** Keep original naming, stored in `attached_assets/`

**Purpose:** Preserve user's file naming and organization

---

## Directory Purposes

### `/knowledge-base/insights/`
**Contains:** AI-generated analysis, consolidated insights, research documents

**File Types:**
- Pattern analyses
- Cross-domain learnings
- Meta-insights (learning about learning)
- Comparative studies
- Strategic recommendations

**Naming:** All files use `topic__AI-INSIGHTS___AssetGenius.md` format

**Update Frequency:** Created once, rarely modified (append-only)

### `/knowledge-base/operations/`
**Contains:** Living operational documents that guide daily work

**File Types:**
- `post-it-notes.md` - Permanent insights queue
- `debug-patterns.md` - Debugging methodologies
- `watchdog-process.md` - Watchdog automation rules
- `replit.md` - Project overview and architecture

**Naming:** Simple descriptive names (no special suffix)

**Update Frequency:** Updated frequently (sometimes multiple times per session)

### `/knowledge-base/evaluations/`
**Contains:** Assessments, reviews, and evaluation reports

**File Types:**
- UX evaluations
- Code reviews
- Architecture assessments
- Performance analyses
- Security audits

**Naming:** `[topic]-evaluation.md` or `[feature]-assessment.md`

**Update Frequency:** Created for specific reviews, may be updated with findings

### `/knowledge-base/policies/`
**Contains:** Rules, standards, conventions, and policy documents

**File Types:**
- This file (file organization policy)
- Code style guides
- Documentation standards
- Process guidelines
- Governance rules

**Naming:** `[topic]-policy.md` or `[topic]-standard.md`

**Update Frequency:** Rarely (only when policies change)

---

## File Lifecycle

### Creation
1. **AI creates insight document** → Save as `topic__AI-INSIGHTS___AssetGenius.md` in `/knowledge-base/insights/`
2. **AI creates operational doc** → Save as `document-name.md` in `/knowledge-base/operations/`
3. **AI creates evaluation** → Save as `topic-evaluation.md` in `/knowledge-base/evaluations/`
4. **User provides file** → Store in `attached_assets/` with original name

### Updates
- **Insights:** Rarely modified (append new versions instead)
- **Operations:** Frequent updates (living documents)
- **Evaluations:** Updated with findings, then archived
- **Policies:** Version-controlled changes

### Archival
- Move to `/knowledge-base/archive/` if no longer active
- Preserve for historical reference
- Include archive date in filename: `topic__AI-INSIGHTS___AssetGenius-ARCHIVED-2025-11-06.md`

---

## Special File Types

### Configuration Files (Root Level)
**Keep at root:** `package.json`, `tsconfig.json`, `vite.config.ts`, etc.

**Reason:** Required by tooling at specific locations

### Documentation (Root Level)
**Common files:** `README.md`, `CHANGELOG.md`, `LICENSE.md`

**Reason:** Standard open-source conventions

### Design Guidelines
**Location:** Root level or `/knowledge-base/operations/`

**File:** `design_guidelines.md`

**Reason:** Frequently referenced during development

---

## Search and Discovery

### Finding AI Insights
```bash
# Find all AI-generated insights
ls knowledge-base/insights/*__AI-INSIGHTS___*.md

# Search insights for specific topic
grep -r "pattern" knowledge-base/insights/

# Strip app name from filename
filename="topic__AI-INSIGHTS___AssetGenius.md"
basename="${filename%%___*}"  # Returns: topic__AI-INSIGHTS
```

### Finding Operational Docs
```bash
# List all operational documents
ls knowledge-base/operations/

# Search post-it notes
grep -i "database" knowledge-base/operations/post-it-notes.md
```

### Cross-Document Search
```bash
# Search entire knowledge base
grep -r "search term" knowledge-base/

# Find by file type
find knowledge-base/ -name "*evaluation.md"
```

---

## Migration Rules

### Moving Existing Files
When organizing existing files into new structure:

1. **Identify file type** (insight, operation, evaluation, policy)
2. **Apply naming convention** if AI-generated insight
3. **Move to appropriate directory**
4. **Update references** in other documents
5. **Test that nothing breaks** (imports, links, etc.)

### Breaking Changes
If moving files would break application code:
- **DON'T MOVE** config files required at root
- **DON'T MOVE** files imported by application code
- **DO MOVE** documentation-only files

---

## Sharing Across Projects

### Removing App Name
```bash
# Strip AssetGenius from filename for sharing
original="topic__AI-INSIGHTS___AssetGenius.md"
shared="${original%___*}.md"  # Returns: topic__AI-INSIGHTS.md
```

### Adding App Name
```bash
# Add app name when importing to new project
shared="topic__AI-INSIGHTS.md"
local="${shared%.md}___NewAppName.md"
```

### Universal Insights
Some insights are universal (not app-specific):
- Can remove `___AssetGenius` permanently
- Store in shared knowledge repository
- Reference from multiple projects

---

## Best Practices

### DO
✅ Use consistent naming conventions  
✅ Place files in correct directories  
✅ Update this policy when conventions change  
✅ Search before creating (avoid duplicates)  
✅ Link related documents  
✅ Include metadata in document headers  
✅ Version policy documents  

### DON'T
❌ Mix insights with operations in same directory  
❌ Use inconsistent separators  
❌ Move files without updating references  
❌ Create redundant documents  
❌ Forget to update changelog when adding files  
❌ Break application imports by moving code files  

---

## Document Metadata Template

Every knowledge-base document should include:

```markdown
# Document Title
**Version:** X.Y  
**Date:** YYYY-MM-DD  
**Authors:** [Human/AI/Both]  
**Status:** [Draft/Active/Archived]  
**Purpose:** Brief description  

**Related Documents:**
- Link to related doc 1
- Link to related doc 2

**Keywords:** tag1, tag2, tag3

---

[Content starts here]
```

---

## Automation Opportunities

### Auto-Organization Script
```bash
#!/bin/bash
# Future enhancement: Auto-detect and organize files

for file in *.md; do
  if [[ $file == *"__AI-INSIGHTS___"* ]]; then
    mv "$file" knowledge-base/insights/
  elif [[ $file == *"-evaluation.md" ]]; then
    mv "$file" knowledge-base/evaluations/
  elif [[ $file == *"-policy.md" ]]; then
    mv "$file" knowledge-base/policies/
  fi
done
```

### Watchdog Integration
- Watchdog creates new insights → Auto-save to `/knowledge-base/insights/`
- Watchdog updates post-its → Auto-commit to `/knowledge-base/operations/`

---

## Version History

**v1.0** (November 6, 2025)
- Initial policy creation
- Defined directory structure
- Established naming conventions
- Created migration rules

---

## Future Enhancements

### Potential Additions
1. **Tagging system** - Metadata tags for better search
2. **Relationship mapping** - Links between related documents
3. **Readiness scoring** - Quality indicators for insights
4. **Auto-archival** - Move old files automatically
5. **Knowledge graph** - Visual representation of relationships

### Community Feedback
If this policy is shared across projects, incorporate feedback and best practices from other teams.

---

## License & Usage

**License:** Open Policy - freely adaptable  
**Attribution:** AssetGenius Project  
**Usage:** Adapt for your projects, share improvements back
