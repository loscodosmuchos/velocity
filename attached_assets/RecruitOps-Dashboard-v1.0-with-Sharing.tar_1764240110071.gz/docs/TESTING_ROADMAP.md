# Testing Roadmap & Strategy

## Phase 2: Testing (Turns 5-8)

### Turn 5: Playwright Test Generation
- Install playwright
- Generate 3 core E2E tests:
  1. **Authentication Flow** - Sign in/out
  2. **Dashboard CRUD** - Create, read, update, delete layouts
  3. **Error Handling** - Invalid input, network failure, conflict resolution

### Turn 6-7: Test Execution
- Run all tests
- Capture screenshots to `test-results/`
- Log failures to `BUG_REPORT.md`
- Verify all 4 major features

### Turn 8: Bug Analysis
- Create `BUGS_CATEGORIZED.md`
- Categorize by severity
- Mark auto-fixable issues
- Prepare repair strategy

## Test Scenarios

### Test 1: Dashboard Layout CRUD
```gherkin
Feature: Dashboard Layout Management
  Scenario: Create new layout from template
    Given I'm on the dashboard
    When I click "Apply Template" for "Recruiter"
    Then Layout loads with 6 modules
    And I see grid with 3 columns
    
  Scenario: Save custom layout
    Given I have modified a layout
    When I click "Save Layout"
    And enter name "My Dashboard"
    Then Layout saves successfully
    And appears in "Saved Layouts"
    
  Scenario: Export layout
    Given I have a saved layout
    When I click "Export"
    Then JSON file downloads
    And contains valid schema
    
  Scenario: Import layout
    Given I have exported JSON
    When I click "Import"
    And select file
    Then Layout loads
    And modules appear correctly
```

### Test 2: Module Drag-Drop
```gherkin
Feature: Drag-Drop Grid
  Scenario: Add module to grid
    Given ModulePalette is open
    When I drag "Revenue KPI" to grid
    Then Module appears at position
    And grid compacts
    
  Scenario: Resize module
    Given Module is in grid
    When I drag resize handle
    Then Module size changes
    And grid recompacts
    
  Scenario: Remove module
    Given Module is in grid
    When I click remove button
    Then Module disappears
    And grid recompacts
```

### Test 3: Theme Switching
```gherkin
Feature: Dynamic Themes
  Scenario: Switch theme
    Given Dashboard is loaded
    When I select "Dark Executive" theme
    Then CSS variables update
    And Layout reflects new colors
    
  Scenario: Theme persists
    Given I switched theme
    When I reload page
    Then Theme is still applied
```

### Test 4: Error Handling
```gherkin
Feature: Error Scenarios
  Scenario: Invalid module selection
    Given Invalid moduleId in config
    When Import executes
    Then Error toast appears
    And User sees message
    
  Scenario: Network failure
    Given Network is disconnected
    When I click Save
    Then Retry button appears
    And timeout message shown
```

## Known Bugs to Check For

| ID | Description | Category | Status |
|----|-------------|----------|--------|
| BUG-001 | LSP error in seed.ts type mismatch | Minor | Found |
| BUG-002 | UserId "default-user" hardcoded | Configuration | Expected |
| BUG-003 | Demo data not toggleable | Feature Request | Expected |
| BUG-004 | CORS not configured | Security | Expected |
| BUG-005 | Rate limiting missing | Security | Expected |

## Auto-Fixable Issues (High Confidence)

1. **Type Mismatch in seed.ts** - Fix import types
2. **UserId Replacement** - Replace "default-user" with env var
3. **CORS Configuration** - Add express.cors middleware
4. **Missing Error Messages** - Add try-catch blocks

## Test Environment Setup

```bash
# Turn 5: Installation
npm install --save-dev @playwright/test

# Create test directory
mkdir -p tests/e2e

# Create test runner config
npx playwright install
```

## Expected Test Coverage

### Dashboard Builder
- ✓ Module catalog loads (37 modules)
- ✓ Templates list loads (8 templates)
- ✓ Apply template creates layout
- ✓ Drag-drop works
- ✓ Save layout persists
- ✓ Export downloads JSON
- ✓ Import creates layout
- ✓ Theme switching works
- ✓ Responsive on mobile
- ✓ Error messages show

### GitHub Integration
- ✓ Push file endpoint works
- ✓ Batch push works
- ✓ Conflict dialog shows

### API Routes
- ✓ All 12 dashboard endpoints respond
- ✓ 2 GitHub endpoints respond
- ✓ Invalid input returns 400
- ✓ Database errors handled
- ✓ Authentication required (future)

## Metrics to Track

| Metric | Target | Status |
|--------|--------|--------|
| Test Pass Rate | 100% | TBD |
| Code Coverage | 80%+ | TBD |
| Performance: Load | <500ms | TBD |
| Performance: Save | <1000ms | TBD |
| Error Handling | 100% routes | TBD |
| Mobile Responsiveness | All breakpoints | TBD |

## Bug Severity Levels

**Critical:** Blocks core functionality
- Example: Dashboard won't load
- Action: Fix immediately

**High:** Significantly impacts UX
- Example: Save doesn't work
- Action: Fix in current sprint

**Medium:** Noticeable but workaround exists
- Example: Theme doesn't persist
- Action: Fix in next sprint

**Low:** Minor issues, no workaround needed
- Example: Tooltip text typo
- Action: Nice to have

**Tech Debt:** Code quality, not user-facing
- Example: Missing comments
- Action: Document for future

---

**Status:** Testing roadmap created, ready for Turn 5
**Next:** Generate Playwright test files and execute
