import { z } from "zod";
import { pgTable, serial, text, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// ============================================================================
// DASHBOARD SYSTEM SCHEMA
// ============================================================================

// Dashboard Modules - Catalog of available widgets
export const dashboardModules = pgTable('dashboard_modules', {
  id: serial('id').primaryKey(),
  type: text('type').notNull(), // 'kpi', 'chart', 'table', 'widget', 'custom'
  name: text('name').notNull(),
  description: text('description'),
  icon: text('icon'), // Lucide icon name
  category: text('category'), // 'analytics', 'recruitment', 'vendor', 'finance'
  defaultSize: jsonb('default_size').$type<{ w: number; h: number; minW?: number; minH?: number }>(),
  configSchema: jsonb('config_schema'), // Zod schema for widget-specific config
  isEnabled: boolean('is_enabled').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

export type DashboardModule = typeof dashboardModules.$inferSelect;
export type InsertDashboardModule = typeof dashboardModules.$inferInsert;
export const insertDashboardModuleSchema = createInsertSchema(dashboardModules);

// Dashboard Templates - Pre-configured layouts for roles
export const dashboardTemplates = pgTable('dashboard_templates', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  role: text('role'), // 'recruiter', 'hiring_manager', 'executive', 'vendor_manager', 'admin'
  layout: jsonb('layout').$type<LayoutItem[]>(),
  themeId: integer('theme_id'), // Associated theme for this template
  isPublic: boolean('is_public').default(false),
  isDefault: boolean('is_default').default(false),
  thumbnailUrl: text('thumbnail_url'),
  createdBy: integer('created_by'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export type DashboardTemplate = typeof dashboardTemplates.$inferSelect;
export type InsertDashboardTemplate = typeof dashboardTemplates.$inferInsert;
export const insertDashboardTemplateSchema = createInsertSchema(dashboardTemplates);

// User Dashboard Layouts - Personal customizations
export const userDashboardLayouts = pgTable('user_dashboard_layouts', {
  id: serial('id').primaryKey(),
  userId: text('user_id').notNull(),
  name: text('name').notNull(),
  layout: jsonb('layout').$type<LayoutItem[]>(),
  isDefault: boolean('is_default').default(false),
  themeId: integer('theme_id'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export type UserDashboardLayout = typeof userDashboardLayouts.$inferSelect;
export type InsertUserDashboardLayout = typeof userDashboardLayouts.$inferInsert;
export const insertUserDashboardLayoutSchema = createInsertSchema(userDashboardLayouts);

// Theme Tokens - Design system configurations
export const themeTokens = pgTable('theme_tokens', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  tokens: jsonb('tokens').$type<ThemeTokenSet>(),
  isPublic: boolean('is_public').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

export type ThemeToken = typeof themeTokens.$inferSelect;
export type InsertThemeToken = typeof themeTokens.$inferInsert;
export const insertThemeTokenSchema = createInsertSchema(themeTokens);

// ============================================================================
// DASHBOARD TYPES & INTERFACES
// ============================================================================

// Layout item for react-grid-layout
export interface LayoutItem {
  i: string; // Unique ID
  x: number;
  y: number;
  w: number; // Width in grid units
  h: number; // Height in grid units
  minW?: number;
  minH?: number;
  maxW?: number;
  maxH?: number;
  static?: boolean; // Cannot be dragged or resized
  isDraggable?: boolean;
  isResizable?: boolean;
  moduleId?: number | null; // References dashboard_modules.id (optional for flexibility)
  config?: Record<string, any>; // Widget-specific configuration
}

// Theme design tokens
export interface ThemeTokenSet {
  colors: {
    primary: { h: number; s: number; l: number };
    secondary: { h: number; s: number; l: number };
    accent: { h: number; s: number; l: number };
    neutral: { h: number; s: number; l: number };
    success: { h: number; s: number; l: number };
    warning: { h: number; s: number; l: number };
    error: { h: number; s: number; l: number };
  };
  spacing: {
    base: number; // Base spacing unit in px
    scale: number; // Multiplier for spacing scale
  };
  typography: {
    fontFamily: string;
    scale: 'minor-third' | 'major-third' | 'perfect-fourth';
    baseSize: number;
  };
  borderRadius: {
    sm: number;
    md: number;
    lg: number;
  };
}

// ============================================================================
// DASHBOARD API SCHEMAS
// ============================================================================

// Get available modules
export const getModulesSchema = z.object({
  category: z.string().optional(),
  search: z.string().optional(),
});
export type GetModulesRequest = z.infer<typeof getModulesSchema>;

// Get templates
export const getTemplatesSchema = z.object({
  role: z.string().optional(),
});
export type GetTemplatesRequest = z.infer<typeof getTemplatesSchema>;

// Shared layout item schema
export const layoutItemSchema = z.object({
  i: z.string(),
  x: z.number(),
  y: z.number(),
  w: z.number(),
  h: z.number(),
  minW: z.number().optional(),
  minH: z.number().optional(),
  maxW: z.number().optional(),
  maxH: z.number().optional(),
  static: z.boolean().optional(),
  isDraggable: z.boolean().optional(),
  isResizable: z.boolean().optional(),
  moduleId: z.number(),
  config: z.record(z.any()).optional(),
});

// Save user layout
export const saveLayoutSchema = z.object({
  name: z.string().min(1, "Layout name is required"),
  layout: z.array(layoutItemSchema),
  isDefault: z.boolean().optional(),
  themeId: z.number().optional(),
});
export type SaveLayoutRequest = z.infer<typeof saveLayoutSchema>;

// Apply template
export const applyTemplateSchema = z.object({
  templateId: z.number(),
  saveAs: z.string().optional(),
});
export type ApplyTemplateRequest = z.infer<typeof applyTemplateSchema>;

// Switch theme
export const switchThemeSchema = z.object({
  themeId: z.number(),
});
export type SwitchThemeRequest = z.infer<typeof switchThemeSchema>;

// Import layout
export const importLayoutSchema = z.object({
  name: z.string().min(1, "Layout name is required"),
  layout: z.array(layoutItemSchema),
  themeId: z.number().optional(),
});
export type ImportLayoutRequest = z.infer<typeof importLayoutSchema>;

// ============================================================================
// DASHBOARD WIDGET DATA TYPES
// ============================================================================

// KPI Card Data
export interface KPIData {
  title: string;
  value: number | string;
  change?: number; // Percentage change
  trend?: 'up' | 'down' | 'neutral';
  subtitle?: string;
  icon?: string;
}

// Chart Data
export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    color?: string;
  }[];
}

// Table Data
export interface TableData {
  headers: { key: string; label: string; sortable?: boolean }[];
  rows: Record<string, any>[];
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
  };
}

// ============================================================================
// USER TYPES
// ============================================================================

export interface User {
  id: string;
  username: string;
  email?: string;
  role?: string;
}

export interface InsertUser {
  username: string;
  email?: string;
  role?: string;
}

// ============================================================================
// LEGACY GITHUB AUTOMATION (kept for backwards compatibility)
// ============================================================================

export const filePushSchema = z.object({
  repository: z.string().min(1, "Repository is required"),
  branch: z.string().min(1, "Branch is required"),
  token: z.string().min(1, "GitHub token is required"),
  files: z.array(z.object({
    path: z.string(),
    content: z.string(),
    filename: z.string()
  })).min(1, "At least one file is required")
});

export type FilePushRequest = z.infer<typeof filePushSchema>;

export const batchPushSchema = z.object({
  repositories: z.array(z.object({
    repository: z.string().min(1, "Repository is required"),
    branch: z.string().min(1, "Branch is required")
  })).min(1, "At least one repository is required"),
  token: z.string().min(1, "GitHub token is required"),
  files: z.array(z.object({
    path: z.string(),
    content: z.string(),
    filename: z.string()
  })).min(1, "At least one file is required")
});

export type BatchPushRequest = z.infer<typeof batchPushSchema>;

export type FileStatus = "pending" | "uploading" | "success" | "error";

export interface GitHubFile {
  path: string;
  content: string;
  filename: string;
}

export interface FileUploadStatus {
  filename: string;
  path: string;
  status: FileStatus;
  commitUrl?: string;
  error?: string;
}

export interface PushResult {
  success: boolean;
  files: FileUploadStatus[];
  totalFiles: number;
  successCount: number;
  errorCount: number;
}

export interface RepositoryTarget {
  repository: string;
  branch: string;
}

export interface RepositoryPushResult {
  repository: string;
  branch: string;
  success: boolean;
  files: FileUploadStatus[];
  totalFiles: number;
  successCount: number;
  errorCount: number;
  error?: string;
}

export interface BatchPushResult {
  success: boolean;
  repositories: RepositoryPushResult[];
  totalRepositories: number;
  successfulRepos: number;
  failedRepos: number;
}

export const checkConflictsSchema = z.object({
  repository: z.string().min(1, "Repository is required"),
  branch: z.string().min(1, "Branch is required"),
  token: z.string().min(1, "GitHub token is required"),
  files: z.array(z.object({
    path: z.string(),
    filename: z.string()
  })).min(1, "At least one file is required")
});

export type CheckConflictsRequest = z.infer<typeof checkConflictsSchema>;

export type ConflictStatus = "new" | "conflict" | "error";

export interface FileConflictInfo {
  filename: string;
  path: string;
  status: ConflictStatus;
  existingContent?: string;
  sha?: string;
  error?: string;
}

export interface ConflictsCheckResult {
  success: boolean;
  files: FileConflictInfo[];
  hasConflicts: boolean;
  conflictCount: number;
  newFileCount: number;
}
