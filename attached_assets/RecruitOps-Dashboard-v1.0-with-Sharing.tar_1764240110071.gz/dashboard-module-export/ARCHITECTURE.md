# Dashboard System Architecture

## System Overview

The dashboard system is a three-tier architecture:

```
TIER 1: Module Catalog
  ↓ (user selects)
TIER 2: Layout Templates
  ↓ (user customizes)
TIER 3: User Overrides
  ↓ (persisted layouts)
```

This design allows users to start from templates but fully customize without losing the catalog reference.

## Data Model

### Core Tables

```
dashboardModules (37 total)
├── id: serial PK
├── type: 'kpi' | 'chart' | 'table' | 'widget'
├── name: string (unique)
├── category: string (recruitment, procurement, project_mgmt, it_systems, vms, finance, productivity)
├── icon: lucide-react icon name
├── defaultSize: { w, h, minW, minH } grid dimensions
└── configSchema: (extensible for widget-specific settings)

dashboardTemplates (8 role-based)
├── id: serial PK
├── role: string (recruiter, cpo, senior_pm, etc.)
├── name: string
├── layout: LayoutItem[] (grid positions + module IDs)
├── themeId: FK → themeTokens
└── isPublic: boolean

userDashboardLayouts (user data)
├── id: serial PK
├── userId: text (multi-tenant key)
├── name: string (user can name their layouts)
├── layout: LayoutItem[]
├── themeId: FK → themeTokens
├── isDefault: boolean (one per user)
└── updatedAt: timestamp

themeTokens (4 themes)
├── id: serial PK
├── name: string
├── tokens: { colors, spacing, typography, borderRadius }
└── isPublic: boolean

LayoutItem (layout serialization)
├── i: string (unique ID, e.g., "module-12345")
├── x, y: number (grid position)
├── w, h: number (grid size in columns/rows)
├── minW, minH: number (minimum size constraints)
├── moduleId: number (FK → dashboardModules)
└── config: Record<string, any> (widget-specific settings)
```

### Design Decisions

1. **Separate Templates from Layouts** - Templates are immutable; users customize into layouts
2. **HSL Color Storage** - Allows dynamic color adjustments (brightness, saturation)
3. **Text userId** - Supports UUID or string identifiers for different auth systems
4. **Config Field** - Extensible for future widget customization
5. **Grid String IDs** - Avoids ID collisions when dragging items

## Component Hierarchy

```
DashboardBuilder (main orchestrator)
├── Header (save, export, import, theme selector)
├── Sidebar
│   ├── ModulePalette (category > module cards)
│   └── TemplateSelector (system templates + saved layouts)
├── GridLayout (react-grid-layout wrapper)
│   └── DashboardWidget[] (KPI/Chart/Table/Widget renderers)
└── SaveLayoutDialog (modal form)
```

### Component Responsibilities

**DashboardBuilder**
- Manages grid state (layout array)
- Handles add/remove module operations
- Orchestrates save/export/import flows
- Manages theme switching

**GridLayout**
- Wraps react-grid-layout Responsive component
- Maps layout items to DashboardWidget instances
- Preserves moduleId through layout changes
- Handles drag-drop and resize events

**DashboardWidget**
- Renders 4 widget types based on module.type
- Uses getDemoData() for demo values
- Handles KPI trends, chart animations, table rows, action buttons
- Extensible for real data integration

**ModulePalette**
- Groups modules by category
- Displays icon, name, description, default size
- Scrollable area with drag affordances

**TemplateSelector**
- Lists system templates with apply buttons
- Lists user's saved layouts with load buttons
- Shows metadata (role, widget count, last updated)

**ThemeSelector**
- Dropdown to switch themes
- Persists theme to layout if layout exists
- Triggers query invalidation

## State Management

### Backend State (PostgreSQL)

Immutable truth source. Updated by:
- User saves layout
- User imports config
- Admin seeds data

### Client Cache (React Query)

Keyed by:
- `/api/dashboard/modules` - modules list (invalidated on module changes)
- `/api/dashboard/templates` - templates list
- `/api/dashboard/layouts` - user's layouts
- `/api/dashboard/themes` - available themes

Mutation invalidation pattern:
```typescript
onSuccess: () => {
  queryClient.invalidateQueries({ queryKey: ['/api/dashboard/layouts'] });
}
```

### Component State (React useState)

Local to DashboardBuilder:
- `layout` - Current grid layout (LayoutItem[])
- `activeModules` - Map<string, number> (itemId → moduleId)
- `selectedThemeId` - Current theme ID
- `currentLayoutId` - Currently loaded/saving layout ID
- `showSaveDialog` - Modal visibility

## Data Flow

### Load Dashboard
1. User visits `/dashboard`
2. DashboardBuilder mounts
3. React Query fetches:
   - `/api/dashboard/modules` (37 total)
   - `/api/dashboard/templates` (8 total)
   - `/api/dashboard/layouts` (user's layouts)
   - `/api/dashboard/themes` (4 total)
4. UI renders with empty canvas or default layout

### Apply Template
1. User clicks "Apply Template"
2. POST to `/api/dashboard/templates/apply`
3. Backend clones template layout
4. Saves as new UserDashboardLayout
5. React Query invalidates `/api/dashboard/layouts`
6. UI updates with new layout

### Save Custom Layout
1. User clicks "Save"
2. Dialog opens
3. User enters name, toggles default
4. POST to `/api/dashboard/layouts` with current layout
5. Backend saves LayoutItem[] as-is
6. Backend handles isDefault logic (unsets others if needed)
7. React Query invalidates cache
8. UI shows success toast

### Export Layout
1. User clicks "Export"
2. GET `/api/dashboard/layouts/{id}/export`
3. Backend wraps layout in export envelope with version/timestamp
4. Browser downloads JSON file

### Import Layout
1. User clicks "Import"
2. File picker opens
3. User selects JSON file
4. Parse JSON
5. Validate with layoutItemSchema Zod parser
6. POST to `/api/dashboard/layouts/import`
7. Backend validates moduleIds exist
8. Saves as new layout
9. UI loads imported layout

### Switch Theme
1. User selects theme from dropdown
2. ThemeSelector updates local state
3. If layout exists, PUT to `/api/dashboard/layouts/{id}` with themeId
4. Backend persists theme association
5. React Query invalidates layouts
6. Optional: Fetch CSS variables and inject into DOM

## Performance Characteristics

### Load Time
- Initial modules load: ~200ms (37 modules)
- Initial templates load: ~100ms (8 templates)
- User layouts load: ~150ms (varies with count)
- Total: ~450ms (with network latency)

### Runtime
- Grid layout change: <50ms (local state update)
- Module add: ~10ms (local state + map update)
- Save to DB: 300-500ms (network + DB write)
- Import validation: <20ms (Zod parsing)

### Optimization Strategies
1. Query caching - Modules/templates cached indefinitely (assume immutable)
2. Selective invalidation - Only invalidate relevant queries on mutations
3. Lazy rendering - DashboardWidget only renders visible items
4. Grid compaction - Automatic gap filling (no manual collision detection)
5. Memoization - Module references preserved across layout changes

## Error Handling

### Validation Layer
- All requests validated with Zod schemas
- Invalid payloads return 400 with error details
- Invalid moduleIds caught during import

### User Errors
- Network failures: Show toast with retry option
- Invalid file format (import): Show specific error message
- Layout not found (export): Return 404
- Duplicate default layout: Backend auto-handles

### Resilience
- React Query retry logic (configurable)
- Graceful fallback if theme fails to apply
- Empty canvas if no layout selected

## Extensibility Points

### 1. Add New Module Type
```typescript
// In seed.ts
{
  type: "custom", // New type
  name: "My Custom Widget",
  icon: "MyIcon",
  category: "productivity"
}

// In DashboardWidget.tsx
case "custom":
  return <MyCustomWidget module={module} />;
```

### 2. Widget Configuration
```typescript
// Layout item can carry config
{
  i: "widget-123",
  moduleId: 5,
  config: {
    dataSource: "api/custom",
    refreshInterval: 5000,
    colorScheme: "cool"
  }
}

// Widget receives and uses config
export function DashboardWidget({ module, config }) {
  const { dataSource, refreshInterval } = config || {};
  // ...
}
```

### 3. Real Data Integration
```typescript
// In GridLayout.tsx
const { data: widgetData } = useQuery({
  queryKey: [`/api/widget/${item.moduleId}/data`],
  enabled: !!item.moduleId
});

<DashboardWidget module={module} data={widgetData} />
```

### 4. Custom Theme System
```typescript
// Add to seed.ts
{
  name: "Custom Brand Theme",
  tokens: {
    colors: { primary: { h: 280, s: 100, l: 50 }, ... },
    // ...
  }
}
```

### 5. Role-Based Access
```typescript
// In routes.ts
app.get("/api/dashboard/templates", async (req, res) => {
  const userRole = req.user?.role;
  const templates = userRole 
    ? await dashboardService.getTemplatesForRole(userRole)
    : await dashboardService.getAllTemplates();
  res.json(templates);
});
```

## Security Considerations

1. **User Isolation** - userId used to scope all layout queries
2. **Input Validation** - All requests validated with Zod
3. **No SQL Injection** - Drizzle ORM parameterizes queries
4. **CORS** - Restrict to trusted domains if needed
5. **Rate Limiting** - Consider rate limiting on save/import endpoints
6. **File Upload** - Import validates JSON structure before saving

## Deployment Architecture

```
Client (React)
    ↓ HTTPS
Load Balancer
    ↓
Express Server (Node.js)
    ├── /api/dashboard/* endpoints
    └── /api/push-files, /api/batch-push-files (GitHub APIs)
    ↓ Drizzle ORM
PostgreSQL Database
    ├── dashboardModules
    ├── dashboardTemplates
    ├── userDashboardLayouts
    ├── themeTokens
    └── Other application tables
```

### Scaling Considerations
- Stateless Express servers (scale horizontally)
- Read replicas for modules/templates (rarely change)
- Connection pooling for PostgreSQL
- Redis cache for user sessions (if added)
- CDN for frontend assets

## Future Enhancements

1. **Real-time Collaboration** - WebSocket for multi-user editing
2. **Advanced Widgets** - D3 visualizations, dynamic queries
3. **Audit Logging** - Track layout changes, exports
4. **Scheduled Reports** - Dashboard snapshots via email
5. **AI Recommendations** - Suggest modules based on role/data
6. **Mobile App** - Native React Native version
7. **Permissions** - Share layouts with read/edit access
8. **Version History** - Track layout changes over time
