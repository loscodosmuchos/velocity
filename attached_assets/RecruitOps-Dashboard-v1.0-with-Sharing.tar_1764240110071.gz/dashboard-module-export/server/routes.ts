import type { Express } from "express";
import { createServer, type Server } from "http";
import { Octokit } from "@octokit/rest";
import { 
  filePushSchema, 
  batchPushSchema, 
  checkConflictsSchema,
  getModulesSchema,
  getTemplatesSchema,
  saveLayoutSchema,
  applyTemplateSchema,
  switchThemeSchema,
  importLayoutSchema,
} from "@shared/schema";
import type { 
  FileUploadStatus, 
  PushResult, 
  BatchPushResult, 
  RepositoryPushResult,
  ConflictsCheckResult,
  FileConflictInfo
} from "@shared/schema";
import { dashboardService } from "./services/DashboardService";
import { themeService } from "./services/ThemeService";
import { seedDatabase } from "./seed";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/push-files", async (req, res) => {
    try {
      const validatedData = filePushSchema.parse(req.body);
      const { repository, branch, token, files } = validatedData;

      const octokit = new Octokit({ auth: token });
      const [owner, repo] = repository.split('/');

      if (!owner || !repo) {
        return res.status(400).json({ 
          error: "Invalid repository format. Expected: owner/repo" 
        });
      }

      const fileStatuses: FileUploadStatus[] = [];
      let successCount = 0;
      let errorCount = 0;

      for (const file of files) {
        try {
          const contentBase64 = Buffer.from(file.content).toString('base64');

          let sha: string | undefined;
          try {
            const { data: existingFile } = await octokit.repos.getContent({
              owner,
              repo,
              path: file.path,
              ref: branch,
            });

            if ('sha' in existingFile) {
              sha = existingFile.sha;
            }
          } catch (error: any) {
            if (error.status !== 404) {
              throw error;
            }
          }

          const response = await octokit.repos.createOrUpdateFileContents({
            owner,
            repo,
            path: file.path,
            message: "Add Playwright automation",
            content: contentBase64,
            branch,
            ...(sha && { sha }),
          });

          fileStatuses.push({
            filename: file.filename,
            path: file.path,
            status: 'success',
            commitUrl: response.data.commit.html_url,
          });
          successCount++;
        } catch (error: any) {
          fileStatuses.push({
            filename: file.filename,
            path: file.path,
            status: 'error',
            error: error.message || 'Failed to upload file',
          });
          errorCount++;
        }
      }

      const result: PushResult = {
        success: errorCount === 0,
        files: fileStatuses,
        totalFiles: files.length,
        successCount,
        errorCount,
      };

      res.json(result);
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to push files to GitHub';
      console.error('Push files error:', errorMessage);
      res.status(500).json({ 
        error: errorMessage
      });
    }
  });

  // Batch push to multiple repositories
  app.post("/api/batch-push-files", async (req, res) => {
    try {
      const validatedData = batchPushSchema.parse(req.body);
      const { repositories, token, files } = validatedData;

      const octokit = new Octokit({ auth: token });
      const repositoryResults: RepositoryPushResult[] = [];
      let successfulRepos = 0;
      let failedRepos = 0;

      // Process each repository sequentially
      for (const repo of repositories) {
        const { repository, branch } = repo;
        const [owner, repoName] = repository.split('/');

        if (!owner || !repoName) {
          repositoryResults.push({
            repository,
            branch,
            success: false,
            files: [],
            totalFiles: 0,
            successCount: 0,
            errorCount: 0,
            error: "Invalid repository format. Expected: owner/repo"
          });
          failedRepos++;
          continue;
        }

        const fileStatuses: FileUploadStatus[] = [];
        let successCount = 0;
        let errorCount = 0;
        let repoError: string | undefined;

        try {
          // Push files to this repository
          for (const file of files) {
            try {
              const contentBase64 = Buffer.from(file.content).toString('base64');

              let sha: string | undefined;
              try {
                const { data: existingFile } = await octokit.repos.getContent({
                  owner,
                  repo: repoName,
                  path: file.path,
                  ref: branch,
                });

                if ('sha' in existingFile) {
                  sha = existingFile.sha;
                }
              } catch (error: any) {
                if (error.status !== 404) {
                  throw error;
                }
              }

              const response = await octokit.repos.createOrUpdateFileContents({
                owner,
                repo: repoName,
                path: file.path,
                message: "Add Playwright automation",
                content: contentBase64,
                branch,
                ...(sha && { sha }),
              });

              fileStatuses.push({
                filename: file.filename,
                path: file.path,
                status: 'success',
                commitUrl: response.data.commit.html_url,
              });
              successCount++;
            } catch (error: any) {
              fileStatuses.push({
                filename: file.filename,
                path: file.path,
                status: 'error',
                error: error.message || 'Failed to upload file',
              });
              errorCount++;
            }
          }
        } catch (error: any) {
          repoError = error.message || 'Failed to push files to this repository';
        }

        const repoSuccess = errorCount === 0 && !repoError;
        repositoryResults.push({
          repository,
          branch,
          success: repoSuccess,
          files: fileStatuses,
          totalFiles: files.length,
          successCount,
          errorCount,
          error: repoError
        });

        if (repoSuccess) {
          successfulRepos++;
        } else {
          failedRepos++;
        }
      }

      const result: BatchPushResult = {
        success: failedRepos === 0,
        repositories: repositoryResults,
        totalRepositories: repositories.length,
        successfulRepos,
        failedRepos
      };

      res.json(result);
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to batch push files to GitHub';
      console.error('Batch push files error:', errorMessage);
      res.status(500).json({ 
        error: errorMessage
      });
    }
  });

  // Check for file conflicts before pushing
  app.post("/api/check-conflicts", async (req, res) => {
    try {
      const validatedData = checkConflictsSchema.parse(req.body);
      const { repository, branch, token, files } = validatedData;

      const octokit = new Octokit({ auth: token });
      const [owner, repo] = repository.split('/');

      if (!owner || !repo) {
        return res.status(400).json({ 
          error: "Invalid repository format. Expected: owner/repo" 
        });
      }

      const fileConflicts: FileConflictInfo[] = [];
      let conflictCount = 0;
      let newFileCount = 0;

      for (const file of files) {
        try {
          const { data: existingFile } = await octokit.repos.getContent({
            owner,
            repo,
            path: file.path,
            ref: branch,
          });

          if ('sha' in existingFile && 'content' in existingFile) {
            const existingContent = Buffer.from(existingFile.content, 'base64').toString('utf-8');
            fileConflicts.push({
              filename: file.filename,
              path: file.path,
              status: 'conflict',
              existingContent,
              sha: existingFile.sha
            });
            conflictCount++;
          }
        } catch (error: any) {
          if (error.status === 404) {
            fileConflicts.push({
              filename: file.filename,
              path: file.path,
              status: 'new'
            });
            newFileCount++;
          } else {
            fileConflicts.push({
              filename: file.filename,
              path: file.path,
              status: 'error',
              error: error.message || 'Failed to check file'
            });
          }
        }
      }

      const result: ConflictsCheckResult = {
        success: true,
        files: fileConflicts,
        hasConflicts: conflictCount > 0,
        conflictCount,
        newFileCount
      };

      res.json(result);
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to check conflicts';
      console.error('Check conflicts error:', errorMessage);
      res.status(500).json({ 
        error: errorMessage
      });
    }
  });

  // ============================================================================
  // DASHBOARD API ROUTES
  // ============================================================================

  // Initialize database with seed data
  app.post("/api/dashboard/seed", async (req, res) => {
    try {
      await seedDatabase();
      res.json({ success: true, message: "Database seeded successfully" });
    } catch (error: any) {
      console.error("Seed error:", error);
      res.status(500).json({ error: error.message || "Failed to seed database" });
    }
  });

  // Get available dashboard modules
  app.get("/api/dashboard/modules", async (req, res) => {
    try {
      const { category } = req.query;
      const modules = await dashboardService.getAvailableModules(category as string);
      res.json(modules);
    } catch (error: any) {
      console.error("Get modules error:", error);
      res.status(500).json({ error: error.message || "Failed to get modules" });
    }
  });

  // Get dashboard templates
  app.get("/api/dashboard/templates", async (req, res) => {
    try {
      const { role } = req.query;
      const templates = role 
        ? await dashboardService.getTemplatesForRole(role as string)
        : await dashboardService.getAllTemplates();
      res.json(templates);
    } catch (error: any) {
      console.error("Get templates error:", error);
      res.status(500).json({ error: error.message || "Failed to get templates" });
    }
  });

  // Get user's saved layouts
  app.get("/api/dashboard/layouts", async (req, res) => {
    try {
      const userId = "default-user"; // TODO: Get from session/auth
      const layouts = await dashboardService.getUserLayouts(userId);
      res.json(layouts);
    } catch (error: any) {
      console.error("Get layouts error:", error);
      res.status(500).json({ error: error.message || "Failed to get layouts" });
    }
  });

  // Get user's default layout
  app.get("/api/dashboard/layouts/default", async (req, res) => {
    try {
      const userId = "default-user"; // TODO: Get from session/auth
      const layout = await dashboardService.getUserDefaultLayout(userId);
      res.json(layout);
    } catch (error: any) {
      console.error("Get default layout error:", error);
      res.status(500).json({ error: error.message || "Failed to get default layout" });
    }
  });

  // Save user layout
  app.post("/api/dashboard/layouts", async (req, res) => {
    try {
      const validatedData = saveLayoutSchema.parse(req.body);
      const userId = "default-user"; // TODO: Get from session/auth
      
      const layout = await dashboardService.saveUserLayout(
        userId,
        validatedData.name,
        validatedData.layout,
        validatedData.isDefault,
        validatedData.themeId
      );
      
      res.json(layout);
    } catch (error: any) {
      console.error("Save layout error:", error);
      res.status(500).json({ error: error.message || "Failed to save layout" });
    }
  });

  // Update user layout
  app.put("/api/dashboard/layouts/:id", async (req, res) => {
    try {
      const layoutId = parseInt(req.params.id);
      const userId = "default-user"; // TODO: Get from session/auth
      
      const layout = await dashboardService.updateUserLayout(
        layoutId,
        userId,
        req.body
      );
      
      if (!layout) {
        return res.status(404).json({ error: "Layout not found" });
      }
      
      res.json(layout);
    } catch (error: any) {
      console.error("Update layout error:", error);
      res.status(500).json({ error: error.message || "Failed to update layout" });
    }
  });

  // Delete user layout
  app.delete("/api/dashboard/layouts/:id", async (req, res) => {
    try {
      const layoutId = parseInt(req.params.id);
      const userId = "default-user"; // TODO: Get from session/auth
      
      const deleted = await dashboardService.deleteUserLayout(layoutId, userId);
      
      if (!deleted) {
        return res.status(404).json({ error: "Layout not found" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error("Delete layout error:", error);
      res.status(500).json({ error: error.message || "Failed to delete layout" });
    }
  });

  // Export layout as JSON
  app.get("/api/dashboard/layouts/:id/export", async (req, res) => {
    try {
      const layoutId = parseInt(req.params.id);
      const userId = "default-user"; // TODO: Get from session/auth

      const layout = await dashboardService.loadUserLayout(userId, layoutId);

      if (!layout) {
        return res.status(404).json({ error: "Layout not found" });
      }

      const exportData = {
        version: "1.0",
        exportedAt: new Date().toISOString(),
        layout: {
          name: layout.name,
          layout: layout.layout,
          themeId: layout.themeId,
        },
      };

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${layout.name.replace(/[^a-z0-9]/gi, '_')}_dashboard.json"`);
      res.json(exportData);
    } catch (error: any) {
      console.error("Export layout error:", error);
      res.status(500).json({ error: error.message || "Failed to export layout" });
    }
  });

  // Import layout from JSON
  app.post("/api/dashboard/layouts/import", async (req, res) => {
    try {
      const validatedData = importLayoutSchema.parse(req.body);
      const userId = "default-user"; // TODO: Get from session/auth

      const importedLayout = await dashboardService.saveUserLayout(
        userId,
        validatedData.name,
        validatedData.layout,
        false,
        validatedData.themeId
      );

      res.json(importedLayout);
    } catch (error: any) {
      console.error("Import layout error:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          error: "Invalid layout format", 
          details: error.errors 
        });
      }
      
      res.status(500).json({ error: error.message || "Failed to import layout" });
    }
  });

  // Apply template
  app.post("/api/dashboard/templates/apply", async (req, res) => {
    try {
      const validatedData = applyTemplateSchema.parse(req.body);
      const userId = "default-user"; // TODO: Get from session/auth
      
      const layout = await dashboardService.applyTemplate(
        validatedData.templateId,
        userId,
        validatedData.saveAs
      );
      
      res.json(layout);
    } catch (error: any) {
      console.error("Apply template error:", error);
      res.status(500).json({ error: error.message || "Failed to apply template" });
    }
  });

  // Get available themes
  app.get("/api/dashboard/themes", async (req, res) => {
    try {
      const themes = await themeService.getThemes();
      res.json(themes);
    } catch (error: any) {
      console.error("Get themes error:", error);
      res.status(500).json({ error: error.message || "Failed to get themes" });
    }
  });

  // Get specific theme
  app.get("/api/dashboard/themes/:id", async (req, res) => {
    try {
      const themeId = parseInt(req.params.id);
      const theme = await themeService.getTheme(themeId);
      
      if (!theme) {
        return res.status(404).json({ error: "Theme not found" });
      }
      
      res.json(theme);
    } catch (error: any) {
      console.error("Get theme error:", error);
      res.status(500).json({ error: error.message || "Failed to get theme" });
    }
  });

  // Get theme CSS variables
  app.get("/api/dashboard/themes/:id/css", async (req, res) => {
    try {
      const themeId = parseInt(req.params.id);
      const theme = await themeService.getTheme(themeId);
      
      if (!theme) {
        return res.status(404).json({ error: "Theme not found" });
      }
      
      const css = themeService.generateCSSVariables(theme);
      res.type('text/css').send(css);
    } catch (error: any) {
      console.error("Get theme CSS error:", error);
      res.status(500).send("/* Error generating CSS */");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
