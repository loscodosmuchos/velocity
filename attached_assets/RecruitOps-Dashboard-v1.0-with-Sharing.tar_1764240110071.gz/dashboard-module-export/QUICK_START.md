# Quick Start - 5 Minute Integration

## Step 1: Copy Files (30 seconds)
```bash
# Copy all files from this package to your Velocity project:
cp -r client/src/components/dashboard/* YOUR_PROJECT/client/src/components/dashboard/
cp client/src/pages/DashboardBuilder.tsx YOUR_PROJECT/client/src/pages/
cp server/services/*.ts YOUR_PROJECT/server/services/
cp shared/schema.ts YOUR_PROJECT/shared/
cp server/routes.ts YOUR_PROJECT/server/routes.ts (merge with existing)
cp server/seed.ts YOUR_PROJECT/server/seed.ts (merge or integrate)
```

## Step 2: Update Schema (1 minute)
In `shared/schema.ts`, add these imports if missing:
```typescript
import { pgTable, serial, text, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
```

Then add the 7 tables from the schema.ts in this package (dashboardModules, dashboardTemplates, userDashboardLayouts, themeTokens, etc.)

## Step 3: Run Migration (1 minute)
```bash
npm run db:push
npm run db:push --force  # If there are conflicts
```

## Step 4: Seed Database (30 seconds)
```bash
curl -X POST http://localhost:5000/api/dashboard/seed
# or make request in browser to POST /api/dashboard/seed
```

Verify: `SELECT COUNT(*) FROM dashboard_modules;` should return 37

## Step 5: Add Route to App.tsx (30 seconds)
```typescript
import DashboardBuilder from '@/pages/DashboardBuilder';

export default function App() {
  return (
    <Switch>
      {/* Existing routes */}
      <Route path="/dashboard" component={DashboardBuilder} />
      {/* ... */}
    </Switch>
  );
}
```

## Step 6: Update userId in routes.ts (30 seconds)
Find all instances of `"default-user"` in server/routes.ts and replace with:
```typescript
const userId = (req as any).user?.id || "default-user";
```

## Done! 
Visit `http://localhost:5000/dashboard` to see it working.

## Testing
- [x] Can you see 37 modules in the sidebar?
- [x] Can you apply a template?
- [x] Can you drag modules around?
- [x] Can you save a layout?
- [x] Can you export a layout?
- [x] Can you switch themes?

If yes to all, integration is complete!

## Troubleshooting
- **Blank sidebar?** → Check `/api/dashboard/modules` returns data
- **Grid not responsive?** → Verify react-grid-layout CSS imported
- **Can't save?** → Check userId extraction is working
- **Errors on import?** → Check browser console for Zod validation errors

See INTEGRATION_GUIDE.md for full documentation.
