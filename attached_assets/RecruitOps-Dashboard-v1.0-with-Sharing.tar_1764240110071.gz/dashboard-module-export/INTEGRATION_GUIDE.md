# Dashboard Module Integration Guide for Velocity

## Overview
This package contains the complete dashboard builder system from RecruitOps Platform. It's production-ready and designed to be integrated into Velocity with minimal modifications.

## Package Contents

### Frontend Components (`client/src/components/dashboard/`)
- **DashboardBuilder.tsx** - Main container with layout/template/theme orchestration
- **GridLayout.tsx** - React-grid-layout wrapper with responsive grid (12 cols, 100px rows)
- **ModulePalette.tsx** - Scrollable module catalog grouped by category
- **TemplateSelector.tsx** - System templates + saved layouts with load/apply functionality
- **DashboardWidget.tsx** - Widget renderer (KPI, Chart, Table, Widget types with demo data)
- **ThemeSelector.tsx** - Dropdown to switch themes with persistence
- **SaveLayoutDialog.tsx** - Form to save layouts with default flag

### Backend Services (`server/services/`)
- **DashboardService.ts** - Core business logic (CRUD for modules, templates, layouts)
- **ThemeService.ts** - Theme management and CSS generation

### Data & Routes
- **shared/schema.ts** - Complete Zod schemas and TypeScript types (7 tables)
- **server/routes.ts** - All API endpoints (dashboard APIs + GitHub APIs)
- **server/seed.ts** - Database seeding with 37 modules, 8 templates, 4 themes

## Critical Integration Points

### 1. Database Setup
```bash
# Add these tables to your PostgreSQL schema (in shared/schema.ts):
- dashboardModules (37 predefined modules)
- dashboardTemplates (8 role-based templates)
- userDashboardLayouts (user customizations)
- themeTokens (4 design themes)
- layoutItems (for layout serialization)
- moduleCategories (for organization)
- userPreferences (for user settings)

# Run migration:
npm run db:push
```

**Key Insight:** The schema uses `integer` IDs for modules/templates and `text` for user_id to support multi-tenant scenarios. If you have existing user tables, ensure userId field type matches.

### 2. API Routes Integration
All routes are in `server/routes.ts`. Add these endpoints to your Express app:

**Dashboard Routes:**
- `GET /api/dashboard/modules` - Fetch all modules (supports category filter)
- `GET /api/dashboard/templates` - Fetch templates (supports role filter)
- `GET /api/dashboard/layouts` - Get user's saved layouts
- `POST /api/dashboard/layouts` - Save new layout
- `PUT /api/dashboard/layouts/:id` - Update layout
- `DELETE /api/dashboard/layouts/:id` - Delete layout
- `GET /api/dashboard/layouts/:id/export` - Export as JSON
- `POST /api/dashboard/layouts/import` - Import from JSON
- `POST /api/dashboard/templates/apply` - Apply template
- `GET /api/dashboard/themes` - Fetch all themes
- `GET /api/dashboard/themes/:id` - Get specific theme
- `GET /api/dashboard/themes/:id/css` - Generate CSS variables
- `POST /api/dashboard/seed` - Initialize database (call on first setup)

### 3. Frontend Page Integration
```typescript
// In your App.tsx or routing, add:
import DashboardBuilder from '@/pages/DashboardBuilder';

// Route: /dashboard
<Route path="/dashboard" component={DashboardBuilder} />
```

### 4. Required Dependencies
Ensure these are in package.json:
- `react-grid-layout` - Layout grid system
- `@tanstack/react-query` - Data fetching/caching
- `zod` - Schema validation
- `drizzle-orm` - Database ORM
- All @radix-ui/* components used in shadcn

### 5. Theme System
Themes are stored as JSON in database and injected as CSS variables. The ThemeService converts theme tokens to:
```css
--color-primary: H S% L%;
--color-secondary: H S% L%;
--spacing-base: Xpx;
--font-family: name;
--border-radius-sm/md/lg: Xpx;
```

**Key Insight:** Themes use HSL (Hue, Saturation %, Lightness %) format for dynamic color manipulation. Store as `{ h: number, s: number, l: number }`.

### 6. User Context
- Routes currently use `"default-user"` as placeholder for userId
- **TODO:** Replace with actual auth context:
  ```typescript
  const userId = req.user?.id || req.session?.userId;
  ```
- This ensures multi-user isolation for layouts and preferences

## Module Architecture (37 Total)

### Categories
1. **Recruitment (7)** - Candidate, requisition, time-to-hire, offers, funnel, sources, interviews
2. **Procurement (11)** - Vendors, spend, contractors, compliance, risk, SOW cycle, savings, trends, renewals
3. **Project Mgmt (7)** - Portfolio health, at-risk projects, resource util, dependencies, heatmap
4. **IT/Systems (6)** - Uptime, integrations, tech debt, API response, performance
5. **VMS (4)** - Contractor compliance, skills gap, performance, certifications
6. **Finance (3)** - Spend trends, budget variance, cost per hire
7. **Productivity (1)** - Quick actions widget

### Widget Types
- **KPI** - Single metric with trend badge (2x2 default)
- **Chart** - Bar/line visualization (6x4 default)
- **Table** - Data grid with demo rows (6x4 or 12x4)
- **Widget** - Quick action buttons (3x4)

**Key Insight:** All widgets use demo data from `getDemoData()` in DashboardWidget.tsx. Replace with real data fetching by:
1. Adding data queries to GridLayout or individual widgets
2. Using TanStack Query to fetch widget-specific data
3. Passing config to widgets via layout items' `config` property

## Template System (8 Total)

Persona-based templates:
1. **Recruiter** - Candidate flow, funnel, sources (Warm Recruiter theme)
2. **CPO** - Vendor risk, compliance, savings (Modern Professional theme)
3. **Senior PM** - Portfolio, at-risk, dependencies (Modern Professional theme)
4. **IT Director** - System health, integrations, tech debt (Dark Executive theme)
5. **VMS Specialist** - Compliance, skills gap, performance (Modern Professional theme)
6. **C-Suite Executive** - Strategic KPIs, costs, health (Dark Executive theme)
7. **HR Director** - Full recruitment + contractors (Warm Recruiter theme)
8. **Vendor Manager** - Vendor performance, compliance (Modern Professional theme)

**Key Insight:** Each template has pre-configured layouts (grid positions, sizes, modules). Templates are immutable; users create copies when customizing.

## Export/Import System

### Export Format
```json
{
  "version": "1.0",
  "exportedAt": "2025-01-14T...",
  "layout": {
    "name": "Dashboard Name",
    "layout": [
      {
        "i": "module-1234567890",
        "x": 0, "y": 0, "w": 3, "h": 2,
        "moduleId": 5,
        "config": { "customProp": "value" }
      }
    ],
    "themeId": 1
  }
}
```

**Key Insight:** Export validation uses `layoutItemSchema` from Zod. Import validates before saving. This ensures configs shared between users don't break due to version mismatches.

## Performance Optimizations Applied

1. **Grid Compaction** - `compactType="vertical"` automatically arranges items
2. **Responsive Breakpoints** - lg/md/sm/xs/xxs columns adapt to screen
3. **Query Caching** - TanStack Query caches modules/templates/layouts
4. **Lazy Widget Rendering** - Only visible widgets render demo data
5. **Module Palette Grouping** - Categories lazy-loaded, virtualized scrolling
6. **Memoization** - Layout changes preserve module references

## Common Integration Issues & Solutions

### Issue: "Module not found" errors
**Solution:** Ensure `npm run db:push` completes before seeding. Check if seed.ts is called on app startup:
```typescript
// In your index.ts or main entry:
import { seedDatabase } from "./seed";
await seedDatabase(); // Call once on startup
```

### Issue: Themes not applying
**Solution:** Check theme CSS variables are injected into document:
```typescript
// In frontend useEffect:
const response = await fetch(`/api/dashboard/themes/${themeId}/css`);
const css = await response.text();
const styleEl = document.createElement('style');
styleEl.textContent = css;
document.head.appendChild(styleEl);
```

### Issue: Grid layout broken on mobile
**Solution:** React-grid-layout handles responsive automatically. Ensure:
- No overflow-hidden on parent containers
- Sidebar width defined in parent layout, not grid
- Cols property matches breakpoint definitions

### Issue: User layouts not persisting
**Solution:** Verify userId extraction from auth context. Currently hardcoded to "default-user":
```typescript
// Change line in routes.ts:
const userId = (req as any).user?.id || "default-user";
```

## Data Flow Diagram

```
User Interface (DashboardBuilder)
    ↓
React Query Cache (queryKey: ['/api/dashboard/...'])
    ↓
Backend Routes (Express endpoints)
    ↓
DashboardService / ThemeService (business logic)
    ↓
PostgreSQL Database (Drizzle ORM)
    ↓
Schema validation (Zod schemas)
```

## State Management Strategy

- **Backend State:** PostgreSQL (modules, templates, layouts, themes)
- **Client Cache:** React Query (automatic invalidation on mutations)
- **Component State:** React useState (UI-only: dialogs, loading states)
- **Grid State:** Local state in DashboardBuilder (layout array)

**Key Insight:** Layouts are immutable in DB but mutable in UI state. Only save after user clicks "Save".

## Customization Points

1. **Add New Module Type:**
   - Add to seed.ts with unique `icon` and `type`
   - Update DashboardWidget.tsx switch statement
   - Test with different `defaultSize` values

2. **Create Custom Theme:**
   - Add to seed.ts themeTokens with HSL colors
   - Reference in templates via themeId
   - CSS variables auto-generate from tokens

3. **Extend Widget Config:**
   - Add fields to `layoutItemSchema` in shared/schema.ts
   - Pass config to widget via props in GridLayout.tsx
   - Widget interprets config for custom behavior

4. **Add Real Data:**
   - Replace `getDemoData()` with API calls
   - Use React Query in GridLayout for data fetching
   - Widget receives real data via props instead of hardcoded

## Deployment Considerations

1. **Database:** Use PostgreSQL with Neon or standard pg driver
2. **API:** All routes stateless (no session state required yet)
3. **Frontend:** Standard React bundle, no special build config needed
4. **Assets:** No static assets (all inline SVG icons from lucide-react)
5. **Environment:** No env vars required currently

## Testing Checklist

- [ ] Database tables created and seeded
- [ ] GET /api/dashboard/modules returns 37 modules
- [ ] GET /api/dashboard/templates returns 8 templates
- [ ] POST /api/dashboard/layouts saves and returns ID
- [ ] Export generates valid JSON with correct schema
- [ ] Import validates JSON and rejects malformed configs
- [ ] Theme selector switches between 4 themes
- [ ] Grid layout responsive on mobile/tablet/desktop
- [ ] Module palette scrolls and groups by category
- [ ] Template selector shows system + saved layouts
- [ ] Drag-and-drop reorders modules in grid
- [ ] Resize handles work on all widgets

## Maintenance Notes

- **seed.ts:** Run once on startup or manually via `POST /api/dashboard/seed`
- **Modules:** Add new ones via admin UI or direct DB insert
- **Templates:** Can be created by users or pre-loaded via seed
- **Themes:** 4 included; add more by extending seed.ts
- **Layouts:** User data accumulates; consider cleanup jobs for unused layouts

## Support & Debugging

1. Check browser console for React Query errors
2. Check server logs for Zod validation failures
3. Verify userId is properly extracted from auth context
4. Test API endpoints directly with curl/Postman
5. Check database with `SELECT * FROM dashboard_modules;` etc.

## Version History

- **v1.0** - Initial release with 37 modules, 8 templates, 4 themes
- **Future:** WebSocket real-time updates, advanced widget config, AI-powered recommendations
