# ElevenLabs Integration: Complete Code Examples & Working Formats

**Document Purpose:** Comprehensive reference with working code examples, API formats, webhook payloads, and copy-paste templates for ElevenLabs conversational AI implementation.

**Version:** 2.0  
**Date:** November 5, 2025

---

## Table of Contents

1. [API Authentication & Setup](#api-authentication--setup)
2. [Agent Creation via API](#agent-creation-via-api)
3. [System Prompt Formats & Examples](#system-prompt-formats--examples)
4. [Voice Configuration & Audio Tags](#voice-configuration--audio-tags)
5. [Workflow Node Structures](#workflow-node-structures)
6. [Data Collection Configuration](#data-collection-configuration)
7. [Webhook Payload Examples](#webhook-payload-examples)
8. [Twilio Integration Code](#twilio-integration-code)
9. [Complete Working Examples](#complete-working-examples)

---

## 1. API Authentication & Setup

### Base Configuration

```bash
# Environment Variables
export ELEVENLABS_API_KEY="your_api_key_here"
export ELEVENLABS_BASE_URL="https://api.elevenlabs.io/v1"
```

### Authentication Headers

```javascript
// JavaScript/Node.js
const headers = {
  'xi-api-key': process.env.ELEVENLABS_API_KEY,
  'Content-Type': 'application/json'
};
```

```python
# Python
headers = {
    'xi-api-key': os.getenv('ELEVENLABS_API_KEY'),
    'Content-Type': 'application/json'
}
```

```bash
# cURL
curl -X POST "https://api.elevenlabs.io/v1/convai/agents" \
  -H "xi-api-key: YOUR_API_KEY" \
  -H "Content-Type: application/json"
```

---

## 2. Agent Creation via API

### Create Basic Agent

```json
POST https://api.elevenlabs.io/v1/convai/agents

{
  "name": "VINessa Project Assistant",
  "voice_id": "21m00Tcm4TlvDq8ikWAM",
  "first_message": "Hello! I'm VINessa, your AI project information specialist. I'll help you capture project details in just 2-3 minutes. Ready to get started?",
  "language": "en",
  "conversation_config": {
    "model_id": "eleven_turbo_v2_5",
    "stability": 0.75,
    "similarity_boost": 0.85,
    "style": 0.65,
    "use_speaker_boost": true
  }
}
```

### Response Format

```json
{
  "agent_id": "agent_abc123xyz",
  "name": "VINessa Project Assistant",
  "voice_id": "21m00Tcm4TlvDq8ikWAM",
  "status": "active",
  "created_at": "2025-11-05T08:27:00Z"
}
```

---

## 3. System Prompt Formats & Examples

### Basic System Prompt Structure

```json
{
  "system_prompt": {
    "content": "You are [AGENT IDENTITY]. Your mission is [CORE PURPOSE]. \n\nKey Responsibilities:\n- [Responsibility 1]\n- [Responsibility 2]\n- [Responsibility 3]\n\nConversational Style:\n- [Style guideline 1]\n- [Style guideline 2]\n\nConversation Flow:\n1. [Step 1]\n2. [Step 2]\n3. [Step 3]",
    "version": "1.0"
  }
}
```

### Complete VINessa System Prompt Example

```text
You are VINessa, the AI Project Information Specialist for Velocity. Your mission is to capture project data in 2-3 minutes through natural conversation, providing immediate relief to time-starved project managers and field teams. You are an ally, not an auditor—your goal is clarity and control, never judgment or performance review.

VOICE SETTINGS:
- Model: Eleven Turbo v2.5
- Speaking Rate: Slightly faster than normal (conversational efficiency)
- Style: Professional but warm, consultative not interrogative
- Use [brief pause] for transitions between questions

CORE RESPONSIBILITIES:
1. Capture 5 essential project data points
2. Detect and flag crisis indicators
3. Identify missing critical information
4. Provide immediate value through active listening

CONVERSATIONAL APPROACH:
- Ask ONE question at a time
- Acknowledge and validate responses
- Use context from previous answers to make connections
- Never ask for information already provided
- If user seems rushed, offer "Quick Mode" (2 minutes)

5 ESSENTIAL QUESTIONS:
1. "What's the project name and who's managing it?"
2. "What's the main purpose or goal of this project?"
3. "Who are the key stakeholders involved?"
4. "What's the current status and any immediate risks?"
5. "What are the key deadlines and budget situation?"

CRISIS DETECTION:
Listen for these keywords and FLAG immediately:
- "Crisis", "urgent", "panic", "emergency"
- "No documentation", "completely lost", "no idea"
- "Budget blown", "way over budget"
- "Deadline missed", "already late"
- "Stakeholder angry", "client escalation"

If crisis detected, say:
"I'm flagging this as urgent for executive review. Let me make sure we capture this accurately."

HANDLING INCOMPLETE INFORMATION:
If user doesn't know something, respond:
"No problem—I'll flag that for follow-up. Let's move to the next question."

CLOSING:
After 5 questions, say:
"Perfect! I've captured the key details. Your project data is saved and ready for the dashboard. Is there anything critical I should add before we wrap up?"

TONE EXAMPLES:
✅ "Great! So this is a network upgrade for Building B, managed by Sarah. Got it."
✅ "I'm hearing some urgency around the timeline—let me make sure we flag that."
✅ "That's really helpful context. Let me capture that detail."
❌ "Why didn't you document that?" (Never judgmental)
❌ "You should have..." (Never prescriptive)
```

---

## 4. Voice Configuration & Audio Tags

### Voice Parameter Structure

```json
{
  "voice_id": "21m00Tcm4TlvDq8ikWAM",
  "voice_settings": {
    "stability": 0.75,
    "similarity_boost": 0.85,
    "style": 0.65,
    "use_speaker_boost": true
  },
  "model_id": "eleven_turbo_v2_5"
}
```

### Audio Tags Reference

```text
EMOTION TAGS:
[laughs] - Natural laughter
[chuckles] - Light laughter
[sighs] - Exhale/relief sound
[gasps] - Surprise sound
[clears throat] - Attention getter

DELIVERY TAGS:
[whispers] - Quiet, confidential tone
[shouts] - Loud, emphatic tone
[yells] - Very loud emphasis
[speaks quickly] - Faster speech rate
[speaks slowly] - Slower, deliberate pace

PAUSE TAGS:
[pause] - Brief pause
[long pause] - Extended pause (1-2 seconds)
[brief pause] - Very short pause

INTONATION:
Use punctuation:
- Ellipsis (...) for trailing off or hesitation
- Em dash (—) for interruption or sudden shift
- Exclamation (!) for emphasis or excitement
- Question mark (?) for inquiry
- CAPITALS for STRONG emphasis
```

### Audio Tag Usage Examples

```text
Example 1 - Building Rapport:
"Welcome to Velocity! [brief pause] I'm VINessa, and I'm here to make your project reporting [chuckles] actually painless for once."

Example 2 - Crisis Detection:
"Okay... [pause] I'm hearing some urgency here. [serious tone] Let me make sure we capture this accurately so the right people are notified immediately."

Example 3 - Empathy:
"I totally understand—[sighs] project documentation can feel overwhelming when you're already stretched thin. Let's just focus on the essentials right now."

Example 4 - Encouragement:
"Perfect! [enthusiastic] You're doing great. Just one more question and we're done."

Example 5 - Whisper for Aside:
"Between you and me, [whispers] the executives love when they get early warnings like this. You're helping them catch problems before they explode."
```

---

## 5. Workflow Node Structures

### Node Types

ElevenLabs workflows use a graph-based structure with these node types:

1. **Subagent Node** - Updates agent configuration mid-conversation
2. **Tool Node** - Executes server-side functions/APIs
3. **End Node** - Terminates conversation
4. **Transfer Node** - Routes to another agent or phone number

### Subagent Node JSON Structure

```json
{
  "node_id": "qualification_node",
  "node_type": "subagent",
  "configuration": {
    "system_prompt_addition": "You are now in QUALIFICATION mode. Your goal is to determine if the user wants:\n1. Premium deal\n2. Refund request\n3. Generic meeting booking\n\nAsk clarifying questions if intent is unclear.",
    "voice_override": null,
    "model_override": null,
    "knowledge_base_ids": ["kb_abc123"],
    "tools": ["tool_verify_user", "tool_check_eligibility"]
  },
  "edges": [
    {
      "condition_type": "llm",
      "condition": "User expresses interest in premium deal",
      "target_node_id": "premium_deal_node"
    },
    {
      "condition_type": "llm",
      "condition": "User requests refund",
      "target_node_id": "refund_node"
    },
    {
      "condition_type": "llm",
      "condition": "User wants to book a meeting",
      "target_node_id": "meeting_booking_node"
    }
  ]
}
```

### Tool Node JSON Structure

```json
{
  "node_id": "validate_data_node",
  "node_type": "tool",
  "configuration": {
    "tool_name": "ValidateProjectData",
    "required": true,
    "parameters": {
      "project_name": "{{extracted.project_name}}",
      "project_manager": "{{extracted.project_manager}}",
      "deadline": "{{extracted.deadline}}"
    }
  },
  "edges": [
    {
      "condition_type": "api_response",
      "condition": "validation_status == 'success'",
      "target_node_id": "summary_node"
    },
    {
      "condition_type": "api_response",
      "condition": "validation_status == 'failed'",
      "target_node_id": "retry_collection_node"
    }
  ]
}
```

### End Node JSON Structure

```json
{
  "node_id": "conversation_complete",
  "node_type": "end",
  "configuration": {
    "closing_message": "Thank you for providing your project details! Your information has been saved and the team will be notified. Have a great day!",
    "post_call_actions": [
      "trigger_webhook",
      "send_summary_email"
    ]
  }
}
```

### Transfer Node JSON Structure

```json
{
  "node_id": "transfer_to_human",
  "node_type": "transfer",
  "configuration": {
    "transfer_type": "phone_number",
    "destination": "+15551234567",
    "transfer_message": "I'm transferring you to our project management specialist who can help you further. Please hold for just a moment."
  }
}
```

---

## 6. Data Collection Configuration

### Data Collection Rules Structure

```json
{
  "data_collection": {
    "enabled": true,
    "rules": [
      {
        "field_name": "project_name",
        "field_type": "string",
        "description": "Extract the complete name of the project mentioned by the user. Look for phrases like 'the project is called', 'we're working on', or 'the [X] project'. Return null if not mentioned.",
        "required": true,
        "validation": {
          "min_length": 3,
          "max_length": 200
        }
      },
      {
        "field_name": "project_manager",
        "field_type": "string",
        "description": "Extract the full name of the project manager. Look for phrases like 'managed by', 'the PM is', '[Name] is running it', or 'I'm the project manager'. Extract first and last name if provided. Return null if not mentioned.",
        "required": true
      },
      {
        "field_name": "project_purpose",
        "field_type": "text",
        "description": "Extract a concise description of why this project exists or what problem it solves. Look for phrases like 'the goal is to', 'we're trying to', 'this will help us', or 'the purpose is'. Return null if not mentioned.",
        "required": true,
        "validation": {
          "min_length": 10,
          "max_length": 500
        }
      },
      {
        "field_name": "stakeholders",
        "field_type": "array",
        "description": "Extract all mentioned stakeholders including names and roles. Look for phrases like 'key stakeholders include', 'working with', 'reports to', 'CFO', 'CTO', 'VP of', etc. Return as array of objects with 'name' and 'role' properties. Return empty array if none mentioned.",
        "required": false,
        "item_structure": {
          "name": "string",
          "role": "string"
        }
      },
      {
        "field_name": "current_status",
        "field_type": "enum",
        "description": "Extract the current project status. Map user responses to one of these values: 'Not Started', 'Planning', 'In Progress', 'On Hold', 'Completed', 'Cancelled'. Look for phrases like 'we're currently', 'status is', 'just started', 'almost done', etc. Return null if not mentioned.",
        "enum_values": ["Not Started", "Planning", "In Progress", "On Hold", "Completed", "Cancelled"],
        "required": true
      },
      {
        "field_name": "deadline",
        "field_type": "date",
        "description": "Extract the project deadline or target completion date. Look for dates mentioned in various formats (MM/DD/YYYY, 'end of Q2', 'by December', 'in 3 months', etc.). Convert to YYYY-MM-DD format. Return null if not mentioned.",
        "required": true,
        "format": "YYYY-MM-DD"
      },
      {
        "field_name": "immediate_risks",
        "field_type": "text",
        "description": "Extract any mentioned risks, blockers, or concerns. Look for phrases like 'worried about', 'risk of', 'problem is', 'concerned that', 'blocked by', etc. Return null if no risks mentioned.",
        "required": false
      },
      {
        "field_name": "budget_status",
        "field_type": "string",
        "description": "Extract budget information including total budget and amount spent. Look for phrases like '$X allocated', 'budget of', 'spent $Y', 'under/over budget', etc. Format as 'Total: $X, Spent: $Y' or similar. Return null if not mentioned.",
        "required": false
      },
      {
        "field_name": "crisis_flag",
        "field_type": "boolean",
        "description": "Set to true if user mentions any crisis keywords: 'urgent', 'crisis', 'panic', 'emergency', 'disaster', 'completely lost', 'no idea', 'way over budget', 'deadline missed', 'stakeholder angry', 'client escalation'. Otherwise false.",
        "required": true,
        "default": false
      },
      {
        "field_name": "confidence_scores",
        "field_type": "object",
        "description": "For each captured field, assess confidence level (0-100) based on clarity and completeness of user's response. Return as object with field names as keys and confidence scores as values.",
        "required": false
      }
    ]
  }
}
```

### Success Evaluation Criteria

```json
{
  "success_evaluation": {
    "enabled": true,
    "criteria": [
      {
        "criterion_id": "all_required_fields_collected",
        "description": "Evaluate if ALL required fields have been successfully collected: project_name, project_manager, project_purpose, current_status, and deadline. Return SUCCESS if all 5 fields are present and not null. Return FAILURE if any required field is missing. Provide rationale explaining which fields were collected and which were missed.",
        "priority": "critical"
      },
      {
        "criterion_id": "conversation_duration_efficient",
        "description": "Evaluate if the conversation was completed in 2-5 minutes (120-300 seconds). Return SUCCESS if duration is within range. Return FAILURE if duration exceeds 5 minutes. Return UNKNOWN if duration cannot be determined. Provide rationale with actual duration.",
        "priority": "high"
      },
      {
        "criterion_id": "crisis_properly_flagged",
        "description": "Evaluate if crisis situations were properly detected and flagged. Return SUCCESS if crisis_flag is true when crisis keywords were used, or false when no crisis keywords were used. Return FAILURE if crisis was mentioned but not flagged. Provide rationale referencing specific keywords.",
        "priority": "critical"
      },
      {
        "criterion_id": "stakeholder_depth_adequate",
        "description": "Evaluate if at least 3 stakeholders were identified with both name and role. Return SUCCESS if 3+ stakeholders collected with complete information. Return FAILURE if fewer than 3 stakeholders or incomplete information. Provide rationale with count.",
        "priority": "medium"
      },
      {
        "criterion_id": "follow_up_items_identified",
        "description": "Evaluate if agent identified and flagged any missing information that requires follow-up. Return SUCCESS if gaps were detected and flagged for follow-up. Return FAILURE if obvious gaps exist but were not flagged. Provide rationale listing specific gaps.",
        "priority": "high"
      }
    ]
  }
}
```

---

## 7. Webhook Payload Examples

### Post-Call Webhook Configuration

```json
{
  "webhook_config": {
    "url": "https://your-server.com/api/elevenlabs/webhook",
    "method": "POST",
    "headers": {
      "Authorization": "Bearer YOUR_WEBHOOK_SECRET",
      "Content-Type": "application/json"
    },
    "trigger": "call_ended",
    "include_transcript": true,
    "include_audio_recording": false
  }
}
```

### Complete Webhook Payload Example

```json
{
  "event_type": "conversation.ended",
  "conversation_id": "conv_a1b2c3d4e5f6",
  "agent_id": "agent_vinessa_01",
  "timestamp": "2025-11-05T14:30:45Z",
  "metadata": {
    "duration_seconds": 185,
    "call_direction": "inbound",
    "caller_phone": "+15551234567",
    "caller_location": "US",
    "call_quality_score": 95
  },
  "transcript": {
    "full_text": "Agent: Hello! I'm VINessa, your AI project information specialist...[full conversation]",
    "turns": [
      {
        "speaker": "agent",
        "text": "Hello! I'm VINessa, your AI project information specialist. I'll help you capture project details in just 2-3 minutes. Ready to get started?",
        "timestamp": "2025-11-05T14:27:00Z"
      },
      {
        "speaker": "user",
        "text": "Yes, I'm ready. This is about the Building B network upgrade project.",
        "timestamp": "2025-11-05T14:27:05Z"
      }
    ]
  },
  "extracted_data": {
    "project_name": "Building B Network Upgrade",
    "project_manager": "Sarah Chen",
    "project_purpose": "Replace end-of-life Cisco switches with modern equipment to prevent network outages",
    "stakeholders": [
      {"name": "John Smith", "role": "VP of IT"},
      {"name": "Lisa Wong", "role": "CTO"},
      {"name": "Mike Johnson", "role": "Support Lead"}
    ],
    "current_status": "In Progress",
    "deadline": "2025-12-15",
    "immediate_risks": "End-of-life equipment, no spare parts available, vendor lead time 6 weeks",
    "budget_status": "Total: $50,000, Spent: $30,000",
    "crisis_flag": false,
    "confidence_scores": {
      "project_name": 100,
      "project_manager": 100,
      "project_purpose": 95,
      "stakeholders": 100,
      "current_status": 100,
      "deadline": 90,
      "immediate_risks": 100,
      "budget_status": 85
    }
  },
  "evaluation_results": {
    "all_required_fields_collected": {
      "result": "SUCCESS",
      "rationale": "All 5 required fields successfully collected: project_name (100% confidence), project_manager (100% confidence), project_purpose (95% confidence), current_status (100% confidence), deadline (90% confidence)."
    },
    "conversation_duration_efficient": {
      "result": "SUCCESS",
      "rationale": "Conversation completed in 185 seconds (3 minutes 5 seconds), which is within the target range of 2-5 minutes."
    },
    "crisis_properly_flagged": {
      "result": "SUCCESS",
      "rationale": "No crisis keywords detected in conversation. Crisis flag correctly set to false."
    },
    "stakeholder_depth_adequate": {
      "result": "SUCCESS",
      "rationale": "3 stakeholders identified with complete name and role information."
    },
    "follow_up_items_identified": {
      "result": "SUCCESS",
      "rationale": "Agent identified potential follow-up needed for vendor contract details and backup plan documentation."
    }
  },
  "follow_up_items": [
    "Confirm vendor contract details and lead time guarantees",
    "Document backup plan if vendor delays occur",
    "Get CFO approval on potential budget variance"
  ],
  "audio_recording_url": null
}
```

---

## 8. Twilio Integration Code

### Twilio Outbound Call (SMS Trigger → ElevenLabs Call)

```javascript
// server.js - Node.js with Express
const express = require('express');
const twilio = require('twilio');
const axios = require('axios');

const app = express();
app.use(express.urlencoded({ extended: false }));

// Twilio SMS Webhook Handler
app.post('/twilio/sms', async (req, res) => {
  const { From, Body } = req.body;
  const command = Body.trim().toUpperCase();
  
  const twiml = new twilio.twiml.MessagingResponse();
  
  if (command === 'CALLBACK') {
    try {
      // Trigger ElevenLabs outbound call
      const response = await axios.post(
        'https://api.elevenlabs.io/v1/convai/conversation/initiate',
        {
          agent_id: process.env.ELEVENLABS_AGENT_ID,
          phone_number: From,
          metadata: {
            trigger: 'sms_callback_request',
            requested_at: new Date().toISOString()
          }
        },
        {
          headers: {
            'xi-api-key': process.env.ELEVENLABS_API_KEY,
            'Content-Type': 'application/json'
          }
        }
      );
      
      twiml.message('VINessa is calling you now! 📞');
      console.log('ElevenLabs call initiated:', response.data);
      
    } catch (error) {
      console.error('Error initiating call:', error);
      twiml.message('Sorry, something went wrong. Please try again in a moment.');
    }
  } else {
    twiml.message('Send CALLBACK to receive a call from VINessa.');
  }
  
  res.type('text/xml');
  res.send(twiml.toString());
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

### Twilio Inbound Call → ElevenLabs Agent

```javascript
// Twilio Voice Webhook Handler
app.post('/twilio/voice', async (req, res) => {
  const { From, CallSid } = req.body;
  
  // Connect to ElevenLabs WebSocket or HTTP endpoint
  const twiml = new twilio.twiml.VoiceResponse();
  
  // Option 1: Forward to ElevenLabs SIP endpoint
  twiml.dial().sip(`sip:${process.env.ELEVENLABS_SIP_URI}`);
  
  // Option 2: Use Twilio Stream to send audio to ElevenLabs
  const connect = twiml.connect();
  connect.stream({
    url: `wss://your-server.com/media-stream?call_sid=${CallSid}`
  });
  
  res.type('text/xml');
  res.send(twiml.toString());
});

// WebSocket handler for real-time audio streaming
const WebSocket = require('ws');
const wss = new WebSocket.Server({ noServer: true });

wss.on('connection', (ws, req) => {
  const callSid = new URL(req.url, 'http://localhost').searchParams.get('call_sid');
  
  // Connect to ElevenLabs WebSocket
  const elevenlabsWs = new WebSocket(
    `wss://api.elevenlabs.io/v1/convai/conversation/stream`,
    {
      headers: {
        'xi-api-key': process.env.ELEVENLABS_API_KEY
      }
    }
  );
  
  // Forward audio between Twilio and ElevenLabs
  ws.on('message', (message) => {
    const msg = JSON.parse(message);
    if (msg.event === 'media' && elevenlabsWs.readyState === WebSocket.OPEN) {
      elevenlabsWs.send(JSON.stringify({
        type: 'audio',
        audio: msg.media.payload
      }));
    }
  });
  
  elevenlabsWs.on('message', (message) => {
    const data = JSON.parse(message);
    if (data.type === 'audio' && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        event: 'media',
        streamSid: callSid,
        media: { payload: data.audio }
      }));
    }
  });
});
```

### Twilio IVR Menu (Multi-Agent Routing)

```javascript
// IVR Menu with Multi-Agent Selection
app.post('/twilio/ivr', (req, res) => {
  const { Digits, CallSid } = req.body;
  const twiml = new twilio.twiml.VoiceResponse();
  
  if (!Digits) {
    // Present menu
    const gather = twiml.gather({
      input: 'dtmf',
      numDigits: 1,
      action: '/twilio/ivr',
      method: 'POST'
    });
    
    gather.say({
      voice: 'Polly.Joanna',
      language: 'en-US'
    }, 'Welcome to Velocity. Press 1 for Project Manager support, 2 for Quality Assurance, 3 for Procurement, or 9 for the operator.');
    
    // Repeat menu after 5 seconds of no input
    twiml.redirect('/twilio/ivr');
    
  } else {
    // Route based on selection
    const agentMap = {
      '1': process.env.AGENT_ID_PROJECT_MANAGER,
      '2': process.env.AGENT_ID_QA,
      '3': process.env.AGENT_ID_PROCUREMENT,
      '9': process.env.AGENT_ID_OPERATOR
    };
    
    const selectedAgent = agentMap[Digits];
    
    if (selectedAgent) {
      // Forward to selected ElevenLabs agent
      twiml.say('Connecting you now. Please hold.');
      twiml.dial().sip(`sip:${selectedAgent}@elevenlabs.io`);
    } else {
      twiml.say('Invalid selection. Please try again.');
      twiml.redirect('/twilio/ivr');
    }
  }
  
  res.type('text/xml');
  res.send(twiml.toString());
});
```

### Call Recording Configuration

```javascript
// Twilio Call with Recording
app.post('/twilio/voice-with-recording', (req, res) => {
  const twiml = new twilio.twiml.VoiceResponse();
  
  // Start recording
  twiml.say('This call will be recorded. Continuing means you consent to recording.');
  twiml.pause({ length: 1 });
  
  // Connect to ElevenLabs with recording enabled
  const dial = twiml.dial({
    record: 'record-from-answer',
    recordingStatusCallback: '/twilio/recording-status',
    recordingStatusCallbackMethod: 'POST'
  });
  
  dial.sip(`sip:${process.env.ELEVENLABS_SIP_URI}`);
  
  res.type('text/xml');
  res.send(twiml.toString());
});

// Recording Status Callback
app.post('/twilio/recording-status', async (req, res) => {
  const { RecordingUrl, RecordingSid, CallSid, RecordingDuration } = req.body;
  
  console.log('Recording completed:', {
    recording_sid: RecordingSid,
    call_sid: CallSid,
    duration: RecordingDuration,
    url: RecordingUrl
  });
  
  // Save recording URL to database
  await saveRecordingToDatabase({
    call_sid: CallSid,
    recording_url: RecordingUrl,
    duration: RecordingDuration
  });
  
  res.sendStatus(200);
});
```

---

## 9. Complete Working Examples

### Example 1: Simple Data Capture Agent (No Workflow)

```json
{
  "agent_name": "Quick Project Logger",
  "voice_id": "21m00Tcm4TlvDq8ikWAM",
  "first_message": "Hi! I'll quickly capture your project details. What's the project name?",
  "system_prompt": "You are a quick project data capture assistant. Ask these 3 questions in order:\n1. What's the project name?\n2. Who's managing it?\n3. What's the deadline?\n\nKeep it brief and friendly. After collecting all 3 answers, say 'Thanks! Your project is logged.' and end the conversation.",
  "conversation_config": {
    "model_id": "eleven_turbo_v2_5",
    "stability": 0.75
  },
  "data_collection": {
    "rules": [
      {
        "field_name": "project_name",
        "field_type": "string",
        "description": "Extract project name from user's response",
        "required": true
      },
      {
        "field_name": "project_manager",
        "field_type": "string",
        "description": "Extract project manager name",
        "required": true
      },
      {
        "field_name": "deadline",
        "field_type": "date",
        "description": "Extract deadline date in YYYY-MM-DD format",
        "required": true
      }
    ]
  },
  "webhook": {
    "url": "https://your-server.com/webhook",
    "method": "POST"
  }
}
```

### Example 2: Multi-Agent Workflow (Complete)

```json
{
  "workflow_name": "Customer Support Routing",
  "start_node": "qualification",
  "nodes": [
    {
      "node_id": "qualification",
      "node_type": "subagent",
      "configuration": {
        "system_prompt": "Greet the user and ask: 'How can I help you today? Are you looking for technical support, billing assistance, or general inquiries?'",
        "first_message": "Welcome! How can I help you today?"
      },
      "edges": [
        {
          "condition_type": "llm",
          "condition": "User mentions technical issue, bug, error, or not working",
          "target_node_id": "technical_support"
        },
        {
          "condition_type": "llm",
          "condition": "User mentions billing, invoice, payment, or charges",
          "target_node_id": "billing_support"
        },
        {
          "condition_type": "llm",
          "condition": "User has general question or other inquiry",
          "target_node_id": "general_support"
        }
      ]
    },
    {
      "node_id": "technical_support",
      "node_type": "subagent",
      "configuration": {
        "system_prompt": "You are a technical support specialist. Collect:\n1. Brief description of the issue\n2. When did it start?\n3. What have you tried already?\n\nProvide basic troubleshooting if possible.",
        "knowledge_base_ids": ["kb_tech_docs"]
      },
      "edges": [
        {
          "condition_type": "llm",
          "condition": "Issue resolved",
          "target_node_id": "satisfaction_survey"
        },
        {
          "condition_type": "llm",
          "condition": "Issue requires escalation",
          "target_node_id": "escalation"
        }
      ]
    },
    {
      "node_id": "billing_support",
      "node_type": "subagent",
      "configuration": {
        "system_prompt": "You are a billing specialist. Collect:\n1. Account number or email\n2. Specific billing question or concern\n\nProvide general billing information and offer to send detailed invoice.",
        "knowledge_base_ids": ["kb_billing_faq"]
      },
      "edges": [
        {
          "condition_type": "llm",
          "condition": "Question answered",
          "target_node_id": "satisfaction_survey"
        }
      ]
    },
    {
      "node_id": "general_support",
      "node_type": "subagent",
      "configuration": {
        "system_prompt": "You handle general inquiries. Answer questions about products, services, hours, and company information.",
        "knowledge_base_ids": ["kb_general_info"]
      },
      "edges": [
        {
          "condition_type": "llm",
          "condition": "Question answered",
          "target_node_id": "satisfaction_survey"
        }
      ]
    },
    {
      "node_id": "escalation",
      "node_type": "transfer",
      "configuration": {
        "transfer_type": "phone_number",
        "destination": "+15551234567",
        "transfer_message": "I'm transferring you to our senior technical support team who can assist further."
      }
    },
    {
      "node_id": "satisfaction_survey",
      "node_type": "subagent",
      "configuration": {
        "system_prompt": "Ask: 'On a scale of 1-5, how satisfied are you with this interaction?' Collect rating and any additional feedback.",
        "data_collection": [
          {
            "field_name": "satisfaction_rating",
            "field_type": "integer",
            "description": "Extract satisfaction rating 1-5"
          },
          {
            "field_name": "feedback",
            "field_type": "text",
            "description": "Extract any additional feedback"
          }
        ]
      },
      "edges": [
        {
          "condition_type": "always",
          "target_node_id": "goodbye"
        }
      ]
    },
    {
      "node_id": "goodbye",
      "node_type": "end",
      "configuration": {
        "closing_message": "Thank you for contacting us! Have a great day!"
      }
    }
  ]
}
```

### Example 3: Python Script - Complete Integration

```python
#!/usr/bin/env python3
"""
Complete ElevenLabs Integration Example
Creates agent, captures data, processes webhook
"""

import os
import requests
from flask import Flask, request, jsonify
from datetime import datetime

# Configuration
ELEVENLABS_API_KEY = os.getenv('ELEVENLABS_API_KEY')
ELEVENLABS_BASE_URL = 'https://api.elevenlabs.io/v1'

app = Flask(__name__)

# Step 1: Create Agent
def create_agent():
    url = f'{ELEVENLABS_BASE_URL}/convai/agents'
    headers = {
        'xi-api-key': ELEVENLABS_API_KEY,
        'Content-Type': 'application/json'
    }
    
    payload = {
        'name': 'Project Data Collector',
        'voice_id': '21m00Tcm4TlvDq8ikWAM',
        'first_message': 'Hi! I need to collect some project details. What\'s the project name?',
        'system_prompt': '''You are a project data collector. Ask these questions in order:
        1. What's the project name?
        2. Who is managing it?
        3. What's the deadline?
        
        Be brief and professional. After collecting all info, say "Thanks! Data saved." and end.''',
        'conversation_config': {
            'model_id': 'eleven_turbo_v2_5',
            'stability': 0.75,
            'similarity_boost': 0.85
        },
        'data_collection': {
            'rules': [
                {
                    'field_name': 'project_name',
                    'field_type': 'string',
                    'description': 'Extract the project name',
                    'required': True
                },
                {
                    'field_name': 'project_manager',
                    'field_type': 'string',
                    'description': 'Extract the project manager name',
                    'required': True
                },
                {
                    'field_name': 'deadline',
                    'field_type': 'date',
                    'description': 'Extract deadline as YYYY-MM-DD',
                    'required': True
                }
            ]
        },
        'webhook': {
            'url': 'https://your-server.com/webhook/elevenlabs',
            'method': 'POST'
        }
    }
    
    response = requests.post(url, headers=headers, json=payload)
    return response.json()

# Step 2: Webhook Receiver
@app.route('/webhook/elevenlabs', methods=['POST'])
def elevenlabs_webhook():
    data = request.json
    
    # Extract conversation data
    conversation_id = data.get('conversation_id')
    extracted_data = data.get('extracted_data', {})
    evaluation = data.get('evaluation_results', {})
    
    # Process the data
    project_data = {
        'conversation_id': conversation_id,
        'timestamp': datetime.now().isoformat(),
        'project_name': extracted_data.get('project_name'),
        'project_manager': extracted_data.get('project_manager'),
        'deadline': extracted_data.get('deadline'),
        'success': all([
            extracted_data.get('project_name'),
            extracted_data.get('project_manager'),
            extracted_data.get('deadline')
        ])
    }
    
    # Save to database (example)
    save_to_database(project_data)
    
    # Send notification if needed
    if project_data['success']:
        send_notification(project_data)
    
    return jsonify({'status': 'received'}), 200

# Helper functions
def save_to_database(data):
    """Save project data to your database"""
    print(f"Saving to DB: {data}")
    # Your database logic here

def send_notification(data):
    """Send notification to team"""
    print(f"Sending notification: {data}")
    # Your notification logic here

if __name__ == '__main__':
    # Create agent on startup
    agent = create_agent()
    print(f"Agent created: {agent}")
    
    # Start webhook server
    app.run(host='0.0.0.0', port=5000)
```

---

## Quick Reference: Common Tasks

### Task: Change Voice Mid-Conversation

```json
{
  "node_id": "empathy_mode",
  "node_type": "subagent",
  "configuration": {
    "voice_override": "EXAVITQu4vr4xnSDxMaL",
    "system_prompt_addition": "Switch to a more empathetic, slower tone. [speaks slowly] I understand this is difficult..."
  }
}
```

### Task: Loop Until Valid Data

```json
{
  "node_id": "collect_email",
  "node_type": "subagent",
  "configuration": {
    "system_prompt": "Ask for user's email address. Validate format."
  },
  "edges": [
    {
      "condition_type": "llm",
      "condition": "Email provided and valid format",
      "target_node_id": "next_step"
    },
    {
      "condition_type": "llm",
      "condition": "Email invalid or not provided",
      "target_node_id": "collect_email"
    }
  ]
}
```

### Task: Detect and Flag Keywords

```json
{
  "field_name": "contains_complaint",
  "field_type": "boolean",
  "description": "Set to true if user mentions: 'complaint', 'unhappy', 'disappointed', 'angry', 'frustrated', 'terrible', 'awful', or similar negative sentiment. Otherwise false.",
  "required": true,
  "default": false
}
```

---

## Troubleshooting Common Issues

### Issue: Webhook Not Firing

**Solution:**
```bash
# Test webhook connectivity
curl -X POST "https://your-server.com/webhook/test" \
  -H "Content-Type: application/json" \
  -d '{"test": "data"}'

# Verify webhook URL in agent config
curl -X GET "https://api.elevenlabs.io/v1/convai/agents/YOUR_AGENT_ID" \
  -H "xi-api-key: YOUR_API_KEY"
```

### Issue: Data Not Extracting

**Solution:** Make field descriptions MORE specific
```json
// ❌ Too vague
"description": "Get the name"

// ✅ Specific
"description": "Extract the user's full name (first and last). Look for phrases like 'My name is', 'I'm', or 'This is [Name] calling'. Format as 'FirstName LastName'. Return null if no name mentioned."
```

### Issue: Agent Repeating Questions

**Solution:** Add conversation memory instruction
```text
System Prompt Addition:
"IMPORTANT: Never ask for information the user has already provided. Reference previous answers in your follow-up questions. For example, if they said 'John is managing it', don't ask 'Who's the project manager?'—you already know it's John."
```

---

## Next Steps

1. **Copy the examples above** - Use as templates for your specific use case
2. **Test with small iterations** - Start with simple 3-question agent, then expand
3. **Monitor webhook data** - Validate extraction accuracy before scaling
4. **Iterate on prompts** - Refine system prompts based on real conversation data
5. **Add complexity gradually** - Start with one workflow path, add branches later

---

**Document Maintained By:** Velocity AI Team  
**Last Updated:** November 5, 2025  
**Version:** 2.0  

For questions or issues, refer to:
- [ElevenLabs API Documentation](https://elevenlabs.io/docs/api-reference)
- [Twilio Voice Documentation](https://www.twilio.com/docs/voice)
- Internal Velocity documentation repository
