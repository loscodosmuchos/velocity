# MCP Process Mapper Integration Guide

## Overview

The Process Mapper is now fully MCP-compatible with use-case driven output configuration. A single endpoint with configurable `use_case` parameter generates different output formats optimized for specific business scenarios.

**Implementation Status:** ✅ READY FOR DEMO

## Quick Start - Call from Another Replit

### MCP Tool Signature

```typescript
velocity_process_generate_map({
  description: string,              // Workflow description or process to map
  use_case: string,                 // 'site_survey' | 'document_existing' | 'spec_new_project' | 'business_assessment'
  workflowFile?: File,              // Optional: Upload PDF or Markdown file instead of description
  workflowType?: string,            // Optional: 'api-integration', 'data-pipeline', etc.
  industry?: string,                // Optional: Industry context
  dataVolume?: string,              // Optional: Data volume/frequency
  compliance?: string,              // Optional: Compliance requirements
  techStack?: string,               // Optional: Existing tech stack
  painPoints?: string              // Optional: Current pain points
})
```

## Use Cases - Tiny Config, Big Difference

### 1. Site Survey / New Employee Assessment

**When to use:** Onboarding new employees, conducting site surveys, assessing skill requirements

**Output Focus:**
- ✅ Roles & responsibilities
- ✅ Training needs & materials
- ✅ Equipment & tools required
- ✅ Onboarding checkpoints
- ✅ Skills matrix

**Example Request:**
```javascript
const result = await mcp.callTool('velocity_process_generate_map', {
  description: "Onboarding process for new warehouse employees including safety training, equipment certification, and system access",
  use_case: 'site_survey'
});
```

**Enhanced Output:**
```json
{
  "title": "Warehouse Employee Onboarding",
  "steps": [...],
  "useCase": {
    "type": "site_survey",
    "name": "Site Survey / New Employee Assessment",
    "recommendedExports": ["Onboarding Checklist", "Skills Matrix", "Training Plan", "Equipment List"],
    "emphasis": {
      "roles": 10,
      "timeline": 3,
      "resources": 9,
      "risks": 4,
      "compliance": 6
    }
  }
}
```

---

### 2. Document Existing Project

**When to use:** Capturing current state, identifying inefficiencies, baseline metrics

**Output Focus:**
- ✅ Current process (as-is)
- ✅ Pain points & bottlenecks
- ✅ Performance metrics
- ✅ Improvement opportunities
- ✅ Workarounds & manual interventions

**Example Request:**
```javascript
const result = await mcp.callTool('velocity_process_generate_map', {
  description: "Current invoice processing workflow - manual data entry, email approvals, Excel tracking",
  use_case: 'document_existing',
  painPoints: "Takes 3-5 days per invoice, frequent errors, no visibility into status"
});
```

**Enhanced Output:**
```json
{
  "title": "Current Invoice Processing Workflow",
  "steps": [...],
  "useCase": {
    "type": "document_existing",
    "name": "Document Existing Project",
    "recommendedExports": ["Process Documentation", "Pain Points Report", "Improvement Roadmap", "Metrics Dashboard"],
    "emphasis": {
      "roles": 6,
      "timeline": 7,
      "resources": 7,
      "risks": 8,
      "compliance": 5
    }
  }
}
```

---

### 3. Spec New Project

**When to use:** Requirements gathering, project planning, resource allocation

**Output Focus:**
- ✅ Project timeline & milestones
- ✅ Resource allocation (people, budget, tools)
- ✅ Dependencies & critical path
- ✅ Risk mitigation strategies
- ✅ Success criteria

**Example Request:**
```javascript
const result = await mcp.callTool('velocity_process_generate_map', {
  description: "Launch new customer portal with self-service features, Q2 2025 deadline, integration with existing CRM",
  use_case: 'spec_new_project',
  compliance: "SOC 2, GDPR compliance required",
  techStack: "React, Node.js, PostgreSQL"
});
```

**Enhanced Output:**
```json
{
  "title": "Customer Portal Launch Project",
  "steps": [...],
  "useCase": {
    "type": "spec_new_project",
    "name": "Spec New Project",
    "recommendedExports": ["Project Plan", "Gantt Chart", "Resource Plan", "Risk Register", "Budget Forecast"],
    "emphasis": {
      "roles": 7,
      "timeline": 10,
      "resources": 9,
      "risks": 9,
      "compliance": 6
    }
  }
}
```

---

### 4. Business Workflow Assessment (Default)

**When to use:** General process analysis, stakeholder mapping, approval workflows

**Output Focus:**
- ✅ Stakeholder matrix
- ✅ Decision points & approvals
- ✅ Process efficiency metrics
- ✅ Integration points
- ✅ SLA tracking

**Example Request:**
```javascript
const result = await mcp.callTool('velocity_process_generate_map', {
  description: "Contract approval workflow from sales to legal to finance to CEO signature",
  use_case: 'business_assessment'
});
```

**Enhanced Output:**
```json
{
  "title": "Contract Approval Workflow",
  "steps": [...],
  "useCase": {
    "type": "business_assessment",
    "name": "Business Workflow Assessment",
    "recommendedExports": ["Process Map", "Stakeholder Matrix", "Approval Workflow", "Integration Diagram", "SLA Document"],
    "emphasis": {
      "roles": 8,
      "timeline": 6,
      "resources": 6,
      "risks": 6,
      "compliance": 8
    }
  }
}
```

---

## REST API Endpoint

**Endpoint:** `POST /api/process/generate`

**Content-Type:** `multipart/form-data`

**Parameters:**
- `description` (string, optional): Text description of the workflow
- `workflowFile` (file, optional): PDF or Markdown file with workflow documentation
- `use_case` (string, optional): Use case type - defaults to 'business_assessment'
  - `site_survey` - Site survey / new employee assessment
  - `document_existing` - Document existing project
  - `spec_new_project` - Spec new project
  - `business_assessment` - General business workflow assessment
- `workflowType` (string, optional): Workflow category for additional context
- `industry` (string, optional): Industry context
- `dataVolume` (string, optional): Data volume/frequency
- `compliance` (string, optional): Compliance requirements
- `techStack` (string, optional): Existing tech stack
- `painPoints` (string, optional): Current pain points

**Example cURL:**
```bash
curl -X POST https://your-repl.replit.dev/api/process/generate \
  -F "description=Employee onboarding process with training and equipment setup" \
  -F "use_case=site_survey" \
  -F "industry=Manufacturing"
```

**Example with File Upload:**
```bash
curl -X POST https://your-repl.replit.dev/api/process/generate \
  -F "workflowFile=@process-documentation.pdf" \
  -F "use_case=document_existing"
```

## Response Format

All use cases return the same core structure with use case metadata:

```typescript
{
  title: string;
  description: string;
  steps: Array<{
    id: string;
    name: string;
    type: 'source' | 'transform' | 'output' | 'decision' | 'integration';
    description: string;
    system?: string;
    techDetails: {
      apiEndpoint?: string;
      dataFormat?: string;
      authentication?: string;
      sla?: string;
      faultTolerance?: string;
      backup?: string;
    };
    inputs: string[];
    outputs: string[];
    position: { x: number; y: number };
  }>;
  connections: Array<{
    id: string;
    from: string;
    to: string;
    label: string;
    dataFlow: string;
  }>;
  requirements: Array<{
    category: 'technical' | 'business' | 'security' | 'performance';
    requirement: string;
    priority: 'high' | 'medium' | 'low';
  }>;
  estimatedComplexity: 'low' | 'medium' | 'high' | 'very_high';
  useCase: {
    type: string;
    name: string;
    description: string;
    recommendedExports: string[];
    emphasis: {
      roles: number;
      timeline: number;
      resources: number;
      risks: number;
      compliance: number;
    };
  };
}
```

## Integration Pattern - Reusable for Other Services

The use case configuration pattern is **designed to be reusable** across all Velocity services:

```typescript
// Pattern can be applied to:
// - Voice Testing Lab (use_case: 'screening' | 'onboarding' | 'feedback' | 'support')
// - Resume Parser (use_case: 'candidate_screen' | 'skill_gap' | 'team_planning' | 'market_intel')
// - Content Generator (use_case: 'job_description' | 'offer_letter' | 'rejection_email' | 'interview_guide')
// - Multi-Lens Evaluation (use_case: 'initial_screen' | 'technical_eval' | 'culture_fit' | 'executive_review')

import { applyUseCaseTemplate } from '@shared/process-config';

const enhancedPrompt = applyUseCaseTemplate(
  basePrompt,
  use_case,
  additionalContext
);
```

## MCP Server Setup (Next Phase)

**Note:** Full MCP server implementation is planned for next phase. Current implementation provides REST API endpoint that can be called from other Replits.

**Planned MCP Server Features:**
- Token-based authentication
- Per-client rate limiting
- Request logging & metrics
- Circuit breaker pattern
- Output sanitization

**Estimated Timeline:** 2-3 weeks for full MCP server implementation

---

## Testing Guide

### Test All 4 Use Cases

```bash
# Site Survey
curl -X POST http://localhost:5000/api/process/generate \
  -F "description=New hire training process" \
  -F "use_case=site_survey"

# Document Existing
curl -X POST http://localhost:5000/api/process/generate \
  -F "description=Current manual invoice processing" \
  -F "use_case=document_existing"

# Spec New Project
curl -X POST http://localhost:5000/api/process/generate \
  -F "description=Launch customer portal Q2 2025" \
  -F "use_case=spec_new_project"

# Business Assessment
curl -X POST http://localhost:5000/api/process/generate \
  -F "description=Contract approval workflow" \
  -F "use_case=business_assessment"
```

---

## Success Metrics

✅ **Single endpoint** with use_case parameter (not 4 separate endpoints)  
✅ **Consistent schema** across all use cases (easy for consumers)  
✅ **Use case metadata** in response (guides downstream processing)  
✅ **Recommended exports** per use case (guides UI generation)  
✅ **Emphasis weights** (guides visualization priorities)  
✅ **Reusable pattern** (can be applied to Voice Lab, Resume Parser, etc.)

---

## Next Steps After Demo

1. **MCP Server Implementation** - Full protocol handler with auth & rate limiting
2. **Apply Pattern to Voice Lab** - Add use_case to voice screening
3. **Apply Pattern to Resume Parser** - Add use_case to resume analysis
4. **Apply Pattern to Content Generator** - Add use_case to content creation
5. **Create MCP Client SDK** - Simplify integration for consuming Replits
