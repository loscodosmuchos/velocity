# MCP Service Catalog Template

**Document Version:** 1.0.0  
**Revision Date:** November 14, 2025  
**Status:** Living Document  
**Purpose:** Self-Service Capability Discovery & Monetization Framework

---

## Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | 2025-11-14 | Velocity AI Platform | Initial release |

---

## Table of Contents

0. [Template Instructions & Guardrails](#section-0-template-instructions--guardrails)
1. [Executive Summary](#section-1-executive-summary)
2. [Development & Debugging Best Practices](#section-2-development--debugging-best-practices)
3. [Service Discovery Framework](#section-3-service-discovery-framework)
4. [Service Catalog Registry](#section-4-service-catalog-registry)
5. [Integration Patterns](#section-5-integration-patterns)
6. [Competitive Value Matrix](#section-6-competitive-value-matrix)
7. [Machine-Readable Metadata](#section-7-machine-readable-metadata)

**Appendices:**
- [Appendix A: Template Adaptation Guide](#appendix-a-template-adaptation-guide)
- [Appendix B: Completeness Checklist](#appendix-b-completeness-checklist)
- [Appendix C: Debugging Playbook](#appendix-c-debugging-playbook)
- [Appendix D: Phase 2 & 3 Roadmap](#appendix-d-phase-2--3-roadmap)

---

## Section 0: Template Instructions & Guardrails

### Purpose of This Document

This document serves **three critical functions**:

1. **Human Sales/Marketing** - Communicate valuable services to potential customers
2. **Machine Discovery** - Provide structured metadata for MCP servers to auto-generate tool definitions
3. **Auto-Packaging Blueprint** - Enable automated creation of standalone service modules

### Three-Phase Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ Phase 1: SERVICE CATALOG (This Document)                   │
│ • Self-inquiry: "What valuable services do we provide?"    │
│ • Natural language + technical specs                       │
│ • Monetization clarity                                     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ Phase 2: MCP SERVER MODULE                                 │
│ • Reads catalog document                                   │
│ • Auto-generates MCP tool definitions                      │
│ • Exposes endpoints with auth, rate limiting, billing      │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ Phase 3: SERVICE PACKAGING SYSTEM                          │
│ • Packages services as standalone modules                  │
│ • Self-contained with README, deps, API client             │
│ • One-command installation                                 │
└─────────────────────────────────────────────────────────────┘
```

### Guardrails & Anti-Distraction Guidelines

**🚨 CRITICAL REMINDERS - Read before starting:**

1. **Completeness Watchdog** - Before marking catalog complete, run [Appendix B: Completeness Checklist](#appendix-b-completeness-checklist)
2. **Stay Focused** - Do NOT get distracted by implementation details. This is a CATALOG, not a codebase.
3. **Capture Everything** - Every API endpoint, background job, webhook, AI service, and data transformation is a potential service. Don't skip anything.
4. **Quantify Value** - For each service, answer: "Why would someone pay for this?" and "What problem does it solve?"
5. **Error Tolerance First** - Document error handling, retry policies, and degradation strategies BEFORE features
6. **Version Everything** - Every service gets a version number. Every schema change gets documented.

### Standard Naming Conventions

All services in this catalog follow these naming rules:

#### Service Names
**Format:** `{Domain}.{Action}.{Resource}`

**Examples:**
- `Voice.Screen.Candidate` - Voice screening service for candidates
- `Resume.Parse.PDF` - PDF resume parsing service
- `Evaluation.Score.MultiLens` - Multi-lens candidate scoring

**Rules:**
- Use PascalCase for all parts
- Domain = Business domain (Voice, Resume, Evaluation, Communication)
- Action = Primary verb (Screen, Parse, Score, Generate, Extract)
- Resource = What it operates on (Candidate, Resume, Application, Draft)

#### API Endpoints
**Format:** `/api/{version}/{domain}/{resource}/{action}`

**Examples:**
- `POST /api/v1/voice/candidate/screen` - Initiate voice screening
- `POST /api/v1/resume/pdf/parse` - Parse PDF resume
- `GET /api/v1/evaluation/candidate/score` - Get candidate score

**Rules:**
- Always version your APIs (`/v1/`, `/v2/`)
- Use lowercase with hyphens for multi-word parts
- Use REST verbs (GET, POST, PUT, DELETE, PATCH)

#### MCP Tool Names
**Format:** `{platform}_{domain}_{action}_{resource}`

**Examples:**
- `velocity_voice_screen_candidate`
- `velocity_resume_parse_pdf`
- `velocity_evaluation_score_multilens`

**Rules:**
- All lowercase with underscores
- Prefix with platform name to avoid collisions
- Max 50 characters for compatibility

#### Category Taxonomy

All services must be categorized using this standard hierarchy:

**Level 1: Primary Domain**
- `voice_intelligence` - Voice, speech, conversation services
- `data_ingestion` - Any service that accepts external data
- `evaluation` - Scoring, ranking, assessment services
- `automation` - Auto-generation, drafting, workflow services
- `analytics` - Reporting, insights, prediction services
- `integration` - External system connections (Twilio, ElevenLabs, etc.)

**Level 2: Service Type**
- `synchronous` - Real-time response (< 5 seconds)
- `asynchronous` - Background processing (> 5 seconds)
- `streaming` - Continuous data flow
- `webhook` - Event-driven callbacks

**Level 3: Pricing Model**
- `per_use` - Charge per API call
- `subscription` - Monthly/annual flat rate
- `tiered` - Volume-based pricing
- `freemium` - Free tier + paid upgrades

### Service Information Sheet Template

**Copy this template for EACH service you document:**

```markdown
---
## Service: {Service Name in PascalCase}

**Service ID:** `{domain}.{action}.{resource}`  
**Version:** `{semantic version}`  
**Status:** `[Production|Beta|Alpha|Deprecated]`

### Classification
- **Primary Domain:** `{voice_intelligence|data_ingestion|evaluation|automation|analytics|integration}`
- **Service Type:** `{synchronous|asynchronous|streaming|webhook}`
- **Pricing Model:** `{per_use|subscription|tiered|freemium}`

### Description
{2-3 sentence natural language description}

**What it does:** {Clear, simple explanation}  
**Why it's valuable:** {ROI, time savings, cost reduction}  
**Who uses it:** {Target audience}

### API Endpoint
**HTTP Method:** `{GET|POST|PUT|DELETE|PATCH}`  
**Path:** `/api/{version}/{domain}/{resource}/{action}`  
**Authentication:** `{API Key|OAuth|JWT|None}`

### Request Schema
```json
{
  "field_name": "string",
  "field_type": "data_type",
  "required": true|false,
  "description": "What this field does"
}
```

### Response Schema
```json
{
  "success": true,
  "data": {
    "result_field": "value"
  },
  "metadata": {
    "processing_time_ms": 0,
    "service_version": "1.0.0"
  }
}
```

### Error Codes
| Code | Message | Cause | Resolution |
|------|---------|-------|------------|
| 400 | Bad Request | Invalid input | Check request schema |
| 401 | Unauthorized | Missing/invalid API key | Verify credentials |
| 429 | Rate Limit Exceeded | Too many requests | Implement backoff |
| 500 | Internal Server Error | Service failure | Retry with exponential backoff |

### Error Handling & Retry Policy
- **Retry Strategy:** `{exponential_backoff|linear|none}`
- **Max Retries:** `{number}`
- **Timeout:** `{seconds}`
- **Fallback Behavior:** `{graceful_degradation|error_response|queue_for_later}`

### Rate Limits
- **Free Tier:** `{X} requests per {minute|hour|day}`
- **Paid Tier:** `{Y} requests per {minute|hour|day}`
- **Burst Limit:** `{Z} requests in {seconds}`

### Pricing
- **Per Use:** `${amount} per request`
- **Subscription:** `${amount}/month` (includes X requests)
- **Volume Discount:** `{describe tiered pricing}`

### SLA Commitment
- **Uptime:** `{99.9%|99.5%|best_effort}`
- **Response Time (p95):** `{milliseconds}`
- **Support Level:** `{24/7|business_hours|community}`

### Dependencies
- **External APIs:** `{Twilio, ElevenLabs, OpenAI, etc.}`
- **Internal Services:** `{other services this depends on}`
- **Database:** `{PostgreSQL, Redis, etc.}`

### MCP Tool Signature
```json
{
  "name": "{platform}_{domain}_{action}_{resource}",
  "description": "{clear description for AI agents}",
  "inputSchema": {
    "type": "object",
    "properties": {
      "{field}": {
        "type": "{string|number|boolean|object|array}",
        "description": "{what this field does}"
      }
    },
    "required": ["{field1}", "{field2}"]
  }
}
```

### Code Example (Developer Integration)
```typescript
// Example: How developers integrate this service
const result = await fetch('/api/v1/{domain}/{resource}/{action}', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    // request data
  })
});
```

### MCP Example (AI Agent Consumption)
```json
// Example: How AI agents call this via MCP
{
  "tool": "{platform}_{domain}_{action}_{resource}",
  "arguments": {
    "field": "value"
  }
}
```

### Competitive Differentiator
**Why choose this over alternatives:**
- ✅ {Unique feature 1}
- ✅ {Unique feature 2}
- ✅ {Cost advantage}

### Changelog
| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025-11-14 | Initial release |

---
```

### Completeness Validation Questions

**Before marking ANY service as "documented", answer these:**

1. ✅ Does it have a clear, unique Service ID?
2. ✅ Is the pricing model defined (even if "free")?
3. ✅ Are ALL error codes documented with resolutions?
4. ✅ Is there a retry policy and timeout specified?
5. ✅ Does it include both developer AND AI agent examples?
6. ✅ Is the competitive differentiator compelling?
7. ✅ Would a stranger understand what this does and why it's valuable?

**If ANY answer is "no", the service is NOT complete.**

---

## Section 1: Executive Summary

### What is Velocity?

**Velocity Candidate Journey Champion** is a voice-first ATS/VMS platform that transforms recruitment through AI-powered automation and multi-dimensional candidate evaluation.

### Target Audiences

**1. Technical Integrators (Developers)**
- **Need:** Integrate recruitment intelligence into existing HRIS/ATS systems
- **Value:** Pre-built API services eliminate months of development time
- **Use Case:** Connect Velocity's voice screening to your applicant tracking workflow

**2. AI Agents & LLMs**
- **Need:** Discover and consume recruitment services via MCP protocol
- **Value:** Structured tool definitions enable autonomous candidate evaluation
- **Use Case:** AI assistant can screen candidates, parse resumes, generate offers without human intervention

### Platform Philosophy

**"EXCLAIM vs EXPLAIN"** - Users should gasp at the speed and intelligence, not need training manuals.

**Core Principles:**
1. **Touch Once Principle** - Every action should trigger automatic follow-ups
2. **Universal Ingestion** - Accept data from ANY source (voice, PDF, API, webhook)
3. **Multi-Lens Intelligence** - Evaluate candidates across 5 dimensions simultaneously
4. **Voice-First Design** - Eliminate communication barriers through patient AI interviewers

### Service Categories Overview

| Category | Service Count | Key Capability | Pricing Model |
|----------|---------------|----------------|---------------|
| **Voice Intelligence** | 6 | SMS-triggered screening in 30s | Per screening |
| **Data Ingestion** | 8 | Parse any resume format | Per parse |
| **Multi-Lens Evaluation** | 5 | 5-dimensional scoring | Per evaluation |
| **Auto-Drafting** | 7 | Generate interview questions, offers | Per generation |
| **Analytics** | 4 | Predictive gap detection | Subscription |
| **Integration** | 12 | Twilio, ElevenLabs, OpenAI | Pass-through pricing |

**Total Services:** 42 cataloged capabilities

---

## Section 2: Development & Debugging Best Practices

### Error-Tolerant Design from Day One

**Golden Rule:** Services should NEVER fail silently. Every error must be:
1. **Logged** - Structured logging with correlation IDs
2. **Returned** - Clear error codes and messages to clients
3. **Monitored** - Alerts on threshold breaches
4. **Recoverable** - Automatic retry or graceful degradation

### Standard Error Response Format

**ALL services must return errors in this format:**

```json
{
  "success": false,
  "error": {
    "code": "SPECIFIC_ERROR_CODE",
    "message": "Human-readable description",
    "details": {
      "field": "which_field_caused_error",
      "received": "what_we_got",
      "expected": "what_we_wanted"
    },
    "correlation_id": "uuid-for-tracking",
    "timestamp": "ISO8601",
    "retry_after": 60,
    "documentation_url": "https://docs.velocity.ai/errors/SPECIFIC_ERROR_CODE"
  }
}
```

### Error Code Naming Convention

**Format:** `{DOMAIN}_{TYPE}_{SPECIFIC}`

**Examples:**
- `VOICE_INVALID_PHONE_FORMAT` - Phone number validation failed
- `RESUME_PARSE_TIMEOUT` - PDF parsing took too long
- `EVALUATION_MISSING_CRITERIA` - Required scoring criteria not provided
- `RATE_LIMIT_EXCEEDED` - Too many requests

### Logging Standards

**Every service must log:**

```typescript
{
  "timestamp": "ISO8601",
  "level": "INFO|WARN|ERROR|DEBUG",
  "service": "voice.screen.candidate",
  "version": "1.0.0",
  "correlation_id": "uuid",
  "user_id": "optional",
  "action": "screen_initiated",
  "duration_ms": 1234,
  "success": true,
  "metadata": {
    // service-specific context
  }
}
```

### Retry Strategies

**Use exponential backoff for ALL retryable operations:**

```typescript
function exponentialBackoff(attempt: number): number {
  const baseDelay = 1000; // 1 second
  const maxDelay = 60000; // 60 seconds
  const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
  // Add jitter to prevent thundering herd
  return delay + Math.random() * 1000;
}
```

**Retryable vs Non-Retryable Errors:**

✅ **Retry These:**
- 429 (Rate Limit)
- 500 (Internal Server Error)
- 502 (Bad Gateway)
- 503 (Service Unavailable)
- 504 (Gateway Timeout)
- Network timeouts
- Database connection errors

❌ **Do NOT Retry These:**
- 400 (Bad Request)
- 401 (Unauthorized)
- 403 (Forbidden)
- 404 (Not Found)
- 422 (Unprocessable Entity)
- Validation errors

### Testing Strategy

**Before deploying ANY service, ensure:**

1. **Unit Tests** - 80%+ code coverage
2. **Integration Tests** - Test external API interactions with mocks
3. **Error Path Tests** - Test EVERY error code path
4. **Load Tests** - Verify rate limits work
5. **Chaos Tests** - Kill dependencies and verify graceful degradation

### Graceful Degradation Patterns

**When a dependency fails, services should:**

```typescript
// Example: Voice screening with AI transcript extraction
async function screenCandidate(conversationId: string) {
  try {
    // Primary: Use Claude for transcript extraction
    return await extractWithClaude(conversationId);
  } catch (error) {
    console.warn('Claude failed, falling back to OpenAI', error);
    try {
      // Fallback: Use OpenAI
      return await extractWithOpenAI(conversationId);
    } catch (fallbackError) {
      console.error('All AI providers failed', fallbackError);
      // Final fallback: Return raw transcript
      return {
        success: true,
        transcript: await getRawTranscript(conversationId),
        extracted_data: null,
        warning: 'AI extraction failed, returning raw transcript'
      };
    }
  }
}
```

### Health Check Endpoints

**ALL services must expose:**

```typescript
GET /api/v1/health

Response:
{
  "status": "healthy|degraded|unhealthy",
  "version": "1.0.0",
  "uptime_seconds": 123456,
  "dependencies": {
    "postgres": "healthy",
    "twilio": "healthy",
    "openai": "degraded" // fallback to Claude active
  },
  "last_error": null,
  "timestamp": "ISO8601"
}
```

### Monitoring & Alerting

**Track these metrics for EVERY service:**

- **Request Rate** - Requests per minute
- **Error Rate** - Errors per minute (alert if > 5%)
- **Latency (p50, p95, p99)** - Response time percentiles
- **Dependency Health** - External API status
- **Queue Depth** - Background job backlog
- **Cache Hit Rate** - For cached services

---

## Section 3: Service Discovery Framework

### Systematic Capability Inventory

**Use this checklist to discover ALL services in your application:**

#### 1. API Endpoints Inventory
```bash
# Find all Express routes
grep -r "app.get\|app.post\|app.put\|app.delete" server/

# Find all route registration
grep -r "registerRoutes\|router." server/
```

**For each endpoint, ask:**
- ✅ Is this valuable to external users?
- ✅ Could this save someone time or money?
- ✅ Is this unique or better than alternatives?

#### 2. Background Jobs Inventory
```bash
# Find all cron jobs
grep -r "cron\|schedule\|setInterval" server/

# Find all queue processors
grep -r "queue\|job\|worker" server/
```

**For each job, ask:**
- ✅ Does this process data asynchronously?
- ✅ Could someone want this as a service?
- ✅ What's the input and output?

#### 3. AI/ML Services Inventory
```bash
# Find all AI provider calls
grep -r "anthropic\|openai\|elevenlabs" server/

# Find all AI prompts
grep -r "systemPrompt\|prompt\|messages:" server/
```

**For each AI service, ask:**
- ✅ What specific problem does this solve?
- ✅ What's the accuracy/quality level?
- ✅ How much does it cost per call?

#### 4. Data Transformation Services
```bash
# Find all parsing/extraction
grep -r "parse\|extract\|transform" server/

# Find all validation
grep -r "validate\|schema\|zod" server/
```

**For each transformation, ask:**
- ✅ What format does it accept?
- ✅ What format does it output?
- ✅ Is this reusable for others?

#### 5. Integration Services
```bash
# Find all external API calls
grep -r "fetch\|axios\|got\|request" server/

# Find all webhooks
grep -r "webhook\|callback" server/
```

**For each integration, ask:**
- ✅ What external service does this connect to?
- ✅ Does it add value beyond the raw API?
- ✅ Is authentication handled?

### Service Discovery Template

**For each discovered capability, fill out:**

```yaml
service_candidate:
  discovered_in: "server/routes/voice-routes.ts line 42"
  current_endpoint: "POST /api/voice/test-call"
  what_it_does: "Initiates Twilio voice call with custom message"
  inputs: ["phone_number", "message", "voice_options"]
  outputs: ["call_sid", "status", "metadata"]
  dependencies: ["Twilio API"]
  
  # Evaluation questions
  is_valuable_externally: true|false
  why_valuable: "Saves developers from learning Twilio API"
  target_audience: "Mobile app developers needing voice notifications"
  pricing_potential: "$0.01 per call + Twilio pass-through"
  
  # Catalog decision
  should_catalog: true|false
  priority: high|medium|low
  notes: "Already used by 3 internal features, ready to expose"
```

---

## Section 4: Service Catalog Registry

### Velocity Platform Services

**This section contains the complete catalog of services Velocity exposes via MCP.**

---

### Category: Voice Intelligence

---

## Service: Voice.Screen.Candidate

**Service ID:** `voice.screen.candidate`  
**Version:** `1.0.0`  
**Status:** `Production`

### Classification
- **Primary Domain:** `voice_intelligence`
- **Service Type:** `asynchronous`
- **Pricing Model:** `per_use`

### Description
SMS-triggered conversational AI that screens candidates via phone call in under 30 seconds from initial text message.

**What it does:** Candidate texts a number, system creates custom ElevenLabs voice agent, calls them back, conducts screening interview, extracts structured data, auto-scores candidate, and creates application record.

**Why it's valuable:** Eliminates 90% of phone screening labor cost, screens candidates 24/7, zero scheduling friction, structured data extraction ensures consistency.

**Who uses it:** Recruiting agencies, high-volume hiring teams, staffing firms processing 100+ applicants per day.

### API Endpoint
**HTTP Method:** `POST`  
**Path:** `/api/v1/voice/candidate/screen`  
**Authentication:** `API Key`

### Request Schema
```json
{
  "phone_number": "+15551234567",
  "job_id": 123,
  "screening_questions": [
    {
      "question": "What's your experience with React?",
      "expected_keywords": ["hooks", "components", "state"]
    }
  ],
  "voice_settings": {
    "voice": "Bella",
    "language": "en-US"
  }
}
```

### Response Schema
```json
{
  "success": true,
  "data": {
    "screening_id": "uuid",
    "candidate_id": 456,
    "application_id": 789,
    "agent_id": "elevenlabs-agent-123",
    "call_status": "initiated",
    "estimated_callback_seconds": 30
  },
  "metadata": {
    "processing_time_ms": 1234,
    "service_version": "1.0.0"
  }
}
```

### Error Codes
| Code | Message | Cause | Resolution |
|------|---------|-------|------------|
| 400 | VOICE_INVALID_PHONE_FORMAT | Phone number not in E.164 format | Use +1XXXXXXXXXX format |
| 401 | VOICE_UNAUTHORIZED | Missing or invalid API key | Check Authorization header |
| 404 | VOICE_JOB_NOT_FOUND | Job ID doesn't exist | Verify job exists in system |
| 429 | VOICE_RATE_LIMIT_EXCEEDED | Too many screening requests | Implement exponential backoff |
| 500 | VOICE_AGENT_CREATION_FAILED | ElevenLabs API error | Check ElevenLabs status, retry |
| 503 | VOICE_TWILIO_UNAVAILABLE | Twilio service down | Wait and retry with backoff |

### Error Handling & Retry Policy
- **Retry Strategy:** `exponential_backoff`
- **Max Retries:** `3`
- **Timeout:** `120 seconds`
- **Fallback Behavior:** `queue_for_later` (process when services recover)

### Rate Limits
- **Free Tier:** `10 screenings per day`
- **Paid Tier:** `1000 screenings per day`
- **Burst Limit:** `5 screenings per minute`

### Pricing
- **Per Use:** `$2.50 per screening` (includes Twilio + ElevenLabs costs)
- **Subscription:** `$500/month` (includes 300 screenings, $1.50 each additional)
- **Volume Discount:** 500+ screenings = $2.00 each, 1000+ = $1.75 each

### SLA Commitment
- **Uptime:** `99.5%`
- **Response Time (p95):** `45 seconds` (from SMS to candidate call initiated)
- **Support Level:** `business_hours`

### Dependencies
- **External APIs:** `Twilio (voice calls), ElevenLabs (conversational AI), Claude/OpenAI (transcript extraction)`
- **Internal Services:** `Evaluation.Score.MultiLens, Application.Create`
- **Database:** `PostgreSQL`

### MCP Tool Signature
```json
{
  "name": "velocity_voice_screen_candidate",
  "description": "Initiates SMS-triggered voice screening for a candidate. System creates AI agent, calls candidate, conducts interview, and returns structured data with auto-scoring.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "phone_number": {
        "type": "string",
        "description": "Candidate phone number in E.164 format (+1XXXXXXXXXX)"
      },
      "job_id": {
        "type": "number",
        "description": "ID of job position candidate is applying for"
      },
      "screening_questions": {
        "type": "array",
        "description": "Custom screening questions for this candidate",
        "items": {
          "type": "object",
          "properties": {
            "question": { "type": "string" },
            "expected_keywords": { "type": "array", "items": { "type": "string" } }
          }
        }
      }
    },
    "required": ["phone_number", "job_id"]
  }
}
```

### Code Example (Developer Integration)
```typescript
// Trigger voice screening when candidate clicks "Apply via Phone"
const response = await fetch('https://api.velocity.ai/v1/voice/candidate/screen', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    phone_number: '+15551234567',
    job_id: 123,
    screening_questions: [
      {
        question: "What's your experience with React?",
        expected_keywords: ["hooks", "components", "state"]
      }
    ]
  })
});

const { screening_id, estimated_callback_seconds } = await response.json();
console.log(`Candidate will receive call in ${estimated_callback_seconds} seconds`);
```

### MCP Example (AI Agent Consumption)
```json
{
  "tool": "velocity_voice_screen_candidate",
  "arguments": {
    "phone_number": "+15551234567",
    "job_id": 123,
    "screening_questions": [
      {
        "question": "What's your experience with React?",
        "expected_keywords": ["hooks", "components", "state"]
      }
    ]
  }
}
```

### Competitive Differentiator
**Why choose this over alternatives (Greenhouse, Lever, HireVue):**
- ✅ **30-second deployment** - SMS → Call in under 30s (competitors require scheduled interviews)
- ✅ **Zero scheduling** - Candidate texts when ready, no calendar coordination
- ✅ **24/7 availability** - AI never sleeps, screens candidates at midnight or 3am
- ✅ **Structured data extraction** - Consistent data format vs unstructured notes
- ✅ **Auto-scoring** - Multi-lens evaluation happens automatically
- ✅ **Cost advantage** - $2.50 per screen vs $50+ for human phone screen

### Changelog
| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025-11-14 | Initial production release |

---

## Service: Resume.Parse.Universal

**Service ID:** `resume.parse.universal`  
**Version:** `1.2.0`  
**Status:** `Production`

### Classification
- **Primary Domain:** `data_ingestion`
- **Service Type:** `synchronous`
- **Pricing Model:** `per_use`

### Description
Universal resume parser supporting PDF, DOCX, Markdown, and plain text with AI-powered extraction of skills, experience, achievements, and career insights.

**What it does:** Accepts resume in any common format, extracts structured data (contact info, work history, skills, education, achievements with metrics), generates career timeline, identifies success patterns.

**Why it's valuable:** Eliminates manual data entry, processes 100+ resumes in minutes, extracts nuanced achievements that regex misses (e.g., "led team of 5" vs "team leadership"), consistent data format enables candidate comparison.

**Who uses it:** ATS integrators, recruiting agencies processing high volume, career coaches analyzing client progression, talent analytics teams.

### API Endpoint
**HTTP Method:** `POST`  
**Path:** `/api/v1/resume/parse`  
**Authentication:** `API Key`

### Request Schema
```json
{
  "resume_source": "file|text|url",
  "file": "base64_encoded_file",
  "text": "plain text resume",
  "url": "https://example.com/resume.pdf",
  "format": "auto|pdf|docx|markdown|txt",
  "extract_insights": true
}
```

### Response Schema
```json
{
  "success": true,
  "data": {
    "contact": {
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "+15551234567",
      "location": "San Francisco, CA"
    },
    "work_history": [
      {
        "company": "Tech Corp",
        "title": "Senior Engineer",
        "start_date": "2020-01",
        "end_date": "2023-06",
        "duration_months": 42,
        "achievements": [
          {
            "text": "Led team of 5 to deliver microservices migration",
            "metrics": ["team_size: 5"],
            "impact": "architecture_improvement"
          }
        ],
        "skills": ["React", "Node.js", "AWS"],
        "emotion": "accomplished"
      }
    ],
    "skills": {
      "technical": ["React", "Node.js", "AWS", "PostgreSQL"],
      "soft": ["leadership", "communication", "mentorship"]
    },
    "education": [
      {
        "institution": "University of California",
        "degree": "BS Computer Science",
        "year": 2019
      }
    ],
    "insights": {
      "career_trajectory": "upward",
      "success_factors": ["Technical depth", "Leadership growth"],
      "opportunities": ["Seek principal engineer role", "Consider certifications"],
      "benchmark": "Senior level, 5+ years experience"
    }
  },
  "metadata": {
    "processing_time_ms": 2340,
    "format_detected": "pdf",
    "pages_processed": 2,
    "confidence_score": 0.95
  }
}
```

### Error Codes
| Code | Message | Cause | Resolution |
|------|---------|-------|------------|
| 400 | RESUME_INVALID_FORMAT | Unsupported file format | Use PDF, DOCX, MD, or TXT |
| 400 | RESUME_MISSING_SOURCE | No file, text, or URL provided | Provide one source |
| 413 | RESUME_FILE_TOO_LARGE | File > 10MB | Compress or split resume |
| 422 | RESUME_PARSE_FAILED | Could not extract text | Check file isn't corrupted/password-protected |
| 429 | RESUME_RATE_LIMIT_EXCEEDED | Too many parse requests | Implement backoff |
| 500 | RESUME_AI_EXTRACTION_FAILED | AI provider error | Retry, service falls back to raw text |

### Error Handling & Retry Policy
- **Retry Strategy:** `exponential_backoff`
- **Max Retries:** `3`
- **Timeout:** `30 seconds`
- **Fallback Behavior:** `partial_data` (return raw text if AI extraction fails)

### Rate Limits
- **Free Tier:** `100 parses per month`
- **Paid Tier:** `10,000 parses per month`
- **Burst Limit:** `50 parses per minute`

### Pricing
- **Per Use:** `$0.10 per parse` (with AI insights), `$0.05` (text extraction only)
- **Subscription:** `$50/month` (includes 1000 parses, $0.03 each additional)
- **Volume Discount:** 10,000+ parses = $0.02 each

### SLA Commitment
- **Uptime:** `99.9%`
- **Response Time (p95):** `3 seconds`
- **Support Level:** `24/7`

### Dependencies
- **External APIs:** `pdf-parse-new (PDF), mammoth (DOCX), Claude/OpenAI (AI extraction)`
- **Internal Services:** `None`
- **Database:** `PostgreSQL (optional caching)`

### MCP Tool Signature
```json
{
  "name": "velocity_resume_parse_universal",
  "description": "Parses resumes in any format (PDF, DOCX, Markdown, text) and extracts structured data including contact info, work history, skills, achievements with metrics, and AI-generated career insights.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "resume_source": {
        "type": "string",
        "enum": ["file", "text", "url"],
        "description": "Source type of the resume"
      },
      "file": {
        "type": "string",
        "description": "Base64 encoded resume file (for resume_source=file)"
      },
      "text": {
        "type": "string",
        "description": "Plain text resume content (for resume_source=text)"
      },
      "format": {
        "type": "string",
        "enum": ["auto", "pdf", "docx", "markdown", "txt"],
        "description": "Resume format, use 'auto' for automatic detection"
      },
      "extract_insights": {
        "type": "boolean",
        "description": "Whether to generate AI career insights (default: true)"
      }
    },
    "required": ["resume_source"]
  }
}
```

### Code Example (Developer Integration)
```typescript
// Parse PDF resume from file upload
const fileData = await fs.readFile('resume.pdf');
const base64 = fileData.toString('base64');

const response = await fetch('https://api.velocity.ai/v1/resume/parse', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    resume_source: 'file',
    file: base64,
    format: 'pdf',
    extract_insights: true
  })
});

const { data } = await response.json();
console.log(`Parsed resume for ${data.contact.name}`);
console.log(`Skills: ${data.skills.technical.join(', ')}`);
```

### MCP Example (AI Agent Consumption)
```json
{
  "tool": "velocity_resume_parse_universal",
  "arguments": {
    "resume_source": "url",
    "url": "https://example.com/candidate-resume.pdf",
    "format": "auto",
    "extract_insights": true
  }
}
```

### Competitive Differentiator
**Why choose this over alternatives (Sovren, Textkernel, HireAbility):**
- ✅ **Universal format support** - PDF, DOCX, Markdown, plain text (competitors often PDF-only)
- ✅ **AI achievement extraction** - Understands "led team of 5" vs just keyword matching
- ✅ **Career insights** - Success patterns, opportunities, benchmarks (unique to Velocity)
- ✅ **Cost advantage** - $0.10 per parse vs $0.50-$2.00 for competitors
- ✅ **Sub-3-second response** - 10x faster than batch processing solutions
- ✅ **No training required** - Works out-of-box, competitors need job-specific training

### Changelog
| Version | Date | Changes |
|---------|------|---------|
| 1.2.0 | 2025-11-10 | Added Markdown format support |
| 1.1.0 | 2025-10-15 | Added career insights extraction |
| 1.0.0 | 2025-09-01 | Initial production release |

---

## Service: Evaluation.Score.MultiLens

**Service ID:** `evaluation.score.multilens`  
**Version:** `1.0.0`  
**Status:** `Production`

### Classification
- **Primary Domain:** `evaluation`
- **Service Type:** `synchronous`
- **Pricing Model:** `per_use`

### Description
AI-powered candidate evaluation across 5 independent dimensions: Skills Match, Experience Level, Culture Fit, Growth Potential, and Compliance Risk.

**What it does:** Analyzes candidate data (resume, screening transcript, application) and generates scores (0-100) for each of 5 lenses with detailed reasoning, detected gaps (14 scenario types), and recommended next actions.

**Why it's valuable:** Eliminates bias by evaluating multiple dimensions independently, catches compliance risks early (saving $50K+ in bad hire costs), provides actionable feedback vs generic "good/bad" scoring, consistent evaluation criteria across all candidates.

**Who uses it:** Hiring managers seeking objective candidate assessment, compliance teams screening for risk, recruiting agencies differentiating candidate quality to clients.

### API Endpoint
**HTTP Method:** `POST`  
**Path:** `/api/v1/evaluation/candidate/score`  
**Authentication:** `API Key`

### Request Schema
```json
{
  "candidate_id": 123,
  "application_id": 456,
  "job_id": 789,
  "evaluation_data": {
    "resume_parsed": { },
    "screening_transcript": "...",
    "application_answers": { }
  },
  "scoring_criteria": {
    "skills_weight": 0.3,
    "experience_weight": 0.2,
    "culture_weight": 0.2,
    "growth_weight": 0.15,
    "compliance_weight": 0.15
  }
}
```

### Response Schema
```json
{
  "success": true,
  "data": {
    "score_id": "uuid",
    "overall_score": 82,
    "lens_scores": {
      "skills_match": {
        "score": 85,
        "reasoning": "Strong React and Node.js experience. Missing AWS certification but has hands-on cloud experience.",
        "strengths": ["React hooks mastery", "Full-stack capability"],
        "gaps": ["AWS certification", "Kubernetes experience"]
      },
      "experience_level": {
        "score": 90,
        "reasoning": "5 years experience exceeds 3-year minimum. Led team of 5, demonstrating seniority.",
        "strengths": ["Leadership experience", "Sustained tenure at previous roles"],
        "gaps": []
      },
      "culture_fit": {
        "score": 75,
        "reasoning": "Values collaboration and mentorship. Prefers structured environment vs startup chaos.",
        "strengths": ["Team player", "Mentorship focus"],
        "gaps": ["May need adaptation period for fast-paced environment"]
      },
      "growth_potential": {
        "score": 80,
        "reasoning": "Consistent upward trajectory. Self-directed learner. Open to feedback.",
        "strengths": ["Fast learner", "Career progression"],
        "gaps": ["Limited cross-functional experience"]
      },
      "compliance_risk": {
        "score": 95,
        "reasoning": "No red flags detected. Work authorization confirmed. Background check pending.",
        "strengths": ["Clean employment history", "Authorized to work"],
        "gaps": []
      }
    },
    "detected_gaps": [
      {
        "scenario": "skill_gap_critical",
        "severity": "medium",
        "description": "Missing AWS certification required for role",
        "recommendation": "Offer conditional hire with 90-day certification requirement"
      }
    ],
    "recommended_actions": [
      "Schedule technical interview focusing on cloud architecture",
      "Request AWS learning plan commitment",
      "Verify leadership examples during reference checks"
    ],
    "risk_flags": []
  },
  "metadata": {
    "processing_time_ms": 3200,
    "ai_model": "claude-3-5-sonnet-20241022",
    "confidence": 0.92
  }
}
```

### Error Codes
| Code | Message | Cause | Resolution |
|------|---------|-------|------------|
| 400 | EVAL_MISSING_DATA | Required evaluation data not provided | Include resume or transcript |
| 404 | EVAL_CANDIDATE_NOT_FOUND | Candidate ID doesn't exist | Verify candidate created |
| 429 | EVAL_RATE_LIMIT_EXCEEDED | Too many scoring requests | Implement backoff |
| 500 | EVAL_AI_FAILURE | AI provider error | Retry with exponential backoff |

### Error Handling & Retry Policy
- **Retry Strategy:** `exponential_backoff`
- **Max Retries:** `3`
- **Timeout:** `10 seconds`
- **Fallback Behavior:** `partial_scores` (return scores for completed lenses if some fail)

### Rate Limits
- **Free Tier:** `50 evaluations per month`
- **Paid Tier:** `5,000 evaluations per month`
- **Burst Limit:** `100 evaluations per minute`

### Pricing
- **Per Use:** `$0.50 per evaluation`
- **Subscription:** `$200/month` (includes 500 evaluations, $0.30 each additional)
- **Volume Discount:** 1,000+ evaluations = $0.25 each

### SLA Commitment
- **Uptime:** `99.9%`
- **Response Time (p95):** `5 seconds`
- **Support Level:** `24/7`

### Dependencies
- **External APIs:** `Claude/OpenAI (scoring intelligence)`
- **Internal Services:** `Resume.Parse.Universal, Voice.Extract.Transcript`
- **Database:** `PostgreSQL`

### MCP Tool Signature
```json
{
  "name": "velocity_evaluation_score_multilens",
  "description": "Evaluates candidate across 5 independent dimensions (Skills Match, Experience Level, Culture Fit, Growth Potential, Compliance Risk) with detailed reasoning, gap detection, and recommended actions.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "candidate_id": {
        "type": "number",
        "description": "Unique candidate identifier"
      },
      "application_id": {
        "type": "number",
        "description": "Application record ID"
      },
      "job_id": {
        "type": "number",
        "description": "Job position ID"
      },
      "evaluation_data": {
        "type": "object",
        "description": "Candidate data for evaluation (resume, transcript, application)"
      },
      "scoring_criteria": {
        "type": "object",
        "description": "Weight configuration for each lens (must sum to 1.0)"
      }
    },
    "required": ["candidate_id", "job_id", "evaluation_data"]
  }
}
```

### Code Example (Developer Integration)
```typescript
// Score candidate after resume parse and voice screening
const response = await fetch('https://api.velocity.ai/v1/evaluation/candidate/score', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    candidate_id: 123,
    application_id: 456,
    job_id: 789,
    evaluation_data: {
      resume_parsed: resumeData,
      screening_transcript: transcriptData
    }
  })
});

const { overall_score, lens_scores, detected_gaps } = await response.json();
console.log(`Overall Score: ${overall_score}/100`);
console.log(`Detected ${detected_gaps.length} gaps`);
```

### MCP Example (AI Agent Consumption)
```json
{
  "tool": "velocity_evaluation_score_multilens",
  "arguments": {
    "candidate_id": 123,
    "job_id": 789,
    "evaluation_data": {
      "resume_parsed": { },
      "screening_transcript": "..."
    }
  }
}
```

### Competitive Differentiator
**Why choose this over alternatives (HireVue, Pymetrics, Criteria Corp):**
- ✅ **5-lens independence** - Each dimension scored separately vs single "hire/no hire" (unique to Velocity)
- ✅ **Gap detection** - 14 scenario types with remediation strategies (competitors provide scores without context)
- ✅ **Compliance built-in** - Catches EEOC, work authorization, background check risks early
- ✅ **Cost advantage** - $0.50 per eval vs $15-$50 for video AI assessments
- ✅ **Explainable AI** - Detailed reasoning for every score (competitors use black-box models)
- ✅ **Bias reduction** - Independent lenses prevent halo effect contamination

### Changelog
| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025-11-14 | Initial production release |

---

**[Additional services would follow the same template format...]**

---

## Section 5: Integration Patterns

### REST API Integration (Developers)

**Standard authentication flow:**

```typescript
// 1. Obtain API key from Velocity dashboard
const API_KEY = process.env.VELOCITY_API_KEY;

// 2. Make authenticated request
async function callVelocityService(endpoint, data) {
  const response = await fetch(`https://api.velocity.ai/v1${endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${API_KEY}`,
      'Content-Type': 'application/json',
      'X-Request-ID': generateUUID() // Optional correlation ID
    },
    body: JSON.stringify(data)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new VelocityError(error.error.code, error.error.message);
  }

  return response.json();
}
```

### MCP Integration (AI Agents)

**Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json`):**

```json
{
  "mcpServers": {
    "velocity": {
      "command": "npx",
      "args": ["-y", "@velocity/mcp-server"],
      "env": {
        "VELOCITY_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

**AI agent usage:**

```
User: "Screen this candidate via phone: +15551234567 for job 123"

AI Agent uses:
{
  "tool": "velocity_voice_screen_candidate",
  "arguments": {
    "phone_number": "+15551234567",
    "job_id": 123
  }
}

Result: Candidate screening initiated, call will occur in 30 seconds.
```

### Webhook Integration (Event-Driven)

**Subscribe to Velocity events:**

```typescript
POST https://api.velocity.ai/v1/webhooks/subscribe
{
  "url": "https://your-app.com/webhooks/velocity",
  "events": [
    "screening.completed",
    "candidate.scored",
    "application.created"
  ],
  "secret": "webhook_signing_secret"
}

// Your webhook handler
app.post('/webhooks/velocity', (req, res) => {
  const signature = req.headers['x-velocity-signature'];
  const isValid = verifySignature(req.body, signature, WEBHOOK_SECRET);
  
  if (!isValid) {
    return res.status(401).send('Invalid signature');
  }

  const { event, data } = req.body;
  
  switch (event) {
    case 'screening.completed':
      handleScreeningComplete(data);
      break;
    case 'candidate.scored':
      handleCandidateScored(data);
      break;
  }
  
  res.sendStatus(200);
});
```

---

## Section 6: Competitive Value Matrix

| Feature | Velocity | Greenhouse | Lever | HireVue | Generic ATS |
|---------|----------|------------|-------|---------|-------------|
| **Voice Screening (SMS-triggered)** | ✅ 30s | ❌ | ❌ | ❌ | ❌ |
| **Multi-Lens Evaluation** | ✅ 5 dimensions | ❌ Single score | ❌ | ✅ 3 dimensions | ❌ |
| **Universal Resume Parser** | ✅ PDF/DOCX/MD/TXT | ✅ PDF only | ✅ PDF only | ❌ | ✅ PDF only |
| **AI Career Insights** | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Auto-Drafting (Offers/Questions)** | ✅ | ❌ | ✅ Templates | ❌ | ✅ Templates |
| **Real-time Gap Detection** | ✅ 14 scenarios | ❌ | ❌ | ❌ | ❌ |
| **MCP/AI Agent Support** | ✅ Native | ❌ | ❌ | ❌ | ❌ |
| **Cost per Screen** | $2.50 | $50+ (human) | $50+ (human) | $15-$50 | $50+ (human) |
| **Setup Time** | 5 minutes | 2-4 weeks | 2-4 weeks | 1 week | 1-2 weeks |
| **API-First Architecture** | ✅ | ⚠️ Limited | ⚠️ Limited | ❌ | ⚠️ Limited |

### Unique Velocity Advantages

1. **SMS → Screen in 30 seconds** - No competitor offers voice screening triggered by text message
2. **Multi-Lens Independence** - Only platform evaluating 5 dimensions separately to prevent bias
3. **AI Agent Native** - First ATS designed for MCP consumption by AI assistants
4. **Touch Once Principle** - Every action triggers automatic follow-ups (others require manual steps)
5. **Voice-First Design** - Eliminates communication barriers vs form-based applications

---

## Section 7: Machine-Readable Metadata

**This section provides structured schemas for Phase 2 (MCP Server) and Phase 3 (Auto-Packager) to consume.**

### Service Registry JSON Schema

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Velocity Service Registry",
  "type": "object",
  "properties": {
    "platform": {
      "type": "string",
      "const": "velocity"
    },
    "version": {
      "type": "string",
      "pattern": "^\\d+\\.\\d+\\.\\d+$"
    },
    "services": {
      "type": "array",
      "items": {
        "$ref": "#/definitions/Service"
      }
    }
  },
  "definitions": {
    "Service": {
      "type": "object",
      "required": ["id", "name", "version", "domain", "type", "pricing", "endpoint", "mcp_tool"],
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^[a-z]+\\.[a-z]+\\.[a-z]+$"
        },
        "name": {
          "type": "string"
        },
        "version": {
          "type": "string",
          "pattern": "^\\d+\\.\\d+\\.\\d+$"
        },
        "domain": {
          "type": "string",
          "enum": ["voice_intelligence", "data_ingestion", "evaluation", "automation", "analytics", "integration"]
        },
        "type": {
          "type": "string",
          "enum": ["synchronous", "asynchronous", "streaming", "webhook"]
        },
        "pricing": {
          "type": "object",
          "properties": {
            "model": {
              "type": "string",
              "enum": ["per_use", "subscription", "tiered", "freemium"]
            },
            "per_use_cost": {
              "type": "number"
            }
          }
        },
        "endpoint": {
          "type": "object",
          "properties": {
            "method": {
              "type": "string",
              "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]
            },
            "path": {
              "type": "string"
            }
          }
        },
        "mcp_tool": {
          "type": "object",
          "properties": {
            "name": {
              "type": "string"
            },
            "description": {
              "type": "string"
            },
            "inputSchema": {
              "type": "object"
            }
          }
        }
      }
    }
  }
}
```

### Example Service Registry (services.json)

```json
{
  "platform": "velocity",
  "version": "1.0.0",
  "services": [
    {
      "id": "voice.screen.candidate",
      "name": "Voice.Screen.Candidate",
      "version": "1.0.0",
      "status": "production",
      "domain": "voice_intelligence",
      "type": "asynchronous",
      "pricing": {
        "model": "per_use",
        "per_use_cost": 2.50,
        "subscription_cost": 500,
        "subscription_includes": 300
      },
      "endpoint": {
        "method": "POST",
        "path": "/api/v1/voice/candidate/screen",
        "auth": "api_key"
      },
      "mcp_tool": {
        "name": "velocity_voice_screen_candidate",
        "description": "Initiates SMS-triggered voice screening for a candidate.",
        "inputSchema": {
          "type": "object",
          "properties": {
            "phone_number": { "type": "string" },
            "job_id": { "type": "number" }
          },
          "required": ["phone_number", "job_id"]
        }
      },
      "sla": {
        "uptime": "99.5%",
        "response_time_p95_ms": 45000
      },
      "dependencies": ["twilio", "elevenlabs", "claude"]
    }
  ]
}
```

---

## Appendix A: Template Adaptation Guide

### How to Use This Template for Your Own MCP Server

**Step 1: Fork this document**
```bash
cp mcp-service-catalog-template.md your-platform-service-catalog.md
```

**Step 2: Update document header**
- Change platform name from "Velocity" to your platform
- Update version to 1.0.0
- Set your revision date
- Update author information

**Step 3: Run Service Discovery**
- Follow [Section 3: Service Discovery Framework](#section-3-service-discovery-framework)
- Inventory ALL your API endpoints, background jobs, AI services
- Use the discovery template to evaluate each capability

**Step 4: Document each service**
- Copy the [Service Information Sheet Template](#service-information-sheet-template)
- Fill out ALL fields (no skipping!)
- Answer the [Completeness Validation Questions](#completeness-validation-questions)

**Step 5: Generate machine-readable metadata**
- Create `services.json` using the schema in Section 7
- Ensure every service has MCP tool signature
- Validate JSON against schema

**Step 6: Validate completeness**
- Run [Appendix B: Completeness Checklist](#appendix-b-completeness-checklist)
- Fix any missing items
- Don't skip error handling documentation

**Step 7: Review pricing strategy**
- For each service, determine: per-use cost, subscription tiers, volume discounts
- Justify pricing vs competitive alternatives
- Document SLA commitments

**Step 8: Publish and iterate**
- Commit catalog to version control
- Set up changelog tracking for service updates
- Review quarterly and add new services

---

## Appendix B: Completeness Checklist

**Run this checklist before marking catalog complete:**

### Service Discovery Completeness
- ✅ All API endpoints inventoried?
- ✅ All background jobs inventoried?
- ✅ All AI/ML services inventoried?
- ✅ All data transformations inventoried?
- ✅ All external integrations inventoried?
- ✅ All webhook handlers inventoried?

### Service Documentation Completeness
For EACH service:
- ✅ Service ID follows naming convention?
- ✅ Version number assigned?
- ✅ Status (Production/Beta/Alpha) declared?
- ✅ Primary domain categorized?
- ✅ Service type categorized?
- ✅ Pricing model defined?
- ✅ Natural language description written?
- ✅ API endpoint documented (method + path)?
- ✅ Request schema provided?
- ✅ Response schema provided?
- ✅ ALL error codes documented?
- ✅ Error retry policy specified?
- ✅ Rate limits defined?
- ✅ Pricing detailed (per-use + subscription)?
- ✅ SLA commitment declared?
- ✅ Dependencies listed?
- ✅ MCP tool signature provided?
- ✅ Developer code example included?
- ✅ AI agent MCP example included?
- ✅ Competitive differentiator explained?
- ✅ Changelog started?

### Error Handling Completeness
- ✅ Standard error format documented?
- ✅ Error code naming convention followed?
- ✅ Retry strategies defined for each service?
- ✅ Retryable vs non-retryable errors classified?
- ✅ Timeout values specified?
- ✅ Fallback behaviors documented?

### Integration Completeness
- ✅ REST API authentication flow documented?
- ✅ MCP integration example provided?
- ✅ Webhook subscription flow documented?
- ✅ Rate limiting implementation explained?

### Metadata Completeness
- ✅ `services.json` created?
- ✅ JSON validates against schema?
- ✅ All services in catalog have JSON entry?
- ✅ MCP tool names match convention?

### Business Completeness
- ✅ Pricing justified vs competitors?
- ✅ Competitive value matrix complete?
- ✅ Target audience identified for each service?
- ✅ ROI/value proposition clear?

**If ANY checkbox is unchecked, catalog is NOT complete.**

---

## Appendix C: Debugging Playbook

### Common Issues & Solutions

#### Issue: Service returns 500 Internal Server Error
**Diagnostic Steps:**
1. Check service health endpoint: `GET /api/v1/health`
2. Review error logs for correlation ID
3. Verify external dependency status (Twilio, ElevenLabs, etc.)
4. Check database connectivity

**Common Causes:**
- External API down (Twilio, ElevenLabs)
- Database connection pool exhausted
- AI provider rate limit exceeded
- Invalid environment variable configuration

**Resolution:**
```bash
# Check dependency health
curl https://api.velocity.ai/v1/health

# Check specific service health
curl https://api.velocity.ai/v1/voice/health

# Review logs with correlation ID
grep "correlation_id: abc-123" /var/log/velocity.log
```

#### Issue: Rate limit exceeded (429)
**Diagnostic Steps:**
1. Check current rate limit status: `GET /api/v1/rate-limit/status`
2. Review request frequency in logs
3. Verify client is implementing exponential backoff

**Resolution:**
```typescript
// Implement exponential backoff
async function callWithRetry(fn, maxRetries = 3) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (error.status === 429 && attempt < maxRetries - 1) {
        const delay = Math.pow(2, attempt) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
      } else {
        throw error;
      }
    }
  }
}
```

#### Issue: Parsing errors (422)
**Diagnostic Steps:**
1. Validate input against schema
2. Check file format and size
3. Verify encoding (UTF-8)

**Common Causes:**
- Invalid file format (e.g., scanned PDF vs text PDF)
- Password-protected files
- Corrupted uploads
- File size exceeds 10MB

**Resolution:**
```bash
# Validate file is parseable
file resume.pdf  # Should show "PDF document" not "data"

# Check file size
ls -lh resume.pdf  # Should be < 10MB

# Test with simpler input
curl -X POST https://api.velocity.ai/v1/resume/parse \
  -H "Authorization: Bearer $API_KEY" \
  -d '{"resume_source": "text", "text": "John Doe\nSoftware Engineer"}'
```

### Debugging Decision Tree

```
Service Error Occurred
│
├─ 4xx Error (Client Error)
│  │
│  ├─ 400 Bad Request
│  │  └─ Fix: Validate input against schema
│  │
│  ├─ 401 Unauthorized
│  │  └─ Fix: Check API key is valid
│  │
│  ├─ 404 Not Found
│  │  └─ Fix: Verify resource exists (candidate, job, etc.)
│  │
│  ├─ 422 Unprocessable Entity
│  │  └─ Fix: Check file format, encoding, size
│  │
│  └─ 429 Rate Limit
│     └─ Fix: Implement exponential backoff
│
└─ 5xx Error (Server Error)
   │
   ├─ 500 Internal Server Error
   │  └─ Action: Check /health endpoint, review logs
   │
   ├─ 503 Service Unavailable
   │  └─ Action: Check dependency status, retry with backoff
   │
   └─ 504 Gateway Timeout
      └─ Action: Increase timeout, check for slow queries
```

### Log Analysis Patterns

**Find errors by correlation ID:**
```bash
grep "correlation_id: abc-123" /var/log/velocity.log | jq .
```

**Find all errors in last hour:**
```bash
grep '"level":"ERROR"' /var/log/velocity.log | grep "$(date -u +%Y-%m-%dT%H)" | jq .
```

**Count errors by service:**
```bash
grep '"level":"ERROR"' /var/log/velocity.log | jq -r .service | sort | uniq -c | sort -rn
```

**Find slow requests (>5s):**
```bash
grep '"duration_ms"' /var/log/velocity.log | jq 'select(.duration_ms > 5000)'
```

---

## Appendix D: Phase 2 & 3 Roadmap

### Phase 2: MCP Server Module

**Goal:** Auto-generate MCP server from `services.json` catalog

**Technical Approach:**
```typescript
// Read services.json
const services = JSON.parse(fs.readFileSync('services.json'));

// Generate MCP tool definitions
const mcpTools = services.services.map(service => ({
  name: service.mcp_tool.name,
  description: service.mcp_tool.description,
  inputSchema: service.mcp_tool.inputSchema,
  handler: async (args) => {
    // Proxy to actual API endpoint
    return fetch(`https://api.velocity.ai${service.endpoint.path}`, {
      method: service.endpoint.method,
      headers: { 'Authorization': `Bearer ${process.env.API_KEY}` },
      body: JSON.stringify(args)
    });
  }
}));

// Start MCP server
const server = new MCPServer(mcpTools);
server.listen();
```

**Deliverables:**
1. `@velocity/mcp-server` npm package
2. Auto-generated tool handlers from `services.json`
3. Authentication & rate limiting middleware
4. Usage tracking and billing hooks

### Phase 3: Service Packaging System

**Goal:** Auto-package each service as standalone installable module

**Technical Approach:**
```typescript
// For each service in catalog
services.services.forEach(service => {
  // Generate standalone module structure
  const module = {
    name: `@velocity/${service.id}`,
    readme: generateReadme(service),
    packageJson: generatePackageJson(service),
    apiClient: generateAPIClient(service),
    types: generateTypeDefinitions(service),
    examples: generateExamples(service)
  };
  
  // Write to exportable-modules/
  writeModuleFiles(module);
  
  // Create tarball
  exec(`tar -czf ${service.id}.tar.gz ${service.id}/`);
});
```

**Deliverables:**
1. Auto-generated README for each service
2. TypeScript client library
3. Integration examples (Express, Next.js, etc.)
4. One-command installation: `npm install @velocity/voice.screen.candidate`

---

**End of MCP Service Catalog Template v1.0.0**

---

## Revision History

| Version | Date | Author | Summary of Changes |
|---------|------|--------|-------------------|
| 1.0.0 | 2025-11-14 | Velocity AI Platform | Initial template release with 3 example services (Voice Screening, Resume Parsing, Multi-Lens Evaluation), standardized formats, debugging playbook, and Phase 2/3 roadmap |

---

**Questions? Contact:** support@velocity.ai  
**Documentation:** https://docs.velocity.ai  
**GitHub:** https://github.com/velocity-ai/mcp-catalog-template
