# AI-Guided Interactive Demo System

## Overview

The Velocity platform features an **AI-guided demo system** where the ElevenLabs voice assistant can:

- 🎯 **Highlight elements** on the page with spotlight effects
- 💬 **Display dynamic messages** from the AI
- 🗺️ **Know the current page** and context
- 🔄 **Navigate between pages** seamlessly
- ✨ **Non-disruptive** - Smooth animations, no refresh

## Architecture

```
┌─────────────────┐         ┌──────────────────┐
│  Voice Widget   │────────▶│  Parent Window   │
│   (Popup)       │ postMsg │  (Main App)      │
└─────────────────┘         └──────────────────┘
        │                            │
        │ ElevenLabs                 │
        │ Client Tools               │
        ▼                            ▼
  Tool Calls          ┌────────────────────────┐
  (navigateToPage)    │  AICommandContext      │
  (highlightElement)  │  Event Bus & State     │
  (showMessage)       └────────────────────────┘
                                   │
                      ┌────────────┴────────────┐
                      │                         │
                      ▼                         ▼
            AIHighlightOverlay         AIDynamicMessage
            (Spotlight effect)         (Message overlay)
```

## ElevenLabs Agent Configuration

### Client Tools Setup

In your ElevenLabs agent dashboard, configure these **Client Tools**:

#### 1. Navigate To Page

```json
{
  "name": "navigateToPage",
  "description": "Navigate the user to a different page in the application",
  "parameters": {
    "path": {
      "type": "string",
      "description": "The route path to navigate to",
      "enum": ["/", "/voice-test", "/work-journey", "/batch-analyzer", "/knowledge", "/docs", "/admin"]
    }
  }
}
```

**Example usage in agent prompt:**
```
When the user says "show me voice testing", use the navigateToPage tool with path="/voice-test"
```

#### 2. Highlight Element

```json
{
  "name": "highlightElement",
  "description": "Highlight a specific element on the page with a spotlight effect",
  "parameters": {
    "elementId": {
      "type": "string",
      "description": "The ID of the element to highlight (optional if using selector)"
    },
    "selector": {
      "type": "string",
      "description": "CSS selector for the element (optional if using elementId)"
    },
    "message": {
      "type": "string",
      "description": "Optional message to display near the highlighted element"
    },
    "duration": {
      "type": "number",
      "description": "Duration in milliseconds (optional, default: until cleared)"
    }
  }
}
```

**Example usage:**
```
When explaining a feature, use highlightElement with:
- elementId: "button-generate" 
- message: "Click this button to generate a journey map"
- duration: 5000
```

#### 3. Show Message

```json
{
  "name": "showMessage",
  "description": "Display a dynamic message overlay from the AI",
  "parameters": {
    "title": {
      "type": "string",
      "description": "Message title"
    },
    "content": {
      "type": "string",
      "description": "Message content"
    },
    "position": {
      "type": "string",
      "description": "Position on screen",
      "enum": ["top", "center", "bottom"]
    },
    "duration": {
      "type": "number",
      "description": "Duration in milliseconds (optional)"
    }
  }
}
```

**Example usage:**
```
After user completes an action, use showMessage with:
- title: "Great job!"
- content: "You've successfully created your first journey map"
- position: "top"
- duration: 5000
```

#### 4. Clear Highlight

```json
{
  "name": "clearHighlight",
  "description": "Remove the current element highlight",
  "parameters": {}
}
```

#### 5. Clear Message

```json
{
  "name": "clearMessage",
  "description": "Remove the current message overlay",
  "parameters": {}
}
```

## Sample Agent System Prompt

```
You are the Velocity AI Demo Guide. Your mission is to provide interactive, voice-guided demos of the Velocity platform.

CAPABILITIES:
- Navigate users between pages using navigateToPage
- Highlight UI elements using highlightElement
- Display helpful messages using showMessage
- Know the current page the user is viewing

DEMO FLOW EXAMPLE:

1. Introduction
   "Welcome to Velocity! I'm your AI guide. Would you like a quick tour?"

2. Navigate to feature
   User: "Yes, show me voice testing"
   Action: navigateToPage("/voice-test")
   Then: highlightElement with elementId="button-test-call"
   Say: "Here's where you can test voice calls. Click this button to try it out."

3. Provide context
   When user asks about a feature, use showMessage to display:
   - Key capabilities
   - Best practices
   - Next steps

4. Interactive guidance
   User: "I'm ready for the next feature"
   Action: navigateToPage("/batch-analyzer")
   Then: highlightElement with selector="[data-testid='button-upload']"
   Say: "Let's explore batch resume analysis. Upload multiple resumes here."

NAVIGATION ROUTES:
- "/" - Home (Journey Mapping)
- "/voice-test" - Voice Agent Testing
- "/work-journey" - Work Journey Analysis
- "/batch-analyzer" - Batch Resume Analyzer
- "/knowledge" - Knowledge Dashboard
- "/docs" - Documentation
- "/admin" - Admin Settings

ELEMENT IDs (commonly used):
- "button-generate" - Generate journey button
- "button-save" - Save journey button
- "button-test-call" - Test call button
- "button-upload" - File upload button
- "button-get-voice-assistant" - Voice assistant button

BEST PRACTICES:
- Always clear previous highlights before highlighting new elements
- Use duration (5000-8000ms) for timed highlights
- Position messages based on highlighted element location
- Navigate only when user explicitly requests or agrees
- Provide context about why you're highlighting elements
```

## Available Pages for Navigation

| Route | Page Name | Description |
|-------|-----------|-------------|
| `/` | Home | Customer Journey Mapping |
| `/voice-test` | Voice Testing | Twilio voice agent testing interface |
| `/work-journey` | Work Journey | Resume-based career path analysis |
| `/batch-analyzer` | Batch Analyzer | Multi-resume comparative analysis |
| `/knowledge` | Knowledge | AI knowledge management system |
| `/docs` | Documentation | Platform documentation |
| `/admin` | Admin Settings | Password protection settings |

## Common Element IDs

Use these IDs with the `highlightElement` tool:

```javascript
// Home Page
"button-generate"           // Generate journey button
"button-save"              // Save journey button
"button-share"             // Share journey button
"button-get-voice-assistant" // Voice assistant button
"input-description"        // Journey description textarea

// Voice Testing Page
"button-test-call"         // Test call button
"select-machine-detection" // Machine detection dropdown
"input-to-number"         // Phone number input

// Batch Analyzer Page
"button-upload"           // File upload button
"button-analyze"          // Analyze resumes button

// Navigation
"nav-dashboard"           // Dashboard nav item
"nav-voice-testing"       // Voice testing nav item
"nav-work-journey"        // Work journey nav item
```

## Example Conversation Flows

### Demo Flow 1: Feature Tour

```
AI: "Welcome! I can guide you through Velocity's features. 
     Would you like to start with journey mapping or voice testing?"

User: "Show me voice testing"

AI: [navigateToPage("/voice-test")]
    [highlightElement: elementId="button-test-call", 
     message="Test voice calls here", duration=5000]
    "Here's the voice testing interface. You can make test calls 
     with custom parameters. Ready to try it?"

User: "What can I customize?"

AI: [showMessage: title="Voice Call Options", 
     content="• Phone number\n• Machine detection\n• Recording\n• Custom messages", 
     position="top", duration=8000]
    "You can customize all these options for your test calls."
```

### Demo Flow 2: Guided Tutorial

```
AI: "I'll walk you through creating a journey map. Are you ready?"

User: "Yes"

AI: [highlightElement: selector="textarea", 
     message="Describe a customer journey here", duration=6000]
    "First, describe a customer journey in natural language. 
     For example, 'A user discovers our product through a Google search.'"

User: [types description]

AI: [clearHighlight]
    [highlightElement: elementId="button-generate", 
     message="Click to generate", duration=5000]
    "Great! Now click this button to generate your journey map."

User: [clicks generate]

AI: [clearHighlight]
    [showMessage: title="Journey Generated!", 
     content="Your AI-powered journey map is ready. You can edit, save, or share it.", 
     position="center", duration=6000]
    "Perfect! Your journey map has been created. Would you like to save it?"
```

## Testing the System

### Manual Testing

1. **Open Voice Assistant**
   - Click "Voice Assistant" button in main app
   - Popup window opens

2. **Test Context Awareness**
   - Check status message shows current page
   - Navigate in main window, ask AI "what page am I on?"

3. **Test Navigation**
   - Ask AI: "Take me to voice testing"
   - Verify navigation occurs in parent window

4. **Test Highlighting**
   - Ask AI: "Show me the generate button"
   - Verify spotlight effect appears
   - Verify message tooltip displays

5. **Test Messages**
   - Ask AI: "Tell me about journey mapping"
   - Verify overlay message appears

### Developer Testing

```javascript
// Manually trigger commands from console
window.postMessage({
  type: 'AI_COMMAND',
  command: 'highlight',
  params: {
    elementId: 'button-generate',
    message: 'Test highlight',
    duration: 5000
  }
}, '*');

window.postMessage({
  type: 'AI_COMMAND',
  command: 'showMessage',
  params: {
    title: 'Test Message',
    content: 'This is a test from the AI assistant',
    position: 'top',
    duration: 5000
  }
}, '*');

window.postMessage({
  type: 'AI_COMMAND',
  command: 'navigate',
  params: { path: '/voice-test' }
}, '*');
```

## Security Considerations

1. **Message Origin Validation**
   - Currently accepts all origins (`'*'`)
   - For production, validate `event.origin`

2. **Navigation Validation**
   - Whitelist allowed routes
   - Prevent external URL navigation

3. **Element Targeting**
   - Sanitize selectors to prevent XSS
   - Validate element IDs against whitelist

## Future Enhancements

- [ ] Screen recording integration
- [ ] Multi-language support
- [ ] Analytics tracking for demo completion
- [ ] Custom CSS animations per element type
- [ ] Voice command transcription display
- [ ] Demo progress tracking
- [ ] Branching demo paths based on user interests
- [ ] Integration with user onboarding system
