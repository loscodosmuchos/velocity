# Velocity Platform Integration Guide

**Source:** Velocity Workforce Management System  
**Target:** Velocity Candidate Journey Champion (Voice-First Multi-Agent Platform)  
**Integration Date:** November 10, 2025

---

## 🎯 Core Platform Philosophy

### Two-Thread Architecture

**Thread 1: Universal Information Ingestion**
```
GOAL: Accept information from ANYWHERE in ANY format

Input Channels:
├── API (structured data)
├── Copy-paste (freeform text)
├── Email (conversation context)
├── Voice (natural language via Twilio/ElevenLabs)
├── Images (whiteboard photos, OCR)
├── Documents (PDFs, Word, Excel, Markdown)
├── Voice memos (audio transcription)
└── Links (web scraping)

Processing Pipeline:
1. Parse → What is this?
2. Convert → Make it structured
3. Tag → Categorize & classify
4. Track → Preserve chain of custody
5. Validate → Hash files (prove no changes)
6. Secure → Encrypt within framework
7. Store → Database persistence
8. Index → Make it searchable

Result: Everything in, nothing lost, everything recoverable
```

**Thread 2: Intelligent Output & Action (Touch Once Principle)**
```
GOAL: Figure out what to do with it, THEN DO IT (only once)

Processing:
1. Recognize what it is (based on context + intent)
2. Determine what it's supposed to do
3. Execute ONE-CLICK ACTION
4. TOUCH ONCE PRINCIPLE: Don't move it again
5. Compress/shorthand while preserving integrity

One-Click Examples:
├── Email needs writing? → Auto-draft → Review → Send
├── Contract missing clauses? → Analyze → Suggest → Queue for approval
├── Missing information? → Identify → Draft email → Queue → Send
├── Approval needed? → Queue → One-click approve → Auto-downstream
└── Action required? → Queue → Auto-remind → Track completion

Result: Information flows. Humans stay in control. Decisions happen fast.
```

---

## 🤖 AI Intelligence Layer (Already Implemented)

### 1. Contract Analysis (`/ai/insights`)

**Features:**
- Upload contracts (SOW, PO, Agreement) for instant AI analysis
- Risk Scoring: 0-100 scale with color-coded severity
  - Green < 30 (Low Risk)
  - Yellow 30-70 (Medium Risk)
  - Red > 70 (High Risk)
- Extracted Terms: Payment schedule, dates, total value, deliverables
- Risk Detection: Missing protections, non-standard clauses, compliance gaps
- Recommendations: Actionable advice for strengthening contracts

**Implementation:**
- Claude 3.5 Sonnet API for analysis
- 2-second analysis time
- Live data integration with POs, SOWs, Invoices

### 2. Predictive Alerts

**Gap Scenarios (14 types):**

| ID | Scenario Type | Entity | Detection Logic |
|----|--------------|---------|-----------------|
| 1 | Maintenance Overdue | Assets | `lastMaintenanceDate + interval > today` |
| 2 | Missing Contract Clauses | SOW | AI analyzes against org policy |
| 3 | Orphan Invoice | Invoice | `invoiceId NOT IN (SELECT invoiceId FROM timecards)` |
| 4 | Quantity Variance | Invoice | `invoicedHours != approvedHours` |
| 5 | Overdue Payment | Invoice | `dueDate < today AND status != 'Paid'` |
| 6 | Unapproved Past-Due PO | PO | `status = 'Pending' AND startDate < today` |
| 7 | Outstanding Reimbursement | Expense | `status = 'Approved' AND reimbursed = false` |
| 8 | Missing Receipt | Expense | `receiptUrl IS NULL` |
| 9 | Policy Violation | Expense | `amount > policyLimit OR category NOT IN allowedCategories` |
| 10 | Delayed Timecard | Timecard | `weekEndDate + 3 days < today AND status = 'Draft'` |
| 11 | Weekend Hours Anomaly | Timecard | `dayOfWeek IN (Saturday, Sunday) AND hours > threshold` |
| 12 | Asset Mismatch | Timecard | `assignedAsset != projectAsset` |
| 13 | Vendor Pattern | Contractor | `invoiceVarianceRate > 20% over last 6 months` |
| 14 | Contract Expiring | SOW | `endDate - today < 30 days` |

**Prediction Features:**
- Budget Overrun Prediction: Analyzes burn rate to forecast exhaustion
- Timeline Risk Detection: Identifies SOWs at risk of missing delivery dates
- Variance Pattern Recognition: Flags recurring discrepancies
- Confidence Scoring: Each prediction includes 0-100% confidence level

### 3. AI Assistant (Context-Aware Chat)

**Features:**
- Floating chat bubble on every page
- Context-aware responses based on current route
- Natural language Q&A
- Page-specific conversation starters
- Related link navigation

**Implementation:**
- Widget appears bottom-right on all pages
- Knows current route context
- Mock responses ready for Claude API integration

---

## 🎙️ Conversational AI Architecture (Voice-First)

### VINessa AI Agents (5 Specialized Bots)

**1. VINessa - Timecard Assistant**
```
User: "I worked 8 hours on Building B"
Flow: Voice → ElevenLabs transcription → Parse intent → Create timecard
Result: Timecard submitted in 45 seconds (vs 10 minutes manual)
Time Savings: 93%
```

**2. VINessa - Equipment Manager**
```
User: "Check out engineer kit for John Smith"
Flow: Voice → Identify employee → Load kit template → Assign 5 assets
Result: New hire onboarding in 2 minutes
Assets: Laptop, phone, hard hat, safety vest, badge
```

**3. VINessa - Project Status Collector**
```
Questions: 5 essential project health checks
Flow: Voice interview → Crisis detection → Executive alerts
Duration: 3 minutes for comprehensive update
```

**4. VINessa - Approval Assistant**
```
User: "Approve all my pending timecards"
Flow: Voice → Fetch pending items → Bulk approve → Notification
Result: Bulk approval in 15 seconds (vs 5 min per item)
Time Savings: 95%
```

**5. VINessa - Help Desk**
```
User: "Why is this PO red?"
Flow: Voice → Context detection → Explain budget status → Related links
Result: Zero training required, instant context-aware answers
```

### Voice Integration Stack

**Components:**
- **Twilio**: Phone infrastructure (SMS, voice calls)
- **ElevenLabs**: Conversational AI agents with workflow nodes
- **WebSocket Bridge**: Real-time audio streaming (μ-law ↔ PCM16 conversion)
- **Natural Language Understanding**: Intent classification and entity extraction

**Architecture:**
```
User Phone Call → Twilio (μ-law 8kHz)
    ↓
WebSocket Bridge (audio conversion)
    ↓
ElevenLabs Agent (16kHz PCM16)
    ↓
AI Processing (intent, entities)
    ↓
Action Execution (create record, approve, assign)
    ↓
Response Generation
    ↓
Voice Synthesis → User
```

**Critical Audio Codec Details:**
- Twilio uses μ-law encoding (8kHz)
- ElevenLabs uses PCM16 (16kHz)
- Conversion requires:
  - Resampling: 8kHz ↔ 16kHz
  - Codec conversion: μ-law ↔ PCM16
  - **Ones' complement fix**: `byte ^ 0xFF` before decode/after encode (critical for audio quality)

---

## 📊 Data Model & Relationships

### Core Entities

**Workforce Management:**
```typescript
Contractors (vendors/suppliers)
├── Has many: Purchase Orders
├── Has many: Statements of Work
├── Has many: Timecards
├── Has many: Invoices
└── Tracks: Historical performance patterns

Employees (internal staff)
├── Has many: Assets (assigned)
├── Has many: Timecards (as approver)
├── Has many: Expenses
└── Role: Manager, Buyer, Contractor, Viewer

Purchase Orders
├── Belongs to: Contractor
├── Has many: Contractors (via join table)
├── Has many: Timecards
├── Has many: Invoices
├── Has many: Change Orders
└── Budget tracking and variance detection

Statements of Work (SOW)
├── Belongs to: Contractor
├── Belongs to: Purchase Order
├── Has many: Change Orders
├── Has many: Deliverables
└── AI risk analysis and compliance checks

Timecards
├── Belongs to: Contractor
├── Belongs to: Purchase Order
├── Belongs to: Employee (approver)
├── Approval workflow
└── Generates: Invoices

Invoices
├── Belongs to: Contractor
├── Belongs to: Purchase Order
├── References: Timecards
├── Variance detection
└── Payment tracking

Expenses
├── Belongs to: Contractor OR Employee
├── Has one: Receipt (file upload)
├── Policy validation
└── Reimbursement tracking

Assets (Equipment)
├── Belongs to: Employee OR Room
├── Has many: Maintenance Records
├── Depreciation tracking
└── Barcode scanning support
```

### Asset Management Specifics

**Equipment Kits (Role-Based Templates):**
```typescript
Engineer Kit:
├── Laptop (Dell XPS 15)
├── Mobile Phone (iPhone 14)
├── Hard Hat (safety equipment)
├── Safety Vest (PPE)
└── Security Badge (access control)

Administrator Kit:
├── Laptop (MacBook Pro)
├── Monitor (27" 4K)
├── Wireless Keyboard
├── Wireless Mouse
└── Headset (noise-cancelling)
```

**Dual Assignment Model:**
- Assets can be assigned to **Employees** (individual ownership)
- Assets can be assigned to **Rooms** (shared resources)
- Example: Conference room projector vs personal laptop

---

## 🛣️ Route Architecture (95+ Routes)

### Dashboard & Core
```
/ - Executive dashboard with AI insights
/notifications - Notification center with alerts
```

### Workforce Management
```
/contractors - List with create/export
/contractors/create - New contractor form
/contractors/edit/:id - Edit contractor
/contractors/show/:id - Contractor details
/contractors/import - Bulk CSV import
```

### Transactional Flows
```
/purchase-orders - PO lifecycle management
/purchase-orders/create - New PO form
/purchase-orders/:id/manage-contractors - Assign contractors
/purchase-orders/templates - PO templates library

/timecards - Timecard submission/approval
/timecards/pending - Pending approval queue
/timecards/bulk-approve - Bulk approval interface

/invoices - Invoice generation/tracking
/invoices/generate - Generate from timecards

/expenses - Expense management
/expenses/bulk-approve - Bulk expense approval
/expenses/reports - Expense analytics
```

### AI & Intelligence
```
/ai/insights - Contract analysis + predictive alerts
/ai/chatbots - Conversational AI dashboard (VINessa agents)
/ai/chatbots-demo - Demo guide for AI assistants
```

### Asset Management
```
/assets - Asset inventory with filtering
/assets/scan - Barcode scanner interface
/assets/kits - Equipment kit templates
/assets/transfer/:id - Asset transfer workflow
/assets/maintenance - Maintenance schedule tracker
```

### Contractor Portal (Self-Service)
```
/contractor-portal - Dashboard for contractors
/contractor-portal/timecards - Submit timecards
/contractor-portal/expenses - Submit expenses
/contractor-portal/documents - Upload documents
/contractor-portal/messages - Communication hub
```

### Admin & Configuration
```
/admin/dashboard - System health metrics
/admin/users - User management
/admin/audit-logs - Compliance audit trail
/admin/data-quality - Data quality dashboard
/admin/chatbots-customize - AI widget manager
```

---

## 🎨 UI/UX Patterns

### Standard Page Layouts

**List Pages:**
```tsx
<ListView>
  <ListViewHeader 
    title="Contractors"
    createButton={true}
    exportButton={true}
  />
  <DataTable
    columns={columns}
    filters={advancedFilters}
    sorting={true}
    pagination={true}
  />
</ListView>
```

**Detail Pages:**
```tsx
<ShowView>
  <ShowViewHeader
    title={record.name}
    editButton={true}
    exportButton={true}
  />
  <Tabs>
    <TabsList>
      <TabsTrigger>Overview</TabsTrigger>
      <TabsTrigger>Related Items</TabsTrigger>
      <TabsTrigger>History</TabsTrigger>
    </TabsList>
  </Tabs>
</ShowView>
```

**Create/Edit Forms:**
```tsx
<CreateView>
  <CreateViewHeader title="New Contractor" />
  <Form>
    <FormFields />
    <ActionButtons>
      <Button variant="outline">Cancel</Button>
      <Button>Save</Button>
    </ActionButtons>
  </Form>
</CreateView>
```

### Color System (Risk Indicators)

```css
/* Risk Levels */
--risk-low: #22c55e;     /* Green: < 30 */
--risk-medium: #f97316;  /* Orange: 30-70 */
--risk-high: #ef4444;    /* Red: > 70 */
--risk-critical: #dc2626; /* Dark Red: > 85 */

/* Status Colors */
--status-draft: #94a3b8;
--status-pending: #f59e0b;
--status-approved: #22c55e;
--status-rejected: #ef4444;
```

---

## ⚡ Integration Recommendations for Our Project

### What to Integrate

**1. File Upload System for Process Mapper** ✅ DONE
- Already implemented PDF and .md file upload
- Extraction working correctly
- FormData submission functional

**2. ElevenLabs Voice Agent Architecture** 🎯 PRIORITY
- Import the `VINessa` agent concept
- Implement specialized voice workflows:
  - Journey Capture Agent (like Timecard Assistant)
  - Interview Agent (like Status Collector)
  - Help Desk Agent
- WebSocket audio bridge already implemented

**3. Multi-Lens Intelligence** 📋 NEXT
- Implement 5-lens analysis for Process Maps:
  - Technical Lens (API endpoints, data formats)
  - Business Lens (ROI, efficiency gains)
  - Operational Lens (timeline feasibility)
  - Security Lens (compliance, risks)
  - Integration Lens (dependencies, third-party APIs)

**4. Predictive Alerts System** 📋 FUTURE
- Port the 14 gap scenario types
- Adapt to our domain:
  - Incomplete journey maps
  - Missing touchpoints
  - Workflow bottlenecks
  - Integration risks
  - Timeline delays

**5. One-Click Actions Philosophy** ✅ ADOPT
- Apply "Touch Once Principle" to all workflows
- Auto-draft emails
- Auto-identify missing information
- Queue approvals
- Minimize friction everywhere

### What NOT to Integrate

❌ Workforce-specific entities (Timecards, POs, SOWs) - Not relevant  
❌ Asset management - Different domain  
❌ Contractor portal - Not our use case  
❌ Purchase order workflows - Not applicable  
❌ Test data - Focus on architecture only

---

## 🔧 Technical Stack Alignment

### Current Stack (Our Project)
```
Frontend: React 18 + TypeScript
UI: shadcn/ui + Tailwind CSS
Routing: wouter
State: TanStack React Query v5
Backend: Express + Node.js
Database: PostgreSQL (Drizzle ORM)
AI: Claude 4.5 Sonnet + OpenAI + Perplexity
Voice: Twilio + ElevenLabs
```

### Velocity Stack
```
Frontend: React 18 + TypeScript
UI: shadcn/ui + Tailwind CSS
Routing: Refine.dev routing
State: React Query (Refine integration)
Backend: Not specified (appears to be Node.js)
Database: PostgreSQL assumed
AI: Claude 3.5 Sonnet
Voice: Twilio + ElevenLabs
```

**Compatibility:** ✅ Excellent  
**Major Differences:** Routing (wouter vs Refine) - Not a blocker  
**Shared Patterns:** shadcn/ui components, React Query, same AI providers

---

## 📈 Performance Metrics from Velocity

### Time Savings
| Task | Before | After | Reduction |
|------|--------|-------|-----------|
| Timecard Submission | 10 min | 45 sec | 93% |
| Equipment Checkout | 15 min | 2 min | 87% |
| Project Updates | 30 min | 3 min | 90% |
| Approvals | 5 min/item | 15 sec/item | 95% |

### Adoption Metrics
- Voice Usage: 78% prefer voice over forms
- First-Time Success: 94%
- Satisfaction Score: 4.7/5.0
- Training Time: 0 minutes

### ROI Calculation
```
Monthly Cost: $200-350 (AI infrastructure)
Monthly Savings: $6,666 (time saved)
ROI: 20x return on investment
```

**Apply to Our Project:**
- Voice-first journey mapping could save 90% of time vs manual forms
- Zero training needed for conversational interface
- High first-time success rate reduces errors

---

## 🎯 Action Items for Integration

### Immediate (This Week)
- [x] Complete file upload for Process Mapper
- [ ] Test with actual PDF/MD workflow documents
- [ ] Review architect feedback

### Short-Term (Next 2 Weeks)
- [ ] Design multi-lens analysis for Process Maps
- [ ] Create specialized ElevenLabs agents:
  - Journey Capture Agent
  - Process Interview Agent
  - Help Desk Agent
- [ ] Implement One-Click Actions across all workflows

### Mid-Term (Month 1)
- [ ] Port predictive alerts system (adapted to our domain)
- [ ] Build contractor self-service portal (for journey sharing)
- [ ] Implement context-aware AI assistant on every page

### Long-Term (Quarter 1)
- [ ] Full Two-Thread Architecture implementation
- [ ] Advanced analytics dashboard
- [ ] Mobile app with offline support
- [ ] Multi-language voice support

---

## 📝 Key Takeaways

**1. Voice-First is Non-Negotiable**
- 78% of users prefer voice over forms
- 93% time reduction for data entry
- Zero training required

**2. Touch Once Principle**
- Every piece of information should be processed exactly once
- Auto-draft, queue for approval, execute
- Minimize friction at every step

**3. Predictive > Reactive**
- Identify problems 30+ days before they happen
- Pattern recognition across all data
- Confidence scoring for predictions

**4. Context-Aware Intelligence**
- AI assistant knows which page you're on
- Recommendations based on user role
- Related links for navigation

**5. One-Click Actions**
- Complex workflows become single button clicks
- System suggests, human approves
- Energy preservation > feature count

---

**Integration Philosophy:**  
"We're not building another form-based system. We're building a conversational platform that removes friction and gives energy back to users."

**Success Metric:**  
EXCLAIM vs EXPLAIN - Will users exclaim "This changes everything!" or just explain what it does?

