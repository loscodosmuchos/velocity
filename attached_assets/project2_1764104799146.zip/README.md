# MVP Sprint Lab - Editable AI-Enabled Dashboard

A live, editable Refine application powered by mock data (Supabase-ready) for managing 14-day sprint projects with real-time data updates and full CRUD operations on sprint tasks, cost tracking, and budget management.

## 🚀 Features Implemented

### ✅ Phase 1: Core Data & Sprint Management Foundation

- **Sprint Management**: View and manage sprint metadata with progress tracking
- **Task CRUD Operations**: Full create, read, update, delete operations for sprint tasks
- **Gantt Chart Visualization**: Interactive 14-day timeline showing task dependencies and status
- **Task Details**: View deliverables, milestones, and success metrics for each task
- **Bulk Actions**: Select multiple tasks and update their status simultaneously
- **Filtering & Sorting**: Filter tasks by status, week, and other criteria
- **Demo Data Management**: All data is flagged as demo data for easy identification

### ✅ Phase 2: Cost Tracking & Budget Management

- **Cost Entry Management**: Create, edit, delete cost entries linked to sprints and tasks
- **Real-time Budget Tracking**: Live budget utilization with spent vs. total budget
- **Burn Rate Calculation**: Daily spending rate with projected total cost
- **Budget Alerts**: Visual warnings for over-budget and near-limit scenarios
- **Cost Breakdown Charts**: Category-wise cost distribution (OpenAI API, Hosting, Database, etc.)
- **Cost Trend Analysis**: Daily and cumulative spending visualization with line charts
- **Projection Reports**: Estimated spending for remaining sprint days
- **CSV Export**: Export cost data with full details for external analysis

### 📊 Dashboard

- **Sprint Overview**: Current day, budget tracking, task completion rates
- **Real-time Cost Metrics**: Actual spend, remaining budget, burn rate, projected total
- **Cost Breakdown Visualization**: Bar chart showing spending by category
- **Progress Metrics**: Visual representation of sprint progress and task status distribution
- **Budget Health Status**: Color-coded indicators (healthy, warning, over-budget)
- **Real-time Updates**: All data updates reflect immediately across views

## 🛠️ Tech Stack

- **Framework**: React + TypeScript
- **UI Library**: Shadcn/ui + Tailwind CSS
- **Data Management**: Refine.dev with mock data provider (Supabase-ready schema)
- **Routing**: React Router v7
- **Forms**: React Hook Form + Zod validation
- **Tables**: TanStack Table with Refine integration
- **Charts**: Recharts for data visualization

## 📁 Project Structure

```
src/
├── components/
│   ├── refine-ui/          # Refine UI components (buttons, views, layout)
│   ├── ui/                 # Shadcn UI components
│   ├── gantt-chart.tsx     # Interactive Gantt chart visualization
│   └── bulk-actions-bar.tsx # Bulk actions for tasks
├── pages/
│   ├── dashboard.tsx       # Main dashboard with cost metrics
│   ├── sprints/
│   │   └── list.tsx        # Sprint list view
│   ├── tasks/
│   │   ├── list.tsx        # Task list with Gantt chart
│   │   ├── show.tsx        # Task detail view
│   │   └── edit.tsx        # Task edit form
│   └── costs/
│       ├── list.tsx        # Cost entries list
│       ├── overview.tsx    # Cost overview dashboard
│       ├── create.tsx      # Create cost entry
│       └── edit.tsx        # Edit cost entry
├── providers/
│   └── data.ts             # Mock data provider (Supabase-ready)
├── types/
│   └── index.ts            # TypeScript interfaces
└── mocks.json              # Demo data for all resources
```

## 🎯 Resources

### Sprints

- **Fields**: name, start_date, end_date, current_day, status, total_budget, budget_used, progress_percentage, is_demo
- **Operations**: List, View (full CRUD ready for future phases)

### Tasks

- **Fields**: title, week, day_start, day_end, team_allocation, cost_estimate, success_metric, status, sprintId, is_demo
- **Operations**: List, Show, Edit, Delete, Bulk Update
- **Statuses**: pending, in-progress, completed, blocked

### Cost Entries (NEW in Phase 2)

- **Fields**: amount, category, description, date, sprintId, taskId (optional), is_demo
- **Operations**: List, Create, Edit, Delete, Export to CSV
- **Categories**: OpenAI API, Hosting, Database, Monitoring, Development, Security, Platform Setup

### Deliverables

- **Fields**: description, is_completed, taskId, is_demo
- **Relations**: Linked to tasks

### Milestones

- **Fields**: description, is_completed, taskId, is_demo
- **Relations**: Linked to tasks

## 🚦 Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The application will start at `http://localhost:5173`

## 📊 Cost Management Features

### Budget Tracking

- View real-time budget utilization on dashboard
- Track actual spend vs. total budget
- Monitor remaining budget with color-coded indicators

### Burn Rate Analysis

- Automatic calculation of daily spending rate
- Projected total cost based on current burn rate
- Visual alerts when projection exceeds budget

### Cost Entry Management

- Create cost entries linked to specific tasks or general sprint costs
- Categorize expenses for detailed tracking
- Edit and delete cost entries as needed

### Reporting & Analysis

- Cost trend visualization with daily and cumulative charts
- Category-wise cost breakdown
- Export cost data to CSV for external analysis
- Projection reports for remaining sprint days

## 📋 Implementation Status

### Phase 1: Core Data & Sprint Management ✅ COMPLETED

All Phase 1 tasks are complete:

- ✅ Set up core tables (Sprints, Tasks, Milestones, Deliverables)
- ✅ Import existing MVP Sprint Lab data with demo data flag
- ✅ Build sprint list view with filtering
- ✅ Create task detail page with editable fields
- ✅ Implement edit functionality for tasks
- ✅ Add delete confirmation with popover
- ✅ Build Gantt chart visualization with live data
- ✅ Create bulk actions for status updates

### Phase 2: Cost Tracking & Budget Management ✅ COMPLETED

All Phase 2 tasks are complete:

- ✅ Create cost entries table (amount, category, task_id, date)
- ✅ Build cost tracking overview card showing used vs total budget
- ✅ Implement cost breakdown chart with categories
- ✅ Add cost projection calculator based on historical burn rate
- ✅ Create cost detail pages to add/edit/delete individual cost items
- ✅ Build budget alert system with configurable thresholds
- ✅ Generate cost projection reports for remaining sprint days
- ✅ Add cost export to CSV with category breakdown

## 🔜 Next Steps (Phase 3)

The foundation is set for:

- Team & Resource Allocation
- Team member profiles with skill allocation
- Resource allocation tracking per task
- Capacity planning and availability calendar
- Team utilization reports

## 🎨 UI Components

All components use the dark theme by default with:

- Consistent Shadcn/ui styling
- Refine UI patterns for CRUD operations
- TanStack Table for data grids
- React Hook Form for forms with Zod validation
- Recharts for data visualization

## 📝 Notes

- **Demo Data**: All records are marked with `is_demo: true` for easy identification
- **Mock Data Provider**: Fully functional CRUD operations using in-memory data
- **Supabase-Ready**: Schema is designed to work seamlessly with Supabase when ready to migrate
- **Type-Safe**: Full TypeScript support with proper type definitions
- **Cost Data**: 15 sample cost entries across multiple sprints for realistic testing
