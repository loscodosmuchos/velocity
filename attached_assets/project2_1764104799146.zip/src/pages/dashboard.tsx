import { useList } from "@refinedev/core";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Sprint, Task, CostEntry } from "@/types";
import { CalendarDays, DollarSign, CheckCircle2, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export function DashboardPage() {
  const { data: sprintsData, isLoading: sprintsLoading } = useList<Sprint>({
    resource: "sprints",
    filters: [{ field: "status", operator: "eq", value: "active" }],
  });

  const { data: tasksData, isLoading: tasksLoading } = useList<Task>({
    resource: "tasks",
    pagination: { pageSize: 100 },
  });

  const { data: costEntriesData, isLoading: costEntriesLoading } = useList<CostEntry>({
    resource: "costEntries",
    pagination: { pageSize: 1000 },
  });

  const activeSprint = sprintsData?.data?.[0];
  const tasks = tasksData?.data || [];
  const costEntries = costEntriesData?.data || [];

  const completedTasks = tasks.filter((t) => t.status === "completed").length;
  const inProgressTasks = tasks.filter((t) => t.status === "in-progress").length;
  const blockedTasks = tasks.filter((t) => t.status === "blocked").length;
  const totalCost = tasks.reduce((sum, t) => sum + t.cost_estimate, 0);
  const spentCost = tasks
    .filter((t) => t.status === "completed" || t.status === "in-progress")
    .reduce((sum, t) => sum + t.cost_estimate, 0);

  // Calculate actual costs from cost entries
  const actualSpentCost = activeSprint
    ? costEntries.filter((entry) => entry.sprintId === activeSprint.id).reduce((sum, entry) => sum + entry.amount, 0)
    : 0;

  // Group costs by category
  const costsByCategory = costEntries
    .filter((entry) => !activeSprint || entry.sprintId === activeSprint.id)
    .reduce(
      (acc, entry) => {
        acc[entry.category] = (acc[entry.category] || 0) + entry.amount;
        return acc;
      },
      {} as Record<string, number>,
    );

  const costChartData = Object.entries(costsByCategory).map(([category, amount]) => ({
    category,
    amount,
  }));

  const categoryColors: Record<string, string> = {
    "OpenAI API": "#8b5cf6",
    Hosting: "#3b82f6",
    Database: "#10b981",
    Monitoring: "#f59e0b",
    Development: "#f97316",
    Security: "#ef4444",
    "Platform Setup": "#06b6d4",
  };

  // Calculate burn rate (cost per day)
  const burnRate = activeSprint && activeSprint.current_day > 0 ? actualSpentCost / activeSprint.current_day : 0;

  const projectedTotalCost = activeSprint ? burnRate * 14 : 0;

  const remainingBudget = activeSprint ? activeSprint.total_budget - actualSpentCost : 0;

  const isLoading = sprintsLoading || tasksLoading || costEntriesLoading;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your active sprint and project metrics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Day</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Day {activeSprint?.current_day || 1}</div>
            <p className="text-xs text-muted-foreground">{14 - (activeSprint?.current_day || 1)} days remaining</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Actual Spend</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${actualSpentCost.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">of ${activeSprint?.total_budget || totalCost} budget</p>
            <Progress value={activeSprint ? (actualSpentCost / activeSprint.total_budget) * 100 : 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasks Complete</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {completedTasks}/{tasks.length}
            </div>
            <p className="text-xs text-muted-foreground">
              {((completedTasks / tasks.length) * 100).toFixed(0)}% completion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sprint Progress</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSprint?.progress_percentage || 0}%</div>
            <p className="text-xs text-muted-foreground">
              {inProgressTasks} in progress, {blockedTasks} blocked
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Tracking & Cost Breakdown */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Budget Tracking</CardTitle>
            <CardDescription>Real-time budget analysis and projections</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total Budget</span>
                <span className="font-semibold">${activeSprint?.total_budget.toFixed(2) || "0.00"}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Spent</span>
                <span className="font-semibold text-orange-600">${actualSpentCost.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Remaining</span>
                <span className={`font-semibold ${remainingBudget < 0 ? "text-red-600" : "text-green-600"}`}>
                  ${remainingBudget.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="pt-4 border-t space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Daily Burn Rate</span>
                <span className="font-semibold">${burnRate.toFixed(2)}/day</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Projected Total</span>
                <span
                  className={`font-semibold ${projectedTotalCost > (activeSprint?.total_budget || 0) ? "text-red-600" : "text-blue-600"}`}>
                  ${projectedTotalCost.toFixed(2)}
                </span>
              </div>
              {projectedTotalCost > (activeSprint?.total_budget || 0) && (
                <Badge variant="destructive" className="w-full justify-center">
                  ⚠️ Over Budget Warning
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Cost Breakdown by Category</CardTitle>
            <CardDescription>Distribution of expenses across categories</CardDescription>
          </CardHeader>
          <CardContent>
            {costChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={costChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" angle={-45} textAnchor="end" height={80} tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="amount" radius={[8, 8, 0, 0]}>
                    {costChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={categoryColors[entry.category] || "#64748b"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-muted-foreground">
                No cost entries yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Active Sprint Details */}
      {activeSprint && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{activeSprint.name}</CardTitle>
                <CardDescription className="mt-2">
                  {new Date(activeSprint.start_date).toLocaleDateString()} -{" "}
                  {new Date(activeSprint.end_date).toLocaleDateString()}
                </CardDescription>
              </div>
              <Badge variant="default">Active</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Overall Progress</span>
                  <span className="text-sm text-muted-foreground">{activeSprint.progress_percentage}%</span>
                </div>
                <Progress value={activeSprint.progress_percentage} />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Task Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Task Status Overview</CardTitle>
          <CardDescription>Distribution of tasks across different statuses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Completed</Badge>
                <span className="text-sm text-muted-foreground">{completedTasks} tasks</span>
              </div>
              <Progress value={(completedTasks / tasks.length) * 100} className="w-1/2" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="default">In Progress</Badge>
                <span className="text-sm text-muted-foreground">{inProgressTasks} tasks</span>
              </div>
              <Progress value={(inProgressTasks / tasks.length) * 100} className="w-1/2" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="outline">Pending</Badge>
                <span className="text-sm text-muted-foreground">
                  {tasks.length - completedTasks - inProgressTasks - blockedTasks} tasks
                </span>
              </div>
              <Progress
                value={((tasks.length - completedTasks - inProgressTasks - blockedTasks) / tasks.length) * 100}
                className="w-1/2"
              />
            </div>
            {blockedTasks > 0 && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="destructive">Blocked</Badge>
                  <span className="text-sm text-muted-foreground">{blockedTasks} tasks</span>
                </div>
                <Progress value={(blockedTasks / tasks.length) * 100} className="w-1/2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
