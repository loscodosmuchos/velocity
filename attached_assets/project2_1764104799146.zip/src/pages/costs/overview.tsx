import { useList, useNavigation } from "@refinedev/core";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, TrendingUp, TrendingDown, AlertTriangle, Download } from "lucide-react";
import type { CostEntry, Sprint } from "@/types";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

export const CostsOverviewPage = () => {
  const { create } = useNavigation();

  const { data: costEntriesData, isLoading: costEntriesLoading } = useList<CostEntry>({
    resource: "costEntries",
    pagination: { pageSize: 1000 },
  });

  const { data: sprintsData, isLoading: sprintsLoading } = useList<Sprint>({
    resource: "sprints",
    filters: [{ field: "status", operator: "eq", value: "active" }],
  });

  const costEntries = costEntriesData?.data || [];
  const activeSprint = sprintsData?.data?.[0];

  // Calculate metrics
  const totalSpent = costEntries.reduce((sum, entry) => sum + entry.amount, 0);
  const sprintCosts = activeSprint ? costEntries.filter((entry) => entry.sprintId === activeSprint.id) : [];
  const sprintSpent = sprintCosts.reduce((sum, entry) => sum + entry.amount, 0);
  const remainingBudget = activeSprint ? activeSprint.total_budget - sprintSpent : 0;

  // Calculate daily burn rate
  const burnRate = activeSprint && activeSprint.current_day > 0 ? sprintSpent / activeSprint.current_day : 0;

  const daysRemaining = activeSprint ? 14 - activeSprint.current_day : 0;
  const projectedSpend = sprintSpent + burnRate * daysRemaining;
  const budgetStatus = activeSprint
    ? projectedSpend > activeSprint.total_budget
      ? "over"
      : projectedSpend > activeSprint.total_budget * 0.9
        ? "warning"
        : "healthy"
    : "healthy";

  // Group costs by date for chart
  const costsByDate = sprintCosts.reduce(
    (acc, entry) => {
      const date = entry.date;
      if (!acc[date]) {
        acc[date] = 0;
      }
      acc[date] += entry.amount;
      return acc;
    },
    {} as Record<string, number>,
  );

  const sortedDates = Object.keys(costsByDate).sort();
  let cumulativeAmount = 0;
  const chartData = sortedDates.map((date) => {
    cumulativeAmount += costsByDate[date];
    return {
      date: new Date(date).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      daily: costsByDate[date],
      cumulative: cumulativeAmount,
    };
  });

  const isLoading = costEntriesLoading || sprintsLoading;

  if (isLoading) {
    return <div>Loading...</div>;
  }

  const exportToCSV = () => {
    const headers = ["Date", "Category", "Description", "Amount", "Sprint", "Task ID"];
    const rows = costEntries.map((entry) => [
      entry.date,
      entry.category,
      entry.description,
      entry.amount.toFixed(2),
      entry.sprintId.toString(),
      entry.taskId?.toString() || "N/A",
    ]);

    const csvContent = [headers.join(","), ...rows.map((row) => row.map((cell) => `"${cell}"`).join(","))].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cost-report-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Cost Overview</h1>
          <p className="text-muted-foreground">Budget tracking, projections, and cost analysis</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportToCSV}>
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button onClick={() => create("costEntries")}>
            <Plus className="h-4 w-4 mr-2" />
            Add Cost Entry
          </Button>
        </div>
      </div>

      {/* Budget Status Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${sprintSpent.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              {activeSprint && ((sprintSpent / activeSprint.total_budget) * 100).toFixed(1)}% of budget
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Remaining Budget</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${remainingBudget < 0 ? "text-red-600" : ""}`}>
              ${remainingBudget.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">{daysRemaining} days remaining</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Burn Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${burnRate.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">per day</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Projected Total</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${budgetStatus === "over" ? "text-red-600" : budgetStatus === "warning" ? "text-yellow-600" : ""}`}>
              ${projectedSpend.toFixed(2)}
            </div>
            <Badge
              variant={budgetStatus === "over" ? "destructive" : budgetStatus === "warning" ? "outline" : "secondary"}
              className="mt-1">
              {budgetStatus === "over" ? "Over Budget" : budgetStatus === "warning" ? "Near Limit" : "On Track"}
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Budget Alert */}
      {budgetStatus !== "healthy" && activeSprint && (
        <Card className={`border-2 ${budgetStatus === "over" ? "border-red-500" : "border-yellow-500"}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className={`h-5 w-5 ${budgetStatus === "over" ? "text-red-600" : "text-yellow-600"}`} />
              Budget Alert
            </CardTitle>
          </CardHeader>
          <CardContent>
            {budgetStatus === "over" ? (
              <p>
                At current burn rate (${burnRate.toFixed(2)}/day), you will exceed budget by{" "}
                <strong className="text-red-600">${(projectedSpend - activeSprint.total_budget).toFixed(2)}</strong>.
                Consider optimizing costs or adjusting scope.
              </p>
            ) : (
              <p>
                You're approaching budget limit. Current projection: ${projectedSpend.toFixed(2)} of $
                {activeSprint.total_budget.toFixed(2)}. Monitor spending closely for remaining {daysRemaining} days.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Cost Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Cost Trend Analysis</CardTitle>
          <CardDescription>Daily and cumulative spending over time</CardDescription>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="daily" stroke="#f97316" strokeWidth={2} name="Daily Cost" />
                <Line type="monotone" dataKey="cumulative" stroke="#3b82f6" strokeWidth={2} name="Cumulative Cost" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[300px] text-muted-foreground">
              No cost data available yet
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cost Projection Report */}
      {activeSprint && (
        <Card>
          <CardHeader>
            <CardTitle>Cost Projection Report</CardTitle>
            <CardDescription>Estimated spending for remaining sprint days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Days Elapsed</p>
                  <p className="text-2xl font-bold">{activeSprint.current_day} days</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Days Remaining</p>
                  <p className="text-2xl font-bold">{daysRemaining} days</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Spent to Date</p>
                  <p className="text-2xl font-bold">${sprintSpent.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Projected Remaining</p>
                  <p className="text-2xl font-bold">${(burnRate * daysRemaining).toFixed(2)}</p>
                </div>
              </div>
              <div className="pt-4 border-t">
                <p className="text-sm text-muted-foreground mb-2">Budget Utilization</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${projectedSpend > activeSprint.total_budget ? "bg-red-500" : projectedSpend > activeSprint.total_budget * 0.9 ? "bg-yellow-500" : "bg-green-500"}`}
                      style={{ width: `${Math.min((projectedSpend / activeSprint.total_budget) * 100, 100)}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium">
                    {((projectedSpend / activeSprint.total_budget) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
