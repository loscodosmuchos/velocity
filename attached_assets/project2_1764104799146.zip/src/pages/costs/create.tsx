import { useForm } from "@refinedev/react-hook-form";
import { useSelect, useNavigation } from "@refinedev/core";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { CostEntry, Sprint, Task } from "@/types";

export const CostsCreatePage = () => {
  const { list } = useNavigation();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
    refineCore: { onFinish },
  } = useForm<CostEntry>({
    refineCoreProps: {
      resource: "costEntries",
      action: "create",
      onMutationSuccess: () => {
        list("costEntries");
      },
    },
    defaultValues: {
      date: new Date().toISOString().split("T")[0],
      is_demo: false,
    },
  });

  const { options: sprintOptions } = useSelect<Sprint>({
    resource: "sprints",
    optionLabel: "name",
    optionValue: "id",
  });

  const selectedSprintId = watch("sprintId");

  const { options: taskOptions } = useSelect<Task>({
    resource: "tasks",
    optionLabel: "title",
    optionValue: "id",
    filters: selectedSprintId ? [{ field: "sprintId", operator: "eq", value: selectedSprintId }] : undefined,
  });

  const categories = ["OpenAI API", "Hosting", "Database", "Monitoring", "Development", "Security", "Platform Setup"];

  return (
    <CreateView>
      <CreateViewHeader title="Add Cost Entry" />
      <form onSubmit={handleSubmit(onFinish)} className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="sprintId">Sprint *</Label>
            <Select
              value={watch("sprintId")?.toString()}
              onValueChange={(value) => {
                setValue("sprintId", parseInt(value), { shouldValidate: true });
                setValue("taskId", undefined);
              }}>
              <SelectTrigger>
                <SelectValue placeholder="Select sprint" />
              </SelectTrigger>
              <SelectContent>
                {sprintOptions?.map((option) => (
                  <SelectItem key={option.value} value={option.value.toString()}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.sprintId?.message && <p className="text-sm text-red-500">{String(errors.sprintId.message)}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="taskId">Task (Optional)</Label>
            <Select
              value={watch("taskId")?.toString() || ""}
              onValueChange={(value) => setValue("taskId", value ? parseInt(value) : null, { shouldValidate: true })}
              disabled={!selectedSprintId}>
              <SelectTrigger>
                <SelectValue placeholder="Select task (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">General (No specific task)</SelectItem>
                {taskOptions?.map((option) => (
                  <SelectItem key={option.value} value={option.value.toString()}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select
              value={watch("category")}
              onValueChange={(value) => setValue("category", value, { shouldValidate: true })}>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.category?.message && <p className="text-sm text-red-500">{String(errors.category.message)}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount ($) *</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              {...register("amount", {
                required: "Amount is required",
                min: { value: 0, message: "Amount must be positive" },
                valueAsNumber: true,
              })}
            />
            {errors.amount?.message && <p className="text-sm text-red-500">{String(errors.amount.message)}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="date">Date *</Label>
            <Input id="date" type="date" {...register("date", { required: "Date is required" })} />
            {errors.date?.message && <p className="text-sm text-red-500">{String(errors.date.message)}</p>}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description *</Label>
          <Textarea
            id="description"
            placeholder="Describe the cost entry..."
            {...register("description", { required: "Description is required" })}
          />
          {errors.description?.message && <p className="text-sm text-red-500">{String(errors.description.message)}</p>}
        </div>

        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => list("costEntries")}>
            Cancel
          </Button>
          <Button type="submit">Create</Button>
        </div>
      </form>
    </CreateView>
  );
};
