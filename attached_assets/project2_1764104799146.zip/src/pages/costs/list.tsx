import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany } from "@refinedev/core";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { DeleteButton } from "@/components/refine-ui/buttons/delete";
import { DataTableFilterCombobox } from "@/components/refine-ui/data-table/data-table-filter";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import type { CostEntry, Sprint, Task } from "@/types";

export const CostsListPage = () => {
  const columns = useMemo<ColumnDef<CostEntry>[]>(
    () => [
      {
        id: "date",
        accessorKey: "date",
        header: ({ column }) => <DataTableSorter column={column}>Date</DataTableSorter>,
        cell: ({ row }) => {
          const date = new Date(row.original.date);
          return date.toLocaleDateString();
        },
      },
      {
        id: "category",
        accessorKey: "category",
        header: ({ column, table }) => (
          <DataTableFilterCombobox
            column={column}
            table={table}
            options={[
              { label: "OpenAI API", value: "OpenAI API" },
              { label: "Hosting", value: "Hosting" },
              { label: "Database", value: "Database" },
              { label: "Monitoring", value: "Monitoring" },
              { label: "Development", value: "Development" },
              { label: "Security", value: "Security" },
              { label: "Platform Setup", value: "Platform Setup" },
            ]}
          />
        ),
        cell: ({ row }) => {
          const categoryColors: Record<string, string> = {
            "OpenAI API": "bg-purple-500/10 text-purple-700 dark:text-purple-400",
            Hosting: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
            Database: "bg-green-500/10 text-green-700 dark:text-green-400",
            Monitoring: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
            Development: "bg-orange-500/10 text-orange-700 dark:text-orange-400",
            Security: "bg-red-500/10 text-red-700 dark:text-red-400",
            "Platform Setup": "bg-cyan-500/10 text-cyan-700 dark:text-cyan-400",
          };

          return (
            <Badge variant="outline" className={categoryColors[row.original.category] || ""}>
              {row.original.category}
            </Badge>
          );
        },
      },
      {
        id: "description",
        accessorKey: "description",
        header: "Description",
      },
      {
        id: "sprint",
        accessorKey: "sprintId",
        header: "Sprint",
        cell: ({ row, table }) => {
          const sprint = (table.options.meta as any)?.sprintsData?.find((s: Sprint) => s.id === row.original.sprintId);
          return sprint ? sprint.name : "-";
        },
      },
      {
        id: "task",
        accessorKey: "taskId",
        header: "Task",
        cell: ({ row, table }) => {
          if (!row.original.taskId) return <span className="text-muted-foreground">General</span>;

          const task = (table.options.meta as any)?.tasksData?.find((t: Task) => t.id === row.original.taskId);
          return task ? task.title : "-";
        },
      },
      {
        id: "amount",
        accessorKey: "amount",
        header: ({ column }) => <DataTableSorter column={column}>Amount</DataTableSorter>,
        cell: ({ row }) => {
          return <div className="font-semibold">${row.original.amount.toFixed(2)}</div>;
        },
      },
      {
        id: "actions",
        cell: ({ row }) => {
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <EditButton recordItemId={row.original.id}>Edit</EditButton>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <DeleteButton recordItemId={row.original.id}>Delete</DeleteButton>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          );
        },
      },
    ],
    [],
  );

  const table = useTable<CostEntry>({
    columns,
    refineCoreProps: {
      resource: "costEntries",
    },
  });

  const sprintIds = table.getRowModel().rows.map((row) => row.original.sprintId);
  const { data: sprintsData } = useMany<Sprint>({
    resource: "sprints",
    ids: sprintIds,
    queryOptions: {
      enabled: sprintIds.length > 0,
    },
  });

  const taskIds = table
    .getRowModel()
    .rows.map((row) => row.original.taskId)
    .filter((id): id is number => id !== null && id !== undefined);
  const { data: tasksData } = useMany<Task>({
    resource: "tasks",
    ids: taskIds,
    queryOptions: {
      enabled: taskIds.length > 0,
    },
  });

  table.options.meta = {
    ...table.options.meta,
    sprintsData: sprintsData?.data,
    tasksData: tasksData?.data,
  };

  return (
    <ListView>
      <ListViewHeader title="Cost Tracking" canCreate />
      <DataTable table={table} />
    </ListView>
  );
};
