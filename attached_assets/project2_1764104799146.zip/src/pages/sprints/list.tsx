import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { DataTableFilterDropdownText } from "@/components/refine-ui/data-table/data-table-filter";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { Sprint } from "@/types";

export function SprintsListPage() {
  const columns = useMemo<ColumnDef<Sprint>[]>(
    () => [
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => <DataTableSorter column={column} title="Sprint Name" />,
        cell: ({ row }) => {
          const isDemoData = row.original.is_demo;
          return (
            <div className="flex items-center gap-2">
              <span className="font-medium">{row.original.name}</span>
              {isDemoData && (
                <Badge variant="outline" className="text-xs">
                  Demo
                </Badge>
              )}
            </div>
          );
        },
      },
      {
        id: "status",
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const status = row.original.status;
          const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
            active: "default",
            completed: "secondary",
            pending: "outline",
            paused: "destructive",
          };
          return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
        },
        meta: {
          filterElement: (props: any) => (
            <DataTableFilterDropdownText
              {...props}
              options={[
                { label: "Active", value: "active" },
                { label: "Completed", value: "completed" },
                { label: "Pending", value: "pending" },
                { label: "Paused", value: "paused" },
              ]}
            />
          ),
        },
      },
      {
        id: "current_day",
        accessorKey: "current_day",
        header: ({ column }) => <DataTableSorter column={column} title="Current Day" />,
        cell: ({ row }) => <span className="text-muted-foreground">Day {row.original.current_day} of 14</span>,
      },
      {
        id: "progress",
        accessorKey: "progress_percentage",
        header: ({ column }) => <DataTableSorter column={column} title="Progress" />,
        cell: ({ row }) => {
          const progress = row.original.progress_percentage;
          return (
            <div className="flex items-center gap-2">
              <Progress value={progress} className="w-24" />
              <span className="text-sm text-muted-foreground">{progress}%</span>
            </div>
          );
        },
      },
      {
        id: "budget",
        accessorKey: "budget_used",
        header: ({ column }) => <DataTableSorter column={column} title="Budget" />,
        cell: ({ row }) => {
          const used = row.original.budget_used;
          const total = row.original.total_budget;
          const percentage = (used / total) * 100;
          return (
            <div className="text-right">
              <div className="font-medium">
                ${used} / ${total}
              </div>
              <div className="text-xs text-muted-foreground">{percentage.toFixed(1)}% used</div>
            </div>
          );
        },
      },
      {
        id: "dates",
        header: "Duration",
        cell: ({ row }) => (
          <div className="text-sm">
            <div>{new Date(row.original.start_date).toLocaleDateString()}</div>
            <div className="text-muted-foreground">to {new Date(row.original.end_date).toLocaleDateString()}</div>
          </div>
        ),
      },
    ],
    [],
  );

  const table = useTable<Sprint>({
    columns,
    refineCoreProps: {
      resource: "sprints",
    },
  });

  return (
    <ListView>
      <ListViewHeader title="Sprints" />
      <DataTable table={table} />
    </ListView>
  );
}
