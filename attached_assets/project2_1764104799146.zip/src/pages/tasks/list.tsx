import { useMemo, useState } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { DataTableFilterDropdownText } from "@/components/refine-ui/data-table/data-table-filter";
import { Badge } from "@/components/ui/badge";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { DeleteButton } from "@/components/refine-ui/buttons/delete";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Eye, Pencil, Trash } from "lucide-react";
import type { Task } from "@/types";
import { GanttChart } from "@/components/gantt-chart";
import { BulkActionsBar } from "@/components/bulk-actions-bar";
import { Checkbox } from "@/components/ui/checkbox";

export function TasksListPage() {
  const [selectedRows, setSelectedRows] = useState<number[]>([]);

  const columns = useMemo<ColumnDef<Task>[]>(
    () => [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
            onCheckedChange={(value) => {
              table.toggleAllPageRowsSelected(!!value);
              if (value) {
                setSelectedRows(table.getRowModel().rows.map((row) => row.original.id));
              } else {
                setSelectedRows([]);
              }
            }}
            aria-label="Select all"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => {
              row.toggleSelected(!!value);
              if (value) {
                setSelectedRows((prev) => [...prev, row.original.id]);
              } else {
                setSelectedRows((prev) => prev.filter((id) => id !== row.original.id));
              }
            }}
            aria-label="Select row"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        id: "title",
        accessorKey: "title",
        header: ({ column }) => <DataTableSorter column={column} title="Task Title" />,
        cell: ({ row }) => {
          const isDemoData = row.original.is_demo;
          return (
            <div className="flex items-center gap-2">
              <span className="font-medium">{row.original.title}</span>
              {isDemoData && (
                <Badge variant="outline" className="text-xs">
                  Demo
                </Badge>
              )}
            </div>
          );
        },
        meta: {
          filterOperator: "contains",
        },
      },
      {
        id: "status",
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const status = row.original.status;
          const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
            completed: "secondary",
            "in-progress": "default",
            pending: "outline",
            blocked: "destructive",
          };
          return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
        },
        meta: {
          filterElement: (props: any) => (
            <DataTableFilterDropdownText
              {...props}
              options={[
                { label: "Completed", value: "completed" },
                { label: "In Progress", value: "in-progress" },
                { label: "Pending", value: "pending" },
                { label: "Blocked", value: "blocked" },
              ]}
            />
          ),
        },
      },
      {
        id: "week",
        accessorKey: "week",
        header: ({ column }) => <DataTableSorter column={column} title="Week" />,
        cell: ({ row }) => <span className="text-muted-foreground">Week {row.original.week}</span>,
      },
      {
        id: "days",
        header: "Days",
        cell: ({ row }) => {
          const start = row.original.day_start;
          const end = row.original.day_end;
          return (
            <span className="text-sm text-muted-foreground">
              Day {start}
              {start !== end && ` - ${end}`}
            </span>
          );
        },
      },
      {
        id: "team_allocation",
        accessorKey: "team_allocation",
        header: ({ column }) => <DataTableSorter column={column} title="Team" />,
        cell: ({ row }) => <span className="text-sm">{row.original.team_allocation} members</span>,
      },
      {
        id: "cost_estimate",
        accessorKey: "cost_estimate",
        header: ({ column }) => <DataTableSorter column={column} title="Cost" />,
        cell: ({ row }) => <span className="font-medium">${row.original.cost_estimate}</span>,
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const record = row.original;
          return (
            <div className="flex items-center gap-2">
              <ShowButton resource="tasks" recordItemId={record.id} size="sm">
                <Eye className="h-4 w-4" />
              </ShowButton>
              <EditButton resource="tasks" recordItemId={record.id} size="sm">
                <Pencil className="h-4 w-4" />
              </EditButton>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <DeleteButton
                      resource="tasks"
                      recordItemId={record.id}
                      size="sm"
                      variant="ghost"
                      className="w-full justify-start">
                      <Trash className="h-4 w-4 mr-2" />
                      Delete
                    </DeleteButton>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          );
        },
      },
    ],
    [],
  );

  const table = useTable<Task>({
    columns,
    refineCoreProps: {
      resource: "tasks",
      sorters: {
        initial: [{ field: "day_start", order: "asc" }],
      },
    },
  });

  return (
    <ListView>
      <ListViewHeader title="Sprint Tasks" />

      {/* Gantt Chart Visualization */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-4">Sprint Timeline</h3>
        <GanttChart />
      </div>

      {/* Tasks Table */}
      <DataTable table={table} />

      {/* Bulk Actions Bar */}
      <BulkActionsBar
        resource="tasks"
        selectedIds={selectedRows}
        onClearSelection={() => {
          setSelectedRows([]);
          table.resetRowSelection();
        }}
      />
    </ListView>
  );
}
