import { useShow, useMany } from "@refinedev/core";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { Task, Deliverable, Milestone } from "@/types";

export function TasksShowPage() {
  const { query } = useShow<Task>({ resource: "tasks" });
  const task = query?.data?.data;

  const { data: deliverablesData } = useMany<Deliverable>({
    resource: "deliverables",
    ids: task ? [task.id] : [],
    queryOptions: {
      enabled: !!task,
    },
  });

  const { data: milestonesData } = useMany<Milestone>({
    resource: "milestones",
    ids: task ? [task.id] : [],
    queryOptions: {
      enabled: !!task,
    },
  });

  const deliverables = deliverablesData?.data?.filter((d) => d.taskId === task?.id) || [];
  const milestones = milestonesData?.data?.filter((m) => m.taskId === task?.id) || [];

  const statusVariants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    completed: "secondary",
    "in-progress": "default",
    pending: "outline",
    blocked: "destructive",
  };

  return (
    <ShowView>
      <ShowViewHeader title={task?.title || "Task Details"} />
      <LoadingOverlay loading={query?.isLoading}>
        {task && (
          <div className="space-y-6">
            {/* Task Overview Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Task Overview</CardTitle>
                  <Badge variant={statusVariants[task.status] || "outline"}>{task.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Week</p>
                    <p className="font-medium">Week {task.week}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-medium">
                      Day {task.day_start}
                      {task.day_start !== task.day_end && ` - ${task.day_end}`}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Team Allocation</p>
                    <p className="font-medium">{task.team_allocation} members</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Cost Estimate</p>
                    <p className="font-medium">${task.cost_estimate}</p>
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Success Metric</p>
                  <p className="text-sm">{task.success_metric}</p>
                </div>
              </CardContent>
            </Card>

            {/* Deliverables Card */}
            <Card>
              <CardHeader>
                <CardTitle>Deliverables</CardTitle>
                <CardDescription>
                  {deliverables.filter((d) => d.is_completed).length} of {deliverables.length} completed
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {deliverables.map((deliverable) => (
                    <li key={deliverable.id} className="flex items-center gap-2">
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center ${
                          deliverable.is_completed ? "bg-green-500 border-green-500" : "border-gray-300"
                        }`}>
                        {deliverable.is_completed && <span className="text-white text-xs">✓</span>}
                      </div>
                      <span className={deliverable.is_completed ? "line-through text-muted-foreground" : ""}>
                        {deliverable.description}
                      </span>
                    </li>
                  ))}
                  {deliverables.length === 0 && (
                    <p className="text-sm text-muted-foreground">No deliverables defined</p>
                  )}
                </ul>
              </CardContent>
            </Card>

            {/* Milestones Card */}
            <Card>
              <CardHeader>
                <CardTitle>Milestones</CardTitle>
                <CardDescription>
                  {milestones.filter((m) => m.is_completed).length} of {milestones.length} achieved
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {milestones.map((milestone) => (
                    <li key={milestone.id} className="flex items-center gap-2">
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center ${
                          milestone.is_completed ? "bg-blue-500 border-blue-500" : "border-gray-300"
                        }`}>
                        {milestone.is_completed && <span className="text-white text-xs">✓</span>}
                      </div>
                      <span className={milestone.is_completed ? "line-through text-muted-foreground" : ""}>
                        {milestone.description}
                      </span>
                    </li>
                  ))}
                  {milestones.length === 0 && <p className="text-sm text-muted-foreground">No milestones defined</p>}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </LoadingOverlay>
    </ShowView>
  );
}
