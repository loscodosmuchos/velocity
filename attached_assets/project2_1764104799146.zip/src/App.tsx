import { Refine } from "@refinedev/core";
import routerBindings from "@refinedev/react-router";
import { BrowserRouter, Routes, Route, Outlet } from "react-router";
import { createDataProvider } from "./providers/data";
import { Layout } from "./components/refine-ui/layout/layout";
import { ErrorComponent } from "./components/refine-ui/layout/error-component";
import { ThemeProvider } from "./components/refine-ui/theme/theme-provider";
import { Toaster } from "./components/refine-ui/notification/toaster";
import { useNotificationProvider } from "./components/refine-ui/notification/use-notification-provider";

// Pages
import { DashboardPage } from "./pages/dashboard";
import { SprintsListPage } from "./pages/sprints/list";
import { TasksListPage } from "./pages/tasks/list";
import { TasksEditPage } from "./pages/tasks/edit";
import { TasksShowPage } from "./pages/tasks/show";
import { CostsListPage } from "./pages/costs/list";
import { CostsCreatePage } from "./pages/costs/create";
import { CostsEditPage } from "./pages/costs/edit";
import { CostsOverviewPage } from "./pages/costs/overview";

const App = () => {
  return (
    <BrowserRouter>
      <ThemeProvider defaultTheme="dark" storageKey="refine-theme">
        <Refine
          routerProvider={routerBindings}
          dataProvider={createDataProvider()}
          notificationProvider={useNotificationProvider}
          resources={[
            {
              name: "dashboard",
              list: "/",
              meta: {
                label: "Dashboard",
                icon: "📊",
              },
            },
            {
              name: "sprints",
              list: "/sprints",
              meta: {
                label: "Sprints",
                icon: "📅",
              },
            },
            {
              name: "tasks",
              list: "/tasks",
              edit: "/tasks/edit/:id",
              show: "/tasks/show/:id",
              meta: {
                label: "Tasks",
                icon: "✓",
              },
            },
            {
              name: "costEntries",
              list: "/costs",
              create: "/costs/create",
              edit: "/costs/edit/:id",
              meta: {
                label: "Costs",
                icon: "💰",
                parent: "costs-menu",
              },
            },
            {
              name: "costs-menu",
              meta: {
                label: "Cost Management",
                icon: "💰",
              },
            },
            {
              name: "costs-overview",
              list: "/costs/overview",
              meta: {
                label: "Cost Overview",
                icon: "📊",
                parent: "costs-menu",
              },
            },
          ]}
          options={{
            syncWithLocation: true,
            warnWhenUnsavedChanges: true,
          }}>
          <Routes>
            <Route
              element={
                <Layout>
                  <Outlet />
                </Layout>
              }>
              <Route index element={<SprintsListPage />} />
              <Route index element={<DashboardPage />} />
              <Route path="/sprints" element={<SprintsListPage />} />
              <Route path="/tasks" element={<TasksListPage />} />
              <Route path="/tasks/edit/:id" element={<TasksEditPage />} />
              <Route path="/tasks/show/:id" element={<TasksShowPage />} />
              <Route path="/costs" element={<CostsListPage />} />
              <Route path="/costs/overview" element={<CostsOverviewPage />} />
              <Route path="/costs/create" element={<CostsCreatePage />} />
              <Route path="/costs/edit/:id" element={<CostsEditPage />} />
              <Route path="*" element={<ErrorComponent />} />
            </Route>
          </Routes>
          <Toaster />
        </Refine>
      </ThemeProvider>
    </BrowserRouter>
  );
};

export default App;
