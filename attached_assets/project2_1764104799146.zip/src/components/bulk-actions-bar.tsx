import { useUpdateMany } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";
import { useState } from "react";

interface BulkActionsBarProps {
  resource: string;
  selectedIds: number[];
  onClearSelection: () => void;
}

export function BulkActionsBar({ resource, selectedIds, onClearSelection }: BulkActionsBarProps) {
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const { mutate: updateMany, isLoading } = useUpdateMany();

  const handleStatusChange = () => {
    if (!selectedStatus) return;

    updateMany(
      {
        resource,
        ids: selectedIds,
        values: { status: selectedStatus },
      },
      {
        onSuccess: () => {
          onClearSelection();
          setSelectedStatus("");
        },
      },
    );
  };

  if (selectedIds.length === 0) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
      <div className="bg-primary text-primary-foreground rounded-lg shadow-lg px-6 py-4 flex items-center gap-4">
        <span className="font-medium">
          {selectedIds.length} task{selectedIds.length > 1 ? "s" : ""} selected
        </span>

        <div className="flex items-center gap-2">
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-40 bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20">
              <SelectValue placeholder="Change status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>

          <Button size="sm" variant="secondary" onClick={handleStatusChange} disabled={!selectedStatus || isLoading}>
            Apply
          </Button>
        </div>

        <Button size="sm" variant="ghost" onClick={onClearSelection} className="ml-2">
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
