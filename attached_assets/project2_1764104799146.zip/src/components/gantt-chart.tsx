import { useList } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Task } from "@/types";

export function GanttChart() {
  const { data: tasksData, isLoading } = useList<Task>({
    resource: "tasks",
    pagination: { pageSize: 100 },
    sorters: [{ field: "day_start", order: "asc" }],
  });

  const tasks = tasksData?.data || [];

  if (isLoading) {
    return <Skeleton className="h-[400px] w-full" />;
  }

  // Calculate the total days (1-14)
  const totalDays = 14;
  const dayWidth = 60; // pixels per day

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>14-Day Sprint Timeline</span>
          <div className="flex gap-4 text-sm font-normal">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Completed</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>In Progress</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-gray-400 rounded" />
              <span>Pending</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="min-w-max">
            {/* Day Headers */}
            <div className="flex mb-2 sticky top-0 bg-background z-10">
              <div className="w-64 flex-shrink-0 pr-4 font-semibold">Task</div>
              <div className="flex">
                {Array.from({ length: totalDays }, (_, i) => i + 1).map((day) => (
                  <div key={day} className="text-center font-medium text-sm" style={{ width: `${dayWidth}px` }}>
                    Day {day}
                  </div>
                ))}
              </div>
            </div>

            {/* Task Rows */}
            <div className="space-y-2">
              {tasks.map((task) => {
                const duration = task.day_end - task.day_start + 1;
                const left = (task.day_start - 1) * dayWidth;
                const width = duration * dayWidth - 4;

                const barColor =
                  task.status === "completed"
                    ? "bg-green-500"
                    : task.status === "in-progress"
                      ? "bg-blue-500"
                      : task.status === "blocked"
                        ? "bg-red-500"
                        : "bg-gray-400";

                return (
                  <div key={task.id} className="flex items-center group hover:bg-muted/50 rounded p-2">
                    {/* Task Info */}
                    <div className="w-64 flex-shrink-0 pr-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium truncate">{task.title}</span>
                        <Badge variant="outline" className="text-xs">
                          W{task.week}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Team: {task.team_allocation} · ${task.cost_estimate}
                      </div>
                    </div>

                    {/* Timeline Bar */}
                    <div className="relative flex-1" style={{ height: "40px" }}>
                      <div
                        className={`absolute top-1/2 -translate-y-1/2 ${barColor} rounded px-2 py-1 text-xs text-white font-medium flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity`}
                        style={{
                          left: `${left}px`,
                          width: `${width}px`,
                        }}
                        title={`${task.title}\nDays ${task.day_start}-${task.day_end}\n${task.success_metric}`}>
                        <span className="truncate">{task.title.split(" ").slice(0, 2).join(" ")}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
