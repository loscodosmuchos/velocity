export interface Sprint {
  id: number;
  name: string;
  start_date: string;
  end_date: string;
  current_day: number;
  status: "active" | "completed" | "pending" | "paused";
  total_budget: number;
  budget_used: number;
  progress_percentage: number;
  is_demo: boolean;
}

export interface Task {
  id: number;
  sprintId: number;
  title: string;
  week: number;
  day_start: number;
  day_end: number;
  team_allocation: number;
  cost_estimate: number;
  success_metric: string;
  status: "completed" | "in-progress" | "pending" | "blocked";
  is_demo: boolean;
}

export interface Deliverable {
  id: number;
  taskId: number;
  description: string;
  is_completed: boolean;
  is_demo: boolean;
}

export interface Milestone {
  id: number;
  taskId: number;
  description: string;
  is_completed: boolean;
  is_demo: boolean;
}

export interface CostEntry {
  id: number;
  sprintId: number;
  taskId?: number | null;
  amount: number;
  category: string;
  description: string;
  date: string;
  is_demo: boolean;
}
