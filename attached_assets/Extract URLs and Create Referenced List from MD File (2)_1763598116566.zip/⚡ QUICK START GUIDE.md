# ⚡ QUICK START GUIDE

## Get Your 203 Transcripts in 3 Steps

### Step 1: Setup (2 minutes)

**In Replit:**
1. Create new Python Repl
2. Upload all files from the zip
3. Run in Shell: `pip install -r requirements.txt`

**Done!** ✅

---

### Step 2: Extract Transcripts (5-10 minutes)

Your `youtube_urls.txt` file is already included with your 203 URLs!

Run in Shell:
```bash
python youtube_transcript_extractor.py youtube_urls.txt
```

**What happens:**
- Extracts all 203 transcripts automatically
- Saves to `transcripts/` folder
- Shows progress for each video
- Creates detailed report

**Wait for it to finish**, then check `transcripts/_extraction_report.txt` to see results.

---

### Step 3: Create Knowledge Base (1 minute)

Run in Shell:
```bash
python knowledge_base_organizer.py transcripts/
```

**What you get:**
- `knowledge_base.md` - All transcripts organized by topic
- `knowledge_base_index.txt` - Quick reference index

---

## 🎉 Done!

You now have:
- ✅ 203 individual transcript files
- ✅ Organized knowledge base by category
- ✅ Statistics and key term analysis
- ✅ Ready for Perplexity or AI analysis

---

## 📤 Next: Use Your Knowledge Base

### Option A: Upload to Perplexity
1. Download `knowledge_base.md`
2. Upload to Perplexity
3. Ask: "Extract all terminology definitions from this transcript collection"

### Option B: Use with Claude/ChatGPT
1. Copy content from `knowledge_base.md`
2. Paste into Claude or ChatGPT
3. Ask for insights, definitions, or analysis

### Option C: Search Locally
1. Open `knowledge_base.md` in any text editor
2. Use Ctrl+F to search for specific terms
3. Review by category

---

## 🔧 If Some Videos Fail

Check `transcripts/_extraction_report.txt` for failed URLs.

**For failed videos:**
1. Use 4K Video Downloader to get SRT files
2. Run: `python srt_to_text_converter.py subtitles/`
3. Copy converted files to `transcripts/` folder
4. Re-run knowledge base organizer

---

## 💡 Pro Tips

- **Start small:** Test with 5-10 URLs first
- **Check the report:** Always review the extraction report
- **Customize categories:** Edit `knowledge_base_organizer.py` to add your own topics
- **Track key terms:** Add your specific terminology to the term list

---

**Need help? Check the full README.md for detailed documentation.**
