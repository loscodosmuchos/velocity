#!/usr/bin/env python3
import re

# Read the markdown file
with open('/home/ubuntu/upload/pasted_file_EuMQnQ_ComprehensiveTerminologyGuide_Procurement,ATS,.md', 'r', encoding='utf-8') as f:
    content = f.read()

# Find all markdown reference-style links [^ref]: URL
reference_pattern = r'\[\^([^\]]+)\]:\s*(https?://[^\s]+)'
references = re.findall(reference_pattern, content)

# Create a dictionary to store reference -> URL mapping
ref_to_url = {ref: url for ref, url in references}

# Find all inline markdown links [text](URL)
inline_pattern = r'\[([^\]]+)\]\((https?://[^\)]+)\)'
inline_links = re.findall(inline_pattern, content)

# Find all bare URLs
bare_url_pattern = r'(?<!")(?<!\()https?://[^\s\)\]"<>]+'
bare_urls = re.findall(bare_url_pattern, content)

# Create the title-to-URL reference file
with open('/home/ubuntu/url_reference.txt', 'w', encoding='utf-8') as f:
    f.write("URL REFERENCE - TITLES MATCHED TO URLS\n")
    f.write("=" * 80 + "\n\n")
    
    # Write reference-style links
    if references:
        f.write("REFERENCE LINKS:\n")
        f.write("-" * 80 + "\n")
        for ref, url in sorted(references, key=lambda x: x[0]):
            f.write(f"[^{ref}]\n")
            f.write(f"  {url}\n\n")
    
    # Write inline links
    if inline_links:
        f.write("\nINLINE LINKS:\n")
        f.write("-" * 80 + "\n")
        for title, url in sorted(set(inline_links), key=lambda x: x[0]):
            f.write(f"{title}\n")
            f.write(f"  {url}\n\n")
    
    # Write bare URLs (without titles)
    bare_only = set(bare_urls) - set([url for _, url in references]) - set([url for _, url in inline_links])
    if bare_only:
        f.write("\nBARE URLS (no associated title):\n")
        f.write("-" * 80 + "\n")
        for url in sorted(bare_only):
            f.write(f"{url}\n")

print("URL reference file created successfully!")
print(f"Total reference links: {len(references)}")
print(f"Total inline links: {len(set(inline_links))}")
print(f"Total unique URLs: {len(set(bare_urls))}")
