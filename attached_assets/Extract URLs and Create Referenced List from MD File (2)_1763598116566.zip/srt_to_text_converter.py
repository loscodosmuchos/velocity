#!/usr/bin/env python3
"""
SRT to Clean Text Converter
Converts SRT subtitle files to clean, readable text
"""

import os
import re
from pathlib import Path

def parse_srt(srt_content):
    """Parse SRT content and extract text only"""
    # Split by double newlines (SRT entries are separated by blank lines)
    entries = re.split(r'\n\s*\n', srt_content.strip())
    
    text_segments = []
    
    for entry in entries:
        lines = entry.strip().split('\n')
        
        # SRT format:
        # 1. Sequence number
        # 2. Timestamp
        # 3+ Text content
        
        if len(lines) >= 3:
            # Skip first two lines (number and timestamp)
            # Join remaining lines as text
            text = ' '.join(lines[2:])
            
            # Clean up common SRT artifacts
            text = re.sub(r'<[^>]+>', '', text)  # Remove HTML tags
            text = re.sub(r'\[.*?\]', '', text)  # Remove [sound effects]
            text = re.sub(r'\(.*?\)', '', text)  # Remove (speaker names)
            text = text.strip()
            
            if text:
                text_segments.append(text)
    
    # Join all segments with spaces
    full_text = ' '.join(text_segments)
    
    # Clean up extra whitespace
    full_text = re.sub(r'\s+', ' ', full_text)
    
    return full_text.strip()

def convert_srt_file(srt_path, output_dir='converted_transcripts'):
    """Convert a single SRT file to clean text"""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Read SRT file
    with open(srt_path, 'r', encoding='utf-8', errors='ignore') as f:
        srt_content = f.read()
    
    # Parse and clean
    clean_text = parse_srt(srt_content)
    
    # Create output filename
    input_name = Path(srt_path).stem
    output_path = os.path.join(output_dir, f"{input_name}.txt")
    
    # Save clean text
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(f"Source: {Path(srt_path).name}\n")
        f.write(f"\n{'='*80}\n\n")
        f.write(clean_text)
    
    return output_path, len(clean_text)

def batch_convert_srt_directory(input_dir, output_dir='converted_transcripts'):
    """Convert all SRT files in a directory"""
    
    # Find all SRT files
    srt_files = list(Path(input_dir).glob('*.srt'))
    
    if not srt_files:
        print(f"No SRT files found in: {input_dir}")
        return
    
    print(f"Found {len(srt_files)} SRT files to convert")
    print("-" * 80)
    
    results = []
    
    for idx, srt_file in enumerate(srt_files, 1):
        print(f"\n[{idx}/{len(srt_files)}] Converting: {srt_file.name}")
        
        try:
            output_path, char_count = convert_srt_file(str(srt_file), output_dir)
            print(f"  ✅ Saved to: {output_path}")
            print(f"  📝 Text length: {char_count:,} characters")
            results.append(('success', srt_file.name, output_path, char_count))
        except Exception as e:
            print(f"  ❌ Error: {str(e)}")
            results.append(('failed', srt_file.name, str(e), 0))
    
    # Print summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    success_count = sum(1 for r in results if r[0] == 'success')
    failed_count = sum(1 for r in results if r[0] == 'failed')
    total_chars = sum(r[3] for r in results if r[0] == 'success')
    
    print(f"✅ Successfully converted: {success_count}")
    print(f"❌ Failed: {failed_count}")
    print(f"📝 Total text extracted: {total_chars:,} characters")
    
    # Save summary report
    report_file = os.path.join(output_dir, '_conversion_report.txt')
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("SRT TO TEXT CONVERSION REPORT\n")
        f.write("="*80 + "\n\n")
        f.write(f"Total files processed: {len(srt_files)}\n")
        f.write(f"Successful: {success_count}\n")
        f.write(f"Failed: {failed_count}\n")
        f.write(f"Total characters extracted: {total_chars:,}\n\n")
        
        f.write("\nCONVERSION DETAILS:\n")
        f.write("-"*80 + "\n")
        for status, filename, output, chars in results:
            if status == 'success':
                f.write(f"✅ {filename}\n")
                f.write(f"   Output: {output}\n")
                f.write(f"   Size: {chars:,} characters\n\n")
            else:
                f.write(f"❌ {filename}\n")
                f.write(f"   Error: {output}\n\n")
    
    print(f"\n📊 Full report saved to: {report_file}")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  Convert single file: python srt_to_text_converter.py <file.srt>")
        print("  Convert directory:   python srt_to_text_converter.py <directory>")
        print("\nExample:")
        print("  python srt_to_text_converter.py subtitles/")
        sys.exit(1)
    
    input_path = sys.argv[1]
    
    if not os.path.exists(input_path):
        print(f"Error: '{input_path}' not found")
        sys.exit(1)
    
    if os.path.isdir(input_path):
        # Convert all SRT files in directory
        batch_convert_srt_directory(input_path)
    elif input_path.endswith('.srt'):
        # Convert single file
        output_path, char_count = convert_srt_file(input_path)
        print(f"✅ Converted successfully!")
        print(f"📝 Output: {output_path}")
        print(f"📝 Text length: {char_count:,} characters")
    else:
        print("Error: Input must be an SRT file or directory containing SRT files")
        sys.exit(1)
