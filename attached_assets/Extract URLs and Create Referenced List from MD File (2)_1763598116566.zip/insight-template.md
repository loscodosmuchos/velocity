---
insight_id: INS-XXX
source_id: XXX
source_url: [VIDEO URL]
timestamp: XX:XX
title: [Concise Descriptive Title]
type: [Definition/Process/Best Practice/Pitfall/Case Study/Metric/Tool/Trend/Opinion/Fact]
topic_area: [Main Topic]
sub_topics: [Sub-topic 1, Sub-topic 2]
tags: [tag1, tag2, tag3, tag4, tag5]
confidence: [High/Medium/Low]
date_captured: YYYY-MM-DD
captured_by: [Your Name or "AI Analysis"]
verified: [true/false]
---

# [Insight Title]

## Source Context
- **Video:** [Video Title]
- **Channel:** [Channel Name]
- **Speaker:** [Name, Title, Credentials]
- **Upload Date:** YYYY-MM-DD
- **Timestamp:** XX:XX
- **Context:** [What was being discussed when this came up]

## Insight

[2-4 sentence summary of the key insight]

### Key Quote (Optional)
> "[Direct quote from video if particularly impactful]"

## Key Concepts
- [Concept 1]
- [Concept 2]
- [Concept 3]

## Relevant To
- [Role 1] - Why this matters to them
- [Role 2] - Why this matters to them
- [Role 3] - Why this matters to them

## Applicability
- **Company Size:** [Startup/Mid-Market/Enterprise/All]
- **Industry:** [Specific industries or "All Industries"]
- **Maturity Level:** [Beginner/Intermediate/Advanced/Expert]
- **Implementation Phase:** [Planning/Design/Implementation/Optimization]

## Related Insights
- [[Related Insight Title 1]] (INS-XXX)
- [[Related Insight Title 2]] (INS-XXX)
- [[Related Insight Title 3]] (INS-XXX)

## Application Notes
[Practical notes on how to apply this insight, any caveats, prerequisites, or considerations]

## Confidence Assessment
**Confidence Level:** [High/Medium/Low]

**Reasoning:**
- Source credibility: [Assessment]
- Specificity: [Specific numbers/examples vs vague statements]
- Corroboration: [Confirmed by other sources? Y/N]
- Recency: [How current is this information?]

## Follow-Up Questions
- [Question 1 to research further]
- [Question 2 to validate]
- [Question 3 to explore]

## Tags
`#tag1` `#tag2` `#tag3` `#tag4` `#tag5` `#tag6` `#tag7` `#tag8`

---

**Captured:** [Date]  
**Last Updated:** [Date]  
**Status:** [Draft/Reviewed/Verified/Published]
