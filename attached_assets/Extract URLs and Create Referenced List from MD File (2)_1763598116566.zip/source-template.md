---
source_id: XXX
source_type: [YouTube Video/Article/Podcast/Webinar/Conference Talk]
url: [FULL URL]
title: [Full Title]
channel_author: [Channel Name or Author]
upload_publish_date: YYYY-MM-DD
duration: [XX:XX for videos, word count for articles]
views_reads: [Number if available]
topic_area: [Main Topic]
extraction_date: YYYY-MM-DD
transcript_available: [true/false]
transcript_quality: [Excellent/Good/Fair/Poor/Auto-Generated]
---

# Source: [Title]

## Basic Information
- **Type:** [YouTube Video/Article/Podcast/etc.]
- **URL:** [FULL URL]
- **Channel/Author:** [Name]
- **Published:** YYYY-MM-DD
- **Duration/Length:** [XX:XX or word count]
- **Views/Reads:** [Number]

## Speaker/Author Credentials
- **Name:** [Full Name]
- **Title:** [Current Title]
- **Organization:** [Company/Organization]
- **Experience:** [Years in field, relevant background]
- **Expertise Areas:** [List areas of expertise]
- **Credibility Assessment:** [High/Medium/Low with reasoning]

## Content Overview
[2-3 paragraph summary of what this source covers]

### Key Topics Covered
- [Topic 1]
- [Topic 2]
- [Topic 3]
- [Topic 4]

### Target Audience
[Who is this content aimed at? What level of expertise assumed?]

## Content Quality Assessment

### Strengths
- [Strength 1]
- [Strength 2]
- [Strength 3]

### Limitations
- [Limitation 1]
- [Limitation 2]
- [Limitation 3]

### Bias/Perspective
[Any notable bias, vendor perspective, or particular viewpoint presented]

## Insights Extracted
Total insights captured from this source: [Number]

- [[Insight Title 1]] (INS-XXX) @ XX:XX
- [[Insight Title 2]] (INS-XXX) @ XX:XX
- [[Insight Title 3]] (INS-XXX) @ XX:XX
[... list all insights]

## Key Terminology Defined
- **[Term 1]** - Definition from this source
- **[Term 2]** - Definition from this source
- **[Term 3]** - Definition from this source

## Notable Quotes
> "[Quote 1]" - @ XX:XX

> "[Quote 2]" - @ XX:XX

> "[Quote 3]" - @ XX:XX

## Related Sources
- [[Source Title 1]] (SRC-XXX) - [How related]
- [[Source Title 2]] (SRC-XXX) - [How related]
- [[Source Title 3]] (SRC-XXX) - [How related]

## Transcript Information
- **Available:** [Yes/No]
- **Quality:** [Excellent/Good/Fair/Poor/Auto-Generated]
- **File Location:** [Path to transcript file]
- **Extraction Method:** [YouTube API/Manual/etc.]
- **Extraction Date:** YYYY-MM-DD

## Usage Recommendations

### Best Used For
[What this source is particularly good for]

### Not Recommended For
[What this source is not suitable for]

### Complementary Sources
[Other sources that should be reviewed alongside this one]

## Tags
`#tag1` `#tag2` `#tag3` `#tag4` `#tag5`

---

**Added to Knowledge Base:** [Date]  
**Last Reviewed:** [Date]  
**Review Status:** [Pending/Reviewed/Verified]  
**Reviewer:** [Name]
