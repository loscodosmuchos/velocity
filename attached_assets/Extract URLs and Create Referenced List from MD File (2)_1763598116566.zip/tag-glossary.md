# Tag Glossary & Taxonomy

**Purpose:** Standardized tagging system for consistent knowledge organization across all topics.

**Usage:** Always reference this glossary when tagging insights to ensure consistency.

---

## Tag Structure Convention

- **Format:** All lowercase, hyphens for spaces, no special characters
- **Examples:** `#procurement`, `#talent-acquisition`, `#cost-savings`
- **Avoid:** `#Procurement`, `#talent_acquisition`, `#cost savings`

---

## 1. Topic Area Tags (Primary Classification)

### HR & Talent
- `#talent-acquisition` - Recruiting and hiring
- `#recruiting` - General recruiting topics
- `#sourcing` - Candidate sourcing strategies
- `#employer-branding` - Employer brand and EVP
- `#candidate-experience` - Candidate journey and experience
- `#onboarding` - New hire onboarding
- `#hr-operations` - HR operational functions
- `#hris` - HR information systems
- `#hrms` - HR management systems
- `#hcm` - Human capital management
- `#benefits-administration` - Employee benefits
- `#compensation` - Pay and rewards
- `#total-rewards` - Complete compensation package
- `#performance-management` - Performance reviews and management
- `#learning-development` - Training and L&D
- `#employee-engagement` - Engagement and retention
- `#workforce-planning` - Strategic workforce planning
- `#hr-analytics` - People analytics and metrics

### Procurement & Sourcing
- `#procurement` - General procurement topics
- `#strategic-sourcing` - Strategic sourcing activities
- `#supplier-management` - Vendor/supplier relationships
- `#contract-management` - Contract lifecycle management
- `#spend-management` - Spend analysis and control
- `#cost-savings` - Cost reduction strategies
- `#procurement-technology` - Procurement systems and tools
- `#source-to-pay` - S2P processes
- `#procure-to-pay` - P2P processes
- `#rfp` - Request for proposal
- `#rfq` - Request for quotation
- `#rfi` - Request for information

### Contingent Workforce
- `#contingent-workforce` - Non-employee workers
- `#vms` - Vendor management systems
- `#msp` - Managed service providers
- `#sow` - Statement of work
- `#temp-staffing` - Temporary staffing
- `#contract-workers` - Contract/freelance workers
- `#gig-economy` - Gig workers and platforms
- `#workforce-management` - Workforce planning and management
- `#direct-sourcing` - Direct sourcing strategies

### Technology & Integration
- `#ats` - Applicant tracking systems
- `#crm` - Customer/candidate relationship management
- `#ipaas` - Integration platform as a service
- `#api` - API integration
- `#automation` - Process automation
- `#ai` - Artificial intelligence
- `#machine-learning` - ML applications
- `#data-analytics` - Data analysis and insights
- `#business-intelligence` - BI and reporting
- `#system-integration` - System connectivity

---

## 2. Role/Audience Tags

### C-Suite
- `#ceo` - Chief Executive Officer
- `#cfo` - Chief Financial Officer
- `#coo` - Chief Operating Officer
- `#cpo` - Chief Procurement Officer
- `#chro` - Chief Human Resources Officer
- `#cto` - Chief Talent Officer
- `#cio` - Chief Information Officer

### Executive Leadership
- `#vp-procurement` - VP of Procurement
- `#vp-hr` - VP of Human Resources
- `#vp-talent-acquisition` - VP of TA
- `#head-of-procurement` - Head of Procurement
- `#head-of-ta` - Head of Talent Acquisition

### Director Level
- `#procurement-director` - Procurement Director
- `#ta-director` - TA Director
- `#hr-director` - HR Director
- `#it-director` - IT Director

### Manager Level
- `#procurement-manager` - Procurement Manager
- `#category-manager` - Category Manager
- `#recruiting-manager` - Recruiting Manager
- `#hr-manager` - HR Manager
- `#hris-manager` - HRIS Manager

### Individual Contributors
- `#procurement-specialist` - Procurement Specialist
- `#buyer` - Buyer/Purchasing Agent
- `#recruiter` - Recruiter
- `#sourcer` - Sourcing Specialist
- `#recruiting-coordinator` - Recruiting Coordinator
- `#hr-specialist` - HR Specialist
- `#hris-analyst` - HRIS Analyst

---

## 3. Company Context Tags

### Size
- `#startup` - Startup companies (<50 employees)
- `#small-business` - Small business (50-500 employees)
- `#mid-market` - Mid-market (500-5000 employees)
- `#enterprise` - Enterprise (5000+ employees)
- `#fortune-500` - Fortune 500 companies
- `#global` - Global/multinational organizations

### Industry
- `#manufacturing` - Manufacturing sector
- `#technology` - Technology/software companies
- `#healthcare` - Healthcare industry
- `#financial-services` - Banking and finance
- `#retail` - Retail sector
- `#professional-services` - Consulting, legal, etc.
- `#all-industries` - Applicable across industries

---

## 4. Concept Type Tags

### Content Classification
- `#definition` - Defines a term or concept
- `#process` - Describes a process or workflow
- `#best-practice` - Recommended approach
- `#pitfall` - Warning or common mistake
- `#case-study` - Real-world example
- `#metric` - KPI or measurement
- `#kpi` - Key performance indicator
- `#tool` - Specific tool or technology
- `#trend` - Emerging trend or pattern
- `#opinion` - Expert opinion (subjective)
- `#fact` - Verifiable data point
- `#framework` - Conceptual framework or model

---

## 5. Implementation Phase Tags

- `#planning` - Planning and strategy phase
- `#design` - Design and architecture phase
- `#implementation` - Implementation and deployment
- `#optimization` - Optimization and improvement
- `#maintenance` - Ongoing maintenance
- `#change-management` - Change management activities

---

## 6. Maturity Level Tags

- `#beginner` - For those new to the topic
- `#intermediate` - Requires some background knowledge
- `#advanced` - For experienced practitioners
- `#expert` - For subject matter experts

---

## 7. Organizational Structure Tags

### Procurement Structures
- `#centralized` - Centralized model
- `#decentralized` - Decentralized model
- `#hybrid` - Hybrid/center-led model
- `#organizational-structure` - General org structure

### TA Structures
- `#three-pillar-model` - TA three-pillar framework
- `#candidate-facing` - Candidate-facing roles
- `#business-facing` - Business-facing roles
- `#centralized-functions` - Shared services

---

## 8. Workflow & Process Tags

- `#workflow` - Process workflow
- `#automation` - Process automation
- `#approval-process` - Approval workflows
- `#requisition-to-hire` - Req to hire process
- `#pr-to-po` - Purchase requisition to PO
- `#source-to-pay` - S2P workflow
- `#candidate-pipeline` - Talent pipeline management

---

## 9. Compliance & Risk Tags

- `#compliance` - Regulatory compliance
- `#risk-management` - Risk mitigation
- `#worker-classification` - Worker classification issues
- `#co-employment` - Co-employment risk
- `#data-privacy` - Data privacy and security
- `#audit` - Audit and controls

---

## 10. Financial & Metrics Tags

- `#cost-savings` - Cost reduction
- `#roi` - Return on investment
- `#cost-per-hire` - Cost per hire metric
- `#time-to-fill` - Time to fill metric
- `#time-to-hire` - Time to hire metric
- `#quality-of-hire` - Quality of hire metric
- `#spend-under-management` - Managed spend
- `#maverick-spend` - Rogue/unmanaged spend
- `#budget` - Budget and financial planning

---

## 11. Geographic Tags

- `#north-america` - North America region
- `#united-states` - United States
- `#canada` - Canada
- `#europe` - Europe region
- `#uk` - United Kingdom
- `#asia-pacific` - APAC region
- `#global` - Global/worldwide

---

## 12. Special Topic Tags

### Staffing Industry
- `#staffing-agency` - Staffing agency operations
- `#temp-to-perm` - Temp to permanent conversion
- `#direct-hire` - Direct hire placement
- `#bill-rate` - Bill rate concepts
- `#pay-rate` - Pay rate concepts
- `#markup` - Markup calculations
- `#margin` - Margin calculations
- `#bench` - Bench management

### Integration & Architecture
- `#system-integration` - System connectivity
- `#api-integration` - API connections
- `#data-flow` - Data flow between systems
- `#single-source-of-truth` - Data consistency
- `#master-data` - Master data management

### Analytics & Reporting
- `#dashboard` - Dashboard design
- `#reporting` - Reporting and analytics
- `#data-visualization` - Data viz
- `#predictive-analytics` - Predictive models
- `#benchmarking` - Industry benchmarks

---

## Tag Usage Guidelines

### How Many Tags Per Insight?
- **Minimum:** 5 tags
- **Optimal:** 7-10 tags
- **Maximum:** 15 tags

### Tag Selection Strategy
1. **Primary Topic** (1-2 tags) - Main subject area
2. **Role/Audience** (1-2 tags) - Who cares about this
3. **Company Context** (1-2 tags) - When it applies
4. **Concept Type** (1 tag) - What kind of content
5. **Additional Context** (2-5 tags) - Specific details

### Example: Well-Tagged Insight

**Insight:** "Centralized procurement saves 15-20% in first year"

**Tags:**
- `#procurement` (primary topic)
- `#centralized` (structure type)
- `#cost-savings` (financial impact)
- `#metric` (concept type)
- `#cpo` (audience)
- `#enterprise` (company size)
- `#best-practice` (recommendation)
- `#implementation` (phase)
- `#fact` (content type)

---

## Adding New Tags

### When to Create a New Tag
- Concept appears 5+ times and doesn't fit existing tags
- New technology or methodology emerges
- Specific sub-topic needs distinction

### Tag Creation Process
1. Check if existing tag can be used
2. Propose new tag with definition
3. Add to this glossary
4. Retag existing insights if applicable

### Tag Naming Conventions
- Use existing patterns (e.g., `#x-management`, `#x-strategy`)
- Be specific but not too narrow
- Consider searchability
- Avoid abbreviations unless industry-standard

---

## Tag Maintenance

### Monthly Review
- Identify underused tags (used <5 times)
- Merge similar tags
- Update definitions as needed

### Quarterly Audit
- Review tag usage patterns
- Consolidate redundant tags
- Add new tags based on content growth
- Update this glossary

---

## Quick Reference: Most Common Tags

**Top 20 Tags (Use These Most Often):**

1. `#procurement`
2. `#talent-acquisition`
3. `#best-practice`
4. `#enterprise`
5. `#cost-savings`
6. `#process`
7. `#ats`
8. `#vms`
9. `#hris`
10. `#metric`
11. `#organizational-structure`
12. `#implementation`
13. `#automation`
14. `#compliance`
15. `#workflow`
16. `#contingent-workforce`
17. `#strategic-sourcing`
18. `#recruiting`
19. `#supplier-management`
20. `#hr-operations`

---

**Last Updated:** [Date]  
**Version:** 1.0  
**Maintainer:** [Name/Team]
