"""
================================================================================
YOUTUBE TRANSCRIPT EXTRACTOR MODULE
================================================================================

SCOPE:
------
This module extracts YouTube video transcripts and organizes them into a 
knowledge base. It works with publicly available captions/subtitles without
requiring API keys, authentication, or video downloads.

WHAT IT DOES:
- Extracts transcripts from YouTube URLs (batch processing)
- Converts SRT subtitle files to clean text
- Organizes transcripts by topic categories
- Generates statistics and key term analysis
- Creates consolidated knowledge base files

WHAT IT DOESN'T DO:
- Download videos (transcript text only)
- Work with private/members-only videos
- Require YouTube login or API keys
- Process non-YouTube video platforms

EDGE CASES HANDLED:
- Videos without transcripts (reports as failed)
- Disabled transcripts (reports as failed)
- Invalid URLs (skips with warning)
- Non-English transcripts (attempts to get any available)
- Network errors (retries with timeout)
- Malformed SRT files (error handling with partial recovery)

DEPENDENCIES:
- youtube-transcript-api (install: pip install youtube-transcript-api)

================================================================================
AI AGENT SETUP INSTRUCTIONS
================================================================================

WHEN A USER ASKS TO USE THIS MODULE:

1. INSTALLATION:
   Run in terminal: pip install youtube-transcript-api

2. IMPORT THE MODULE:
   from youtube_transcript_module import YouTubeTranscriptExtractor

3. BASIC USAGE - Extract from URLs:
   extractor = YouTubeTranscriptExtractor()
   results = extractor.extract_from_urls([
       "https://www.youtube.com/watch?v=VIDEO_ID_1",
       "https://www.youtube.com/watch?v=VIDEO_ID_2"
   ])

4. BATCH PROCESSING - From file:
   extractor = YouTubeTranscriptExtractor()
   results = extractor.extract_from_file("urls.txt", output_dir="transcripts")

5. CONVERT SRT FILES:
   extractor = YouTubeTranscriptExtractor()
   results = extractor.convert_srt_directory("srt_files/", output_dir="transcripts")

6. CREATE KNOWLEDGE BASE:
   extractor = YouTubeTranscriptExtractor()
   kb = extractor.create_knowledge_base("transcripts/", output_file="knowledge_base.md")

7. ALL-IN-ONE PIPELINE:
   extractor = YouTubeTranscriptExtractor()
   extractor.process_pipeline(
       url_file="urls.txt",
       output_dir="transcripts",
       create_kb=True
   )

RETURN VALUES:
- All methods return dictionaries with 'success', 'failed', 'results' keys
- Check results['success'] for list of successful operations
- Check results['failed'] for errors with details
- Files are saved to specified output directories

ERROR HANDLING:
- Module handles all exceptions internally
- Returns detailed error messages in results['failed']
- Never crashes - always returns results dict

================================================================================
"""

import os
import re
from pathlib import Path
from collections import defaultdict
from typing import List, Dict, Tuple, Optional


class YouTubeTranscriptExtractor:
    """
    Self-contained YouTube transcript extraction and knowledge base builder.
    
    Usage:
        extractor = YouTubeTranscriptExtractor()
        results = extractor.extract_from_urls(["https://youtube.com/watch?v=..."])
    """
    
    def __init__(self):
        """Initialize the extractor."""
        self._check_dependencies()
        
    def _check_dependencies(self):
        """Check if required libraries are installed."""
        try:
            from youtube_transcript_api import YouTubeTranscriptApi
            self.YouTubeTranscriptApi = YouTubeTranscriptApi
        except ImportError:
            raise ImportError(
                "youtube-transcript-api not installed. "
                "Run: pip install youtube-transcript-api"
            )
    
    # ========================================================================
    # CORE EXTRACTION METHODS
    # ========================================================================
    
    def extract_video_id(self, url: str) -> Optional[str]:
        """
        Extract video ID from various YouTube URL formats.
        
        Handles:
        - youtube.com/watch?v=VIDEO_ID
        - youtu.be/VIDEO_ID
        - youtube.com/embed/VIDEO_ID
        - URLs with additional parameters
        
        Edge cases:
        - Invalid URLs return None
        - Malformed URLs return None
        """
        patterns = [
            r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)',
            r'youtube\.com\/watch\?.*v=([^&\n?#]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        return None
    
    def get_transcript(self, video_id: str) -> Tuple[str, bool, str]:
        """
        Fetch transcript for a video ID.
        
        Returns:
            (transcript_text, success, error_message)
        
        Edge cases:
        - No transcript available: returns error message
        - Transcripts disabled: returns error message
        - Network errors: returns error message
        - Non-English: attempts to get any available language
        """
        try:
            from youtube_transcript_api._errors import (
                TranscriptsDisabled, 
                NoTranscriptFound,
                VideoUnavailable
            )
            
            # Try to get transcript
            transcript_list = self.YouTubeTranscriptApi.list_transcripts(video_id)
            
            # Prefer English, but accept any language
            try:
                transcript = transcript_list.find_transcript(['en'])
            except:
                try:
                    transcript = transcript_list.find_generated_transcript(['en'])
                except:
                    # Get first available transcript
                    available = list(transcript_list)
                    if available:
                        transcript = available[0]
                    else:
                        return "", False, "No transcripts available"
            
            # Fetch the actual transcript
            transcript_data = transcript.fetch()
            
            # Combine all text segments
            full_text = ' '.join([entry['text'] for entry in transcript_data])
            
            return full_text, True, ""
            
        except TranscriptsDisabled:
            return "", False, "Transcripts disabled for this video"
        except NoTranscriptFound:
            return "", False, "No transcript found"
        except VideoUnavailable:
            return "", False, "Video unavailable"
        except Exception as e:
            return "", False, f"Error: {str(e)}"
    
    def extract_from_urls(
        self, 
        urls: List[str], 
        output_dir: str = "transcripts",
        verbose: bool = True
    ) -> Dict:
        """
        Extract transcripts from a list of YouTube URLs.
        
        Args:
            urls: List of YouTube URLs
            output_dir: Directory to save transcript files
            verbose: Print progress messages
        
        Returns:
            Dictionary with 'success', 'failed', 'skipped' lists
        
        Edge cases:
        - Empty URL list: returns empty results
        - Invalid URLs: added to 'skipped'
        - Duplicate URLs: processed only once
        - Network failures: added to 'failed' with error message
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Remove duplicates while preserving order
        urls = list(dict.fromkeys([url.strip() for url in urls if url.strip()]))
        
        if not urls:
            return {'success': [], 'failed': [], 'skipped': [], 'total': 0}
        
        results = {
            'success': [],
            'failed': [],
            'skipped': []
        }
        
        if verbose:
            print(f"Processing {len(urls)} URLs...")
            print("-" * 80)
        
        for idx, url in enumerate(urls, 1):
            if verbose:
                print(f"[{idx}/{len(urls)}] {url}")
            
            # Extract video ID
            video_id = self.extract_video_id(url)
            if not video_id:
                if verbose:
                    print(f"  ❌ Invalid URL")
                results['skipped'].append(url)
                continue
            
            # Get transcript
            transcript_text, success, error_msg = self.get_transcript(video_id)
            
            if success:
                # Save to file
                output_file = os.path.join(output_dir, f"{video_id}.txt")
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(f"Video ID: {video_id}\n")
                    f.write(f"URL: {url}\n")
                    f.write(f"\n{'='*80}\n\n")
                    f.write(transcript_text)
                
                if verbose:
                    print(f"  ✅ Saved to {output_file}")
                results['success'].append({
                    'url': url,
                    'video_id': video_id,
                    'file': output_file
                })
            else:
                if verbose:
                    print(f"  ❌ {error_msg}")
                results['failed'].append({
                    'url': url,
                    'video_id': video_id,
                    'error': error_msg
                })
        
        results['total'] = len(urls)
        
        if verbose:
            print("\n" + "="*80)
            print(f"✅ Success: {len(results['success'])}")
            print(f"❌ Failed: {len(results['failed'])}")
            print(f"⚠️  Skipped: {len(results['skipped'])}")
        
        return results
    
    def extract_from_file(
        self, 
        url_file: str, 
        output_dir: str = "transcripts",
        verbose: bool = True
    ) -> Dict:
        """
        Extract transcripts from URLs in a text file (one URL per line).
        
        Args:
            url_file: Path to file containing URLs
            output_dir: Directory to save transcripts
            verbose: Print progress messages
        
        Returns:
            Dictionary with extraction results
        
        Edge cases:
        - File not found: raises FileNotFoundError
        - Empty file: returns empty results
        - Lines with comments (#): ignored
        - Blank lines: ignored
        """
        if not os.path.exists(url_file):
            raise FileNotFoundError(f"URL file not found: {url_file}")
        
        with open(url_file, 'r', encoding='utf-8') as f:
            urls = [
                line.strip() 
                for line in f 
                if line.strip() and not line.strip().startswith('#')
            ]
        
        return self.extract_from_urls(urls, output_dir, verbose)
    
    # ========================================================================
    # SRT CONVERSION METHODS
    # ========================================================================
    
    def parse_srt(self, srt_content: str) -> str:
        """
        Parse SRT content and extract clean text.
        
        Edge cases:
        - Malformed SRT: extracts what it can
        - Missing timestamps: skips entry
        - HTML tags: removed
        - Special characters: preserved
        """
        entries = re.split(r'\n\s*\n', srt_content.strip())
        text_segments = []
        
        for entry in entries:
            lines = entry.strip().split('\n')
            
            if len(lines) >= 3:
                # Skip sequence number and timestamp, get text
                text = ' '.join(lines[2:])
                
                # Clean up
                text = re.sub(r'<[^>]+>', '', text)  # Remove HTML tags
                text = re.sub(r'\[.*?\]', '', text)  # Remove [sound effects]
                text = re.sub(r'\(.*?\)', '', text)  # Remove (speaker names)
                text = text.strip()
                
                if text:
                    text_segments.append(text)
        
        full_text = ' '.join(text_segments)
        full_text = re.sub(r'\s+', ' ', full_text)
        
        return full_text.strip()
    
    def convert_srt_file(
        self, 
        srt_path: str, 
        output_dir: str = "converted_transcripts"
    ) -> Tuple[str, int]:
        """
        Convert a single SRT file to clean text.
        
        Returns:
            (output_path, character_count)
        
        Edge cases:
        - File not found: raises FileNotFoundError
        - Encoding errors: tries utf-8, then ignores errors
        - Empty SRT: creates empty output file
        """
        os.makedirs(output_dir, exist_ok=True)
        
        if not os.path.exists(srt_path):
            raise FileNotFoundError(f"SRT file not found: {srt_path}")
        
        # Read with error handling
        with open(srt_path, 'r', encoding='utf-8', errors='ignore') as f:
            srt_content = f.read()
        
        clean_text = self.parse_srt(srt_content)
        
        # Create output filename
        input_name = Path(srt_path).stem
        output_path = os.path.join(output_dir, f"{input_name}.txt")
        
        # Save
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"Source: {Path(srt_path).name}\n")
            f.write(f"\n{'='*80}\n\n")
            f.write(clean_text)
        
        return output_path, len(clean_text)
    
    def convert_srt_directory(
        self, 
        input_dir: str, 
        output_dir: str = "converted_transcripts",
        verbose: bool = True
    ) -> Dict:
        """
        Convert all SRT files in a directory.
        
        Edge cases:
        - Directory not found: raises FileNotFoundError
        - No SRT files: returns empty results
        - Mixed file types: only processes .srt files
        """
        if not os.path.exists(input_dir):
            raise FileNotFoundError(f"Directory not found: {input_dir}")
        
        srt_files = list(Path(input_dir).glob('*.srt'))
        
        if not srt_files:
            if verbose:
                print(f"No SRT files found in {input_dir}")
            return {'success': [], 'failed': [], 'total': 0}
        
        results = {'success': [], 'failed': []}
        
        if verbose:
            print(f"Converting {len(srt_files)} SRT files...")
            print("-" * 80)
        
        for idx, srt_file in enumerate(srt_files, 1):
            if verbose:
                print(f"[{idx}/{len(srt_files)}] {srt_file.name}")
            
            try:
                output_path, char_count = self.convert_srt_file(
                    str(srt_file), 
                    output_dir
                )
                if verbose:
                    print(f"  ✅ {char_count:,} characters")
                results['success'].append({
                    'input': str(srt_file),
                    'output': output_path,
                    'chars': char_count
                })
            except Exception as e:
                if verbose:
                    print(f"  ❌ {str(e)}")
                results['failed'].append({
                    'input': str(srt_file),
                    'error': str(e)
                })
        
        results['total'] = len(srt_files)
        
        if verbose:
            print("\n" + "="*80)
            print(f"✅ Success: {len(results['success'])}")
            print(f"❌ Failed: {len(results['failed'])}")
        
        return results
    
    # ========================================================================
    # KNOWLEDGE BASE METHODS
    # ========================================================================
    
    def analyze_transcript(self, file_path: str) -> Dict:
        """
        Analyze a single transcript file.
        
        Edge cases:
        - File not found: raises FileNotFoundError
        - Empty file: returns minimal analysis
        - Encoding errors: handles gracefully
        """
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Extract metadata
        video_id = None
        url = None
        
        lines = content.split('\n')
        for line in lines[:5]:
            if line.startswith('Video ID:'):
                video_id = line.replace('Video ID:', '').strip()
            elif line.startswith('URL:'):
                url = line.replace('URL:', '').strip()
        
        # Get main text
        text_start = content.find('='*40)
        if text_start != -1:
            text = content[text_start:].strip()
        else:
            text = content
        
        # Basic stats
        word_count = len(text.split())
        char_count = len(text)
        
        # Extract key terms
        key_terms = self._extract_key_terms(text)
        
        return {
            'file': Path(file_path).name,
            'video_id': video_id,
            'url': url,
            'word_count': word_count,
            'char_count': char_count,
            'key_terms': key_terms,
            'text': text
        }
    
    def _extract_key_terms(self, text: str) -> Dict[str, int]:
        """Extract key terms and their frequencies."""
        term_list = [
            'procurement', 'purchase order', 'PO', 'RFP', 'RFQ', 'RFI',
            'ATS', 'applicant tracking', 'HRIS', 'HCM', 'HRMS',
            'contingent workforce', 'VMS', 'MSP', 'staffing',
            'SOW', 'statement of work', 'contractor', 'freelancer',
            'vendor management', 'supplier', 'requisition',
            'time-to-hire', 'cost per hire', 'candidate pipeline',
            'payroll', 'benefits', 'onboarding', 'compliance',
            'ITAM', 'IT asset', 'project management', 'PMP'
        ]
        
        found_terms = {}
        text_lower = text.lower()
        
        for term in term_list:
            count = text_lower.count(term.lower())
            if count > 0:
                found_terms[term] = count
        
        return found_terms
    
    def _categorize_transcripts(self, transcripts: List[Dict]) -> Dict:
        """Categorize transcripts by primary topic."""
        categories = {
            'Procurement': ['procurement', 'purchase', 'supplier', 'vendor', 'rfp', 'rfq', 'sourcing'],
            'ATS & Recruitment': ['ats', 'applicant', 'recruitment', 'hiring', 'candidate', 'resume'],
            'HRIS & HR Systems': ['hris', 'hrms', 'hcm', 'payroll', 'benefits', 'employee data'],
            'Contingent Workforce': ['contingent', 'contractor', 'freelancer', 'gig', 'temp', 'agency'],
            'VMS & MSP': ['vms', 'msp', 'vendor management', 'managed service'],
            'Staffing & SOW': ['staffing', 'sow', 'statement of work', 'bill rate', 'markup'],
            'IT Asset Management': ['itam', 'it asset', 'hardware', 'software asset'],
            'Project Management': ['project management', 'pmp', 'agile', 'scrum', 'waterfall'],
            'General HR': ['onboarding', 'performance', 'compliance', 'training', 'workforce']
        }
        
        categorized = defaultdict(list)
        
        for transcript in transcripts:
            text_lower = transcript['text'].lower()
            
            # Score each category
            scores = {}
            for category, keywords in categories.items():
                score = sum(text_lower.count(keyword) for keyword in keywords)
                scores[category] = score
            
            # Assign to highest scoring category
            if scores:
                best_category = max(scores, key=scores.get)
                if scores[best_category] > 0:
                    categorized[best_category].append(transcript)
                else:
                    categorized['Uncategorized'].append(transcript)
            else:
                categorized['Uncategorized'].append(transcript)
        
        return categorized
    
    def create_knowledge_base(
        self, 
        transcript_dir: str, 
        output_file: str = "knowledge_base.md",
        verbose: bool = True
    ) -> Dict:
        """
        Create consolidated knowledge base from transcripts.
        
        Args:
            transcript_dir: Directory containing transcript files
            output_file: Output markdown file path
            verbose: Print progress messages
        
        Returns:
            Dictionary with statistics and file paths
        
        Edge cases:
        - Directory not found: raises FileNotFoundError
        - No transcript files: creates empty knowledge base
        - Mixed file types: only processes .txt files
        """
        if not os.path.exists(transcript_dir):
            raise FileNotFoundError(f"Directory not found: {transcript_dir}")
        
        # Find transcript files
        transcript_files = list(Path(transcript_dir).glob('*.txt'))
        transcript_files = [f for f in transcript_files if not f.name.startswith('_')]
        
        if not transcript_files:
            if verbose:
                print(f"No transcript files found in {transcript_dir}")
            return {'transcripts': 0, 'categories': 0, 'output': None}
        
        if verbose:
            print(f"Analyzing {len(transcript_files)} transcripts...")
        
        # Analyze all transcripts
        transcripts = []
        for file_path in transcript_files:
            try:
                analysis = self.analyze_transcript(str(file_path))
                transcripts.append(analysis)
            except Exception as e:
                if verbose:
                    print(f"  ⚠️  Error analyzing {file_path.name}: {str(e)}")
        
        if verbose:
            print(f"✅ Analyzed {len(transcripts)} transcripts")
            print("🏷️  Categorizing...")
        
        # Categorize
        categorized = self._categorize_transcripts(transcripts)
        
        # Generate knowledge base
        if verbose:
            print(f"📝 Creating {output_file}...")
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("# Knowledge Base: Procurement, ATS, HR, HRIS, Staffing & Contingent Workforce\n\n")
            f.write(f"**Generated from {len(transcripts)} video transcripts**\n\n")
            f.write("---\n\n")
            
            # Table of contents
            f.write("## Table of Contents\n\n")
            for category in sorted(categorized.keys()):
                count = len(categorized[category])
                anchor = category.lower().replace(' ', '-').replace('&', '')
                f.write(f"- [{category}](#{anchor}) ({count} transcripts)\n")
            f.write("\n---\n\n")
            
            # Statistics
            f.write("## Overview Statistics\n\n")
            total_words = sum(t['word_count'] for t in transcripts)
            total_chars = sum(t['char_count'] for t in transcripts)
            f.write(f"- **Total Transcripts:** {len(transcripts)}\n")
            f.write(f"- **Total Words:** {total_words:,}\n")
            f.write(f"- **Total Characters:** {total_chars:,}\n")
            f.write(f"- **Categories:** {len(categorized)}\n\n")
            
            # Key terms
            f.write("### Most Frequent Key Terms\n\n")
            all_terms = defaultdict(int)
            for transcript in transcripts:
                for term, count in transcript['key_terms'].items():
                    all_terms[term] += count
            
            sorted_terms = sorted(all_terms.items(), key=lambda x: x[1], reverse=True)[:20]
            f.write("| Term | Occurrences |\n")
            f.write("|------|-------------|\n")
            for term, count in sorted_terms:
                f.write(f"| {term} | {count} |\n")
            f.write("\n---\n\n")
            
            # Content by category
            for category in sorted(categorized.keys()):
                f.write(f"## {category}\n\n")
                f.write(f"**{len(categorized[category])} transcripts**\n\n")
                
                for idx, transcript in enumerate(categorized[category], 1):
                    f.write(f"### {category} - Transcript {idx}\n\n")
                    
                    if transcript['url']:
                        f.write(f"**Source:** [{transcript['video_id']}]({transcript['url']})\n\n")
                    elif transcript['video_id']:
                        f.write(f"**Video ID:** {transcript['video_id']}\n\n")
                    else:
                        f.write(f"**File:** {transcript['file']}\n\n")
                    
                    f.write(f"**Stats:** {transcript['word_count']:,} words\n\n")
                    
                    if transcript['key_terms']:
                        terms_str = ", ".join([
                            f"{term} ({count})" 
                            for term, count in sorted(
                                transcript['key_terms'].items(), 
                                key=lambda x: x[1], 
                                reverse=True
                            )[:10]
                        ])
                        f.write(f"**Key Terms:** {terms_str}\n\n")
                    
                    f.write("**Preview:**\n\n")
                    preview = transcript['text'][:500].replace('\n', ' ')
                    f.write(f"> {preview}...\n\n")
                    f.write("---\n\n")
        
        if verbose:
            print(f"✅ Knowledge base created: {output_file}")
            print("\nCategory Summary:")
            for category in sorted(categorized.keys()):
                count = len(categorized[category])
                print(f"  {category}: {count} transcripts")
        
        return {
            'transcripts': len(transcripts),
            'categories': len(categorized),
            'output': output_file,
            'category_breakdown': {k: len(v) for k, v in categorized.items()}
        }
    
    # ========================================================================
    # CONVENIENCE METHODS
    # ========================================================================
    
    def process_pipeline(
        self,
        url_file: Optional[str] = None,
        urls: Optional[List[str]] = None,
        output_dir: str = "transcripts",
        create_kb: bool = True,
        kb_output: str = "knowledge_base.md",
        verbose: bool = True
    ) -> Dict:
        """
        Complete pipeline: extract transcripts and create knowledge base.
        
        Args:
            url_file: Path to file with URLs (one per line)
            urls: List of URLs (alternative to url_file)
            output_dir: Directory to save transcripts
            create_kb: Whether to create knowledge base
            kb_output: Knowledge base output file
            verbose: Print progress
        
        Returns:
            Dictionary with all results
        
        Edge cases:
        - Neither url_file nor urls provided: raises ValueError
        - Both provided: uses url_file
        """
        if not url_file and not urls:
            raise ValueError("Must provide either url_file or urls")
        
        # Extract transcripts
        if url_file:
            extract_results = self.extract_from_file(url_file, output_dir, verbose)
        else:
            extract_results = self.extract_from_urls(urls, output_dir, verbose)
        
        # Create knowledge base
        kb_results = None
        if create_kb and extract_results['success']:
            if verbose:
                print("\n" + "="*80)
            kb_results = self.create_knowledge_base(output_dir, kb_output, verbose)
        
        return {
            'extraction': extract_results,
            'knowledge_base': kb_results
        }


# ============================================================================
# STANDALONE USAGE (when run as script)
# ============================================================================

if __name__ == "__main__":
    import sys
    
    print("="*80)
    print("YOUTUBE TRANSCRIPT EXTRACTOR MODULE")
    print("="*80)
    print()
    
    if len(sys.argv) < 2:
        print("USAGE:")
        print("  python youtube_transcript_module.py <url_file>")
        print()
        print("EXAMPLE:")
        print("  python youtube_transcript_module.py urls.txt")
        print()
        print("The url_file should contain one YouTube URL per line.")
        print()
        sys.exit(1)
    
    url_file = sys.argv[1]
    
    if not os.path.exists(url_file):
        print(f"❌ Error: File not found: {url_file}")
        sys.exit(1)
    
    # Run pipeline
    extractor = YouTubeTranscriptExtractor()
    results = extractor.process_pipeline(
        url_file=url_file,
        output_dir="transcripts",
        create_kb=True,
        kb_output="knowledge_base.md",
        verbose=True
    )
    
    print("\n" + "="*80)
    print("✅ COMPLETE!")
    print("="*80)
    print(f"Transcripts saved to: transcripts/")
    if results['knowledge_base']:
        print(f"Knowledge base saved to: {results['knowledge_base']['output']}")
