# YouTube Transcript Module - Usage Examples

## Quick Start

### 1. Install Dependency
```bash
pip install youtube-transcript-api
```

### 2. Import Module
```python
from youtube_transcript_module import YouTubeTranscriptExtractor
```

---

## Example 1: Extract from URL List

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

# Create extractor
extractor = YouTubeTranscriptExtractor()

# Define URLs
urls = [
    "https://www.youtube.com/watch?v=UqZPu0G93Fw",
    "https://www.youtube.com/watch?v=FoAe_3jBEdk",
    "https://www.youtube.com/watch?v=ktSzxVEnTZ8"
]

# Extract transcripts
results = extractor.extract_from_urls(urls, output_dir="my_transcripts")

# Check results
print(f"Success: {len(results['success'])}")
print(f"Failed: {len(results['failed'])}")
```

---

## Example 2: Extract from File

Create a file `urls.txt`:
```
https://www.youtube.com/watch?v=VIDEO_ID_1
https://www.youtube.com/watch?v=VIDEO_ID_2
https://www.youtube.com/watch?v=VIDEO_ID_3
```

Then run:
```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()
results = extractor.extract_from_file("urls.txt", output_dir="transcripts")
```

---

## Example 3: Paste URLs Directly (Interactive)

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

# Get URLs from user paste
print("Paste YouTube URLs (one per line), then press Enter twice:")
urls = []
while True:
    line = input()
    if not line:
        break
    urls.append(line.strip())

# Extract
extractor = YouTubeTranscriptExtractor()
results = extractor.extract_from_urls(urls)

print(f"\n✅ Extracted {len(results['success'])} transcripts")
```

---

## Example 4: Convert SRT Files

If you have SRT files from 4K Video Downloader:

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

# Convert all SRT files in a directory
results = extractor.convert_srt_directory(
    input_dir="srt_files/",
    output_dir="clean_transcripts/"
)

print(f"Converted {len(results['success'])} files")
```

---

## Example 5: Create Knowledge Base

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

# Create knowledge base from transcripts
kb_results = extractor.create_knowledge_base(
    transcript_dir="transcripts/",
    output_file="my_knowledge_base.md"
)

print(f"Created KB with {kb_results['transcripts']} transcripts")
print(f"Categories: {kb_results['categories']}")
print(f"Output: {kb_results['output']}")
```

---

## Example 6: Complete Pipeline (All-in-One)

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

# Extract transcripts AND create knowledge base in one step
results = extractor.process_pipeline(
    url_file="urls.txt",
    output_dir="transcripts",
    create_kb=True,
    kb_output="knowledge_base.md"
)

# Access results
extraction = results['extraction']
kb = results['knowledge_base']

print(f"Extracted: {len(extraction['success'])} transcripts")
print(f"KB Categories: {kb['categories']}")
```

---

## Example 7: Silent Mode (No Console Output)

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

# Run without printing progress
results = extractor.extract_from_urls(
    urls=["https://youtube.com/watch?v=..."],
    verbose=False  # Silent mode
)

# Process results programmatically
for item in results['success']:
    print(f"Saved: {item['file']}")
```

---

## Example 8: Error Handling

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

results = extractor.extract_from_urls([
    "https://youtube.com/watch?v=VALID_ID",
    "https://youtube.com/watch?v=INVALID_ID",
    "not a url"
])

# Check what failed
for failed in results['failed']:
    print(f"Failed: {failed['url']}")
    print(f"Reason: {failed['error']}")

# Check what was skipped (invalid URLs)
for skipped in results['skipped']:
    print(f"Skipped: {skipped}")
```

---

## Example 9: Batch Processing with Progress Tracking

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

# Read large URL list
with open("large_url_list.txt") as f:
    urls = [line.strip() for line in f if line.strip()]

print(f"Processing {len(urls)} URLs...")

extractor = YouTubeTranscriptExtractor()
results = extractor.extract_from_urls(urls, verbose=True)

# Save report
with open("extraction_report.txt", "w") as f:
    f.write(f"Total: {results['total']}\n")
    f.write(f"Success: {len(results['success'])}\n")
    f.write(f"Failed: {len(results['failed'])}\n")
    f.write(f"Skipped: {len(results['skipped'])}\n\n")
    
    f.write("FAILED URLs:\n")
    for item in results['failed']:
        f.write(f"  {item['url']} - {item['error']}\n")
```

---

## Example 10: Integration with Other Code

```python
from youtube_transcript_module import YouTubeTranscriptExtractor
import json

def process_youtube_research(topic_urls):
    """
    Process YouTube videos for research topic.
    Returns structured data.
    """
    extractor = YouTubeTranscriptExtractor()
    
    # Extract transcripts
    results = extractor.extract_from_urls(topic_urls, verbose=False)
    
    # Create knowledge base
    if results['success']:
        kb = extractor.create_knowledge_base(
            "transcripts",
            f"{topic}_kb.md",
            verbose=False
        )
        
        return {
            'success': True,
            'transcripts_extracted': len(results['success']),
            'knowledge_base': kb['output'],
            'categories': kb['category_breakdown']
        }
    else:
        return {
            'success': False,
            'error': 'No transcripts extracted'
        }

# Use in your application
research_data = process_youtube_research([
    "https://youtube.com/watch?v=...",
    "https://youtube.com/watch?v=..."
])

print(json.dumps(research_data, indent=2))
```

---

## Return Value Structure

All methods return dictionaries with consistent structure:

### `extract_from_urls()` / `extract_from_file()`
```python
{
    'success': [
        {
            'url': 'https://...',
            'video_id': 'ABC123',
            'file': 'transcripts/ABC123.txt'
        },
        ...
    ],
    'failed': [
        {
            'url': 'https://...',
            'video_id': 'XYZ789',
            'error': 'Transcripts disabled'
        },
        ...
    ],
    'skipped': ['invalid_url_1', ...],
    'total': 10
}
```

### `create_knowledge_base()`
```python
{
    'transcripts': 25,
    'categories': 7,
    'output': 'knowledge_base.md',
    'category_breakdown': {
        'Procurement': 5,
        'ATS & Recruitment': 8,
        'HRIS & HR Systems': 4,
        ...
    }
}
```

### `process_pipeline()`
```python
{
    'extraction': { ... },  # Same as extract_from_urls
    'knowledge_base': { ... }  # Same as create_knowledge_base
}
```

---

## Command Line Usage

You can also run the module as a standalone script:

```bash
python youtube_transcript_module.py urls.txt
```

This will:
1. Extract all transcripts from URLs in `urls.txt`
2. Save to `transcripts/` directory
3. Create `knowledge_base.md` automatically

---

## Tips

1. **Large batches**: The module handles hundreds of URLs efficiently
2. **Network issues**: Failed extractions are reported, not crashed
3. **Duplicates**: Automatically removed
4. **Empty lines/comments**: Ignored in URL files (lines starting with #)
5. **Silent mode**: Use `verbose=False` for programmatic use
6. **File organization**: Each video gets its own file named by video ID

---

## Edge Cases Handled

✅ Invalid URLs - skipped with warning  
✅ Videos without transcripts - reported as failed  
✅ Disabled transcripts - reported as failed  
✅ Network errors - reported with error message  
✅ Duplicate URLs - processed only once  
✅ Empty files - handled gracefully  
✅ Non-English transcripts - attempts to get any available  
✅ Malformed SRT files - extracts what it can  

---

## Need Help?

The module is self-documenting. Check the docstrings:

```python
from youtube_transcript_module import YouTubeTranscriptExtractor

extractor = YouTubeTranscriptExtractor()

# Get help on any method
help(extractor.extract_from_urls)
help(extractor.create_knowledge_base)
```
