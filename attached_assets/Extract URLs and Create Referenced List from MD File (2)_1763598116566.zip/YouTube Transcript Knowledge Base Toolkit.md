# YouTube Transcript Knowledge Base Toolkit

**Complete system for extracting YouTube transcripts and building organized knowledge bases**

✅ No API keys required  
✅ Works in Replit  
✅ Completely anonymous (no login needed)  
✅ Batch process hundreds of videos  

---

## 🚀 Quick Start (Replit Setup)

### Step 1: Create New Repl

1. Go to [Replit](https://replit.com)
2. Click "Create Repl"
3. Choose "Python" template
4. Name it something like "YouTube-Transcript-Extractor"

### Step 2: Upload Files

Upload these 3 Python scripts to your Repl:
- `youtube_transcript_extractor.py`
- `srt_to_text_converter.py`
- `knowledge_base_organizer.py`

### Step 3: Install Required Library

In the Replit Shell, run:

```bash
pip install youtube-transcript-api
```

### Step 4: Upload Your URL List

Create a file called `youtube_urls.txt` in your Repl and paste your 203 YouTube URLs (one per line).

### Step 5: Run the Extractor

In the Replit Shell, run:

```bash
python youtube_transcript_extractor.py youtube_urls.txt
```

**That's it!** The script will:
- Extract all 203 transcripts automatically
- Save each as a clean text file in `transcripts/` folder
- Generate a detailed report

---

## 📚 Three Tools Included

### Tool 1: YouTube Transcript Extractor

**What it does:** Extracts transcripts directly from YouTube (no video download needed)

**Usage:**
```bash
python youtube_transcript_extractor.py <url_file>
```

**Example:**
```bash
python youtube_transcript_extractor.py youtube_urls.txt
```

**Output:**
- `transcripts/` folder with individual transcript files
- `transcripts/_extraction_report.txt` with detailed results

**Features:**
- ✅ Batch processing
- ✅ Progress tracking
- ✅ Error handling
- ✅ Detailed reporting
- ✅ Handles multiple URL formats

---

### Tool 2: SRT to Text Converter

**What it does:** Converts SRT subtitle files (from 4K Video Downloader) to clean text

**Usage:**

Convert single file:
```bash
python srt_to_text_converter.py subtitle.srt
```

Convert entire directory:
```bash
python srt_to_text_converter.py subtitles/
```

**Output:**
- `converted_transcripts/` folder with clean text files
- `converted_transcripts/_conversion_report.txt` with results

**Features:**
- ✅ Removes timestamps
- ✅ Removes formatting tags
- ✅ Cleans up artifacts
- ✅ Batch processing

---

### Tool 3: Knowledge Base Organizer

**What it does:** Consolidates all transcripts into organized, categorized knowledge base

**Usage:**
```bash
python knowledge_base_organizer.py transcripts/
```

**Output:**
- `knowledge_base.md` - Consolidated markdown document
- `knowledge_base_index.txt` - Quick reference index

**Features:**
- ✅ Auto-categorizes by topic (Procurement, ATS, HRIS, Staffing, etc.)
- ✅ Extracts key terms and frequencies
- ✅ Generates statistics
- ✅ Creates searchable index
- ✅ Ready for Perplexity or other AI analysis

**Categories:**
- Procurement
- ATS & Recruitment
- HRIS & HR Systems
- Contingent Workforce
- VMS & MSP
- Staffing & SOW
- General HR

---

## 🔄 Complete Workflow Examples

### Workflow A: Extract from YouTube (Recommended)

```bash
# 1. Extract all transcripts
python youtube_transcript_extractor.py youtube_urls.txt

# 2. Organize into knowledge base
python knowledge_base_organizer.py transcripts/

# 3. Done! Use knowledge_base.md for analysis
```

### Workflow B: Convert from 4K Video Downloader SRTs

```bash
# 1. Download SRTs using 4K Video Downloader
#    (Save all SRT files to a folder, e.g., "subtitles/")

# 2. Convert SRTs to clean text
python srt_to_text_converter.py subtitles/

# 3. Organize into knowledge base
python knowledge_base_organizer.py converted_transcripts/

# 4. Done! Use knowledge_base.md for analysis
```

### Workflow C: Hybrid Approach

```bash
# 1. Extract what you can from YouTube
python youtube_transcript_extractor.py youtube_urls.txt

# 2. For videos that failed, download SRTs with 4K Video Downloader

# 3. Convert those SRTs
python srt_to_text_converter.py subtitles/

# 4. Move converted files to transcripts folder
cp converted_transcripts/*.txt transcripts/

# 5. Organize everything together
python knowledge_base_organizer.py transcripts/
```

---

## 📊 What You Get

After running all tools, you'll have:

1. **Individual Transcripts** - Each video as a separate text file
2. **Extraction Report** - Success/failure details for each URL
3. **Consolidated Knowledge Base** - All content organized by topic
4. **Index File** - Quick reference to all transcripts
5. **Statistics** - Word counts, key terms, category breakdown

---

## 💡 Tips for Best Results

### For YouTube Extraction:

- **Most videos work:** If a video has captions/subtitles, it will work
- **No login needed:** Completely anonymous
- **Fast:** Processes 200+ videos in minutes (no video download)
- **Check the report:** See which videos failed and why

### For 4K Video Downloader:

- **Use as backup:** For videos where YouTube extraction fails
- **Download settings:** Choose smallest video size (QCIF) to save time/space
- **Enable subtitles:** Make sure SRT download is enabled
- **Batch processing:** Paste all URLs at once

### For Knowledge Base:

- **Customize categories:** Edit `knowledge_base_organizer.py` to add your own categories
- **Add more key terms:** Update the `term_list` to track specific terminology
- **Use with AI:** Upload `knowledge_base.md` to Perplexity, Claude, or ChatGPT for analysis

---

## 🔧 Troubleshooting

### "No transcript found"
- Video doesn't have captions/subtitles
- Try downloading with 4K Video Downloader instead

### "Transcripts disabled"
- Video owner disabled transcripts
- Try downloading with 4K Video Downloader instead

### "Module not found: youtube_transcript_api"
- Run: `pip install youtube-transcript-api`

### "File not found"
- Check that your URL file exists
- Make sure file path is correct

---

## 📝 File Formats

### Input: URL File Format
```
https://www.youtube.com/watch?v=VIDEO_ID_1
https://www.youtube.com/watch?v=VIDEO_ID_2
https://youtu.be/VIDEO_ID_3
```

### Output: Transcript File Format
```
Video ID: VIDEO_ID
URL: https://www.youtube.com/watch?v=VIDEO_ID

================================================================================

[Clean transcript text here...]
```

---

## 🎯 Use Cases

### For Your Project (Terminology Guide):

1. **Extract definitions:** Find how professionals explain terms
2. **Validate terminology:** Cross-check your glossary against real usage
3. **Find gaps:** Discover terms you haven't covered
4. **Add citations:** Reference specific videos for definitions
5. **Industry insights:** Learn how insiders actually talk about these topics

### General Use Cases:

- Research paper background material
- Course content development
- Industry trend analysis
- Competitive intelligence
- Training material creation

---

## 🚫 Limitations

- Only works for videos with publicly available transcripts/captions
- Auto-generated captions may have errors (same as YouTube's)
- Cannot extract from private or members-only videos
- Respects YouTube's terms of service (public data only)

---

## 📦 What's Included

```
youtube-transcript-toolkit/
├── youtube_transcript_extractor.py    # Main extractor
├── srt_to_text_converter.py          # SRT converter
├── knowledge_base_organizer.py       # KB organizer
├── README.md                          # This file
└── youtube_urls.txt                   # Your URL list (you create this)
```

---

## ⚡ Performance

**For 203 YouTube URLs:**
- Extraction time: ~5-10 minutes
- No video downloads needed
- Minimal storage (text files only)
- Works on free Replit tier

**For 203 SRT files:**
- Conversion time: ~1-2 minutes
- Removes all formatting
- Clean, readable output

---

## 🎓 Next Steps

After creating your knowledge base:

1. **Upload to Perplexity:** Ask it to extract key insights
2. **Use with Claude/ChatGPT:** Analyze terminology usage
3. **Search for patterns:** Find common definitions
4. **Build your glossary:** Extract verified definitions
5. **Add citations:** Link terms to specific videos

---

## 🤝 Support

If you encounter issues:

1. Check the extraction/conversion reports
2. Verify your URL file format
3. Make sure library is installed
4. Try with a small test batch first

---

## 📄 License

Free to use for personal and commercial projects.

---

**Happy transcript extracting! 🎉**
