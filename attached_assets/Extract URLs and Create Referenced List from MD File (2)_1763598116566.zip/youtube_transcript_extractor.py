#!/usr/bin/env python3
"""
YouTube Transcript Extractor
No API keys required - extracts publicly available transcripts
"""

import os
import re
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import TranscriptsDisabled, NoTranscriptFound

def extract_video_id(url):
    """Extract video ID from various YouTube URL formats"""
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)',
        r'youtube\.com\/watch\?.*v=([^&\n?#]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None

def clean_filename(title):
    """Create safe filename from video title"""
    # Remove invalid filename characters
    title = re.sub(r'[<>:"/\\|?*]', '', title)
    # Limit length
    return title[:100]

def get_transcript(video_id):
    """Fetch transcript for a video ID"""
    try:
        # Try to get transcript (prefers English, but will take any available)
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        
        # Try English first
        try:
            transcript = transcript_list.find_transcript(['en'])
        except:
            # Get any available transcript
            transcript = transcript_list.find_generated_transcript(['en'])
        
        # Fetch the actual transcript
        transcript_data = transcript.fetch()
        
        # Combine all text segments
        full_text = ' '.join([entry['text'] for entry in transcript_data])
        
        return full_text, True
        
    except TranscriptsDisabled:
        return "Error: Transcripts are disabled for this video", False
    except NoTranscriptFound:
        return "Error: No transcript found for this video", False
    except Exception as e:
        return f"Error: {str(e)}", False

def process_url_file(input_file, output_dir='transcripts'):
    """Process a file containing YouTube URLs (one per line)"""
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Read URLs
    with open(input_file, 'r', encoding='utf-8') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    print(f"Found {len(urls)} URLs to process")
    print("-" * 80)
    
    results = {
        'success': [],
        'failed': [],
        'skipped': []
    }
    
    for idx, url in enumerate(urls, 1):
        print(f"\n[{idx}/{len(urls)}] Processing: {url}")
        
        # Extract video ID
        video_id = extract_video_id(url)
        if not video_id:
            print(f"  ❌ Could not extract video ID")
            results['skipped'].append(url)
            continue
        
        print(f"  Video ID: {video_id}")
        
        # Get transcript
        transcript_text, success = get_transcript(video_id)
        
        if success:
            # Save to file
            output_file = os.path.join(output_dir, f"{video_id}.txt")
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(f"Video ID: {video_id}\n")
                f.write(f"URL: {url}\n")
                f.write(f"\n{'='*80}\n\n")
                f.write(transcript_text)
            
            print(f"  ✅ Transcript saved to: {output_file}")
            results['success'].append(url)
        else:
            print(f"  ❌ {transcript_text}")
            results['failed'].append((url, transcript_text))
    
    # Print summary
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    print(f"✅ Successfully extracted: {len(results['success'])}")
    print(f"❌ Failed: {len(results['failed'])}")
    print(f"⚠️  Skipped (invalid URL): {len(results['skipped'])}")
    
    # Save summary report
    report_file = os.path.join(output_dir, '_extraction_report.txt')
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("YOUTUBE TRANSCRIPT EXTRACTION REPORT\n")
        f.write("="*80 + "\n\n")
        f.write(f"Total URLs processed: {len(urls)}\n")
        f.write(f"Successful: {len(results['success'])}\n")
        f.write(f"Failed: {len(results['failed'])}\n")
        f.write(f"Skipped: {len(results['skipped'])}\n\n")
        
        if results['failed']:
            f.write("\nFAILED EXTRACTIONS:\n")
            f.write("-"*80 + "\n")
            for url, error in results['failed']:
                f.write(f"{url}\n  Reason: {error}\n\n")
        
        if results['skipped']:
            f.write("\nSKIPPED URLs:\n")
            f.write("-"*80 + "\n")
            for url in results['skipped']:
                f.write(f"{url}\n")
    
    print(f"\n📊 Full report saved to: {report_file}")
    
    return results

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python youtube_transcript_extractor.py <url_file>")
        print("\nExample: python youtube_transcript_extractor.py youtube_urls.txt")
        sys.exit(1)
    
    input_file = sys.argv[1]
    
    if not os.path.exists(input_file):
        print(f"Error: File '{input_file}' not found")
        sys.exit(1)
    
    process_url_file(input_file)
