# Organizational Structure Research Findings

## 1. PROCUREMENT ORGANIZATIONAL STRUCTURES

### Types of Procurement Structures

#### A. Centralized Procurement
**Structure:** All procurement activities handled by central department led by Chief Procurement Officer (CPO)

**Key Roles:**
- Chief Procurement Officer (CPO) - Overall leadership
- Procurement Director - Strategic oversight
- Category Managers - Manage specific spend categories
- Procurement Specialists - Execute sourcing and contracting
- Supplier Relationship Managers - Manage vendor relationships

**Responsibilities:**
- Sourcing and supplier selection
- Contract negotiation
- Supplier management
- Policy development and enforcement
- Spend analytics and reporting

**Advantages:**
- Cost savings through consolidated purchasing power
- Improved standardization across organization
- Better compliance and risk management
- Economies of scale
- Centralized data and analytics

**Disadvantages:**
- Limited responsiveness to individual department needs
- Potential bottlenecks in approval processes
- Lack of ownership by business units
- May not understand specific departmental requirements

**Best For:** Large enterprises with significant spend, need for standardization, and focus on cost savings

---

#### B. Decentralized Procurement
**Structure:** Each department/business unit has own procurement team managing purchases within designated budget

**Key Roles:**
- Department Procurement Leads - Report to business unit leaders
- Local Buyers - Handle day-to-day purchasing
- Department Budget Managers - Control spending

**Responsibilities:**
- Department-specific purchasing decisions
- Local supplier relationships
- Quick response to operational needs
- Budget management at unit level

**Advantages:**
- High responsiveness to department needs
- Strong ownership and accountability
- Better understanding of specific requirements
- Faster decision-making

**Disadvantages:**
- Lost savings opportunities (no volume leverage)
- Risk of maverick/rogue spending
- Inconsistent practices across organization
- Duplicate efforts and inefficiency
- Compliance challenges

**Best For:** Smaller organizations, highly specialized departments, or businesses requiring rapid response

---

#### C. Hybrid Procurement (Center-Led)
**Structure:** Combines centralized and decentralized elements - central team sets policies and handles high-value categories while providing guidance to decentralized teams

**Key Roles:**
- Chief Procurement Officer (CPO) - Overall strategy
- Central Category Managers - High-value/strategic categories
- Procurement Centers of Excellence - Best practices, tools, training
- Business Unit Procurement Leads - Tactical execution
- Compliance Officers - Policy enforcement

**Responsibilities:**
- **Central Team:** Policy setting, strategic sourcing, high-value contracts, supplier negotiations, analytics
- **Decentralized Teams:** Tactical purchasing, local supplier management, operational support

**Advantages:**
- Balance between control and flexibility
- Standardization with agility
- Cost savings on strategic categories
- Responsive to local needs
- Scalable structure

**Disadvantages:**
- Complex structure requiring clear governance
- Communication challenges between central and local teams
- Potential role confusion
- Requires strong change management

**Best For:** Large enterprises with diverse business units requiring both standardization and flexibility

---

### Procurement Hierarchy (Typical Enterprise Structure)

**C-Suite Level:**
- Chief Procurement Officer (CPO) / VP of Procurement

**Director Level:**
- Director of Strategic Sourcing
- Director of Procurement Operations
- Director of Supplier Management
- Director of Procurement Technology

**Manager Level:**
- Category Managers (by spend category)
- Procurement Operations Managers
- Supplier Relationship Managers
- Contract Managers
- Procurement Analytics Manager

**Specialist/Coordinator Level:**
- Procurement Specialists
- Sourcing Analysts
- Contract Administrators
- Procurement Coordinators
- Supplier Quality Specialists

**Support Level:**
- Procurement Assistants
- Data Entry Specialists

---

### Key Procurement Workflows

**1. Purchase Requisition to Purchase Order (PR to PO)**
- Employee submits purchase requisition
- Manager approves requisition
- Procurement reviews and sources supplier
- Procurement negotiates terms
- Purchase order issued to supplier
- Goods/services received
- Invoice processed and payment made

**2. Strategic Sourcing Process**
- Identify need and define requirements
- Market research and supplier identification
- RFI/RFP/RFQ issuance
- Proposal evaluation
- Supplier selection
- Contract negotiation
- Contract execution
- Supplier onboarding

**3. Supplier Management Cycle**
- Supplier qualification and onboarding
- Performance monitoring (scorecards)
- Relationship management
- Risk assessment
- Continuous improvement initiatives
- Contract renewal or termination

---

## Resources Found:
- GEP Blog: Procurement Organizational Structure (https://www.gep.com/blog/strategy/procurement-organizational-structure-benefits-types)
- Procurement Tactics: Organization Structure Guide
- ProcureDesk: Building Procurement Team
- Precoro: Procurement Organization Structure



## 2. TALENT ACQUISITION (TA) ORGANIZATIONAL STRUCTURES

### The Three Pillars of World-Class TA Organizations

According to industry expert Johnny Campbell (CEO/Co-Founder of SocialTalent.com), successful TA functions are built on three critical components that work together as an integrated system.

---

#### A. Candidate-Facing Teams (The Frontline)

**Purpose:** Dedicated to understanding the candidate market, building relationships, optimizing candidate experience, and maintaining robust talent pipelines.

**Key Roles:**

**1. Sourcers/Strategic Sourcing Specialists**
- Proactively build and maintain talent pipelines for future demand
- Research and identify passive candidates
- Use Boolean search, LinkedIn Recruiter, and sourcing tools
- Build talent communities for hard-to-fill roles

**2. Recruitment Coordinators**
- Manage interview scheduling and logistics
- Coordinate candidate communications
- Leverage AI and automation for scheduling
- Ensure excellent candidate experience throughout process
- Handle offer letter preparation and background checks

**3. Employer Branding Specialists**
- Develop and maintain employer value proposition (EVP)
- Create recruitment marketing content
- Manage careers site and social media presence
- Coordinate campus recruiting and events
- Build talent community engagement

**4. Recruitment Marketing Managers**
- Develop candidate attraction strategies
- Manage job advertising and programmatic job ads
- Analyze source effectiveness
- Optimize career site conversion rates

**Responsibilities:**
- Building and maintaining candidate pipelines
- Optimizing candidate experience at every touchpoint
- Leveraging technology for efficiency while maintaining human touch
- Proactive market research and talent mapping
- Managing candidate communications and logistics

**Technology Focus:** Heavy use of ATS, CRM, sourcing tools, scheduling automation, and candidate engagement platforms

---

#### B. Business-Facing Teams (Strategic Liaisons)

**Purpose:** Internal consultants who ensure recruitment strategies align with business objectives, acting as the bridge between talent acquisition and business needs.

**Key Roles:**

**1. Talent Advisors/Talent Business Partners**
- Embedded within business units
- Strategic liaisons to hiring managers
- Understand business strategy and translate to hiring needs
- Craft tailored recruitment solutions by business unit
- Advise on workforce planning and talent strategy

**2. Recruiters (Full-Cycle)**
- Manage end-to-end recruitment process
- Partner with hiring managers on job requirements
- Screen and interview candidates
- Manage offer negotiations
- Provide market intelligence and hiring insights

**3. Hiring Managers (Not in TA, but key partners)**
- Define role requirements and ideal candidate profiles
- Participate in interviews and selection decisions
- Make final hiring decisions
- Onboard new hires

**Responsibilities:**
- Deep understanding of business unit needs and culture
- Consulting on best practices for hiring
- Workforce planning and headcount forecasting
- Internal mobility and talent development (in mature orgs)
- Upskilling and reskilling initiatives
- Building strong hiring manager relationships

**Maturity Indicator:** In mature organizations, talent advisors expand beyond just hiring to include internal mobility, upskilling, and broader workforce planning.

---

#### C. Centralized/Shared Functions (The Backbone)

**Purpose:** Provide support, tools, processes, and infrastructure that enable both candidate-facing and business-facing teams to excel.

**Key Roles:**

**1. TA Operations Team**
- Manage recruitment technology stack (ATS, CRM, etc.)
- Standardize and optimize recruitment processes
- Produce analytics, reporting, and dashboards
- Ensure compliance and audit readiness
- Manage vendor relationships (job boards, agencies, tools)

**Staffing Ratio:** Approximately 1 in 10 TA team members should be in TA Operations (per Allyn Bailey)

**2. Employer Branding (Centralized)**
- Maintain consistent global employer brand
- Adapt messaging for local markets while maintaining cohesion
- Develop EVP and employer brand guidelines
- Coordinate global recruitment marketing campaigns

**3. Early-in-Career Recruiting Team**
- Campus recruiting and university relations
- Intern and graduate programs
- Seasonal hiring cycles (different from core recruiting)
- Entry-level talent pipeline development
- Requires different marketing and assessment approaches

**4. Executive Recruiting Team**
- C-minus-X level hiring (C-suite and direct reports)
- Strategic, high-touch recruiting approach
- Long-game hiring (resembles courting professional athletes)
- Smaller requisition loads but higher complexity
- Often better in-house than outsourced due to cultural fit importance

**5. Recruitment Analytics & Insights**
- Track and report on key recruiting metrics
- Provide data-driven insights for decision-making
- Benchmark against industry standards
- Identify process bottlenecks and improvement opportunities

**Responsibilities:**
- Technology management and optimization
- Process standardization and continuous improvement
- Data analytics and reporting
- Compliance and risk management
- Vendor and agency management
- Employer brand consistency
- Specialized hiring programs (campus, executive)

---

### TA Team Hierarchy (Typical Enterprise Structure)

**Executive Level:**
- Chief Talent Officer / VP of Talent Acquisition
- Head of Talent Acquisition

**Director Level:**
- Director of Talent Acquisition
- Director of Employer Branding
- Director of TA Operations
- Director of Executive Search

**Manager Level:**
- Talent Acquisition Managers (by business unit or region)
- Recruiting Managers
- Sourcing Manager
- Employer Branding Manager
- TA Operations Manager

**Specialist/Individual Contributor Level:**
- Talent Advisors/Business Partners
- Recruiters (Full-Cycle)
- Sourcers/Sourcing Specialists
- Recruitment Coordinators
- Employer Branding Specialists
- Recruitment Marketing Specialists
- TA Analysts

**Support Level:**
- Recruiting Assistants
- Scheduling Coordinators

---

### TA Team Sizing Guidelines

**Minimum Viable Structure:**
- **1 Recruiter:** Handles everything (not ideal but reality for small companies)
- **2 Recruiters:** Can begin specialization - one candidate-facing, one more business-facing
- **5-10 Recruiters:** Add dedicated sourcing and coordination support
- **10+ Recruiters:** Implement full three-pillar model with centralized functions

**Recruiter-to-Hire Ratio:** Varies by industry and role complexity
- **High-volume/low-complexity:** 1 recruiter per 50-100 hires/year
- **Professional roles:** 1 recruiter per 30-50 hires/year
- **Technical/specialized:** 1 recruiter per 20-30 hires/year
- **Executive/leadership:** 1 recruiter per 10-15 hires/year

---

### Key TA Workflows

**1. Strategic Workforce Planning**
- Business reviews headcount needs
- TA advises on market conditions and feasibility
- Hiring plan developed and approved
- Pipeline building begins proactively

**2. Requisition to Hire**
- Hiring manager submits requisition
- Talent advisor/recruiter intake meeting
- Job description finalized
- Sourcing strategy developed
- Candidates sourced and screened
- Interviews coordinated
- Offer extended and negotiated
- Background check and onboarding

**3. Talent Pipeline Management**
- Proactive sourcing for future needs
- Talent community engagement
- Passive candidate relationship building
- Pipeline health monitoring and reporting

---

### Integration is Key

The three pillars (candidate-facing, business-facing, centralized) are **not silos** — they must work as interconnected parts of a cohesive whole. When integrated properly:
- Candidate-facing teams provide excellent experience and strong pipelines
- Business-facing teams ensure strategic alignment and hiring manager satisfaction
- Centralized functions enable efficiency, consistency, and scalability

This integration transforms TA from a transactional recruitment function into a **strategic asset** that drives organizational growth.

---

## Resources Found:
- LinkedIn Talent Blog: Structuring Your TA Team (Johnny Campbell)
- AIHR: 7 Steps to Building Talent Acquisition Team
- RecruitCRM: Recruitment Team Structure
- TechnologyAdvice: Recruitment Team Roles & Job Descriptions

