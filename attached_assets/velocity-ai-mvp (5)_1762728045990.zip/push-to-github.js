#!/usr/bin/env node

const fs = require("fs");
const path = require("path");

const GITHUB_TOKEN = "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";
const REPO_OWNER = "loscodosmuchos";
const REPO_NAME = "refine";
const BRANCH = "master";

const files = [
  {
    path: "playwright.config.ts",
    content: fs.readFileSync("./playwright.config.ts", "utf-8"),
  },
  {
    path: "tests/routes-audit.spec.ts",
    content: fs.readFileSync("./tests/routes-audit.spec.ts", "utf-8"),
  },
  {
    path: "tests/routes-config.json",
    content: fs.readFileSync("./tests/routes-config.json", "utf-8"),
  },
  {
    path: ".github/workflows/audit.yml",
    content: fs.readFileSync("./.github/workflows/audit.yml", "utf-8"),
  },
  {
    path: "README-PLAYWRIGHT.md",
    content: fs.readFileSync("./README-PLAYWRIGHT.md", "utf-8"),
  },
];

async function pushToGitHub() {
  console.log("🚀 Starting GitHub push...");

  for (const file of files) {
    try {
      const fileContent = Buffer.from(file.content).toString("base64");

      const response = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${file.path}`, {
        method: "PUT",
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: `Add Playwright route audit automation - ${file.path}`,
          content: fileContent,
          branch: BRANCH,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        console.error(`❌ Failed to push ${file.path}:`, error.message);
        throw new Error(`GitHub API error: ${error.message}`);
      }

      console.log(`✅ Pushed: ${file.path}`);
    } catch (error) {
      console.error(`Error pushing ${file.path}:`, error.message);
      process.exit(1);
    }
  }

  console.log("🎉 All files pushed successfully!");
  console.log(`📍 View at: https://github.com/${REPO_OWNER}/${REPO_NAME}/tree/${BRANCH}`);
}

pushToGitHub();
