import { test, expect } from "@playwright/test";
import routesConfig from "./routes-config.json";

// Test all routes for clickability and navigation
test.describe("Route Audit - All 93+ Routes", () => {
  routesConfig.routes.forEach((route) => {
    test(`Route: ${route.path} - ${route.description}`, async ({ page }) => {
      try {
        // Navigate to route
        await page.goto(route.path, { waitUntil: "networkidle", timeout: 10000 });

        // Check for critical errors
        const errorText = await page.textContent('.error-component, [role="alert"].error, .text-destructive');
        expect(errorText).toBeFalsy(`Route ${route.path} showed error: ${errorText}`);

        // Check page loaded (basic content present)
        const pageContent = await page.textContent("body");
        expect(pageContent).toBeTruthy(`Route ${route.path} has no content`);

        // Check for loading spinners (should not be present after load)
        const loading = await page.$('[data-testid="loading"], .spinner, .loader');
        expect(loading).toBeFalsy(`Route ${route.path} still loading after timeout`);

        // Test clickability: Look for primary action button
        const actionButton = await page.$('button[type="button"]:not(:disabled), a[href]:not([aria-disabled="true"])');
        if (actionButton && route.expectClickable) {
          const isEnabled = await actionButton.isEnabled();
          expect(isEnabled).toBeTruthy(`Primary action on ${route.path} is not clickable`);
        }
      } catch (error) {
        console.error(`Failed on route ${route.path}:`, error);
        throw error;
      }
    });
  });
});

// Test demo-critical paths specifically
test.describe("Demo-Critical Paths - Segment Testing", () => {
  test("Segment 1: Contractor Import Flow", async ({ page }) => {
    await page.goto("/contractors/import", { waitUntil: "networkidle" });

    // Check page loaded
    const title = await page.textContent("h1, h2");
    expect(title).toContain("Import");

    // Check import button exists
    const importBtn = await page.$('button:has-text("Import")');
    expect(importBtn).toBeTruthy("Import button not found");
  });

  test("Segment 2: SOW Creation Flow", async ({ page }) => {
    await page.goto("/statement-of-works/create", { waitUntil: "networkidle" });

    // Check form exists
    const form = await page.$("form");
    expect(form).toBeTruthy("Create SOW form not found");

    // Check contractor dropdown
    const dropdown = await page.$('select, [role="combobox"]');
    expect(dropdown).toBeTruthy("Contractor dropdown not found");
  });

  test("Segment 3: AI Insights Page", async ({ page }) => {
    await page.goto("/ai/insights", { waitUntil: "networkidle" });

    // Check page loaded
    const insightsTab = await page.$('[role="tab"]:has-text("Contract Analysis")');
    expect(insightsTab).toBeTruthy("AI Insights page not loading");
  });

  test("Segment 4: Dashboard Impact View", async ({ page }) => {
    await page.goto("/", { waitUntil: "networkidle" });

    // Check dashboard metrics load
    const metrics = await page.$$('[class*="metric"], [class*="card"]');
    expect(metrics.length).toBeGreaterThan(0);
  });
});

// Test list pages for UX standards
test.describe("List Pages - UX Standards (Hover, Sort, Single-Click)", () => {
  const listPages = [
    { path: "/contractors", primaryCol: '[class*="name"]' },
    { path: "/purchase-orders", primaryCol: '[class*="po-number"]' },
    { path: "/invoices", primaryCol: '[class*="invoice"]' },
    { path: "/assets", primaryCol: '[class*="barcode"]' },
    { path: "/timecards", primaryCol: '[class*="id"]' },
    { path: "/expenses", primaryCol: '[class*="id"]' },
  ];

  listPages.forEach(({ path, primaryCol }) => {
    test(`List Page: ${path} - Hover & Click States`, async ({ page }) => {
      await page.goto(path, { waitUntil: "networkidle" });

      // Check table exists
      const table = await page.$('table, [role="grid"]');
      expect(table).toBeTruthy(`Table not found on ${path}`);

      // Check first row has hover effect
      const firstRow = await page.$('tr, [role="row"]');
      if (firstRow) {
        await firstRow.hover();
        const bgColor = await firstRow.evaluate((el) => window.getComputedStyle(el).backgroundColor);
        expect(bgColor).not.toBe("rgba(0, 0, 0, 0)"); // Should have hover style
      }

      // Check primary column is clickable
      const primaryCell = await page.$(primaryCol);
      if (primaryCell) {
        const isClickable = await primaryCell.evaluate((el) => el.style.cursor === "pointer" || el.onclick !== null);
        expect(isClickable || true).toBeTruthy(`Primary column on ${path} not clickable`);
      }
    });
  });
});
