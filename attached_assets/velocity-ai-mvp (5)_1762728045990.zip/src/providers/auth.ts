import { AuthBindings } from "@refinedev/core";
import axios from "axios";

export interface IUser {
  id: number;
  avatarUrl: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  email: string;
}

export const createAuthProvider = (apiUrl: string): AuthBindings => ({
  login: async ({ email }) => {
    try {
      const response = await axios.post(`${apiUrl}/login`, { email });

      const { accessToken, user } = response.data;

      localStorage.setItem("accessToken", accessToken);
      localStorage.setItem("user", JSON.stringify(user));

      return {
        success: true,
        redirectTo: "/",
      };
    } catch (error) {
      return {
        success: false,
        error: new Error("Invalid credentials"),
      };
    }
  },

  logout: async () => {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("user");

    return {
      success: true,
      redirectTo: "/login",
    };
  },

  onError: async (error) => {
    if (error.status === 401) {
      return {
        logout: true,
        redirectTo: "/login",
        error: new Error("Unauthorized"),
      };
    }

    return { error };
  },

  check: async () => {
    const token = localStorage.getItem("accessToken");

    if (!token) {
      return {
        authenticated: false,
        redirectTo: "/login",
      };
    }

    return {
      authenticated: true,
    };
  },

  getIdentity: async () => {
    const user = localStorage.getItem("user");

    if (!user) {
      return null;
    }

    return JSON.parse(user) as IUser;
  },
});
