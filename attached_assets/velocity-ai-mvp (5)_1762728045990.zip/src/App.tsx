import { Refine } from "@refinedev/core";
import { BrowserRouter, Routes, Route, Outlet } from "react-router";
import routerProvider from "@refinedev/react-router";
import {
  Home,
  Users,
  FileText,
  Clock,
  Receipt,
  DollarSign,
  Package,
  AlertCircle,
  Shield,
  Settings,
  BarChart3,
  Briefcase,
  User,
  UserPlus,
  Brain,
  Bot,
  Search,
  Filter,
  TrendingUp,
} from "lucide-react";

import { createDataProvider } from "./providers/data";
import { useNotificationProvider } from "./components/refine-ui/notification/use-notification-provider";
import { Toaster } from "./components/refine-ui/notification/toaster";
import { ThemeProvider } from "./components/refine-ui/theme/theme-provider";
import { Layout } from "./components/refine-ui/layout/layout";
import { ErrorComponent } from "./components/refine-ui/layout/error-component";

// Dashboard
import { DashboardPage } from "./pages/dashboard";

// Contractors
import { ContractorsListPage } from "./pages/contractors/list";
import { ContractorsShowPage } from "./pages/contractors/show";
import { CreateContractorPage } from "./pages/contractors/create";
import { EditContractorPage } from "./pages/contractors/edit";
import { ImportContractorsPage } from "./pages/contractors/import";

// Employees
import { EmployeesListPage } from "./pages/employees/list";
import { EmployeesShowPage } from "./pages/employees/show";
import { CreateEmployeePage } from "./pages/employees/create";

// Purchase Orders
import { PurchaseOrdersListPage } from "./pages/purchaseorders/list";
import { PurchaseOrderShowPage } from "./pages/purchaseorders/show";
import { CreatePurchaseOrderPage } from "./pages/purchaseorders/create";
import { EditPurchaseOrderPage } from "./pages/purchaseorders/edit";
import { ManagePOContractorsPage } from "./pages/purchaseorders/manage-contractors";
import { POTemplatesPage } from "./pages/purchaseorders/templates";

// Timecards
import { TimecardsListPage } from "./pages/timecards/list";
import { TimecardShowPage } from "./pages/timecards/show";
import { CreateTimecardPage } from "./pages/timecards/create";
import { PendingTimecardsPage } from "./pages/timecards/pending";
import { BulkApproveTimecardsPage } from "./pages/timecards/bulk-approve";

// Invoices
import { InvoicesListPage } from "./pages/invoices/list";
import { InvoiceShowPage } from "./pages/invoices/show";
import { CreateInvoicePage } from "./pages/invoices/create";
import { EditInvoicePage } from "./pages/invoices/edit";
import { GenerateInvoicePage } from "./pages/invoices/generate";

// Statements of Work
import { StatementOfWorksListPage } from "./pages/statementofworks/list";
import { StatementOfWorkShowPage } from "./pages/statementofworks/show";
import { CreateStatementOfWorkPage } from "./pages/statementofworks/create";
import { EditStatementOfWorkPage } from "./pages/statementofworks/edit";
import { SOWComplianceReportPage } from "./pages/statementofworks/compliance-report";

// Change Orders
import { ChangeOrdersListPage } from "./pages/changeorders/list";
import { ChangeOrderShowPage } from "./pages/changeorders/show";
import { CreateChangeOrderPage } from "./pages/changeorders/create";

// Expenses
import { ExpensesListPage } from "./pages/expenses/list";
import { ExpenseShowPage } from "./pages/expenses/show";
import { CreateExpensePage } from "./pages/expenses/create";
import { BulkApproveExpensesPage } from "./pages/expenses/bulk-approve";
import { ExpenseReportsPage } from "./pages/expenses/reports";

// Assets - using default imports
import AssetsListPage from "./pages/assets/list";
import AssetShowPage from "./pages/assets/show";
import AssetCreatePage from "./pages/assets/create";
import AssetScanPage from "./pages/assets/scan";
import AssetKitsPage from "./pages/assets/kits";
import AssetTransferPage from "./pages/assets/transfer";
import AssetMaintenancePage from "./pages/assets/maintenance";

// AI
import { AIInsightsPage } from "./pages/ai/insights";
import ChatbotsPage from "./pages/ai/chatbots";
import { ChatbotsDisplayPage } from "./pages/ai/chatbots-display";

// Admin
import { AdminHub } from "./pages/hubs/admin-hub";
import { AdminDashboardPage } from "./pages/admin/dashboard";
import { UserManagementPage } from "./pages/admin/user-management";
import { AuditLogsListPage } from "./pages/admin/audit-logs";
import { SystemExceptionsListPage } from "./pages/admin/exceptions";
import { DataQualityDashboardPage } from "./pages/admin/data-quality";
import { ChatbotsCustomizePage } from "./pages/admin/chatbots-customize";
import VoicePanelPage from "./pages/admin/voice-panel";
import XLSXImportPage from "./pages/admin/xlsx-import";

// Approvals
import { ApprovalRequestsPage } from "./pages/approvals/requests";
import { ApprovalRulesPage } from "./pages/approvals/rules";
import { ApprovalConfigurationPage } from "./pages/approvals/configure";
import { EmailLogsPage } from "./pages/approvals/email-logs";

// Contractor Portal
import { ContractorPortalDashboard } from "./pages/contractor-portal/dashboard";
import { ContractorProfilePage } from "./pages/contractor-portal/profile";
import { ContractorTimecardsPage } from "./pages/contractor-portal/timecards";
import { ContractorTimecardCreatePage } from "./pages/contractor-portal/timecard-create";
import { ContractorInvoicesPage } from "./pages/contractor-portal/invoices";
import { ContractorExpensesPage } from "./pages/contractor-portal/expenses";
import { ContractorExpenseCreatePage } from "./pages/contractor-portal/expense-create";
import { ContractorDocumentsPage } from "./pages/contractor-portal/documents";
import { UploadContractorDocumentPage } from "./pages/contractor-portal/documents-upload";
import { ContractorMessagesPage } from "./pages/contractor-portal/messages";

// Hubs
import { AnalyticsHub } from "./pages/hubs/analytics-hub";
import { PC2PurchaseOrdersHub } from "./pages/hubs/pc2-purchase-orders";
import { PC3WorkforceHub } from "./pages/hubs/pc3-workforce-home";

// Search & Filters
import { GlobalSearchPage } from "./pages/search/global";
import { FilterPresetsPage } from "./pages/filters/presets";

// Budget
import { BudgetForecastingPage } from "./pages/budget/forecasting";

// Notifications
import { NotificationCenterPage } from "./pages/notifications/center";

const dataProvider = createDataProvider();

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider defaultTheme="light" storageKey="velocity-theme">
        <Refine
          routerProvider={routerProvider}
          dataProvider={dataProvider}
          notificationProvider={useNotificationProvider}
          resources={[
            {
              name: "dashboard",
              list: "/",
              meta: { label: "Dashboard", icon: <Home /> },
            },
            {
              name: "contractors",
              list: "/contractors",
              create: "/contractors/create",
              edit: "/contractors/edit/:id",
              show: "/contractors/show/:id",
              meta: { label: "Contractors", icon: <Users /> },
            },
            {
              name: "employees",
              list: "/employees",
              create: "/employees/create",
              show: "/employees/show/:id",
              meta: { label: "Employees", icon: <User /> },
            },
            {
              name: "purchaseorders",
              list: "/purchase-orders",
              create: "/purchase-orders/create",
              edit: "/purchase-orders/edit/:id",
              show: "/purchase-orders/show/:id",
              meta: { label: "Purchase Orders", icon: <FileText /> },
            },
            {
              name: "timecards",
              list: "/timecards",
              create: "/timecards/create",
              show: "/timecards/show/:id",
              meta: { label: "Timecards", icon: <Clock /> },
            },
            {
              name: "invoices",
              list: "/invoices",
              create: "/invoices/create",
              edit: "/invoices/edit/:id",
              show: "/invoices/show/:id",
              meta: { label: "Invoices", icon: <Receipt /> },
            },
            {
              name: "statementofworks",
              list: "/statement-of-works",
              create: "/statement-of-works/create",
              edit: "/statement-of-works/edit/:id",
              show: "/statement-of-works/show/:id",
              meta: { label: "Statements of Work", icon: <Briefcase /> },
            },
            {
              name: "changeorders",
              list: "/change-orders",
              create: "/change-orders/create",
              show: "/change-orders/show/:id",
              meta: { label: "Change Orders", icon: <AlertCircle /> },
            },
            {
              name: "expenses",
              list: "/expenses",
              create: "/expenses/create",
              show: "/expenses/show/:id",
              meta: { label: "Expenses", icon: <DollarSign /> },
            },
            {
              name: "assets",
              list: "/assets",
              create: "/assets/create",
              show: "/assets/show/:id",
              meta: { label: "Assets", icon: <Package /> },
            },
            {
              name: "ai",
              meta: { label: "AI Intelligence", icon: <Brain />, group: true },
            },
            {
              name: "ai/insights",
              list: "/ai/insights",
              meta: { label: "AI Insights", parent: "ai", icon: <Brain /> },
            },
            {
              name: "ai/chatbots",
              list: "/ai/chatbots",
              meta: { label: "Chatbots", parent: "ai", icon: <Bot /> },
            },
            {
              name: "admin",
              meta: { label: "Administration", icon: <Settings />, group: true },
            },
            {
              name: "admin/dashboard",
              list: "/admin/dashboard",
              meta: { label: "Admin Dashboard", parent: "admin", icon: <BarChart3 /> },
            },
            {
              name: "admin/users",
              list: "/admin/users",
              meta: { label: "User Management", parent: "admin", icon: <UserPlus /> },
            },
            {
              name: "approvals",
              list: "/approvals",
              meta: { label: "Approvals", icon: <Shield /> },
            },
            {
              name: "hubs",
              meta: { label: "Hubs", icon: <BarChart3 />, group: true },
            },
            {
              name: "hubs/analytics",
              list: "/analytics-hub",
              meta: { label: "Analytics Hub", parent: "hubs", icon: <TrendingUp /> },
            },
            {
              name: "hubs/pc2",
              list: "/pc2-purchase-orders",
              meta: { label: "PC2 Procurement", parent: "hubs", icon: <FileText /> },
            },
            {
              name: "hubs/pc3",
              list: "/pc3-workforce-home",
              meta: { label: "PC3 Workforce", parent: "hubs", icon: <Users /> },
            },
          ]}
          options={{
            syncWithLocation: true,
            warnWhenUnsavedChanges: true,
            title: {
              icon: <BarChart3 className="h-6 w-6" />,
              text: "Velocity",
            },
          }}>
          <Routes>
            <Route
              element={
                <Layout>
                  <Outlet />
                </Layout>
              }>
              {/* Dashboard */}
              <Route index element={<DashboardPage />} />

              {/* Contractors */}
              <Route path="/contractors">
                <Route index element={<ContractorsListPage />} />
                <Route path="create" element={<CreateContractorPage />} />
                <Route path="edit/:id" element={<EditContractorPage />} />
                <Route path="show/:id" element={<ContractorsShowPage />} />
                <Route path="import" element={<ImportContractorsPage />} />
              </Route>

              {/* Employees */}
              <Route path="/employees">
                <Route index element={<EmployeesListPage />} />
                <Route path="create" element={<CreateEmployeePage />} />
                <Route path="show/:id" element={<EmployeesShowPage />} />
              </Route>

              {/* Purchase Orders */}
              <Route path="/purchase-orders">
                <Route index element={<PurchaseOrdersListPage />} />
                <Route path="create" element={<CreatePurchaseOrderPage />} />
                <Route path="edit/:id" element={<EditPurchaseOrderPage />} />
                <Route path="show/:id" element={<PurchaseOrderShowPage />} />
                <Route path=":id/manage-contractors" element={<ManagePOContractorsPage />} />
                <Route path="templates" element={<POTemplatesPage />} />
              </Route>

              {/* Timecards */}
              <Route path="/timecards">
                <Route index element={<TimecardsListPage />} />
                <Route path="create" element={<CreateTimecardPage />} />
                <Route path="show/:id" element={<TimecardShowPage />} />
                <Route path="pending" element={<PendingTimecardsPage />} />
                <Route path="bulk-approve" element={<BulkApproveTimecardsPage />} />
              </Route>

              {/* Invoices */}
              <Route path="/invoices">
                <Route index element={<InvoicesListPage />} />
                <Route path="create" element={<CreateInvoicePage />} />
                <Route path="edit/:id" element={<EditInvoicePage />} />
                <Route path="show/:id" element={<InvoiceShowPage />} />
                <Route path="generate" element={<GenerateInvoicePage />} />
              </Route>

              {/* Statements of Work */}
              <Route path="/statement-of-works">
                <Route index element={<StatementOfWorksListPage />} />
                <Route path="create" element={<CreateStatementOfWorkPage />} />
                <Route path="edit/:id" element={<EditStatementOfWorkPage />} />
                <Route path="show/:id" element={<StatementOfWorkShowPage />} />
                <Route path="compliance-report" element={<SOWComplianceReportPage />} />
              </Route>

              {/* Change Orders */}
              <Route path="/change-orders">
                <Route index element={<ChangeOrdersListPage />} />
                <Route path="create" element={<CreateChangeOrderPage />} />
                <Route path="show/:id" element={<ChangeOrderShowPage />} />
              </Route>

              {/* Expenses */}
              <Route path="/expenses">
                <Route index element={<ExpensesListPage />} />
                <Route path="create" element={<CreateExpensePage />} />
                <Route path="show/:id" element={<ExpenseShowPage />} />
                <Route path="bulk-approve" element={<BulkApproveExpensesPage />} />
                <Route path="reports" element={<ExpenseReportsPage />} />
              </Route>

              {/* Assets */}
              <Route path="/assets">
                <Route index element={<AssetsListPage />} />
                <Route path="create" element={<AssetCreatePage />} />
                <Route path="show/:id" element={<AssetShowPage />} />
                <Route path="scan" element={<AssetScanPage />} />
                <Route path="kits" element={<AssetKitsPage />} />
                <Route path="transfer/:id" element={<AssetTransferPage />} />
                <Route path="maintenance" element={<AssetMaintenancePage />} />
              </Route>

              {/* AI */}
              <Route path="/ai">
                <Route path="insights" element={<AIInsightsPage />} />
                <Route path="chatbots" element={<ChatbotsPage />} />
                <Route path="chatbots-display" element={<ChatbotsDisplayPage />} />
              </Route>

              {/* Admin */}
              <Route path="/admin">
                <Route index element={<AdminHub />} />
                <Route path="dashboard" element={<AdminDashboardPage />} />
                <Route path="users" element={<UserManagementPage />} />
                <Route path="audit-logs" element={<AuditLogsListPage />} />
                <Route path="exceptions" element={<SystemExceptionsListPage />} />
                <Route path="data-quality" element={<DataQualityDashboardPage />} />
                <Route path="chatbots-customize" element={<ChatbotsCustomizePage />} />
                <Route path="voice-panel" element={<VoicePanelPage />} />
                <Route path="xlsx-import" element={<XLSXImportPage />} />
              </Route>

              {/* Approvals */}
              <Route path="/approvals">
                <Route index element={<ApprovalRequestsPage />} />
                <Route path="rules" element={<ApprovalRulesPage />} />
                <Route path="configure" element={<ApprovalConfigurationPage />} />
                <Route path="email-logs" element={<EmailLogsPage />} />
              </Route>

              {/* Contractor Portal */}
              <Route path="/contractor-portal">
                <Route index element={<ContractorPortalDashboard />} />
                <Route path="profile" element={<ContractorProfilePage />} />
                <Route path="timecards">
                  <Route index element={<ContractorTimecardsPage />} />
                  <Route path="create" element={<ContractorTimecardCreatePage />} />
                </Route>
                <Route path="invoices" element={<ContractorInvoicesPage />} />
                <Route path="expenses">
                  <Route index element={<ContractorExpensesPage />} />
                  <Route path="create" element={<ContractorExpenseCreatePage />} />
                </Route>
                <Route path="documents">
                  <Route index element={<ContractorDocumentsPage />} />
                  <Route path="upload" element={<UploadContractorDocumentPage />} />
                </Route>
                <Route path="messages" element={<ContractorMessagesPage />} />
              </Route>

              {/* Hubs */}
              <Route path="/analytics-hub" element={<AnalyticsHub />} />
              <Route path="/pc2-purchase-orders" element={<PC2PurchaseOrdersHub />} />
              <Route path="/pc3-workforce-home" element={<PC3WorkforceHub />} />

              {/* Additional Features */}
              <Route path="/search/global" element={<GlobalSearchPage />} />
              <Route path="/filters/presets" element={<FilterPresetsPage />} />
              <Route path="/budget/forecasting" element={<BudgetForecastingPage />} />
              <Route path="/notifications" element={<NotificationCenterPage />} />

              {/* 404 Catch All */}
              <Route path="*" element={<ErrorComponent />} />
            </Route>
          </Routes>
          <Toaster />
        </Refine>
      </ThemeProvider>
    </BrowserRouter>
  );
}
