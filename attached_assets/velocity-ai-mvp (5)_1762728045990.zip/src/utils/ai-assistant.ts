/**
 * AI-Powered Intelligent Assistant
 * Context-aware Q&A system for user support
 */

export interface AssistantMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  context?: {
    page: string;
    entityType?: string;
    entityId?: number;
  };
}

export interface AssistantResponse {
  answer: string;
  relatedLinks?: Array<{
    label: string;
    url: string;
  }>;
  suggestedActions?: Array<{
    label: string;
    action: string;
  }>;
}

/**
 * Mock AI assistant - simulates intelligent Q&A
 * In production, integrate with Claude API or similar
 */
export async function askAssistant(
  question: string,
  context?: {
    page?: string;
    entityType?: string;
    entityId?: number;
  },
): Promise<AssistantResponse> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const questionLower = question.toLowerCase();

  // Budget/PO related questions
  if (questionLower.includes("po") && questionLower.includes("red")) {
    return {
      answer:
        "A Purchase Order appears in red when it's at risk of budget overrun or has exceeded its allocated budget. This color indicates that immediate attention is needed. The system monitors spending against the PO total and flags when utilization exceeds 90% or when the burn rate suggests the budget will be exhausted before the contract end date.",
      relatedLinks: [
        { label: "View Budget Dashboard", url: "/budget/forecasting" },
        { label: "View All Purchase Orders", url: "/purchase-orders" },
      ],
      suggestedActions: [
        { label: "Review PO Details", action: "navigate_po" },
        { label: "Check Timecards", action: "view_timecards" },
      ],
    };
  }

  if (questionLower.includes("gr") || questionLower.includes("goods receipt")) {
    return {
      answer:
        "GR (Goods Receipt) is a critical approval step in the invoice process. It represents the authorization for fund release after work has been verified. An invoice cannot be paid until GR approval is complete. The GR Amount shows the total authorized for release, while GR Balance shows what remains. Managers must approve GR to confirm that services were delivered as invoiced.",
      relatedLinks: [
        { label: "View Pending Invoices", url: "/invoices" },
        { label: "Invoice Processing Guide", url: "/admin" },
      ],
      suggestedActions: [{ label: "Approve Pending GRs", action: "approve_gr" }],
    };
  }

  if (questionLower.includes("timecard") && questionLower.includes("approve")) {
    return {
      answer:
        "To approve timecards: Navigate to the 'Pending Timecards' page from the Timecards menu. Review each timecard for accuracy (hours, date, task description, PO assignment). Click 'Approve' to accept or 'Reject' with a reason if corrections are needed. For bulk approvals, use the 'Bulk Approve' page to select multiple timecards at once. Approved timecards automatically generate invoices.",
      relatedLinks: [
        { label: "Pending Timecards", url: "/timecards/pending" },
        { label: "Bulk Approve", url: "/timecards/bulk-approve" },
      ],
      suggestedActions: [
        { label: "Go to Pending Timecards", action: "navigate_pending" },
        { label: "Start Bulk Approval", action: "bulk_approve" },
      ],
    };
  }

  if (
    questionLower.includes("variance") ||
    (questionLower.includes("invoice") && questionLower.includes("discrepancy"))
  ) {
    return {
      answer:
        "Invoice variance occurs when the actual invoice amount differs from the requested amount. This is flagged in the system with a variance indicator. Common causes include: unauthorized overtime, incorrect hourly rates, or timecard errors. The system tracks variance amounts and flags contractors with recurring variance patterns. Review the invoice details to identify the source of the discrepancy and contact the contractor if needed.",
      relatedLinks: [
        { label: "View Invoices with Variance", url: "/invoices" },
        { label: "Expense Reports", url: "/expenses/reports" },
      ],
      suggestedActions: [{ label: "Review Variance Details", action: "check_variance" }],
    };
  }

  if (questionLower.includes("sow") || questionLower.includes("statement of work")) {
    return {
      answer:
        "A Statement of Work (SOW) defines the terms, deliverables, and payment schedule for contractor engagements. There are two types: Fixed Fee (set total value) and Deliverables Based (payment tied to specific milestones). The system tracks invoiced amounts against SOW value and alerts when overruns occur. Change Orders can be submitted if scope changes require budget adjustments.",
      relatedLinks: [
        { label: "View SOWs", url: "/statement-of-works" },
        { label: "Change Orders", url: "/change-orders" },
        { label: "SOW Compliance Report", url: "/statement-of-works/compliance-report" },
      ],
      suggestedActions: [{ label: "Create New SOW", action: "create_sow" }],
    };
  }

  if (questionLower.includes("contractor") && questionLower.includes("add")) {
    return {
      answer:
        "To add a new contractor: Go to Contractors > Create New. Fill in required fields: name, email, pay rate, location, job description, hiring manager, and assigned manager. Assign to a department for budget tracking. Link to a Purchase Order to allocate funds. Once created, the contractor can access the Contractor Portal to submit timecards and expenses.",
      relatedLinks: [
        { label: "Create Contractor", url: "/contractors/create" },
        { label: "Import Contractors (CSV)", url: "/contractors/import" },
      ],
      suggestedActions: [{ label: "Start Creating Contractor", action: "create_contractor" }],
    };
  }

  if (questionLower.includes("budget") && questionLower.includes("forecast")) {
    return {
      answer:
        "Budget Forecasting uses historical spend data and current burn rates to project future costs. The system analyzes PO utilization, timecard trends, and invoice patterns to predict budget overruns before they occur. You can view forecasts by department, fiscal period, or specific PO. The AI-powered alerts identify high-risk POs and suggest corrective actions.",
      relatedLinks: [
        { label: "Budget Forecasting Dashboard", url: "/budget/forecasting" },
        { label: "AI Insights", url: "/ai/insights" },
      ],
      suggestedActions: [{ label: "View Forecast", action: "view_forecast" }],
    };
  }

  if (questionLower.includes("ai") || questionLower.includes("contract analysis")) {
    return {
      answer:
        "AI Contract Analysis uses advanced machine learning to review contracts for risk, compliance, and missing protections. Upload a contract (SOW, PO, agreement) and the system extracts key terms, identifies risks, and provides recommendations. The analysis includes: risk scoring (0-100), compliance checks (insurance, IP rights, termination clauses), and actionable recommendations to strengthen your contracts.",
      relatedLinks: [
        { label: "AI Insights Dashboard", url: "/ai/insights" },
        { label: "Upload Contract for Analysis", url: "/ai/insights" },
      ],
      suggestedActions: [{ label: "Analyze a Contract", action: "analyze_contract" }],
    };
  }

  // Default response for unmatched questions
  return {
    answer:
      "I can help you with questions about Purchase Orders, Timecards, Invoices, SOWs, Contractors, Budget Forecasting, and AI Contract Analysis. Try asking about specific features like 'How do I approve timecards?' or 'Why is this PO in red?' You can also explore the navigation menu for different sections of the system.",
    relatedLinks: [
      { label: "Dashboard", url: "/dashboard" },
      { label: "Help Documentation", url: "/admin" },
    ],
    suggestedActions: [
      { label: "View Dashboard", action: "go_dashboard" },
      { label: "View All Contractors", action: "view_contractors" },
    ],
  };
}

/**
 * Get conversation starter suggestions based on current page
 */
export function getConversationStarters(page?: string): string[] {
  const starters: Record<string, string[]> = {
    "/dashboard": [
      "What do the AI insights mean?",
      "How is budget utilization calculated?",
      "Which metrics should I monitor?",
    ],
    "/purchase-orders": ["Why is this PO flagged in red?", "How do I add contractors to a PO?", "What is GR approval?"],
    "/timecards": [
      "How do I approve timecards?",
      "What happens if I reject a timecard?",
      "Can I approve multiple timecards at once?",
    ],
    "/invoices": [
      "What does invoice variance mean?",
      "How is GR approval different from regular approval?",
      "When are invoices paid?",
    ],
    "/contractors": [
      "How do I add a new contractor?",
      "What documents are required?",
      "How do I track contractor spend?",
    ],
    "/ai/insights": [
      "How accurate is the risk scoring?",
      "What should I do about high-risk contracts?",
      "Can I analyze multiple contracts at once?",
    ],
  };

  if (page && starters[page]) {
    return starters[page];
  }

  return [
    "How do I create a Purchase Order?",
    "What are the AI insights showing?",
    "How do I approve timecards?",
    "What is budget forecasting?",
  ];
}
