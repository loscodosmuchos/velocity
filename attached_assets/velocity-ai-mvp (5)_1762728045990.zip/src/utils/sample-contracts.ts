/**
 * Sample contracts for demo purposes
 * These showcase the AI analysis capabilities with realistic contract text
 */

export const sampleContracts = {
  completeSOW: {
    name: "IT Services SOW - Complete",
    type: "SOW" as const,
    content: `STATEMENT OF WORK
Professional IT Services Agreement

This Statement of Work is entered into between Velocity Corporation and Tech Solutions Inc.

Total Contract Value: $450,000
Contract Period: January 1, 2024 - December 31, 2024

SCOPE OF WORK:
1. Software Development Services
   - Custom application development
   - System integration and API development
   - Database design and optimization

2. Technical Support Services
   - 24/7 on-call support
   - Incident response and resolution
   - System monitoring and maintenance

DELIVERABLES:
Phase 1 (Q1 2024): Requirements analysis and system design documentation
Phase 2 (Q2 2024): Application development and initial testing
Phase 3 (Q3 2024): Integration with existing systems
Phase 4 (Q4 2024): Final testing, deployment, and training

PAYMENT SCHEDULE:
- 25% upon contract execution ($112,500)
- 25% upon Phase 2 completion ($112,500)
- 25% upon Phase 3 completion ($112,500)
- 25% upon final acceptance ($112,500)

INTELLECTUAL PROPERTY:
All work product, including source code, documentation, and deliverables, shall be considered work-for-hire and shall be the exclusive property of Velocity Corporation. Contractor assigns all rights, title, and interest to Velocity.

INSURANCE REQUIREMENTS:
Contractor shall maintain:
- General Liability Insurance: $1,000,000 per occurrence
- Professional Liability Insurance: $2,000,000 aggregate
- Workers Compensation as required by law

TERMINATION:
Either party may terminate this agreement with 30 days written notice. In the event of termination, Contractor shall be paid for work completed through termination date.

CONFIDENTIALITY:
Contractor agrees to maintain confidentiality of all proprietary information and trade secrets encountered during the engagement.`,
  },

  incompleteSOW: {
    name: "IT Services SOW - Missing Protections",
    type: "SOW" as const,
    content: `STATEMENT OF WORK
Professional IT Services Agreement

This Statement of Work is between Velocity Corporation and Tech Solutions Inc.

Total Contract Value: $450,000
Contract Period: January 1, 2024 - December 31, 2024

SCOPE OF WORK:
1. Software Development Services
   - Custom application development
   - System integration and API development
   - Database design and optimization

2. Technical Support Services
   - 24/7 on-call support
   - Incident response and resolution

DELIVERABLES:
Phase 1 (Q1 2024): Requirements analysis and system design
Phase 2 (Q2 2024): Application development and testing
Phase 3 (Q3 2024): Integration with systems
Phase 4 (Q4 2024): Final testing and deployment

PAYMENT SCHEDULE:
Invoices will be submitted monthly for services rendered.

CONFIDENTIALITY:
Contractor agrees to keep information confidential.`,
  },

  purchaseOrder: {
    name: "Purchase Order - Standard",
    type: "PO" as const,
    content: `PURCHASE ORDER #PO-2024-1234

Vendor: Tech Solutions Inc.
Ship To: Velocity Corporation
        123 Business Park
        Atlanta, GA 30303

Order Date: January 15, 2024
Required By: December 31, 2024

LINE ITEMS:
1. Professional IT Services - $450,000
   Description: Software development and technical support services
   Period: 01/01/2024 - 12/31/2024

TOTAL AMOUNT: $450,000.00

PAYMENT TERMS:
Net 30 days from invoice date

INSURANCE REQUIREMENTS:
Vendor must provide certificate of insurance showing:
- General Liability: $1,000,000
- Professional Liability: $2,000,000

DELIVERY:
Services to be delivered per schedule outlined in attached Statement of Work.

TERMS AND CONDITIONS:
Standard Velocity Corporation purchasing terms apply. This PO is subject to the master services agreement dated October 1, 2023.`,
  },

  highRiskContract: {
    name: "Consulting Agreement - High Risk",
    type: "Agreement" as const,
    content: `CONSULTING AGREEMENT

This Agreement is made between Velocity Corporation ("Client") and Independent Consultant ("Consultant").

Engagement Period: Open-ended, month-to-month
Compensation: $200 per hour, billed weekly

SERVICES:
Consultant will provide general business consulting services as requested by Client from time to time.

PAYMENT:
Client will pay Consultant within 15 days of invoice receipt.

RELATIONSHIP:
Consultant is an independent contractor.`,
  },
};

export function getSampleContract(key: keyof typeof sampleContracts) {
  return sampleContracts[key];
}

export function getAllSampleContracts() {
  return Object.entries(sampleContracts).map(([key, contract]) => ({
    key,
    ...contract,
  }));
}
