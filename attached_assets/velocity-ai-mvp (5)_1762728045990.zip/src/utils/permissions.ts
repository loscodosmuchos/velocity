/**
 * Permission-based Access Control Utilities
 * Manages role-based permissions and data visibility restrictions
 */

export type UserRole = "Admin" | "Manager" | "Contractor" | "Viewer";

export type Permission =
  | "contractors.view"
  | "contractors.create"
  | "contractors.edit"
  | "contractors.delete"
  | "contractors.export"
  | "purchaseorders.view"
  | "purchaseorders.create"
  | "purchaseorders.edit"
  | "purchaseorders.delete"
  | "purchaseorders.approve"
  | "timecards.view"
  | "timecards.create"
  | "timecards.approve"
  | "timecards.reject"
  | "invoices.view"
  | "invoices.create"
  | "invoices.gr_approve"
  | "invoices.export"
  | "sow.view"
  | "sow.create"
  | "sow.edit"
  | "sow.delete"
  | "changeorders.view"
  | "changeorders.create"
  | "changeorders.approve"
  | "admin.view_audit_logs"
  | "admin.view_exceptions"
  | "admin.manage_users"
  | "admin.system_settings"
  | "budget.view"
  | "budget.forecast"
  | "reports.view"
  | "reports.export";

/**
 * Role-based permission matrix
 */
export const rolePermissions: Record<UserRole, Permission[]> = {
  Admin: [
    "contractors.view",
    "contractors.create",
    "contractors.edit",
    "contractors.delete",
    "contractors.export",
    "purchaseorders.view",
    "purchaseorders.create",
    "purchaseorders.edit",
    "purchaseorders.delete",
    "purchaseorders.approve",
    "timecards.view",
    "timecards.create",
    "timecards.approve",
    "timecards.reject",
    "invoices.view",
    "invoices.create",
    "invoices.gr_approve",
    "invoices.export",
    "sow.view",
    "sow.create",
    "sow.edit",
    "sow.delete",
    "changeorders.view",
    "changeorders.create",
    "changeorders.approve",
    "admin.view_audit_logs",
    "admin.view_exceptions",
    "admin.manage_users",
    "admin.system_settings",
    "budget.view",
    "budget.forecast",
    "reports.view",
    "reports.export",
  ],

  Manager: [
    "contractors.view",
    "contractors.create",
    "contractors.edit",
    "contractors.export",
    "purchaseorders.view",
    "purchaseorders.create",
    "purchaseorders.edit",
    "purchaseorders.approve",
    "timecards.view",
    "timecards.approve",
    "timecards.reject",
    "invoices.view",
    "invoices.create",
    "invoices.gr_approve",
    "sow.view",
    "sow.create",
    "sow.edit",
    "changeorders.view",
    "changeorders.create",
    "changeorders.approve",
    "budget.view",
    "reports.view",
    "reports.export",
  ],

  Contractor: ["contractors.view", "timecards.view", "timecards.create", "invoices.view", "sow.view", "reports.view"],

  Viewer: [
    "contractors.view",
    "purchaseorders.view",
    "timecards.view",
    "invoices.view",
    "sow.view",
    "budget.view",
    "reports.view",
  ],
};

/**
 * Check if a role has a specific permission
 */
export const hasPermission = (role: UserRole, permission: Permission): boolean => {
  return rolePermissions[role].includes(permission);
};

/**
 * Check if a role has any of the specified permissions
 */
export const hasAnyPermission = (role: UserRole, permissions: Permission[]): boolean => {
  return permissions.some((permission) => hasPermission(role, permission));
};

/**
 * Check if a role has all of the specified permissions
 */
export const hasAllPermissions = (role: UserRole, permissions: Permission[]): boolean => {
  return permissions.every((permission) => hasPermission(role, permission));
};

/**
 * Get all permissions for a role
 */
export const getRolePermissions = (role: UserRole): Permission[] => {
  return rolePermissions[role];
};

/**
 * Department-based data filtering
 * Restricts data visibility based on user's department
 */
export const applyDepartmentFilter = (role: UserRole, userDepartmentId?: number, filters: any[] = []): any[] => {
  // Admins can see all departments
  if (role === "Admin") {
    return filters;
  }

  // Managers and Viewers see only their department
  if ((role === "Manager" || role === "Viewer") && userDepartmentId) {
    return [
      ...filters,
      {
        field: "departmentId",
        operator: "eq",
        value: userDepartmentId,
      },
    ];
  }

  // Contractors see only their own data
  if (role === "Contractor") {
    // This would be applied at the contractor level, not department level
    return filters;
  }

  return filters;
};

/**
 * User-based data filtering
 * Restricts data visibility to user's own records
 */
export const applyUserFilter = (role: UserRole, userId: number, resource: string, filters: any[] = []): any[] => {
  // Contractors can only see their own data
  if (role === "Contractor") {
    if (resource === "contractors") {
      return [
        ...filters,
        {
          field: "id",
          operator: "eq",
          value: userId,
        },
      ];
    }

    if (resource === "timecards" || resource === "invoices") {
      return [
        ...filters,
        {
          field: "contractorId",
          operator: "eq",
          value: userId,
        },
      ];
    }
  }

  return filters;
};

/**
 * Permission-based action visibility
 * Determines which actions are available based on role
 */
export interface ResourceActions {
  canView: boolean;
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canApprove?: boolean;
  canExport?: boolean;
}

export const getResourceActions = (role: UserRole, resource: string): ResourceActions => {
  const actions: ResourceActions = {
    canView: false,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  };

  const resourcePrefix = resource.toLowerCase();

  actions.canView = hasPermission(role, `${resourcePrefix}.view` as Permission);
  actions.canCreate = hasPermission(role, `${resourcePrefix}.create` as Permission);
  actions.canEdit = hasPermission(role, `${resourcePrefix}.edit` as Permission);
  actions.canDelete = hasPermission(role, `${resourcePrefix}.delete` as Permission);

  // Additional actions for specific resources
  if (resource === "purchaseorders" || resource === "timecards" || resource === "changeorders") {
    actions.canApprove = hasPermission(role, `${resourcePrefix}.approve` as Permission);
  }

  if (resource === "contractors" || resource === "invoices" || resource === "reports") {
    actions.canExport = hasPermission(role, `${resourcePrefix}.export` as Permission);
  }

  return actions;
};

/**
 * Get filtered navigation items based on role
 */
export const getFilteredNavigationItems = (role: UserRole) => {
  const allItems = [
    { name: "Dashboard", path: "/dashboard", permission: null },
    { name: "Contractors", path: "/contractors", permission: "contractors.view" as Permission },
    { name: "Purchase Orders", path: "/purchase-orders", permission: "purchaseorders.view" as Permission },
    { name: "Timecards", path: "/timecards", permission: "timecards.view" as Permission },
    { name: "Invoices", path: "/invoices", permission: "invoices.view" as Permission },
    { name: "SOW Tracking", path: "/statement-of-works", permission: "sow.view" as Permission },
    { name: "Change Orders", path: "/change-orders", permission: "changeorders.view" as Permission },
    { name: "Budget Forecasting", path: "/budget/forecasting", permission: "budget.view" as Permission },
    { name: "System Admin", path: "/admin", permission: "admin.view_audit_logs" as Permission },
  ];

  return allItems.filter((item) => !item.permission || hasPermission(role, item.permission));
};

/**
 * Mock current user context
 * In production, this would be retrieved from authentication context
 */
export interface CurrentUser {
  id: number;
  email: string;
  role: UserRole;
  departmentId?: number;
  permissions: Permission[];
}

export const getCurrentUser = (): CurrentUser => {
  // Mock current user - in production, retrieve from auth context
  return {
    id: 1,
    email: "admin@velocity.com",
    role: "Admin",
    departmentId: 1,
    permissions: getRolePermissions("Admin"),
  };
};

/**
 * Check if current user can perform an action
 */
export const canPerformAction = (action: Permission): boolean => {
  const currentUser = getCurrentUser();
  return currentUser.permissions.includes(action);
};
