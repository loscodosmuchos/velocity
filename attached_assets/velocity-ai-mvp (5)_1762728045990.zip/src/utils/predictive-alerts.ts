/**
 * AI-Powered Predictive Alerts System
 * Analyzes system data to predict budget overruns, timeline risks, and variances
 */

import type { PurchaseOrder, Timecard, Invoice, StatementOfWork } from "@/types";

export interface PredictiveAlert {
  id: string;
  type: "Budget Overrun" | "Timeline Risk" | "Variance Prediction" | "Compliance Risk";
  severity: "Low" | "Medium" | "High" | "Critical";
  title: string;
  description: string;
  predictedImpact: string;
  recommendedAction: string;
  entityType: "PurchaseOrder" | "SOW" | "Contractor" | "Department";
  entityId: number;
  entityName: string;
  confidence: number; // 0-100
  predictedDate?: string;
  estimatedCost?: number;
  createdAt: string;
}

/**
 * Analyze purchase orders for budget overrun risks
 */
export function predictBudgetOverruns(
  purchaseOrders: PurchaseOrder[],
  timecards: Timecard[],
  invoices: Invoice[],
): PredictiveAlert[] {
  const alerts: PredictiveAlert[] = [];
  const now = new Date();

  purchaseOrders
    .filter((po) => po.status === "Active")
    .forEach((po) => {
      const poTimecards = timecards.filter((tc) => tc.purchaseOrderId === po.id && tc.status === "Approved");
      const poInvoices = invoices.filter((inv) => inv.purchaseOrderId === po.id);

      // Calculate burn rate (spent per day)
      const startDate = new Date(po.startDate);
      const daysElapsed = Math.max(1, Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)));
      const burnRate = po.spentAmount / daysElapsed;

      // Calculate remaining days
      const endDate = new Date(po.endDate);
      const daysRemaining = Math.floor((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

      // Predict final spend
      const predictedFinalSpend = po.spentAmount + burnRate * daysRemaining;
      const overrunAmount = predictedFinalSpend - po.totalAmount;

      // Generate alert if overrun predicted
      if (overrunAmount > 0 && daysRemaining > 0) {
        const overrunPercent = (overrunAmount / po.totalAmount) * 100;
        const severity: PredictiveAlert["severity"] =
          overrunPercent > 20 ? "Critical" : overrunPercent > 10 ? "High" : overrunPercent > 5 ? "Medium" : "Low";

        alerts.push({
          id: `budget-overrun-${po.id}`,
          type: "Budget Overrun",
          severity,
          title: `PO ${po.poNumber} - Budget Overrun Predicted`,
          description: `Based on current burn rate of $${burnRate.toFixed(2)}/day, this PO is projected to exceed budget by ${overrunPercent.toFixed(1)}%.`,
          predictedImpact: `Estimated overrun: $${overrunAmount.toFixed(2)} by ${endDate.toLocaleDateString()}`,
          recommendedAction:
            overrunPercent > 15
              ? "Immediate action required: Review contractor hours, negotiate rate reduction, or request budget increase"
              : "Monitor closely and consider adjusting scope or timeline",
          entityType: "PurchaseOrder",
          entityId: po.id,
          entityName: po.poNumber,
          confidence: Math.min(95, 70 + daysElapsed / 10), // Higher confidence with more historical data
          predictedDate: endDate.toISOString(),
          estimatedCost: overrunAmount,
          createdAt: new Date().toISOString(),
        });
      }

      // Check for rapid burn rate (>80% budget consumed with >30% time remaining)
      const budgetUtilization = (po.spentAmount / po.totalAmount) * 100;
      const timeUtilization = (daysElapsed / (daysElapsed + daysRemaining)) * 100;

      if (budgetUtilization > 80 && timeUtilization < 70) {
        alerts.push({
          id: `rapid-burn-${po.id}`,
          type: "Budget Overrun",
          severity: "High",
          title: `PO ${po.poNumber} - Rapid Budget Consumption`,
          description: `${budgetUtilization.toFixed(1)}% of budget consumed with ${(100 - timeUtilization).toFixed(1)}% of contract period remaining.`,
          predictedImpact: "Budget will be exhausted before contract end date",
          recommendedAction: "Reduce contractor hours immediately or secure additional funding",
          entityType: "PurchaseOrder",
          entityId: po.id,
          entityName: po.poNumber,
          confidence: 85,
          predictedDate: new Date(now.getTime() + daysRemaining * 0.3 * 24 * 60 * 60 * 1000).toISOString(),
          estimatedCost: po.remainingFunds,
          createdAt: new Date().toISOString(),
        });
      }
    });

  return alerts;
}

/**
 * Predict invoice variances based on historical patterns
 */
export function predictInvoiceVariances(invoices: Invoice[]): PredictiveAlert[] {
  const alerts: PredictiveAlert[] = [];

  // Find contractors with history of variance
  const contractorVariances = new Map<number, number[]>();

  invoices
    .filter((inv) => inv.hasVariance)
    .forEach((inv) => {
      const variances = contractorVariances.get(inv.contractorId) || [];
      variances.push(inv.varianceAmount);
      contractorVariances.set(inv.contractorId, variances);
    });

  // Alert if contractor has pattern of variances
  contractorVariances.forEach((variances, contractorId) => {
    if (variances.length >= 2) {
      const avgVariance = variances.reduce((sum, v) => sum + Math.abs(v), 0) / variances.length;
      const totalVariance = variances.reduce((sum, v) => sum + Math.abs(v), 0);

      if (avgVariance > 500) {
        alerts.push({
          id: `variance-pattern-${contractorId}`,
          type: "Variance Prediction",
          severity: avgVariance > 2000 ? "High" : "Medium",
          title: `Contractor #${contractorId} - Invoice Variance Pattern Detected`,
          description: `This contractor has ${variances.length} invoices with variances, averaging $${avgVariance.toFixed(2)} per invoice.`,
          predictedImpact: `Total variance: $${totalVariance.toFixed(2)}. Future invoices likely to have similar discrepancies.`,
          recommendedAction:
            "Review time tracking process with contractor. Consider requiring pre-approval for hours before submission.",
          entityType: "Contractor",
          entityId: contractorId,
          entityName: `Contractor #${contractorId}`,
          confidence: Math.min(90, 50 + variances.length * 10),
          estimatedCost: avgVariance,
          createdAt: new Date().toISOString(),
        });
      }
    }
  });

  return alerts;
}

/**
 * Detect timeline risks for SOWs
 */
export function predictTimelineRisks(sows: StatementOfWork[], purchaseOrders: PurchaseOrder[]): PredictiveAlert[] {
  const alerts: PredictiveAlert[] = [];
  const now = new Date();

  sows
    .filter((sow) => sow.status === "Active")
    .forEach((sow) => {
      const endDate = new Date(sow.endDate);
      const startDate = new Date(sow.startDate);
      const totalDays = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const daysElapsed = Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const daysRemaining = Math.floor((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

      const timeProgress = (daysElapsed / totalDays) * 100;
      const workProgress = (sow.invoicedAmount / sow.totalValue) * 100;

      // Timeline risk if time progress significantly ahead of work progress
      if (timeProgress > 60 && workProgress < 40 && daysRemaining > 0) {
        alerts.push({
          id: `timeline-risk-${sow.id}`,
          type: "Timeline Risk",
          severity: timeProgress > 80 ? "Critical" : "High",
          title: `SOW ${sow.sowNumber} - Delivery Risk Detected`,
          description: `${timeProgress.toFixed(0)}% of timeline elapsed but only ${workProgress.toFixed(0)}% of work completed (based on invoicing).`,
          predictedImpact: "Project unlikely to complete on time. Delay or scope reduction probable.",
          recommendedAction:
            daysRemaining < 30
              ? "Critical: Schedule urgent review meeting. Consider contract extension or deliverable reduction."
              : "Schedule status review with contractor to assess delivery risks and mitigation plan.",
          entityType: "SOW",
          entityId: sow.id,
          entityName: sow.sowNumber,
          confidence: 75,
          predictedDate: endDate.toISOString(),
          createdAt: new Date().toISOString(),
        });
      }
    });

  return alerts;
}

/**
 * Generate all predictive alerts
 */
export function generatePredictiveAlerts(data: {
  purchaseOrders: PurchaseOrder[];
  timecards: Timecard[];
  invoices: Invoice[];
  sows: StatementOfWork[];
}): PredictiveAlert[] {
  const budgetAlerts = predictBudgetOverruns(data.purchaseOrders, data.timecards, data.invoices);
  const varianceAlerts = predictInvoiceVariances(data.invoices);
  const timelineAlerts = predictTimelineRisks(data.sows, data.purchaseOrders);

  const allAlerts = [...budgetAlerts, ...varianceAlerts, ...timelineAlerts];

  // Sort by severity and confidence
  return allAlerts.sort((a, b) => {
    const severityWeight = { Critical: 4, High: 3, Medium: 2, Low: 1 };
    const scoreA = severityWeight[a.severity] * a.confidence;
    const scoreB = severityWeight[b.severity] * b.confidence;
    return scoreB - scoreA;
  });
}

/**
 * Get severity color for UI
 */
export function getSeverityColor(severity: PredictiveAlert["severity"]): string {
  const colors = {
    Low: "#22c55e",
    Medium: "#f97316",
    High: "#ef4444",
    Critical: "#dc2626",
  };
  return colors[severity];
}

/**
 * Get severity icon
 */
export function getSeverityIcon(severity: PredictiveAlert["severity"]): string {
  const icons = {
    Low: "info",
    Medium: "alert-triangle",
    High: "alert-circle",
    Critical: "alert-octagon",
  };
  return icons[severity];
}
