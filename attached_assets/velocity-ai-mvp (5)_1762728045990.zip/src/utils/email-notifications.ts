/**
 * Email Notification Utility
 * Simulates email notifications for invoice status changes and system exceptions
 * In production, this would integrate with services like SendGrid, AWS SES, or Mailgun
 */

export interface EmailNotificationPayload {
  to: string[];
  subject: string;
  body: string;
  priority: "low" | "normal" | "high" | "critical";
  category: "invoice" | "exception" | "approval" | "alert";
  metadata?: Record<string, any>;
}

export interface EmailTemplate {
  subject: string;
  body: string;
}

/**
 * Email templates for various notification types
 */
export const emailTemplates = {
  invoiceStatusChange: (invoiceNumber: string, oldStatus: string, newStatus: string): EmailTemplate => ({
    subject: `Invoice ${invoiceNumber} Status Updated: ${newStatus}`,
    body: `
      <h2>Invoice Status Change</h2>
      <p>Invoice <strong>${invoiceNumber}</strong> status has been updated.</p>
      <ul>
        <li>Previous Status: ${oldStatus}</li>
        <li>New Status: ${newStatus}</li>
        <li>Updated: ${new Date().toLocaleString()}</li>
      </ul>
      <p>Please review the invoice in the Velocity Workforce Management System.</p>
      <a href="${window.location.origin}/invoices/${invoiceNumber}" style="padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;">View Invoice</a>
    `,
  }),

  invoiceVarianceDetected: (invoiceNumber: string, requestedAmount: number, actualAmount: number): EmailTemplate => ({
    subject: `⚠️ Invoice Variance Detected: ${invoiceNumber}`,
    body: `
      <h2>Invoice Amount Variance</h2>
      <p>A discrepancy has been detected in invoice <strong>${invoiceNumber}</strong>.</p>
      <ul>
        <li>Requested Amount: $${requestedAmount.toLocaleString()}</li>
        <li>Actual Amount: $${actualAmount.toLocaleString()}</li>
        <li>Variance: $${Math.abs(actualAmount - requestedAmount).toLocaleString()}</li>
      </ul>
      <p><strong>Action Required:</strong> Please review and approve or dispute this variance.</p>
      <a href="${window.location.origin}/invoices/${invoiceNumber}" style="padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px;">Review Invoice</a>
    `,
  }),

  budgetOverrunAlert: (departmentName: string, budgetAllocated: number, projectedSpend: number): EmailTemplate => ({
    subject: `🚨 Budget Overrun Alert: ${departmentName}`,
    body: `
      <h2>Budget Overrun Detected</h2>
      <p>Department <strong>${departmentName}</strong> is projected to exceed its budget.</p>
      <ul>
        <li>Allocated Budget: $${budgetAllocated.toLocaleString()}</li>
        <li>Projected Spend: $${projectedSpend.toLocaleString()}</li>
        <li>Overrun: $${(projectedSpend - budgetAllocated).toLocaleString()}</li>
      </ul>
      <p><strong>Action Required:</strong> Review budget allocation and spending patterns.</p>
      <a href="${window.location.origin}/budget/forecasting" style="padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px;">View Budget Forecast</a>
    `,
  }),

  systemExceptionAlert: (exceptionType: string, entityName: string, description: string): EmailTemplate => ({
    subject: `System Exception: ${exceptionType}`,
    body: `
      <h2>System Exception Detected</h2>
      <p>An exception has been detected in the system that requires attention.</p>
      <ul>
        <li>Exception Type: <strong>${exceptionType}</strong></li>
        <li>Entity: ${entityName}</li>
        <li>Description: ${description}</li>
        <li>Detected: ${new Date().toLocaleString()}</li>
      </ul>
      <p><strong>Action Required:</strong> Please review and resolve this exception.</p>
      <a href="${window.location.origin}/admin/exceptions" style="padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 4px;">View Exceptions</a>
    `,
  }),

  timecardApprovalRequest: (contractorName: string, hours: number, amount: number): EmailTemplate => ({
    subject: `Timecard Approval Required: ${contractorName}`,
    body: `
      <h2>Timecard Approval Request</h2>
      <p>A timecard submission from <strong>${contractorName}</strong> requires your approval.</p>
      <ul>
        <li>Total Hours: ${hours}</li>
        <li>Total Amount: $${amount.toLocaleString()}</li>
        <li>Submitted: ${new Date().toLocaleString()}</li>
      </ul>
      <p>Please review and approve or reject this timecard.</p>
      <a href="${window.location.origin}/timecards/pending" style="padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;">Review Timecards</a>
    `,
  }),
};

/**
 * Simulated email notification service
 * In production, replace with actual email service integration
 */
export class EmailNotificationService {
  private static queue: EmailNotificationPayload[] = [];

  /**
   * Send an email notification
   */
  static async send(payload: EmailNotificationPayload): Promise<{ success: boolean; messageId?: string }> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 100));

    // Log to console in development
    console.log("📧 Email Notification:", {
      to: payload.to,
      subject: payload.subject,
      priority: payload.priority,
      category: payload.category,
    });

    // Queue the email
    this.queue.push({
      ...payload,
      metadata: {
        ...payload.metadata,
        sentAt: new Date().toISOString(),
      },
    });

    // Simulate success
    return {
      success: true,
      messageId: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };
  }

  /**
   * Send bulk email notifications
   */
  static async sendBulk(payloads: EmailNotificationPayload[]): Promise<{ success: boolean; sent: number }> {
    const results = await Promise.all(payloads.map((payload) => this.send(payload)));
    const successCount = results.filter((r) => r.success).length;

    return {
      success: successCount === payloads.length,
      sent: successCount,
    };
  }

  /**
   * Get email notification queue (for debugging)
   */
  static getQueue(): EmailNotificationPayload[] {
    return [...this.queue];
  }

  /**
   * Clear email notification queue
   */
  static clearQueue(): void {
    this.queue = [];
  }
}

/**
 * Convenience functions for common notification scenarios
 */
export const sendInvoiceStatusChangeEmail = async (
  recipientEmails: string[],
  invoiceNumber: string,
  oldStatus: string,
  newStatus: string,
) => {
  const template = emailTemplates.invoiceStatusChange(invoiceNumber, oldStatus, newStatus);
  return EmailNotificationService.send({
    to: recipientEmails,
    subject: template.subject,
    body: template.body,
    priority: "normal",
    category: "invoice",
    metadata: { invoiceNumber, oldStatus, newStatus },
  });
};

export const sendInvoiceVarianceEmail = async (
  recipientEmails: string[],
  invoiceNumber: string,
  requestedAmount: number,
  actualAmount: number,
) => {
  const template = emailTemplates.invoiceVarianceDetected(invoiceNumber, requestedAmount, actualAmount);
  return EmailNotificationService.send({
    to: recipientEmails,
    subject: template.subject,
    body: template.body,
    priority: "high",
    category: "invoice",
    metadata: { invoiceNumber, requestedAmount, actualAmount },
  });
};

export const sendBudgetOverrunEmail = async (
  recipientEmails: string[],
  departmentName: string,
  budgetAllocated: number,
  projectedSpend: number,
) => {
  const template = emailTemplates.budgetOverrunAlert(departmentName, budgetAllocated, projectedSpend);
  return EmailNotificationService.send({
    to: recipientEmails,
    subject: template.subject,
    body: template.body,
    priority: "critical",
    category: "exception",
    metadata: { departmentName, budgetAllocated, projectedSpend },
  });
};

export const sendSystemExceptionEmail = async (
  recipientEmails: string[],
  exceptionType: string,
  entityName: string,
  description: string,
) => {
  const template = emailTemplates.systemExceptionAlert(exceptionType, entityName, description);
  return EmailNotificationService.send({
    to: recipientEmails,
    subject: template.subject,
    body: template.body,
    priority: "high",
    category: "exception",
    metadata: { exceptionType, entityName, description },
  });
};

export const sendTimecardApprovalEmail = async (
  recipientEmails: string[],
  contractorName: string,
  hours: number,
  amount: number,
) => {
  const template = emailTemplates.timecardApprovalRequest(contractorName, hours, amount);
  return EmailNotificationService.send({
    to: recipientEmails,
    subject: template.subject,
    body: template.body,
    priority: "normal",
    category: "approval",
    metadata: { contractorName, hours, amount },
  });
};
