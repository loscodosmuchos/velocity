/**
 * Approval Workflow Integration for Multi-Lens Analysis
 * Automatically creates approval requests based on risk levels
 */

import type { MultiLensAnalysisResult } from "./multi-lens-analyzer";
import type { ApprovalRequest } from "../types";

export interface ApprovalWorkflowConfig {
  entityType: "SOW" | "PO" | "Agreement";
  entityId: number;
  entityName: string;
  requestedBy: number;
  requestedByName: string;
}

/**
 * Determine if contract requires approval based on risk levels
 */
export function requiresApproval(analysis: MultiLensAnalysisResult): boolean {
  // Require approval if:
  // 1. Overall risk is HIGH or CRITICAL
  // 2. Any individual lens is CRITICAL
  // 3. Legal or Compliance lens is HIGH

  if (analysis.overallRiskLevel === "HIGH" || analysis.overallRiskLevel === "CRITICAL") {
    return true;
  }

  const criticalLenses = [
    analysis.legalLens.riskLevel.level,
    analysis.financialLens.riskLevel.level,
    analysis.operationalLens.riskLevel.level,
    analysis.vendorLens.riskLevel.level,
    analysis.complianceLens.riskLevel.level,
  ];

  if (criticalLenses.includes("CRITICAL")) {
    return true;
  }

  if (analysis.legalLens.riskLevel.level === "HIGH" || analysis.complianceLens.riskLevel.level === "HIGH") {
    return true;
  }

  return false;
}

/**
 * Determine approval chain based on risk analysis
 */
export function determineApprovalChain(analysis: MultiLensAnalysisResult): Array<{ role: string; slaHours: number }> {
  const chain: Array<{ role: string; slaHours: number }> = [];

  // Always start with procurement manager
  chain.push({ role: "Procurement Manager", slaHours: 24 });

  // Add legal if legal risks are present
  if (analysis.legalLens.riskLevel.level === "HIGH" || analysis.legalLens.riskLevel.level === "CRITICAL") {
    chain.push({ role: "Legal Counsel", slaHours: 48 });
  }

  // Add finance if financial risks or high value
  if (
    analysis.financialLens.riskLevel.level === "HIGH" ||
    analysis.financialLens.riskLevel.level === "CRITICAL" ||
    analysis.financialLens.budgetImpact.estimatedTotal > 100000
  ) {
    chain.push({ role: "Finance Director", slaHours: 24 });
  }

  // Add compliance if compliance gaps
  if (analysis.complianceLens.riskLevel.level === "HIGH" || analysis.complianceLens.riskLevel.level === "CRITICAL") {
    chain.push({ role: "Compliance Officer", slaHours: 48 });
  }

  // Add executive approval for critical overall risk
  if (analysis.overallRiskLevel === "CRITICAL") {
    chain.push({ role: "Executive Approval", slaHours: 72 });
  }

  return chain;
}

/**
 * Create approval request from multi-lens analysis
 */
export function createApprovalRequest(
  analysis: MultiLensAnalysisResult,
  config: ApprovalWorkflowConfig,
): Partial<ApprovalRequest> {
  const approvalChain = determineApprovalChain(analysis);

  // Calculate due date based on first approval SLA
  const dueDate = new Date();
  dueDate.setHours(dueDate.getHours() + (approvalChain[0]?.slaHours || 24));

  return {
    entityType: config.entityType === "SOW" ? "PurchaseOrder" : "PurchaseOrder",
    entityId: config.entityId,
    entityName: config.entityName,
    requestedBy: config.requestedBy,
    requestedByName: config.requestedByName,
    currentApproverId: 1, // TODO: Map to actual user from approval chain
    currentApproverName: approvalChain[0]?.role || "Procurement Manager",
    approvalChainStep: 1,
    totalChainSteps: approvalChain.length,
    status: "Pending",
    requestedDate: new Date().toISOString(),
    dueDate: dueDate.toISOString(),
    approvalNotes: generateApprovalNotes(analysis),
    slaStatus: "On Time",
    emailSent: false,
    remindersSent: 0,
  };
}

/**
 * Generate approval notes from analysis results
 */
function generateApprovalNotes(analysis: MultiLensAnalysisResult): string {
  const notes: string[] = [];

  notes.push(`Multi-Lens AI Analysis Complete - Overall Risk: ${analysis.overallRiskLevel}`);
  notes.push(`Risk Score: ${analysis.overallRiskScore}/100`);
  notes.push("");

  // Add lens-specific concerns
  if (analysis.legalLens.clausesMissing.length > 0) {
    notes.push(
      `⚠️ Legal: ${analysis.legalLens.clausesMissing.length} missing clause(s) - ${analysis.legalLens.clausesMissing.slice(0, 2).join(", ")}`,
    );
  }

  if (analysis.financialLens.riskLevel.level !== "LOW") {
    notes.push(
      `💰 Financial: ${analysis.financialLens.paymentTermsAnalysis.clarity} payment terms - ${analysis.financialLens.budgetImpact.overrunRisk} overrun risk`,
    );
  }

  if (analysis.complianceLens.regulatoryAlignment.gaps.length > 0) {
    notes.push(`🛡️ Compliance: ${analysis.complianceLens.regulatoryAlignment.gaps.length} regulatory gap(s) detected`);
  }

  notes.push("");
  notes.push("Top Recommendations:");
  analysis.topRecommendations.slice(0, 3).forEach((rec, idx) => {
    notes.push(`${idx + 1}. [${rec.lens}] ${rec.action}`);
  });

  return notes.join("\n");
}

/**
 * Auto-escalate critical contracts
 */
export function shouldAutoEscalate(analysis: MultiLensAnalysisResult): boolean {
  // Auto-escalate if:
  // 1. Overall risk is CRITICAL
  // 2. Legal or Compliance is CRITICAL
  // 3. Multiple lenses are HIGH risk

  if (analysis.overallRiskLevel === "CRITICAL") {
    return true;
  }

  if (analysis.legalLens.riskLevel.level === "CRITICAL" || analysis.complianceLens.riskLevel.level === "CRITICAL") {
    return true;
  }

  const highRiskCount = [
    analysis.legalLens.riskLevel.level,
    analysis.financialLens.riskLevel.level,
    analysis.operationalLens.riskLevel.level,
    analysis.complianceLens.riskLevel.level,
  ].filter((level) => level === "HIGH" || level === "CRITICAL").length;

  return highRiskCount >= 3;
}

/**
 * Generate escalation message
 */
export function generateEscalationMessage(analysis: MultiLensAnalysisResult): string {
  const messages = [
    `CRITICAL CONTRACT ALERT: ${analysis.contractName}`,
    "",
    `Overall Risk Score: ${analysis.overallRiskScore}/100 (${analysis.overallRiskLevel})`,
    "",
    "Critical Issues Detected:",
  ];

  if (analysis.legalLens.riskLevel.level === "CRITICAL") {
    messages.push(
      `• LEGAL: ${analysis.legalLens.liabilityExposure.description} (Est. exposure: $${analysis.legalLens.liabilityExposure.estimatedExposure?.toLocaleString() || "Unknown"})`,
    );
  }

  if (analysis.financialLens.riskLevel.level === "CRITICAL") {
    messages.push(
      `• FINANCIAL: ${analysis.financialLens.budgetImpact.overrunRisk} budget overrun risk ($${analysis.financialLens.budgetImpact.estimatedTotal.toLocaleString()})`,
    );
  }

  if (analysis.complianceLens.riskLevel.level === "CRITICAL") {
    messages.push(
      `• COMPLIANCE: ${analysis.complianceLens.regulatoryAlignment.gaps.length} critical regulatory gap(s)`,
    );
  }

  messages.push("");
  messages.push("IMMEDIATE ACTION REQUIRED:");
  analysis.topRecommendations
    .filter((r) => r.priority === "Critical")
    .forEach((rec) => {
      messages.push(`• ${rec.action}`);
    });

  messages.push("");
  messages.push("This contract cannot proceed without executive review and mitigation plan.");

  return messages.join("\n");
}
