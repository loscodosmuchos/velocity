/**
 * XLSX Parser - Multi-Sheet Import Handler
 * Handles Excel file parsing, validation, and data transformation
 */

import * as XLSX from "xlsx";
import type { Contractor, PurchaseOrder, Asset, Employee } from "@/types";

export interface SheetMetadata {
  sheetName: string;
  entityType: "contractors" | "purchaseorders" | "assets" | "employees" | "unknown";
  rowCount: number;
  columnCount: number;
  headers: string[];
}

export interface ColumnMapping {
  excelColumn: string;
  fieldName: string;
  fieldType: string;
  required: boolean;
  transform?: (value: any) => any;
}

export interface ValidationError {
  row: number;
  column: string;
  value: any;
  error: string;
  severity: "error" | "warning";
}

export interface ImportPreview {
  sheetName: string;
  entityType: string;
  totalRows: number;
  validRows: number;
  errors: ValidationError[];
  warnings: ValidationError[];
  preview: any[];
  suggestedMappings: ColumnMapping[];
}

export interface ImportJob {
  id: string;
  fileName: string;
  uploadedAt: string;
  status: "pending" | "validating" | "importing" | "completed" | "failed";
  sheets: ImportPreview[];
  totalRecords: number;
  successCount: number;
  errorCount: number;
  warningCount: number;
  canRollback: boolean;
  rollbackExpiresAt?: string;
}

/**
 * Parse XLSX file and extract sheets
 */
export async function parseXLSXFile(file: File): Promise<SheetMetadata[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });

        const sheets: SheetMetadata[] = workbook.SheetNames.map((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

          const headers = (jsonData[0] || []).map((h) => String(h).trim());
          const rowCount = jsonData.length - 1; // Exclude header row
          const columnCount = headers.length;

          // Detect entity type based on headers
          const entityType = detectEntityType(headers);

          return {
            sheetName,
            entityType,
            rowCount,
            columnCount,
            headers,
          };
        });

        resolve(sheets);
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsBinaryString(file);
  });
}

/**
 * Detect entity type based on column headers
 */
function detectEntityType(headers: string[]): "contractors" | "purchaseorders" | "assets" | "employees" | "unknown" {
  const headerStr = headers.join("|").toLowerCase();

  // Contractor detection
  if (
    headerStr.includes("contractor") ||
    (headerStr.includes("first") && headerStr.includes("last") && headerStr.includes("rate"))
  ) {
    return "contractors";
  }

  // Purchase Order detection
  if (
    headerStr.includes("po") ||
    headerStr.includes("purchase") ||
    (headerStr.includes("amount") && headerStr.includes("start") && headerStr.includes("end"))
  ) {
    return "purchaseorders";
  }

  // Asset detection
  if (
    headerStr.includes("asset") ||
    headerStr.includes("barcode") ||
    headerStr.includes("serial") ||
    (headerStr.includes("equipment") && headerStr.includes("value"))
  ) {
    return "assets";
  }

  // Employee detection
  if (
    headerStr.includes("employee") ||
    (headerStr.includes("job") && headerStr.includes("title") && headerStr.includes("birth"))
  ) {
    return "employees";
  }

  return "unknown";
}

/**
 * Get suggested column mappings for entity type
 */
export function getSuggestedMappings(entityType: string, headers: string[]): ColumnMapping[] {
  const mappings: Record<string, ColumnMapping[]> = {
    contractors: [
      { excelColumn: "", fieldName: "firstName", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "lastName", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "email", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "phone", fieldType: "string", required: false },
      { excelColumn: "", fieldName: "payRate", fieldType: "number", required: true },
      { excelColumn: "", fieldName: "location", fieldType: "string", required: false },
      { excelColumn: "", fieldName: "jobDescription", fieldType: "string", required: false },
      { excelColumn: "", fieldName: "status", fieldType: "enum", required: true },
      { excelColumn: "", fieldName: "startDate", fieldType: "date", required: true },
    ],
    purchaseorders: [
      { excelColumn: "", fieldName: "poNumber", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "totalAmount", fieldType: "number", required: true },
      { excelColumn: "", fieldName: "startDate", fieldType: "date", required: true },
      { excelColumn: "", fieldName: "endDate", fieldType: "date", required: true },
      { excelColumn: "", fieldName: "status", fieldType: "enum", required: true },
      { excelColumn: "", fieldName: "type", fieldType: "enum", required: true },
      { excelColumn: "", fieldName: "description", fieldType: "string", required: false },
    ],
    assets: [
      { excelColumn: "", fieldName: "name", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "barcode", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "serialNumber", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "category", fieldType: "enum", required: true },
      { excelColumn: "", fieldName: "value", fieldType: "number", required: true },
      { excelColumn: "", fieldName: "purchaseDate", fieldType: "date", required: true },
      { excelColumn: "", fieldName: "status", fieldType: "enum", required: true },
    ],
    employees: [
      { excelColumn: "", fieldName: "firstName", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "lastName", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "email", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "jobTitle", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "role", fieldType: "string", required: true },
      { excelColumn: "", fieldName: "phone", fieldType: "string", required: false },
    ],
  };

  const fieldMappings = mappings[entityType] || [];

  // Auto-match headers to fields
  return fieldMappings.map((mapping) => {
    const matchedHeader = headers.find((h) => {
      const headerLower = h.toLowerCase().replace(/[_\s]+/g, "");
      const fieldLower = mapping.fieldName.toLowerCase();
      return headerLower.includes(fieldLower) || fieldLower.includes(headerLower);
    });

    return {
      ...mapping,
      excelColumn: matchedHeader || "",
    };
  });
}

/**
 * Validate data before import
 */
export function validateImportData(data: any[], mappings: ColumnMapping[], entityType: string): ValidationError[] {
  const errors: ValidationError[] = [];

  data.forEach((row, index) => {
    mappings.forEach((mapping) => {
      if (!mapping.excelColumn) return;

      const value = row[mapping.excelColumn];

      // Required field validation
      if (mapping.required && (value === undefined || value === null || value === "")) {
        errors.push({
          row: index + 2, // +2 because row 1 is header and arrays are 0-indexed
          column: mapping.excelColumn,
          value,
          error: `${mapping.fieldName} is required`,
          severity: "error",
        });
      }

      // Type validation
      if (value !== undefined && value !== null && value !== "") {
        if (mapping.fieldType === "number" && isNaN(Number(value))) {
          errors.push({
            row: index + 2,
            column: mapping.excelColumn,
            value,
            error: `${mapping.fieldName} must be a number`,
            severity: "error",
          });
        }

        if (mapping.fieldType === "email" && !isValidEmail(String(value))) {
          errors.push({
            row: index + 2,
            column: mapping.excelColumn,
            value,
            error: `${mapping.fieldName} must be a valid email`,
            severity: "error",
          });
        }

        if (mapping.fieldType === "date" && !isValidDate(value)) {
          errors.push({
            row: index + 2,
            column: mapping.excelColumn,
            value,
            error: `${mapping.fieldName} must be a valid date`,
            severity: "warning",
          });
        }
      }
    });
  });

  return errors;
}

/**
 * Transform Excel data to entity format
 */
export function transformDataToEntities(data: any[], mappings: ColumnMapping[], entityType: string): any[] {
  return data.map((row) => {
    const entity: any = {};

    mappings.forEach((mapping) => {
      if (!mapping.excelColumn) return;

      let value = row[mapping.excelColumn];

      // Apply transformation
      if (mapping.transform) {
        value = mapping.transform(value);
      } else {
        // Default transformations
        if (mapping.fieldType === "number") {
          value = Number(value) || 0;
        } else if (mapping.fieldType === "date") {
          value = transformDate(value);
        } else if (mapping.fieldType === "boolean") {
          value = Boolean(value);
        } else {
          value = String(value || "");
        }
      }

      entity[mapping.fieldName] = value;
    });

    // Add system fields
    entity.createdAt = new Date().toISOString();
    entity.updatedAt = new Date().toISOString();

    return entity;
  });
}

/**
 * Detect duplicates in import data
 */
export function detectDuplicates(
  newData: any[],
  existingData: any[],
  uniqueFields: string[],
): { duplicates: any[]; unique: any[] } {
  const duplicates: any[] = [];
  const unique: any[] = [];

  newData.forEach((newRecord) => {
    const isDuplicate = existingData.some((existingRecord) => {
      return uniqueFields.every((field) => {
        return String(newRecord[field]).toLowerCase() === String(existingRecord[field]).toLowerCase();
      });
    });

    if (isDuplicate) {
      duplicates.push(newRecord);
    } else {
      unique.push(newRecord);
    }
  });

  return { duplicates, unique };
}

/**
 * Preview import (first 5 rows)
 */
export async function generateImportPreview(
  file: File,
  sheetName: string,
  mappings: ColumnMapping[],
): Promise<ImportPreview> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        const totalRows = jsonData.length;
        const preview = jsonData.slice(0, 5); // First 5 rows

        const entityType = detectEntityType(mappings.map((m) => m.fieldName));
        const errors = validateImportData(jsonData, mappings, entityType);

        const result: ImportPreview = {
          sheetName,
          entityType,
          totalRows,
          validRows: totalRows - errors.filter((e) => e.severity === "error").length,
          errors: errors.filter((e) => e.severity === "error"),
          warnings: errors.filter((e) => e.severity === "warning"),
          preview: transformDataToEntities(preview, mappings, entityType),
          suggestedMappings: mappings,
        };

        resolve(result);
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsBinaryString(file);
  });
}

/**
 * Create import job
 */
export function createImportJob(fileName: string, sheets: ImportPreview[]): ImportJob {
  const totalRecords = sheets.reduce((sum, sheet) => sum + sheet.totalRows, 0);
  const errorCount = sheets.reduce((sum, sheet) => sum + sheet.errors.length, 0);
  const warningCount = sheets.reduce((sum, sheet) => sum + sheet.warnings.length, 0);

  const now = new Date();
  const rollbackExpires = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours

  return {
    id: `import_${Date.now()}`,
    fileName,
    uploadedAt: now.toISOString(),
    status: "pending",
    sheets,
    totalRecords,
    successCount: 0,
    errorCount,
    warningCount,
    canRollback: true,
    rollbackExpiresAt: rollbackExpires.toISOString(),
  };
}

// Helper functions

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidDate(value: any): boolean {
  if (!value) return false;
  const date = new Date(value);
  return !isNaN(date.getTime());
}

function transformDate(value: any): string {
  if (!value) return "";

  // Handle Excel date numbers
  if (typeof value === "number") {
    const date = XLSX.SSF.parse_date_code(value);
    return `${date.y}-${String(date.m).padStart(2, "0")}-${String(date.d).padStart(2, "0")}`;
  }

  // Handle string dates
  const date = new Date(value);
  if (!isNaN(date.getTime())) {
    return date.toISOString().split("T")[0];
  }

  return String(value);
}
