import type { Timecard, Invoice } from "@/types";

/**
 * Generate an invoice from approved timecards
 */
export function generateInvoiceFromTimecards(
  timecards: Timecard[],
  invoiceNumberPrefix: string = "INV-2024-",
): Omit<Invoice, "id" | "createdAt" | "updatedAt"> {
  if (timecards.length === 0) {
    throw new Error("Cannot generate invoice without timecards");
  }

  // Verify all timecards are approved
  const unapproved = timecards.filter((t) => t.status !== "Approved");
  if (unapproved.length > 0) {
    throw new Error("All timecards must be approved before generating an invoice");
  }

  // Verify all timecards are for the same contractor and PO
  const contractorId = timecards[0].contractorId;
  const purchaseOrderId = timecards[0].purchaseOrderId;

  const differentContractor = timecards.some((t) => t.contractorId !== contractorId);
  const differentPO = timecards.some((t) => t.purchaseOrderId !== purchaseOrderId);

  if (differentContractor || differentPO) {
    throw new Error("All timecards must be for the same contractor and purchase order");
  }

  // Calculate total amount
  const requestedAmount = timecards.reduce((sum, t) => sum + t.totalAmount, 0);
  const actualAmount = requestedAmount; // Initially same, can be adjusted

  // Generate invoice number
  const timestamp = Date.now();
  const invoiceNumber = `${invoiceNumberPrefix}${timestamp.toString().slice(-6)}`;

  // Get date range
  const dates = timecards.map((t) => new Date(t.date));
  const minDate = new Date(Math.min(...dates.map((d) => d.getTime())));
  const maxDate = new Date(Math.max(...dates.map((d) => d.getTime())));

  const invoiceDate = new Date().toISOString().split("T")[0];
  const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

  return {
    invoiceNumber,
    contractorId,
    purchaseOrderId,
    status: "Draft",
    requestedAmount,
    actualAmount,
    grAmount: actualAmount,
    grBalance: actualAmount, // Full amount pending GR approval
    invoiceDate,
    dueDate,
    paidDate: undefined,
    timecardIds: timecards.map((t) => t.id),
    varianceAmount: 0,
    hasVariance: false,
    notes: `Generated from ${timecards.length} timecard(s). Period: ${minDate.toISOString().split("T")[0]} to ${maxDate.toISOString().split("T")[0]}`,
  };
}

/**
 * Calculate variance between requested and actual amounts
 */
export function calculateInvoiceVariance(
  requestedAmount: number,
  actualAmount: number,
): { varianceAmount: number; hasVariance: boolean; variancePercentage: number } {
  const varianceAmount = actualAmount - requestedAmount;
  const hasVariance = Math.abs(varianceAmount) > 0.01; // Allow for floating point precision
  const variancePercentage = requestedAmount > 0 ? (varianceAmount / requestedAmount) * 100 : 0;

  return {
    varianceAmount,
    hasVariance,
    variancePercentage,
  };
}

/**
 * Validate invoice against PO budget
 */
export function validateInvoiceAgainstPO(
  invoiceAmount: number,
  poRemainingFunds: number,
): { isValid: boolean; exceedsBy?: number } {
  if (invoiceAmount <= poRemainingFunds) {
    return { isValid: true };
  }

  return {
    isValid: false,
    exceedsBy: invoiceAmount - poRemainingFunds,
  };
}
