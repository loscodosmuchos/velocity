/**
 * Stakeholder Role-Based Filtering
 * Determines which lenses are relevant to each user role
 */

export type StakeholderRole = "Legal" | "Finance" | "Operations" | "Procurement" | "Executive" | "Compliance";

export interface StakeholderLensAccess {
  role: StakeholderRole;
  primaryLenses: string[];
  secondaryLenses: string[];
  canApprove: boolean;
  canEscalate: boolean;
}

/**
 * Define lens access permissions per stakeholder role
 */
export const STAKEHOLDER_LENS_ACCESS: Record<StakeholderRole, StakeholderLensAccess> = {
  Legal: {
    role: "Legal",
    primaryLenses: ["legal", "compliance"],
    secondaryLenses: ["vendor"],
    canApprove: true,
    canEscalate: true,
  },
  Finance: {
    role: "Finance",
    primaryLenses: ["financial"],
    secondaryLenses: ["vendor", "operational"],
    canApprove: true,
    canEscalate: true,
  },
  Operations: {
    role: "Operations",
    primaryLenses: ["operational"],
    secondaryLenses: ["vendor", "financial"],
    canApprove: false,
    canEscalate: true,
  },
  Procurement: {
    role: "Procurement",
    primaryLenses: ["vendor", "financial"],
    secondaryLenses: ["operational", "legal"],
    canApprove: true,
    canEscalate: true,
  },
  Executive: {
    role: "Executive",
    primaryLenses: ["legal", "financial", "operational", "vendor", "compliance"],
    secondaryLenses: [],
    canApprove: true,
    canEscalate: true,
  },
  Compliance: {
    role: "Compliance",
    primaryLenses: ["compliance", "legal"],
    secondaryLenses: ["vendor"],
    canApprove: true,
    canEscalate: true,
  },
};

/**
 * Get lens visibility for a specific role
 */
export function getLensAccessForRole(role: StakeholderRole): StakeholderLensAccess {
  return STAKEHOLDER_LENS_ACCESS[role];
}

/**
 * Check if a role has access to view a specific lens
 */
export function canViewLens(role: StakeholderRole, lensName: string): boolean {
  const access = STAKEHOLDER_LENS_ACCESS[role];
  return access.primaryLenses.includes(lensName) || access.secondaryLenses.includes(lensName);
}

/**
 * Get priority lenses for a role (for filtering/sorting)
 */
export function getPriorityLensesForRole(role: StakeholderRole): string[] {
  return STAKEHOLDER_LENS_ACCESS[role].primaryLenses;
}

/**
 * Filter recommendations by stakeholder role relevance
 */
export function filterRecommendationsByRole(
  recommendations: Array<{ lens: string; action: string; priority: string }>,
  role: StakeholderRole,
): Array<{ lens: string; action: string; priority: string }> {
  const access = getLensAccessForRole(role);
  const relevantLenses = [...access.primaryLenses, ...access.secondaryLenses];

  return recommendations.filter((rec) => relevantLenses.includes(rec.lens.toLowerCase()));
}

/**
 * Get role-specific summary message
 */
export function getRoleSummary(role: StakeholderRole, riskLevel: string): string {
  const summaries: Record<StakeholderRole, Record<string, string>> = {
    Legal: {
      CRITICAL: "Critical legal risks detected. Immediate review required before execution.",
      HIGH: "High legal risks present. Review and address before proceeding.",
      MEDIUM: "Some legal gaps identified. Recommend review before signing.",
      LOW: "Legal review complete. No significant concerns.",
    },
    Finance: {
      CRITICAL: "Critical financial risks detected. Budget approval required.",
      HIGH: "High financial impact. CFO review recommended.",
      MEDIUM: "Financial terms need clarification. Review payment schedule.",
      LOW: "Financial terms acceptable. Within budget parameters.",
    },
    Operations: {
      CRITICAL: "Timeline unrealistic. Project cannot be delivered as specified.",
      HIGH: "Operational challenges identified. Resource planning needed.",
      MEDIUM: "Some operational concerns. Coordinate with resource planning.",
      LOW: "Operationally feasible. Resources available.",
    },
    Procurement: {
      CRITICAL: "Vendor relationship concerns. Escalate to senior procurement.",
      HIGH: "Vendor performance issues noted. Review history before proceeding.",
      MEDIUM: "Standard vendor engagement. Monitor delivery closely.",
      LOW: "Trusted vendor with strong track record.",
    },
    Executive: {
      CRITICAL: "High-risk contract. Executive approval required before execution.",
      HIGH: "Multiple risk factors present. Review with legal and finance.",
      MEDIUM: "Acceptable risk level with standard mitigations.",
      LOW: "Low-risk contract. Proceed with standard approval process.",
    },
    Compliance: {
      CRITICAL: "Critical compliance gaps. Cannot execute without addressing.",
      HIGH: "Compliance issues present. Legal and compliance review required.",
      MEDIUM: "Minor compliance gaps. Document and address before signing.",
      LOW: "Compliant with all regulatory requirements.",
    },
  };

  return summaries[role]?.[riskLevel] || "Review contract based on your area of responsibility.";
}

/**
 * Determine if role can take action on contract
 */
export function canTakeAction(role: StakeholderRole, actionType: "approve" | "escalate" | "revise"): boolean {
  const access = getLensAccessForRole(role);

  switch (actionType) {
    case "approve":
      return access.canApprove;
    case "escalate":
      return access.canEscalate;
    case "revise":
      return true; // All roles can request revisions
    default:
      return false;
  }
}
