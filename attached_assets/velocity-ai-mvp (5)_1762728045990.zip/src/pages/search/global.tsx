import { useState } from "react";
import { useList, useGo } from "@refinedev/core";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Search, Users, FileText, Clock, Receipt, FileEdit, ExternalLink } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Contractor, PurchaseOrder, Timecard, Invoice, StatementOfWork } from "@/types";

export function GlobalSearchPage() {
  const go = useGo();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  const { data: contractorsData, refetch: refetchContractors } = useList<Contractor>({
    resource: "contractors",
    filters: searchQuery
      ? [
          {
            operator: "or",
            value: [
              { field: "firstName", operator: "contains", value: searchQuery },
              { field: "lastName", operator: "contains", value: searchQuery },
              { field: "email", operator: "contains", value: searchQuery },
            ],
          },
        ]
      : [],
    queryOptions: {
      enabled: false,
    },
  });

  const { data: posData, refetch: refetchPOs } = useList<PurchaseOrder>({
    resource: "purchaseorders",
    filters: searchQuery
      ? [
          {
            operator: "or",
            value: [
              { field: "poNumber", operator: "contains", value: searchQuery },
              { field: "description", operator: "contains", value: searchQuery },
            ],
          },
        ]
      : [],
    queryOptions: {
      enabled: false,
    },
  });

  const { data: timecardsData, refetch: refetchTimecards } = useList<Timecard>({
    resource: "timecards",
    filters: searchQuery ? [{ field: "taskDescription", operator: "contains", value: searchQuery }] : [],
    queryOptions: {
      enabled: false,
    },
  });

  const { data: invoicesData, refetch: refetchInvoices } = useList<Invoice>({
    resource: "invoices",
    filters: searchQuery ? [{ field: "invoiceNumber", operator: "contains", value: searchQuery }] : [],
    queryOptions: {
      enabled: false,
    },
  });

  const { data: sowsData, refetch: refetchSOWs } = useList<StatementOfWork>({
    resource: "statementofworks",
    filters: searchQuery
      ? [
          {
            operator: "or",
            value: [
              { field: "sowNumber", operator: "contains", value: searchQuery },
              { field: "terms", operator: "contains", value: searchQuery },
            ],
          },
        ]
      : [],
    queryOptions: {
      enabled: false,
    },
  });

  const contractors = contractorsData?.data || [];
  const pos = posData?.data || [];
  const timecards = timecardsData?.data || [];
  const invoices = invoicesData?.data || [];
  const sows = sowsData?.data || [];

  const totalResults = contractors.length + pos.length + timecards.length + invoices.length + sows.length;

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    await Promise.all([refetchContractors(), refetchPOs(), refetchTimecards(), refetchInvoices(), refetchSOWs()]);
    setIsSearching(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  return (
    <ListView>
      <ListViewHeader canCreate={false} title="Global Search" />

      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Across All Modules
            </CardTitle>
            <CardDescription>
              Search contractors, purchase orders, timecards, invoices, and SOWs from a single interface
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                placeholder="Search by name, number, description, or any field..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={isSearching || !searchQuery.trim()} className="gap-2">
                <Search className="h-4 w-4" />
                Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {totalResults > 0 && (
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-base px-3 py-1">
              {totalResults} Results Found
            </Badge>
          </div>
        )}

        {isSearching && (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="mt-4 text-muted-foreground">Searching...</p>
          </div>
        )}

        {!isSearching && totalResults > 0 && (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all">All ({totalResults})</TabsTrigger>
              <TabsTrigger value="contractors">
                <Users className="h-4 w-4 mr-1" />({contractors.length})
              </TabsTrigger>
              <TabsTrigger value="pos">
                <FileText className="h-4 w-4 mr-1" />({pos.length})
              </TabsTrigger>
              <TabsTrigger value="timecards">
                <Clock className="h-4 w-4 mr-1" />({timecards.length})
              </TabsTrigger>
              <TabsTrigger value="invoices">
                <Receipt className="h-4 w-4 mr-1" />({invoices.length})
              </TabsTrigger>
              <TabsTrigger value="sows">
                <FileEdit className="h-4 w-4 mr-1" />({sows.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4 mt-6">
              {contractors.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Contractors ({contractors.length})
                  </h3>
                  {contractors.map((contractor) => (
                    <Card
                      key={contractor.id}
                      className="hover:border-primary cursor-pointer transition-colors"
                      onClick={() => go({ to: `/contractors/${contractor.id}` })}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">
                            {contractor.firstName} {contractor.lastName}
                          </p>
                          <p className="text-sm text-muted-foreground">{contractor.email}</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {pos.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Purchase Orders ({pos.length})
                  </h3>
                  {pos.map((po) => (
                    <Card
                      key={po.id}
                      className="hover:border-primary cursor-pointer transition-colors"
                      onClick={() => go({ to: `/purchase-orders/${po.id}` })}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">{po.poNumber}</p>
                          <p className="text-sm text-muted-foreground">{po.description}</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {timecards.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Timecards ({timecards.length})
                  </h3>
                  {timecards.slice(0, 5).map((timecard) => (
                    <Card
                      key={timecard.id}
                      className="hover:border-primary cursor-pointer transition-colors"
                      onClick={() => go({ to: `/timecards/${timecard.id}` })}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">Timecard #{timecard.id}</p>
                          <p className="text-sm text-muted-foreground">{timecard.taskDescription}</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {invoices.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Receipt className="h-4 w-4" />
                    Invoices ({invoices.length})
                  </h3>
                  {invoices.slice(0, 5).map((invoice) => (
                    <Card
                      key={invoice.id}
                      className="hover:border-primary cursor-pointer transition-colors"
                      onClick={() => go({ to: `/invoices/${invoice.id}` })}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">{invoice.invoiceNumber}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
                              invoice.actualAmount,
                            )}
                          </p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {sows.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold flex items-center gap-2">
                    <FileEdit className="h-4 w-4" />
                    Statement of Works ({sows.length})
                  </h3>
                  {sows.slice(0, 5).map((sow) => (
                    <Card
                      key={sow.id}
                      className="hover:border-primary cursor-pointer transition-colors"
                      onClick={() => go({ to: `/statement-of-works/${sow.id}` })}>
                      <CardContent className="p-4 flex items-center justify-between">
                        <div>
                          <p className="font-medium">{sow.sowNumber}</p>
                          <p className="text-sm text-muted-foreground">{sow.terms.substring(0, 60)}...</p>
                        </div>
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="contractors" className="space-y-2 mt-6">
              {contractors.map((contractor) => (
                <Card
                  key={contractor.id}
                  className="hover:border-primary cursor-pointer transition-colors"
                  onClick={() => go({ to: `/contractors/${contractor.id}` })}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        {contractor.firstName} {contractor.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground">{contractor.email}</p>
                      <p className="text-sm text-muted-foreground">{contractor.location}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="pos" className="space-y-2 mt-6">
              {pos.map((po) => (
                <Card
                  key={po.id}
                  className="hover:border-primary cursor-pointer transition-colors"
                  onClick={() => go({ to: `/purchase-orders/${po.id}` })}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium">{po.poNumber}</p>
                      <p className="text-sm text-muted-foreground">{po.description}</p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline">{po.type}</Badge>
                        <Badge>{po.status}</Badge>
                      </div>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="timecards" className="space-y-2 mt-6">
              {timecards.map((timecard) => (
                <Card
                  key={timecard.id}
                  className="hover:border-primary cursor-pointer transition-colors"
                  onClick={() => go({ to: `/timecards/${timecard.id}` })}>
                  <CardContent className="p-4">
                    <p className="font-medium">Timecard #{timecard.id}</p>
                    <p className="text-sm text-muted-foreground">{timecard.taskDescription}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="outline">{timecard.hours}h</Badge>
                      <Badge>{timecard.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="invoices" className="space-y-2 mt-6">
              {invoices.map((invoice) => (
                <Card
                  key={invoice.id}
                  className="hover:border-primary cursor-pointer transition-colors"
                  onClick={() => go({ to: `/invoices/${invoice.id}` })}>
                  <CardContent className="p-4">
                    <p className="font-medium">{invoice.invoiceNumber}</p>
                    <p className="text-sm text-muted-foreground">
                      Amount:{" "}
                      {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
                        invoice.actualAmount,
                      )}
                    </p>
                    <Badge className="mt-2">{invoice.status}</Badge>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="sows" className="space-y-2 mt-6">
              {sows.map((sow) => (
                <Card
                  key={sow.id}
                  className="hover:border-primary cursor-pointer transition-colors"
                  onClick={() => go({ to: `/statement-of-works/${sow.id}` })}>
                  <CardContent className="p-4">
                    <p className="font-medium">{sow.sowNumber}</p>
                    <p className="text-sm text-muted-foreground">{sow.terms.substring(0, 100)}...</p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="outline">{sow.type}</Badge>
                      <Badge>{sow.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        )}

        {!isSearching && totalResults === 0 && searchQuery && (
          <div className="text-center py-12">
            <div className="rounded-full bg-muted p-6 inline-block mb-4">
              <Search className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Results Found</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              No matches found for "<strong>{searchQuery}</strong>". Try different keywords or search terms.
            </p>
          </div>
        )}
      </div>
    </ListView>
  );
}
