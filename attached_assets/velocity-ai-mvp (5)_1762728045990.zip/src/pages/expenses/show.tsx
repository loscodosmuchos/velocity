import { useShow, useOne } from "@refinedev/core";
import { useParams } from "react-router";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download } from "lucide-react";
import type { ContractorExpense, Contractor, PurchaseOrder } from "@/types";

export function ExpenseShowPage() {
  const { id } = useParams<{ id: string }>();
  const { query } = useShow<ContractorExpense>({
    resource: "contractor_expenses",
    id,
  });

  const expense = query.data?.data;

  const { data: contractorData } = useOne<Contractor>({
    resource: "contractors",
    id: expense?.contractorId,
    queryOptions: { enabled: !!expense?.contractorId },
  });

  const { data: poData } = useOne<PurchaseOrder>({
    resource: "purchaseorders",
    id: expense?.purchaseOrderId,
    queryOptions: { enabled: !!expense?.purchaseOrderId },
  });

  if (!expense) return null;

  return (
    <ShowView>
      <ShowViewHeader title={`Expense #${expense.id}`} />
      <div className="p-4 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Expense Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Contractor</p>
                <p className="font-medium">
                  {contractorData?.data
                    ? `${contractorData.data.firstName} ${contractorData.data.lastName}`
                    : expense.contractorId}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Purchase Order</p>
                <p className="font-medium">{poData?.data?.poNumber || expense.purchaseOrderId}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Expense Type</p>
                <Badge variant="outline">{expense.expenseType}</Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <Badge
                  variant={
                    expense.status === "Paid"
                      ? "default"
                      : expense.status === "Approved"
                        ? "secondary"
                        : expense.status === "Rejected"
                          ? "destructive"
                          : "outline"
                  }>
                  {expense.status}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Amount</p>
                <p className="font-medium text-lg">
                  {expense.currency} {expense.amount.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Expense Date</p>
                <p className="font-medium">{new Date(expense.expenseDate).toLocaleDateString()}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-muted-foreground">Description</p>
                <p className="font-medium">{expense.description}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {expense.receiptUrl && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Receipt
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <p className="text-sm">{expense.receiptFileName || "Receipt Document"}</p>
                <Button variant="outline" size="sm" asChild>
                  <a href={expense.receiptUrl} target="_blank" rel="noopener noreferrer">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {expense.rejectionReason && (
          <Card className="border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="text-red-900">Rejection Reason</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-800">{expense.rejectionReason}</p>
            </CardContent>
          </Card>
        )}

        {expense.notes && (
          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{expense.notes}</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Timeline</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm text-muted-foreground">Submitted</p>
              <p className="font-medium">{new Date(expense.submittedDate).toLocaleString()}</p>
            </div>
            {expense.approvedDate && (
              <div>
                <p className="text-sm text-muted-foreground">Approved</p>
                <p className="font-medium">{new Date(expense.approvedDate).toLocaleString()}</p>
              </div>
            )}
            {expense.paidDate && (
              <div>
                <p className="text-sm text-muted-foreground">Paid</p>
                <p className="font-medium">{new Date(expense.paidDate).toLocaleString()}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ShowView>
  );
}
