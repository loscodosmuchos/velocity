import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import { useMany } from "@refinedev/core";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableFilterDropdownText } from "@/components/refine-ui/data-table/data-table-filter";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { CreateButton } from "@/components/refine-ui/buttons/create";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal } from "lucide-react";
import type { ContractorExpense, Contractor, PurchaseOrder } from "@/types";
import { useNavigate } from "react-router";

export function ExpensesListPage() {
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<ContractorExpense>[]>(
    () => [
      {
        accessorKey: "id",
        header: "ID",
        cell: ({ row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/expenses/show/${row.original.id}`)}>
              {row.original.id}
            </span>
          );
        },
      },
      {
        accessorKey: "contractorId",
        header: "Contractor",
        cell: ({ getValue, table }) => {
          const contractorId = getValue<number>();
          const contractors = (table.options.meta as any)?.contractors || [];
          const contractor = contractors.find((c: Contractor) => c.id === contractorId);
          return contractor ? `${contractor.firstName} ${contractor.lastName}` : contractorId;
        },
        meta: {
          filterComponent: DataTableFilterDropdownText,
        },
      },
      {
        accessorKey: "expenseType",
        header: "Type",
        cell: ({ getValue }) => {
          const type = getValue<string>();
          return <Badge variant="outline">{type}</Badge>;
        },
      },
      {
        accessorKey: "description",
        header: "Description",
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ getValue, row }) => {
          const amount = getValue<number>();
          const currency = row.original.currency;
          return `${currency} ${amount.toFixed(2)}`;
        },
      },
      {
        accessorKey: "expenseDate",
        header: "Date",
        cell: ({ getValue }) => {
          const date = getValue<string>();
          return new Date(date).toLocaleDateString();
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return (
            <Badge
              variant={
                status === "Paid"
                  ? "default"
                  : status === "Approved"
                    ? "secondary"
                    : status === "Rejected"
                      ? "destructive"
                      : "outline"
              }>
              {status}
            </Badge>
          );
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => (
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/expenses/show/${row.original.id}`);
              }}>
              View
            </Button>
          </div>
        ),
      },
    ],
    [navigate],
  );

  const table = useTable<ContractorExpense>({
    columns,
    refineCoreProps: {
      resource: "contractor_expenses",
    },
  });

  const contractorIds = table.getRowModel().rows.map((row) => row.original.contractorId);
  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: { enabled: contractorIds.length > 0 },
  });

  table.options.meta = {
    ...table.options.meta,
    contractors: contractorsData?.data || [],
  };

  return (
    <ListView>
      <ListViewHeader title="Expense Management">
        <CreateButton resource="expenses" />
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
