import { useMemo, useState } from "react";
import { useTable } from "@refinedev/react-table";
import { useUpdateMany } from "@refinedev/core";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Check, X } from "lucide-react";
import type { ContractorExpense } from "@/types";

export function BulkApproveExpensesPage() {
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");

  const { mutate: updateMany, isPending } = useUpdateMany();

  const columns = useMemo<ColumnDef<ContractorExpense>[]>(
    () => [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected()}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => {
              row.toggleSelected(!!value);
              const id = row.original.id;
              setSelectedIds((prev) => (value ? [...prev, id] : prev.filter((i) => i !== id)));
            }}
          />
        ),
      },
      {
        accessorKey: "id",
        header: "ID",
      },
      {
        accessorKey: "expenseType",
        header: "Type",
        cell: ({ getValue }) => {
          const type = getValue<string>();
          return <Badge variant="outline">{type}</Badge>;
        },
      },
      {
        accessorKey: "description",
        header: "Description",
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ getValue, row }) => {
          const amount = getValue<number>();
          const currency = row.original.currency;
          return `${currency} ${amount.toFixed(2)}`;
        },
      },
      {
        accessorKey: "expenseDate",
        header: "Date",
        cell: ({ getValue }) => {
          const date = getValue<string>();
          return new Date(date).toLocaleDateString();
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return <Badge variant="secondary">{status}</Badge>;
        },
      },
    ],
    [],
  );

  const table = useTable<ContractorExpense>({
    columns,
    refineCoreProps: {
      resource: "contractor_expenses",
      filters: {
        permanent: [{ field: "status", operator: "eq", value: "Submitted" }],
      },
    },
    enableRowSelection: true,
  });

  const handleBulkApprove = () => {
    updateMany(
      {
        resource: "contractor_expenses",
        ids: selectedIds,
        values: {
          status: "Approved",
          approvedDate: new Date().toISOString(),
        },
      },
      {
        onSuccess: () => {
          setShowApproveDialog(false);
          setSelectedIds([]);
          table.resetRowSelection();
        },
      },
    );
  };

  const handleBulkReject = () => {
    updateMany(
      {
        resource: "contractor_expenses",
        ids: selectedIds,
        values: {
          status: "Rejected",
          rejectedDate: new Date().toISOString(),
          rejectionReason,
        },
      },
      {
        onSuccess: () => {
          setShowRejectDialog(false);
          setRejectionReason("");
          setSelectedIds([]);
          table.resetRowSelection();
        },
      },
    );
  };

  return (
    <>
      <ListView>
        <ListViewHeader title="Bulk Approve Expenses">
          <div className="flex gap-2">
            <Button variant="default" disabled={selectedIds.length === 0} onClick={() => setShowApproveDialog(true)}>
              <Check className="h-4 w-4 mr-2" />
              Approve ({selectedIds.length})
            </Button>
            <Button variant="destructive" disabled={selectedIds.length === 0} onClick={() => setShowRejectDialog(true)}>
              <X className="h-4 w-4 mr-2" />
              Reject ({selectedIds.length})
            </Button>
          </div>
        </ListViewHeader>
        <DataTable table={table} />
      </ListView>

      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Expenses</DialogTitle>
            <DialogDescription>Are you sure you want to approve {selectedIds.length} expense(s)?</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleBulkApprove} disabled={isPending}>
              {isPending ? "Approving..." : "Approve"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Expenses</DialogTitle>
            <DialogDescription>Provide a reason for rejecting {selectedIds.length} expense(s).</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="reason">Rejection Reason</Label>
            <Textarea
              id="reason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Explain why these expenses are being rejected"
              className="mt-2"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleBulkReject} disabled={isPending || !rejectionReason.trim()}>
              {isPending ? "Rejecting..." : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
