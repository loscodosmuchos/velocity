import { useForm } from "@refinedev/react-hook-form";
import { useSelect, useGetIdentity, type HttpError } from "@refinedev/core";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { useNavigate } from "react-router";
import type { ContractorExpense, PurchaseOrder } from "@/types";

const expenseFormSchema = z.object({
  contractorId: z.number(),
  purchaseOrderId: z.number({ required_error: "Purchase order is required" }),
  expenseType: z.enum(["Travel", "Materials", "Equipment", "Meals", "Lodging", "Other"]),
  description: z.string().min(5, "Description must be at least 5 characters"),
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  expenseDate: z.string(),
  receiptFileName: z.string().optional(),
  notes: z.string().optional(),
  currency: z.enum(["USD", "CAD", "EUR", "GBP"]),
});

type ExpenseFormValues = z.infer<typeof expenseFormSchema>;

export function CreateExpensePage() {
  const navigate = useNavigate();
  const { data: identity } = useGetIdentity<{ id: number }>();

  const {
    refineCore: { onFinish, formLoading },
    ...form
  } = useForm<ContractorExpense, HttpError, ExpenseFormValues>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      contractorId: identity?.id || 0,
      expenseType: "Travel",
      amount: 0,
      expenseDate: new Date().toISOString().split("T")[0],
      currency: "USD",
      description: "",
    },
    refineCoreProps: {
      resource: "contractor_expenses",
      action: "create",
      redirect: "list",
    },
  });

  const { options: poOptions } = useSelect<PurchaseOrder>({
    resource: "purchaseorders",
    optionLabel: "poNumber",
    optionValue: "id",
    filters: [{ field: "status", operator: "eq", value: "Active" }],
  });

  function onSubmit(values: ExpenseFormValues) {
    onFinish({
      ...values,
    });
  }

  return (
    <CreateView>
      <CreateViewHeader title="Submit Expense" />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-4 max-w-2xl">
          <FormField
            control={form.control}
            name="purchaseOrderId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Purchase Order</FormLabel>
                <Select onValueChange={(value) => field.onChange(Number(value))}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select PO" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {poOptions?.map((option) => (
                      <SelectItem key={option.value} value={String(option.value)}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="expenseType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expense Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Travel">Travel</SelectItem>
                    <SelectItem value="Materials">Materials</SelectItem>
                    <SelectItem value="Equipment">Equipment</SelectItem>
                    <SelectItem value="Meals">Meals</SelectItem>
                    <SelectItem value="Lodging">Lodging</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea placeholder="Describe the expense" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Currency</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="CAD">CAD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="expenseDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expense Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes (Optional)</FormLabel>
                <FormControl>
                  <Textarea placeholder="Additional notes" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => navigate("/expenses")}>
              Cancel
            </Button>
            <Button type="submit" disabled={formLoading}>
              {formLoading ? "Submitting..." : "Submit Expense"}
            </Button>
          </div>
        </form>
      </Form>
    </CreateView>
  );
}
