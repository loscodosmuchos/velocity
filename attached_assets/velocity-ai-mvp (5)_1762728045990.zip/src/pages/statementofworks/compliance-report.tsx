import { useList } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Progress } from "@/components/ui/progress";
import { FileText, AlertTriangle, CheckCircle, Download } from "lucide-react";
import { useNavigate } from "react-router";
import type { StatementOfWork, ChangeOrder } from "../../types";

export function SOWComplianceReportPage() {
  const navigate = useNavigate();

  const { data: sowsData, isLoading: sowsLoading } = useList<StatementOfWork>({
    resource: "statementofworks",
    pagination: { pageSize: 1000 },
  });

  const { data: changeOrdersData, isLoading: coLoading } = useList<ChangeOrder>({
    resource: "changeorders",
    pagination: { pageSize: 1000 },
  });

  const sows = sowsData?.data ?? [];
  const changeOrders = changeOrdersData?.data ?? [];

  // Filter Fixed Fee SOWs
  const fixedFeeSows = sows.filter((sow) => sow.type === "Fixed Fee");

  // Calculate metrics
  const totalFixedFeeSows = fixedFeeSows.length;
  const activeFixedFeeSows = fixedFeeSows.filter((sow) => sow.status === "Active").length;
  const completedFixedFeeSows = fixedFeeSows.filter((sow) => sow.status === "Completed").length;

  // Compliance issues
  const overBudgetSows = fixedFeeSows.filter((sow) => sow.invoicedAmount > sow.totalValue);
  const nearingLimitSows = fixedFeeSows.filter(
    (sow) => sow.invoicedAmount > sow.totalValue * 0.9 && sow.invoicedAmount <= sow.totalValue,
  );

  // Change orders by SOW
  const getChangeOrdersForSow = (sowId: number) => changeOrders.filter((co) => co.sowId === sowId);

  const sowsWithChangeOrders = fixedFeeSows.filter((sow) => getChangeOrdersForSow(sow.id).length > 0);

  const totalChangeOrderImpact = changeOrders
    .filter((co) => co.status === "Approved")
    .reduce((sum, co) => sum + co.requestedChange, 0);

  const handleExport = () => {
    const reportData = fixedFeeSows.map((sow) => {
      const cos = getChangeOrdersForSow(sow.id);
      const approvedCos = cos.filter((co) => co.status === "Approved");
      const totalCoImpact = approvedCos.reduce((sum, co) => sum + co.requestedChange, 0);
      const utilization = ((sow.invoicedAmount / sow.totalValue) * 100).toFixed(1);
      const compliance = sow.invoicedAmount <= sow.totalValue ? "Compliant" : "Over Budget";

      return {
        SOW: sow.sowNumber,
        Status: sow.status,
        TotalValue: sow.totalValue,
        Invoiced: sow.invoicedAmount,
        Remaining: sow.remainingValue,
        Utilization: `${utilization}%`,
        ChangeOrders: cos.length,
        ChangeOrderImpact: totalCoImpact,
        Compliance: compliance,
      };
    });

    const csv = [Object.keys(reportData[0]).join(","), ...reportData.map((row) => Object.values(row).join(","))].join(
      "\n",
    );

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sow-compliance-report-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <ListView>
      <ListViewHeader title="SOW Compliance Report - Fixed Fee Projects" canCreate={false} />
      <LoadingOverlay loading={sowsLoading || coLoading}>
        <div className="space-y-6 p-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Fixed Fee SOWs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{totalFixedFeeSows}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active SOWs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{activeFixedFeeSows}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Compliance Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-600">{overBudgetSows.length}</div>
                <div className="text-xs text-muted-foreground mt-1">Over budget</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total CO Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">${Math.abs(totalChangeOrderImpact).toLocaleString()}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  From {changeOrders.filter((co) => co.status === "Approved").length} approved COs
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Export Button */}
          <div className="flex justify-end">
            <Button onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>

          {/* Over Budget SOWs */}
          {overBudgetSows.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-600">
                  <AlertTriangle className="h-5 w-5" />
                  Over Budget SOWs ({overBudgetSows.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {overBudgetSows.map((sow) => {
                    const overAmount = sow.invoicedAmount - sow.totalValue;
                    const overPercent = ((overAmount / sow.totalValue) * 100).toFixed(1);
                    return (
                      <div
                        key={sow.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                        onClick={() => navigate(`/statement-of-works/${sow.id}`)}>
                        <div className="flex-1">
                          <div className="font-medium">{sow.sowNumber}</div>
                          <div className="text-sm text-muted-foreground">
                            Budgeted: ${sow.totalValue.toLocaleString()} | Invoiced: $
                            {sow.invoicedAmount.toLocaleString()}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-orange-600">+${overAmount.toLocaleString()}</div>
                          <div className="text-xs text-muted-foreground">{overPercent}% over</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Nearing Limit SOWs */}
          {nearingLimitSows.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-600">
                  <AlertTriangle className="h-5 w-5" />
                  Nearing Budget Limit ({nearingLimitSows.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {nearingLimitSows.map((sow) => {
                    const utilization = ((sow.invoicedAmount / sow.totalValue) * 100).toFixed(1);
                    return (
                      <div
                        key={sow.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                        onClick={() => navigate(`/statement-of-works/${sow.id}`)}>
                        <div className="flex-1">
                          <div className="font-medium">{sow.sowNumber}</div>
                          <div className="text-sm text-muted-foreground mb-2">
                            ${sow.invoicedAmount.toLocaleString()} of ${sow.totalValue.toLocaleString()}
                          </div>
                          <Progress value={parseFloat(utilization)} className="h-2" />
                        </div>
                        <div className="text-right ml-4">
                          <div className="font-bold text-yellow-600">{utilization}%</div>
                          <div className="text-xs text-muted-foreground">utilized</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* All Fixed Fee SOWs */}
          <Card>
            <CardHeader>
              <CardTitle>All Fixed Fee SOWs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {fixedFeeSows.map((sow) => {
                  const cos = getChangeOrdersForSow(sow.id);
                  const approvedCos = cos.filter((co) => co.status === "Approved");
                  const totalCoImpact = approvedCos.reduce((sum, co) => sum + co.requestedChange, 0);
                  const utilization = ((sow.invoicedAmount / sow.totalValue) * 100).toFixed(1);
                  const isCompliant = sow.invoicedAmount <= sow.totalValue;

                  return (
                    <div
                      key={sow.id}
                      className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer"
                      onClick={() => navigate(`/statement-of-works/${sow.id}`)}>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="font-medium text-lg">{sow.sowNumber}</div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge
                              variant={
                                sow.status === "Active"
                                  ? "default"
                                  : sow.status === "Completed"
                                    ? "secondary"
                                    : "outline"
                              }>
                              {sow.status}
                            </Badge>
                            {isCompliant ? (
                              <Badge variant="outline" className="text-green-600">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Compliant
                              </Badge>
                            ) : (
                              <Badge variant="destructive">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Over Budget
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">${sow.totalValue.toLocaleString()}</div>
                          <div className="text-xs text-muted-foreground">Total Value</div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="text-muted-foreground">Invoiced</div>
                          <div className="font-medium">${sow.invoicedAmount.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Remaining</div>
                          <div className="font-medium">${sow.remainingValue.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Utilization</div>
                          <div className="font-medium">{utilization}%</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Change Orders</div>
                          <div className="font-medium">
                            {cos.length} ({approvedCos.length} approved)
                          </div>
                        </div>
                      </div>

                      {totalCoImpact !== 0 && (
                        <div className="mt-3 p-2 bg-muted rounded text-sm">
                          <span className="text-muted-foreground">Change Order Impact:</span>{" "}
                          <span className={`font-bold ${totalCoImpact > 0 ? "text-orange-600" : "text-green-600"}`}>
                            {totalCoImpact > 0 ? "+" : ""}${totalCoImpact.toLocaleString()}
                          </span>
                        </div>
                      )}

                      <Progress value={parseFloat(utilization)} className="h-2 mt-3" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </LoadingOverlay>
    </ListView>
  );
}
