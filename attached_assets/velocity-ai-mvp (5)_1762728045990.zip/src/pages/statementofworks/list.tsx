import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useList } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import {
  DataTableFilterDropdownText,
  DataTableFilterCombobox,
  DataTableFilterDropdownNumeric,
} from "@/components/refine-ui/data-table/data-table-filter";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { StatementOfWork, Contractor } from "../../types";

export function StatementOfWorksListPage() {
  const { data: contractorsData } = useList<Contractor>({
    resource: "contractors",
  });
  const contractors = contractorsData?.data ?? [];

  const columns = useMemo<ColumnDef<StatementOfWork>[]>(
    () => [
      {
        id: "sowNumber",
        accessorKey: "sowNumber",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>SOW Number</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownText
                  defaultOperator="contains"
                  column={column}
                  table={table}
                  placeholder="Filter by SOW number"
                />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="font-medium text-blue-600">{row.original.sowNumber}</div>;
        },
      },
      {
        id: "contractorId",
        accessorKey: "contractorId",
        size: 200,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Contractor</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={contractors.map((item) => ({
                  label: `${item.firstName} ${item.lastName}`,
                  value: item.id.toString(),
                }))}
              />
            </div>
          );
        },
        cell: ({ getValue }) => {
          const contractorId = getValue<number>();
          const contractor = contractors.find((item) => item.id === contractorId);
          return contractor ? (
            <div>{`${contractor.firstName} ${contractor.lastName}`}</div>
          ) : (
            <div className="text-muted-foreground">-</div>
          );
        },
      },
      {
        id: "type",
        accessorKey: "type",
        size: 160,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Type</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Fixed Fee", value: "Fixed Fee" },
                  { label: "Deliverables Based", value: "Deliverables Based" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          return (
            <Badge variant={row.original.type === "Fixed Fee" ? "default" : "secondary"}>{row.original.type}</Badge>
          );
        },
      },
      {
        id: "totalValue",
        accessorKey: "totalValue",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Total Value</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownNumeric
                  defaultOperator="eq"
                  column={column}
                  table={table}
                  placeholder="Filter by value"
                />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="font-medium">${row.original.totalValue.toLocaleString()}</div>;
        },
      },
      {
        id: "invoicedAmount",
        accessorKey: "invoicedAmount",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Invoiced</span>
              <div>
                <DataTableSorter column={column} />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="text-muted-foreground">${row.original.invoicedAmount.toLocaleString()}</div>;
        },
      },
      {
        id: "remainingValue",
        accessorKey: "remainingValue",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Remaining</span>
              <div>
                <DataTableSorter column={column} />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          const remaining = row.original.remainingValue;
          const isLow = remaining < row.original.totalValue * 0.2;
          return <div className={cn("font-medium", isLow && "text-orange-600")}>${remaining.toLocaleString()}</div>;
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Status</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Draft", value: "Draft" },
                  { label: "Active", value: "Active" },
                  { label: "Completed", value: "Completed" },
                  { label: "Cancelled", value: "Cancelled" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          const status = row.original.status;
          const variant =
            status === "Active"
              ? "default"
              : status === "Completed"
                ? "secondary"
                : status === "Draft"
                  ? "outline"
                  : "destructive";
          return <Badge variant={variant}>{status}</Badge>;
        },
      },
      {
        id: "startDate",
        accessorKey: "startDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Start Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="text-sm">{new Date(row.original.startDate).toLocaleDateString()}</div>;
        },
      },
      {
        id: "endDate",
        accessorKey: "endDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>End Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="text-sm">{new Date(row.original.endDate).toLocaleDateString()}</div>;
        },
      },
      {
        id: "actions",
        size: 84,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => {
          return <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>;
        },
        cell: ({ row }) => {
          const sow = row.original;
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className={cn(
                    "flex",
                    "size-8",
                    "border",
                    "rounded-full",
                    "text-muted-foreground",
                    "data-[state=open]:bg-muted",
                    "data-[state=open]:text-foreground",
                    "mx-auto",
                  )}>
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="flex flex-col gap-2 p-2">
                <ShowButton
                  variant="ghost"
                  size="sm"
                  className="w-full items-center justify-start"
                  resource="statementofworks"
                  recordItemId={sow.id}
                />
                <EditButton
                  variant="ghost"
                  size="sm"
                  className="w-full items-center justify-start"
                  resource="statementofworks"
                  recordItemId={sow.id}
                />
              </DropdownMenuContent>
            </DropdownMenu>
          );
        },
      },
    ],
    [contractors],
  );

  const table = useTable<StatementOfWork>({
    columns,
    refineCoreProps: {},
    initialState: {
      columnPinning: {
        left: [],
        right: ["actions"],
      },
    },
  });

  return (
    <ListView>
      <ListViewHeader canCreate={true} />
      <DataTable table={table} />
    </ListView>
  );
}
