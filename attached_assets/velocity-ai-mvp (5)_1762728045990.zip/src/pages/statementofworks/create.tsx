import { type HttpError, useBack } from "@refinedev/core";
import { useForm } from "@refinedev/react-hook-form";
import { useSelect } from "@refinedev/core";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Loader2, ChevronsUpDown, Check } from "lucide-react";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { cn } from "@/lib/utils";
import type { StatementOfWork, Contractor, PurchaseOrder } from "../../types";

const sowFormSchema = z.object({
  sowNumber: z.string().min(1, { message: "SOW number is required." }),
  contractorId: z.number({ required_error: "Contractor is required." }),
  purchaseOrderId: z.number().optional().nullable(),
  type: z.enum(["Fixed Fee", "Deliverables Based"], {
    required_error: "Please select a type.",
  }),
  totalValue: z.number({ required_error: "Total value is required." }).min(0, "Total value must be positive."),
  startDate: z.string().min(1, { message: "Start date is required." }),
  endDate: z.string().min(1, { message: "End date is required." }),
  terms: z.string().min(10, { message: "Terms must be at least 10 characters." }),
  deliverables: z.string().optional(),
  paymentSchedule: z.string().optional(),
  status: z.enum(["Draft", "Active", "Completed", "Cancelled"]),
});

type SOWFormValues = z.infer<typeof sowFormSchema>;

export function CreateStatementOfWorkPage() {
  const back = useBack();

  const {
    refineCore: { onFinish, formLoading },
    ...form
  } = useForm<StatementOfWork, HttpError, SOWFormValues>({
    resolver: zodResolver(sowFormSchema),
    defaultValues: {
      sowNumber: `SOW-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999)).padStart(4, "0")}`,
      totalValue: 0,
      status: "Draft",
      type: "Fixed Fee",
      terms: "",
      deliverables: "",
      paymentSchedule: "",
      startDate: new Date().toISOString().split("T")[0],
      endDate: "",
    },
    refineCoreProps: {
      resource: "statementofworks",
      action: "create",
      redirect: "show",
    },
  });

  const { options: contractorOptions, queryResult: contractorsQuery } = useSelect<Contractor>({
    resource: "contractors",
    optionValue: "id",
    optionLabel: (item: Contractor) => `${item.firstName} ${item.lastName}`,
  });

  const { options: poOptions, queryResult: posQuery } = useSelect<PurchaseOrder>({
    resource: "purchaseorders",
    optionValue: "id",
    optionLabel: "poNumber",
  });

  function onSubmit(values: SOWFormValues) {
    const payload = {
      ...values,
      invoicedAmount: 0,
      remainingValue: values.totalValue,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onFinish(payload as any);
  }

  const selectedType = form.watch("type");

  return (
    <CreateView>
      <CreateViewHeader title="Create Statement of Work" />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="sowNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SOW Number</FormLabel>
                  <FormControl>
                    <Input placeholder="SOW-2024-0001" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contractorId"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Contractor</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          className={cn("justify-between", !field.value && "text-muted-foreground")}
                          type="button"
                          disabled={contractorsQuery.isLoading}>
                          {field.value
                            ? contractorOptions?.find(
                                (option: { value: number; label: string }) => option.value === field.value,
                              )?.label
                            : "Select contractor..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0">
                      <Command>
                        <CommandInput placeholder="Search contractor..." />
                        <CommandList>
                          <CommandEmpty>No contractor found.</CommandEmpty>
                          <CommandGroup>
                            {contractorOptions?.map((option: { value: number; label: string }) => (
                              <CommandItem
                                value={option.label}
                                key={option.value}
                                onSelect={() => {
                                  form.setValue("contractorId", option.value as number);
                                }}>
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    option.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {option.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="purchaseOrderId"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Purchase Order (Optional)</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          className={cn("justify-between", !field.value && "text-muted-foreground")}
                          type="button"
                          disabled={posQuery.isLoading}>
                          {field.value
                            ? poOptions?.find(
                                (option: { value: number; label: string }) => option.value === field.value,
                              )?.label
                            : "Select PO..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0">
                      <Command>
                        <CommandInput placeholder="Search PO..." />
                        <CommandList>
                          <CommandEmpty>No PO found.</CommandEmpty>
                          <CommandGroup>
                            {poOptions?.map((option: { value: number; label: string }) => (
                              <CommandItem
                                value={option.label}
                                key={option.value}
                                onSelect={() => {
                                  form.setValue("purchaseOrderId", option.value as number);
                                }}>
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    option.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {option.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Fixed Fee">Fixed Fee</SelectItem>
                      <SelectItem value="Deliverables Based">Deliverables Based</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="totalValue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Total Value ($)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="100000"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Draft">Draft</SelectItem>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                      <SelectItem value="Cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="terms"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Payment Terms</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter payment terms and conditions..."
                    className="resize-none"
                    rows={3}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {selectedType === "Deliverables Based" && (
            <FormField
              control={form.control}
              name="deliverables"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deliverables</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the deliverables..." className="resize-none" rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="paymentSchedule"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Payment Schedule (Optional)</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Describe the payment schedule..."
                    className="resize-none"
                    rows={2}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => back()} disabled={formLoading}>
              Cancel
            </Button>
            <Button type="submit" disabled={formLoading}>
              {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create SOW
            </Button>
          </div>
        </form>
      </Form>
    </CreateView>
  );
}
