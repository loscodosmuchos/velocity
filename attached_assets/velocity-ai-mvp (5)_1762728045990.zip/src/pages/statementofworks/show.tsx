import { useOne, useList } from "@refinedev/core";
import { useParams, useNavigate } from "react-router";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, AlertCircle, Brain, Sparkles } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { StatementOfWork, Contractor, PurchaseOrder, ChangeOrder } from "../../types";
import { MultiLensAnalyzer } from "../ai/multi-lens-analyzer";
import { useState } from "react";

export function StatementOfWorkShowPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showMultiLens, setShowMultiLens] = useState(false);

  const { data, isLoading } = useOne<StatementOfWork>({
    resource: "statementofworks",
    id: id,
  });

  const sow = data?.data;

  const { data: contractorData } = useOne<Contractor>({
    resource: "contractors",
    id: sow?.contractorId,
    queryOptions: {
      enabled: !!sow?.contractorId,
    },
  });

  const { data: poData } = useOne<PurchaseOrder>({
    resource: "purchaseorders",
    id: sow?.purchaseOrderId,
    queryOptions: {
      enabled: !!sow?.purchaseOrderId,
    },
  });

  const { data: changeOrdersData } = useList<ChangeOrder>({
    resource: "changeorders",
    filters: [
      {
        field: "sowId",
        operator: "eq",
        value: id,
      },
    ],
    queryOptions: {
      enabled: !!id,
    },
  });

  const contractor = contractorData?.data;
  const po = poData?.data;
  const changeOrders = changeOrdersData?.data ?? [];

  const utilizationPercent = sow ? ((sow.invoicedAmount / sow.totalValue) * 100).toFixed(1) : "0";

  const totalChangeOrderAmount = changeOrders
    .filter((co) => co.status === "Approved")
    .reduce((sum, co) => sum + co.requestedChange, 0);

  const hasVariance = sow && sow.invoicedAmount > sow.totalValue * 0.9;

  return (
    <ShowView>
      <ShowViewHeader title={`SOW: ${sow?.sowNumber || id}`} />
      <LoadingOverlay loading={isLoading}>
        <div className="space-y-6 p-4">
          {/* Alerts */}
          {hasVariance && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This SOW has utilized over 90% of its total value. Consider reviewing budget and change orders.
              </AlertDescription>
            </Alert>
          )}

          {/* AI Analysis Banner */}
          {!showMultiLens && sow && (
            <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-blue-500/5">
              <CardContent className="flex items-center justify-between p-6">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Brain className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      AI-Powered Contract Analysis Available
                      <Badge variant="secondary" className="text-xs">
                        <Sparkles className="h-3 w-3 mr-1" />
                        NEW
                      </Badge>
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Analyze this SOW from 5 stakeholder perspectives: Legal, Financial, Operational, Vendor,
                      Compliance
                    </p>
                  </div>
                </div>
                <Button onClick={() => setShowMultiLens(true)} size="lg" className="gap-2">
                  <Brain className="h-4 w-4" />
                  Run Analysis
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Multi-Lens Analysis Section */}
          {showMultiLens && sow && (
            <Tabs defaultValue="details" className="space-y-6">
              <TabsList>
                <TabsTrigger value="details">SOW Details</TabsTrigger>
                <TabsTrigger value="ai-analysis" className="gap-2">
                  <Brain className="h-4 w-4" />
                  AI Analysis
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details">
                {/* Main Info */}
                <Card>
                  <CardHeader>
                    <CardTitle>SOW Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">SOW Number</div>
                        <div className="font-medium text-lg">{sow?.sowNumber}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Type</div>
                        <Badge variant={sow?.type === "Fixed Fee" ? "default" : "secondary"}>{sow?.type}</Badge>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Status</div>
                        <Badge
                          variant={
                            sow?.status === "Active"
                              ? "default"
                              : sow?.status === "Completed"
                                ? "secondary"
                                : sow?.status === "Draft"
                                  ? "outline"
                                  : "destructive"
                          }>
                          {sow?.status}
                        </Badge>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Contractor</div>
                        <div className="font-medium">
                          {contractor ? `${contractor.firstName} ${contractor.lastName}` : "-"}
                        </div>
                        {contractor && (
                          <Button
                            variant="link"
                            size="sm"
                            className="p-0 h-auto"
                            onClick={() => navigate(`/contractors/${contractor.id}`)}>
                            View Profile
                          </Button>
                        )}
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Purchase Order</div>
                        <div className="font-medium">{po?.poNumber || "Not Linked"}</div>
                        {po && (
                          <Button
                            variant="link"
                            size="sm"
                            className="p-0 h-auto"
                            onClick={() => navigate(`/purchase-orders/${po.id}`)}>
                            View PO
                          </Button>
                        )}
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Duration</div>
                        <div className="font-medium">
                          {sow &&
                            `${new Date(sow.startDate).toLocaleDateString()} - ${new Date(sow.endDate).toLocaleDateString()}`}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Financial Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Financial Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div>
                        <div className="text-sm text-muted-foreground">Total Value</div>
                        <div className="text-2xl font-bold">${sow?.totalValue.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Invoiced Amount</div>
                        <div className="text-2xl font-bold text-blue-600">${sow?.invoicedAmount.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">{utilizationPercent}% utilized</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Remaining Value</div>
                        <div className="text-2xl font-bold text-green-600">${sow?.remainingValue.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Change Orders Impact</div>
                        <div
                          className={`text-2xl font-bold ${
                            totalChangeOrderAmount > 0 ? "text-orange-600" : "text-muted-foreground"
                          }`}>
                          {totalChangeOrderAmount > 0 ? "+" : ""}${totalChangeOrderAmount.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Terms */}
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Terms</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap">{sow?.terms}</p>
                  </CardContent>
                </Card>

                {/* Deliverables (if applicable) */}
                {sow?.deliverables && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Deliverables</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm whitespace-pre-wrap">{sow.deliverables}</p>
                    </CardContent>
                  </Card>
                )}

                {/* Payment Schedule (if provided) */}
                {sow?.paymentSchedule && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Schedule</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm whitespace-pre-wrap">{sow.paymentSchedule}</p>
                    </CardContent>
                  </Card>
                )}

                {/* Change Orders */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Change Orders ({changeOrders.length})</CardTitle>
                    <Button size="sm" onClick={() => navigate(`/change-orders/create?sowId=${id}`)}>
                      <FileText className="h-4 w-4 mr-2" />
                      Request Change Order
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {changeOrders.length === 0 ? (
                      <div className="text-center text-muted-foreground py-8">
                        No change orders recorded for this SOW.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {changeOrders.map((co) => (
                          <div
                            key={co.id}
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                            onClick={() => navigate(`/change-orders/${co.id}`)}>
                            <div className="flex-1">
                              <div className="font-medium">{co.changeOrderNumber}</div>
                              <div className="text-sm text-muted-foreground">
                                {co.justification.substring(0, 80)}...
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <div
                                  className={`font-bold ${co.requestedChange > 0 ? "text-orange-600" : "text-green-600"}`}>
                                  {co.requestedChange > 0 ? "+" : ""}${co.requestedChange.toLocaleString()}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {new Date(co.requestedDate).toLocaleDateString()}
                                </div>
                              </div>
                              <Badge
                                variant={
                                  co.status === "Approved"
                                    ? "default"
                                    : co.status === "Pending"
                                      ? "secondary"
                                      : "destructive"
                                }>
                                {co.status}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="ai-analysis">
                <MultiLensAnalyzer
                  contractContent={sow.terms || ""}
                  contractName={sow.sowNumber}
                  contractId={sow.sowNumber}
                  documentType="SOW"
                  vendorId={sow.contractorId}
                />
              </TabsContent>
            </Tabs>
          )}

          {!showMultiLens && (
            <>
              {/* Main Info */}
              <Card>
                <CardHeader>
                  <CardTitle>SOW Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">SOW Number</div>
                      <div className="font-medium text-lg">{sow?.sowNumber}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Type</div>
                      <Badge variant={sow?.type === "Fixed Fee" ? "default" : "secondary"}>{sow?.type}</Badge>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Status</div>
                      <Badge
                        variant={
                          sow?.status === "Active"
                            ? "default"
                            : sow?.status === "Completed"
                              ? "secondary"
                              : sow?.status === "Draft"
                                ? "outline"
                                : "destructive"
                        }>
                        {sow?.status}
                      </Badge>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Contractor</div>
                      <div className="font-medium">
                        {contractor ? `${contractor.firstName} ${contractor.lastName}` : "-"}
                      </div>
                      {contractor && (
                        <Button
                          variant="link"
                          size="sm"
                          className="p-0 h-auto"
                          onClick={() => navigate(`/contractors/${contractor.id}`)}>
                          View Profile
                        </Button>
                      )}
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Purchase Order</div>
                      <div className="font-medium">{po?.poNumber || "Not Linked"}</div>
                      {po && (
                        <Button
                          variant="link"
                          size="sm"
                          className="p-0 h-auto"
                          onClick={() => navigate(`/purchase-orders/${po.id}`)}>
                          View PO
                        </Button>
                      )}
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Duration</div>
                      <div className="font-medium">
                        {sow &&
                          `${new Date(sow.startDate).toLocaleDateString()} - ${new Date(sow.endDate).toLocaleDateString()}`}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Financial Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Financial Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div>
                      <div className="text-sm text-muted-foreground">Total Value</div>
                      <div className="text-2xl font-bold">${sow?.totalValue.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Invoiced Amount</div>
                      <div className="text-2xl font-bold text-blue-600">${sow?.invoicedAmount.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">{utilizationPercent}% utilized</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Remaining Value</div>
                      <div className="text-2xl font-bold text-green-600">${sow?.remainingValue.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Change Orders Impact</div>
                      <div
                        className={`text-2xl font-bold ${
                          totalChangeOrderAmount > 0 ? "text-orange-600" : "text-muted-foreground"
                        }`}>
                        {totalChangeOrderAmount > 0 ? "+" : ""}${totalChangeOrderAmount.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Terms */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment Terms</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm whitespace-pre-wrap">{sow?.terms}</p>
                </CardContent>
              </Card>

              {/* Deliverables (if applicable) */}
              {sow?.deliverables && (
                <Card>
                  <CardHeader>
                    <CardTitle>Deliverables</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap">{sow.deliverables}</p>
                  </CardContent>
                </Card>
              )}

              {/* Payment Schedule (if provided) */}
              {sow?.paymentSchedule && (
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Schedule</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap">{sow.paymentSchedule}</p>
                  </CardContent>
                </Card>
              )}

              {/* Change Orders */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Change Orders ({changeOrders.length})</CardTitle>
                  <Button size="sm" onClick={() => navigate(`/change-orders/create?sowId=${id}`)}>
                    <FileText className="h-4 w-4 mr-2" />
                    Request Change Order
                  </Button>
                </CardHeader>
                <CardContent>
                  {changeOrders.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      No change orders recorded for this SOW.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {changeOrders.map((co) => (
                        <div
                          key={co.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer"
                          onClick={() => navigate(`/change-orders/${co.id}`)}>
                          <div className="flex-1">
                            <div className="font-medium">{co.changeOrderNumber}</div>
                            <div className="text-sm text-muted-foreground">{co.justification.substring(0, 80)}...</div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div
                                className={`font-bold ${co.requestedChange > 0 ? "text-orange-600" : "text-green-600"}`}>
                                {co.requestedChange > 0 ? "+" : ""}${co.requestedChange.toLocaleString()}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {new Date(co.requestedDate).toLocaleDateString()}
                              </div>
                            </div>
                            <Badge
                              variant={
                                co.status === "Approved"
                                  ? "default"
                                  : co.status === "Pending"
                                    ? "secondary"
                                    : "destructive"
                              }>
                              {co.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </LoadingOverlay>
    </ShowView>
  );
}
