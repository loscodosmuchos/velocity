import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useList, type HttpError } from "@refinedev/core";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Plus, Users } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { EquipmentKit } from "@/types";

export default function EquipmentKitsPage() {
  const columns = useMemo<ColumnDef<EquipmentKit>[]>(
    () => [
      {
        id: "name",
        accessorKey: "name",
        header: "Kit Name",
        cell: ({ getValue, row }) => {
          const name = getValue<string>();
          const roleType = row.original.roleType;
          return (
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="font-medium">{name}</p>
                <p className="text-xs text-muted-foreground">{roleType}</p>
              </div>
            </div>
          );
        },
      },
      {
        id: "description",
        accessorKey: "description",
        header: "Description",
        cell: ({ getValue }) => {
          return <span className="text-sm">{getValue<string>()}</span>;
        },
      },
      {
        id: "assetCount",
        accessorKey: "assetIds",
        header: "Assets",
        cell: ({ getValue }) => {
          const assetIds = getValue<number[]>();
          return (
            <Badge variant="secondary">
              {assetIds.length} {assetIds.length === 1 ? "item" : "items"}
            </Badge>
          );
        },
      },
      {
        id: "totalValue",
        accessorKey: "totalValue",
        header: "Total Value",
        cell: ({ getValue }) => {
          return <span className="font-medium">${getValue<number>().toLocaleString()}</span>;
        },
      },
      {
        id: "status",
        accessorKey: "isActive",
        header: "Status",
        cell: ({ getValue }) => {
          const isActive = getValue<boolean>();
          return <Badge variant={isActive ? "default" : "secondary"}>{isActive ? "Active" : "Inactive"}</Badge>;
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const kit = row.original;
          return (
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  View Details
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{kit.name}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Description</p>
                    <p className="text-sm mt-1">{kit.description}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Role Type</p>
                    <Badge className="mt-1">{kit.roleType}</Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                    <p className="text-lg font-bold mt-1">${kit.totalValue.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Assets Included</p>
                    <div className="mt-2 space-y-1">
                      {kit.assetIds.map((id) => (
                        <Badge key={id} variant="outline">
                          Asset #{id}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button className="w-full">
                    <Users className="mr-2 h-4 w-4" />
                    Assign to New Hire
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          );
        },
      },
    ],
    [],
  );

  const table = useTable<EquipmentKit, HttpError>({
    columns,
    refineCoreProps: {
      resource: "equipmentKits",
    },
  });

  const { data: kitsData } = useList<EquipmentKit>({
    resource: "equipmentKits",
  });

  const stats = useMemo(() => {
    if (!kitsData?.data) return { total: 0, active: 0, totalValue: 0 };

    return {
      total: kitsData.data.length,
      active: kitsData.data.filter((k) => k.isActive).length,
      totalValue: kitsData.data.reduce((sum, k) => sum + k.totalValue, 0),
    };
  }, [kitsData?.data]);

  return (
    <ListView>
      <ListViewHeader title="Equipment Kits" />

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Kits</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stats.total}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Kits</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stats.active}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Value</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">${stats.totalValue.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Usage Guide */}
      <Card className="mb-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200">
        <CardHeader>
          <CardTitle className="text-lg">📦 New Hire Onboarding Workflow</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>
            <strong>Step 1:</strong> Manager selects appropriate kit based on role (Engineer, Sales, Manager, etc.)
          </p>
          <p>
            <strong>Step 2:</strong> System auto-allocates all kit assets to new employee
          </p>
          <p>
            <strong>Step 3:</strong> Confirmation email sent with checkout details
          </p>
          <p className="text-muted-foreground italic mt-2">
            💡 VINessa can also handle kit assignments via voice: "Check out engineer kit for John Smith"
          </p>
        </CardContent>
      </Card>

      <DataTable table={table} />
    </ListView>
  );
}
