import { useOne, useMany } from "@refinedev/core";
import { useParams } from "react-router";
import { useNavigate } from "react-router";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Package, Calendar, DollarSign, Wrench, User, Building, ArrowRight } from "lucide-react";
import type { Asset, Contractor, Room } from "@/types";

export default function AssetsShowPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const { data: assetData, isLoading } = useOne<Asset>({
    resource: "assets",
    id: id!,
  });

  const asset = assetData?.data;

  // Fetch assigned contractor or room
  const { data: contractorData } = useMany<Contractor>({
    resource: "contractors",
    ids: asset?.assignedEmployeeId ? [asset.assignedEmployeeId] : [],
    queryOptions: {
      enabled: !!asset?.assignedEmployeeId,
    },
  });

  const { data: roomData } = useMany<Room>({
    resource: "rooms",
    ids: asset?.assignedRoomId ? [asset.assignedRoomId] : [],
    queryOptions: {
      enabled: !!asset?.assignedRoomId,
    },
  });

  if (isLoading || !asset) {
    return <div>Loading...</div>;
  }

  const contractor = contractorData?.data?.[0];
  const room = roomData?.data?.[0];

  // Calculate current value with depreciation
  const yearsSincePurchase =
    (new Date().getTime() - new Date(asset.purchaseDate).getTime()) / (1000 * 60 * 60 * 24 * 365);
  const depreciationAmount = asset.value * (asset.depreciationRate / 100) * yearsSincePurchase;
  const currentValue = Math.max(0, asset.value - depreciationAmount);

  return (
    <ShowView>
      <ShowViewHeader title={asset.name} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Main Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Asset Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Barcode</p>
                  <p className="font-mono text-sm mt-1">{asset.barcode}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Serial Number</p>
                  <p className="font-mono text-sm mt-1">{asset.serialNumber}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Category</p>
                  <Badge variant="outline" className="mt-1">
                    {asset.category}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge className="mt-1">{asset.status}</Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Condition</p>
                  <Badge variant="secondary" className="mt-1">
                    {asset.condition}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Warranty</p>
                  <p className="text-sm mt-1">{asset.warranty}</p>
                </div>
              </div>

              {asset.notes && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Notes</p>
                    <p className="text-sm mt-1">{asset.notes}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Assignment Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {asset.assignmentType === "employee" ? <User className="h-5 w-5" /> : <Building className="h-5 w-5" />}
                Current Assignment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {asset.assignmentType && (contractor || room) ? (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge>{asset.assignmentType === "employee" ? "Employee" : "Room"}</Badge>
                  </div>
                  {asset.assignmentType === "employee" && contractor ? (
                    <div>
                      <p className="font-semibold">
                        {contractor.firstName} {contractor.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground">{contractor.jobDescription}</p>
                      <p className="text-sm text-muted-foreground">{contractor.email}</p>
                    </div>
                  ) : room ? (
                    <div>
                      <p className="font-semibold">{room.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {room.building} - Room {room.roomNumber}
                      </p>
                      <p className="text-sm text-muted-foreground">{room.roomType}</p>
                    </div>
                  ) : null}
                  <div className="mt-3">
                    <p className="text-sm font-medium text-muted-foreground">Assigned Date</p>
                    <p className="text-sm">{new Date(asset.assignedDate!).toLocaleDateString()}</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <Badge variant="secondary">Unassigned</Badge>
                  <p className="text-sm mt-2">This asset is currently available</p>
                </div>
              )}

              <Button className="w-full" variant="outline" onClick={() => navigate(`/assets/transfer/${asset.id}`)}>
                <ArrowRight className="mr-2 h-4 w-4" />
                Transfer Asset
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Financial & Maintenance */}
        <div className="space-y-6">
          {/* Financial */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <DollarSign className="h-5 w-5" />
                Financial
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Purchase Value</p>
                <p className="text-2xl font-bold">${asset.value.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current Value</p>
                <p className="text-2xl font-bold text-green-600">${currentValue.toLocaleString()}</p>
              </div>
              <Separator />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Depreciation Rate</p>
                <p className="text-sm">{asset.depreciationRate}% per year</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Depreciation</p>
                <p className="text-sm text-red-600">-${depreciationAmount.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          {/* Maintenance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wrench className="h-5 w-5" />
                Maintenance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Maintenance Cost</p>
                <p className="text-xl font-bold">${asset.maintenanceCost.toLocaleString()}</p>
              </div>
              {asset.lastMaintenanceDate && (
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Last Maintenance</p>
                  <p className="text-sm">{new Date(asset.lastMaintenanceDate).toLocaleDateString()}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Calendar className="h-5 w-5" />
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Purchase Date</p>
                <p className="text-sm">{new Date(asset.purchaseDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Age</p>
                <p className="text-sm">{yearsSincePurchase.toFixed(1)} years</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </ShowView>
  );
}
