import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany, type HttpError } from "@refinedev/core";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { DataTableFilterDropdownText } from "@/components/refine-ui/data-table/data-table-filter";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Barcode, Upload } from "lucide-react";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { DeleteButton } from "@/components/refine-ui/buttons/delete";
import type { Asset, Contractor } from "@/types";
import { useNavigate } from "react-router";

export default function AssetsListPage() {
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<Asset>[]>(
    () => [
      {
        id: "barcode",
        accessorKey: "barcode",
        header: ({ column }) => <DataTableSorter column={column} title="Barcode" />,
        cell: ({ getValue, row }) => {
          const barcode = getValue<string>();
          return (
            <div
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => navigate(`/assets/show/${row.original.id}`)}>
              <Barcode className="h-4 w-4 text-muted-foreground" />
              <span className="font-mono text-sm hover:underline">{barcode}</span>
            </div>
          );
        },
        meta: {
          filterOperator: "contains",
        },
      },
      {
        id: "name",
        accessorKey: "name",
        header: ({ column }) => <DataTableSorter column={column} title="Asset Name" />,
        cell: ({ getValue, row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/assets/show/${row.original.id}`)}>
              {getValue<string>()}
            </span>
          );
        },
        meta: {
          filterOperator: "contains",
        },
      },
      {
        id: "category",
        accessorKey: "category",
        header: "Category",
        cell: ({ getValue }) => {
          const category = getValue<string>();
          return <Badge variant="outline">{category}</Badge>;
        },
      },
      {
        id: "serialNumber",
        accessorKey: "serialNumber",
        header: "Serial Number",
        cell: ({ getValue }) => {
          return <span className="font-mono text-xs">{getValue<string>()}</span>;
        },
      },
      {
        id: "status",
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          const variants = {
            Available: "default" as const,
            Assigned: "secondary" as const,
            Maintenance: "destructive" as const,
            Retired: "outline" as const,
          };
          return <Badge variant={variants[status as keyof typeof variants]}>{status}</Badge>;
        },
      },
      {
        id: "condition",
        accessorKey: "condition",
        header: "Condition",
        cell: ({ getValue }) => {
          const condition = getValue<string>();
          return <Badge variant="outline">{condition}</Badge>;
        },
      },
      {
        id: "assignedToContractorId",
        accessorKey: "assignedToContractorId",
        header: "Assigned To",
        cell: ({ getValue, table }) => {
          const contractorId = getValue<number | undefined>();
          if (!contractorId) return <span className="text-muted-foreground">-</span>;

          const meta = table.options.meta as {
            contractorsData: { data: Contractor[] } | undefined;
          };

          const contractor = meta?.contractorsData?.data?.find((c) => c.id === contractorId);

          return contractor ? `${contractor.firstName} ${contractor.lastName}` : contractorId;
        },
      },
      {
        id: "value",
        accessorKey: "value",
        header: ({ column }) => <DataTableSorter column={column} title="Value" />,
        cell: ({ getValue }) => {
          return <span className="font-medium">${getValue<number>().toLocaleString()}</span>;
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const asset = row.original;
          return (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/assets/show/${asset.id}`);
                }}>
                View
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/assets/edit/${asset.id}`);
                }}>
                Edit
              </Button>
            </div>
          );
        },
      },
    ],
    [navigate],
  );

  const table = useTable<Asset, HttpError>({
    columns,
    refineCoreProps: {
      resource: "assets",
    },
  });

  const {
    refineCore: {
      tableQuery: { data: tableData },
    },
    setOptions,
  } = table;

  // Fetch contractors for assigned assets
  const contractorIds = useMemo(
    () =>
      tableData?.data
        ?.map((asset) => asset.assignedToContractorId)
        .filter((id): id is number => id !== undefined && id !== null) ?? [],
    [tableData?.data],
  );

  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: {
      enabled: contractorIds.length > 0,
    },
  });

  // Set table meta with contractor data
  useMemo(() => {
    setOptions((prev) => ({
      ...prev,
      meta: {
        ...prev.meta,
        contractorsData,
      },
    }));
  }, [contractorsData, setOptions]);

  return (
    <ListView>
      <ListViewHeader title="Asset Management" />
      <div className="flex gap-2 mb-4">
        <Button variant="outline" onClick={() => navigate("/assets/scan")}>
          <Barcode className="mr-2 h-4 w-4" />
          Scan Barcode
        </Button>
        <Button variant="outline" onClick={() => navigate("/assets/upload")}>
          <Upload className="mr-2 h-4 w-4" />
          Upload Image
        </Button>
      </div>
      <DataTable table={table} />
    </ListView>
  );
}
