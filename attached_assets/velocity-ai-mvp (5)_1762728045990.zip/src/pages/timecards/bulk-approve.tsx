import { useState, useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany, useUpdateMany, useNotification } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { CheckCircle, XCircle, Clock } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Timecard, Contractor, PurchaseOrder } from "@/types";

export function BulkApproveTimecardsPage() {
  const { open } = useNotification();
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");

  const { mutate: updateMany, isLoading: isUpdating } = useUpdateMany();

  const columns = useMemo<ColumnDef<Timecard>[]>(
    () => [
      {
        id: "select",
        size: 50,
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getRowModel().rows.length > 0 &&
              table.getRowModel().rows.every((row) => selectedIds.includes(row.original.id))
            }
            onCheckedChange={(checked) => {
              if (checked) {
                setSelectedIds(table.getRowModel().rows.map((row) => row.original.id));
              } else {
                setSelectedIds([]);
              }
            }}
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={selectedIds.includes(row.original.id)}
            onCheckedChange={(checked) => {
              if (checked) {
                setSelectedIds([...selectedIds, row.original.id]);
              } else {
                setSelectedIds(selectedIds.filter((id) => id !== row.original.id));
              }
            }}
          />
        ),
      },
      {
        id: "id",
        accessorKey: "id",
        size: 80,
        header: ({ column }) => (
          <div className="flex items-center gap-1">
            <span>ID</span>
            <DataTableSorter column={column} />
          </div>
        ),
      },
      {
        id: "contractorId",
        accessorKey: "contractorId",
        size: 200,
        header: "Contractor",
        cell: ({ row, table }) => {
          const contractorId = row.original.contractorId;
          const contractors = (table.options.meta as any)?.contractors || [];
          const contractor = contractors.find((c: Contractor) => c.id === contractorId);
          return contractor ? `${contractor.firstName} ${contractor.lastName}` : `Contractor #${contractorId}`;
        },
      },
      {
        id: "date",
        accessorKey: "date",
        size: 120,
        header: "Date",
      },
      {
        id: "hours",
        accessorKey: "hours",
        size: 100,
        header: "Hours",
        cell: ({ row }) => `${row.original.hours}h`,
      },
      {
        id: "totalAmount",
        accessorKey: "totalAmount",
        size: 120,
        header: "Amount",
        cell: ({ row }) =>
          new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
          }).format(row.original.totalAmount),
      },
      {
        id: "taskDescription",
        accessorKey: "taskDescription",
        size: 300,
        header: "Task Description",
        enableSorting: false,
        cell: ({ row }) => {
          const desc = row.original.taskDescription;
          return desc.length > 50 ? `${desc.substring(0, 50)}...` : desc;
        },
      },
    ],
    [selectedIds],
  );

  const table = useTable<Timecard>({
    columns,
    refineCoreProps: {
      resource: "timecards",
      filters: {
        permanent: [
          {
            field: "status",
            operator: "eq",
            value: "Pending",
          },
        ],
      },
    },
  });

  const contractorIds = table.getRowModel().rows.map((row) => row.original.contractorId);
  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: {
      enabled: contractorIds.length > 0,
    },
  });

  const poIds = table.getRowModel().rows.map((row) => row.original.purchaseOrderId);
  const { data: purchaseOrdersData } = useMany<PurchaseOrder>({
    resource: "purchaseorders",
    ids: poIds,
    queryOptions: {
      enabled: poIds.length > 0,
    },
  });

  table.options.meta = {
    ...table.options.meta,
    contractors: contractorsData?.data || [],
    purchaseOrders: purchaseOrdersData?.data || [],
  };

  const handleBulkApprove = () => {
    if (selectedIds.length === 0) {
      open?.({
        type: "error",
        message: "No timecards selected",
        description: "Please select at least one timecard to approve",
      });
      return;
    }

    updateMany(
      {
        resource: "timecards",
        ids: selectedIds,
        values: {
          status: "Approved",
          approvedDate: new Date().toISOString(),
          approvedBy: 1, // Mock manager ID
        },
      },
      {
        onSuccess: () => {
          open?.({
            type: "success",
            message: "Timecards approved",
            description: `Successfully approved ${selectedIds.length} timecard${selectedIds.length > 1 ? "s" : ""}`,
          });
          setSelectedIds([]);
          table.refineCore.tableQuery.refetch();
        },
      },
    );
  };

  const handleBulkReject = () => {
    if (selectedIds.length === 0) {
      open?.({
        type: "error",
        message: "No timecards selected",
        description: "Please select at least one timecard to reject",
      });
      return;
    }

    if (!rejectionReason.trim()) {
      open?.({
        type: "error",
        message: "Rejection reason required",
        description: "Please provide a reason for rejecting these timecards",
      });
      return;
    }

    updateMany(
      {
        resource: "timecards",
        ids: selectedIds,
        values: {
          status: "Rejected",
          rejectionReason: rejectionReason,
        },
      },
      {
        onSuccess: () => {
          open?.({
            type: "success",
            message: "Timecards rejected",
            description: `Successfully rejected ${selectedIds.length} timecard${selectedIds.length > 1 ? "s" : ""}`,
          });
          setSelectedIds([]);
          setRejectionReason("");
          setShowRejectDialog(false);
          table.refineCore.tableQuery.refetch();
        },
      },
    );
  };

  const totalAmount = useMemo(() => {
    return table
      .getRowModel()
      .rows.filter((row) => selectedIds.includes(row.original.id))
      .reduce((sum, row) => sum + row.original.totalAmount, 0);
  }, [selectedIds, table]);

  return (
    <ListView>
      <ListViewHeader canCreate={false}>
        <div className="flex items-center gap-3">
          {selectedIds.length > 0 && (
            <>
              <Badge variant="secondary" className="text-base px-3 py-1">
                {selectedIds.length} Selected
              </Badge>
              <Badge variant="outline" className="text-base px-3 py-1">
                Total: {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(totalAmount)}
              </Badge>
              <div className="flex gap-2">
                <Button onClick={handleBulkApprove} disabled={isUpdating} size="sm" className="gap-2">
                  <CheckCircle className="h-4 w-4" />
                  Approve Selected
                </Button>
                <Button
                  onClick={() => setShowRejectDialog(true)}
                  disabled={isUpdating}
                  variant="destructive"
                  size="sm"
                  className="gap-2">
                  <XCircle className="h-4 w-4" />
                  Reject Selected
                </Button>
              </div>
            </>
          )}
        </div>
      </ListViewHeader>

      {table.getRowModel().rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center">
          <div className="rounded-full bg-muted p-6 mb-4">
            <Clock className="h-12 w-12 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Pending Timecards</h3>
          <p className="text-muted-foreground max-w-md">
            All timecards have been reviewed. New submissions will appear here for approval.
          </p>
        </div>
      ) : (
        <DataTable table={table} />
      )}

      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject Timecards</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to reject {selectedIds.length} timecard{selectedIds.length > 1 ? "s" : ""}. Please provide a
              reason for rejection.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4">
            <Label htmlFor="rejection-reason">Rejection Reason</Label>
            <Textarea
              id="rejection-reason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Enter reason for rejection..."
              className="mt-2"
              rows={4}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleBulkReject} className="bg-destructive text-destructive-foreground">
              Reject Timecards
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </ListView>
  );
}
