import { useShow, useOne, useUpdate } from "@refinedev/core";
import { useParams } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { ListButton } from "@/components/refine-ui/buttons/list";
import { CheckCircle, XCircle, Clock } from "lucide-react";
import { useState } from "react";
import type { Timecard, Contractor, PurchaseOrder } from "@/types";

export function TimecardShowPage() {
  const { id } = useParams();
  const [rejectionReason, setRejectionReason] = useState("");

  const { queryResult } = useShow<Timecard>({
    resource: "timecards",
    id,
  });

  const { data, isLoading } = queryResult;
  const timecard = data?.data;

  const { data: contractorData } = useOne<Contractor>({
    resource: "contractors",
    id: timecard?.contractorId || 0,
    queryOptions: {
      enabled: !!timecard?.contractorId,
    },
  });

  const { data: purchaseOrderData } = useOne<PurchaseOrder>({
    resource: "purchaseorders",
    id: timecard?.purchaseOrderId || 0,
    queryOptions: {
      enabled: !!timecard?.purchaseOrderId,
    },
  });

  const { mutate: updateTimecard, isLoading: isUpdating } = useUpdate();

  const handleApprove = () => {
    if (!timecard) return;
    updateTimecard({
      resource: "timecards",
      id: timecard.id,
      values: {
        ...timecard,
        status: "Approved",
        approvedBy: 1, // Mock manager ID
        approvedDate: new Date().toISOString().split("T")[0],
      },
      successNotification: {
        message: "Timecard approved successfully",
        type: "success",
      },
    });
  };

  const handleReject = () => {
    if (!timecard || !rejectionReason) return;
    updateTimecard({
      resource: "timecards",
      id: timecard.id,
      values: {
        ...timecard,
        status: "Rejected",
        approvedBy: 1, // Mock manager ID
        rejectionReason,
      },
      successNotification: {
        message: "Timecard rejected",
        type: "success",
      },
    });
  };

  const contractor = contractorData?.data;
  const purchaseOrder = purchaseOrderData?.data;

  const statusVariant =
    timecard?.status === "Approved" ? "default" : timecard?.status === "Pending" ? "secondary" : "destructive";

  const statusIcon =
    timecard?.status === "Approved" ? (
      <CheckCircle className="h-4 w-4" />
    ) : timecard?.status === "Pending" ? (
      <Clock className="h-4 w-4" />
    ) : (
      <XCircle className="h-4 w-4" />
    );

  return (
    <ShowView>
      <ShowViewHeader>
        <ListButton />
        {timecard?.status === "Pending" && <EditButton />}
      </ShowViewHeader>
      <LoadingOverlay loading={isLoading}>
        <div className="p-4 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Timecard #{id}</CardTitle>
                <Badge variant={statusVariant} className="flex items-center gap-1">
                  {statusIcon}
                  {timecard?.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Contractor</Label>
                  <p className="font-medium">
                    {contractor ? `${contractor.firstName} ${contractor.lastName}` : "Loading..."}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Purchase Order</Label>
                  <p className="font-medium">{purchaseOrder?.poNumber || "Loading..."}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Date</Label>
                  <p className="font-medium">{timecard?.date}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Hours Worked</Label>
                  <p className="font-medium">{timecard?.hours}h</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Hourly Rate</Label>
                  <p className="font-medium">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(timecard?.hourlyRate || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Total Amount</Label>
                  <p className="font-medium text-lg">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(timecard?.totalAmount || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Submitted Date</Label>
                  <p className="font-medium">{timecard?.submittedDate}</p>
                </div>
                {timecard?.approvedDate && (
                  <div>
                    <Label className="text-muted-foreground">
                      {timecard.status === "Approved" ? "Approved Date" : "Decision Date"}
                    </Label>
                    <p className="font-medium">{timecard.approvedDate}</p>
                  </div>
                )}
              </div>

              <div>
                <Label className="text-muted-foreground">Task Description</Label>
                <p className="mt-2 p-3 bg-muted rounded-md">{timecard?.taskDescription}</p>
              </div>

              {timecard?.rejectionReason && (
                <div>
                  <Label className="text-muted-foreground text-destructive">Rejection Reason</Label>
                  <p className="mt-2 p-3 bg-destructive/10 rounded-md text-destructive">{timecard.rejectionReason}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {timecard?.status === "Pending" && (
            <Card>
              <CardHeader>
                <CardTitle>Manager Approval</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Button onClick={handleApprove} disabled={isUpdating} className="flex-1">
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Approve Timecard
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rejectionReason">Rejection Reason (if rejecting)</Label>
                  <Textarea
                    id="rejectionReason"
                    placeholder="Provide reason for rejection..."
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    rows={3}
                  />
                  <Button
                    onClick={handleReject}
                    disabled={isUpdating || !rejectionReason}
                    variant="destructive"
                    className="w-full">
                    <XCircle className="mr-2 h-4 w-4" />
                    Reject Timecard
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {purchaseOrder && (
            <Card>
              <CardHeader>
                <CardTitle>PO Budget Check</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-muted-foreground">PO Total</Label>
                    <p className="font-medium">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.totalAmount)}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Remaining Funds</Label>
                    <p className="font-medium">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.remainingFunds)}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">After This Timecard</Label>
                    <p
                      className={`font-medium ${
                        purchaseOrder.remainingFunds - (timecard?.totalAmount || 0) < 0
                          ? "text-destructive"
                          : "text-green-600"
                      }`}>
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.remainingFunds - (timecard?.totalAmount || 0))}
                    </p>
                  </div>
                </div>
                {purchaseOrder.remainingFunds - (timecard?.totalAmount || 0) < 0 && (
                  <div className="mt-4 p-3 bg-destructive/10 text-destructive rounded-md">
                    ⚠️ Warning: Approving this timecard will exceed the PO budget!
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </LoadingOverlay>
    </ShowView>
  );
}
