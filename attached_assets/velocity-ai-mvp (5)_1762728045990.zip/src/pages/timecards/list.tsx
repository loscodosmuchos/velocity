import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany } from "@refinedev/core";
import { useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import {
  DataTableFilterDropdownText,
  DataTableFilterCombobox,
} from "@/components/refine-ui/data-table/data-table-filter";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { cn } from "@/lib/utils";
import type { Timecard, Contractor, PurchaseOrder } from "@/types";

export function TimecardsListPage() {
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<Timecard>[]>(
    () => [
      {
        id: "id",
        accessorKey: "id",
        size: 80,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>ID</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/timecards/show/${row.original.id}`)}>
              {row.original.id}
            </span>
          );
        },
      },
      {
        id: "contractorId",
        accessorKey: "contractorId",
        size: 200,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Contractor</span>
              <DataTableFilterDropdownText
                defaultOperator="eq"
                column={column}
                table={table}
                placeholder="Filter by contractor ID"
              />
            </div>
          );
        },
        cell: ({ row, table }) => {
          const contractorId = row.original.contractorId;
          const contractors = (table.options.meta as any)?.contractors || [];
          const contractor = contractors.find((c: Contractor) => c.id === contractorId);
          return contractor ? `${contractor.firstName} ${contractor.lastName}` : `Contractor #${contractorId}`;
        },
      },
      {
        id: "purchaseOrderId",
        accessorKey: "purchaseOrderId",
        size: 150,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>PO</span>
              <DataTableFilterDropdownText
                defaultOperator="eq"
                column={column}
                table={table}
                placeholder="Filter by PO ID"
              />
            </div>
          );
        },
        cell: ({ row, table }) => {
          const poId = row.original.purchaseOrderId;
          const purchaseOrders = (table.options.meta as any)?.purchaseOrders || [];
          const po = purchaseOrders.find((p: PurchaseOrder) => p.id === poId);
          return po ? po.poNumber : `PO #${poId}`;
        },
      },
      {
        id: "date",
        accessorKey: "date",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
      },
      {
        id: "hours",
        accessorKey: "hours",
        size: 100,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Hours</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return `${row.original.hours}h`;
        },
      },
      {
        id: "totalAmount",
        accessorKey: "totalAmount",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Amount</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
          }).format(row.original.totalAmount);
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Status</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Pending", value: "Pending" },
                  { label: "Approved", value: "Approved" },
                  { label: "Rejected", value: "Rejected" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          const status = row.original.status;
          const variant = status === "Approved" ? "default" : status === "Pending" ? "secondary" : "destructive";
          return <Badge variant={variant}>{status}</Badge>;
        },
      },
      {
        id: "taskDescription",
        accessorKey: "taskDescription",
        size: 300,
        header: "Task Description",
        enableSorting: false,
        enableColumnFilter: false,
      },
      {
        id: "actions",
        size: 84,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => {
          return <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>;
        },
        cell: ({ row }) => {
          const timecard = row.original;
          return (
            <div className="flex items-center gap-2 justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/timecards/show/${timecard.id}`);
                }}>
                View
              </Button>
            </div>
          );
        },
      },
    ],
    [navigate],
  );

  const table = useTable<Timecard>({
    columns,
    refineCoreProps: {
      resource: "timecards",
    },
    initialState: {
      columnPinning: {
        left: [],
        right: ["actions"],
      },
    },
  });

  // Fetch related contractors
  const contractorIds = table.getRowModel().rows.map((row) => row.original.contractorId);
  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: {
      enabled: contractorIds.length > 0,
    },
  });

  // Fetch related purchase orders
  const poIds = table.getRowModel().rows.map((row) => row.original.purchaseOrderId);
  const { data: purchaseOrdersData } = useMany<PurchaseOrder>({
    resource: "purchaseorders",
    ids: poIds,
    queryOptions: {
      enabled: poIds.length > 0,
    },
  });

  // Update table meta with related data
  table.options.meta = {
    ...table.options.meta,
    contractors: contractorsData?.data || [],
    purchaseOrders: purchaseOrdersData?.data || [],
  };

  return (
    <ListView>
      <ListViewHeader canCreate={true} />
      <DataTable table={table} />
    </ListView>
  );
}
