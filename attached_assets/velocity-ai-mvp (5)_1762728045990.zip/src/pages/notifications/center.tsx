import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useUpdate, useGo } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Bell, BellOff, CheckCircle, AlertCircle, Info, Clock, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Notification } from "@/types";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function NotificationCenterPage() {
  const go = useGo();
  const { mutate: updateNotification } = useUpdate();

  const getNotificationIcon = (type: Notification["type"]) => {
    switch (type) {
      case "approval_request":
        return <Clock className="h-4 w-4 text-blue-600" />;
      case "alert":
        return <AlertCircle className="h-4 w-4 text-orange-600" />;
      case "exception":
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      case "info":
        return <Info className="h-4 w-4 text-gray-600" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const columns = useMemo<ColumnDef<Notification>[]>(
    () => [
      {
        id: "type",
        accessorKey: "type",
        size: 60,
        header: "",
        cell: ({ row }) => (
          <div className="flex items-center justify-center">{getNotificationIcon(row.original.type)}</div>
        ),
      },
      {
        id: "title",
        accessorKey: "title",
        size: 250,
        header: "Title",
        cell: ({ row }) => (
          <div className="flex items-center gap-2">
            <span className={cn("font-medium", row.original.status === "unread" && "text-primary")}>
              {row.original.title}
            </span>
            {row.original.status === "unread" && (
              <Badge variant="default" className="h-5 px-1.5 text-xs">
                New
              </Badge>
            )}
          </div>
        ),
      },
      {
        id: "message",
        accessorKey: "message",
        size: 400,
        header: "Message",
        enableSorting: false,
        cell: ({ row }) => <span className="text-sm text-muted-foreground">{row.original.message}</span>,
      },
      {
        id: "createdAt",
        accessorKey: "createdAt",
        size: 150,
        header: "Date",
        cell: ({ row }) => {
          const date = new Date(row.original.createdAt);
          return <span className="text-sm">{date.toLocaleDateString()}</span>;
        },
      },
      {
        id: "actions",
        size: 150,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => <div className="flex w-full items-center justify-center">Actions</div>,
        cell: ({ row }) => {
          const notification = row.original;
          return (
            <div className="flex justify-center gap-2">
              {notification.actionUrl && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (notification.status === "unread") {
                      updateNotification({
                        resource: "notifications",
                        id: notification.id,
                        values: { status: "read", readAt: new Date().toISOString() },
                      });
                    }
                    go({ to: notification.actionUrl! });
                  }}
                  className="gap-2">
                  <ExternalLink className="h-3 w-3" />
                  View
                </Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    •••
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {notification.status === "unread" && (
                    <DropdownMenuItem
                      onClick={() => {
                        updateNotification({
                          resource: "notifications",
                          id: notification.id,
                          values: { status: "read", readAt: new Date().toISOString() },
                        });
                      }}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Mark as Read
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem
                    onClick={() => {
                      updateNotification({
                        resource: "notifications",
                        id: notification.id,
                        values: { status: "archived" },
                      });
                    }}>
                    <BellOff className="h-4 w-4 mr-2" />
                    Archive
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          );
        },
      },
    ],
    [go, updateNotification],
  );

  const table = useTable<Notification>({
    columns,
    refineCoreProps: {
      resource: "notifications",
      filters: {
        permanent: [
          {
            field: "status",
            operator: "in",
            value: ["unread", "read"],
          },
        ],
      },
      sorters: {
        initial: [
          {
            field: "createdAt",
            order: "desc",
          },
        ],
      },
    },
  });

  const unreadCount = table.getRowModel().rows.filter((row) => row.original.status === "unread").length;

  const markAllAsRead = () => {
    const unreadIds = table
      .getRowModel()
      .rows.filter((row) => row.original.status === "unread")
      .map((row) => row.original.id);

    unreadIds.forEach((id) => {
      updateNotification({
        resource: "notifications",
        id,
        values: { status: "read", readAt: new Date().toISOString() },
      });
    });
  };

  return (
    <ListView>
      <ListViewHeader canCreate={false}>
        <div className="flex items-center gap-3">
          {unreadCount > 0 && (
            <>
              <Badge variant="default" className="text-base px-3 py-1">
                {unreadCount} Unread
              </Badge>
              <Button onClick={markAllAsRead} size="sm" variant="outline" className="gap-2">
                <CheckCircle className="h-4 w-4" />
                Mark All as Read
              </Button>
            </>
          )}
        </div>
      </ListViewHeader>

      {table.getRowModel().rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center">
          <div className="rounded-full bg-muted p-6 mb-4">
            <Bell className="h-12 w-12 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Notifications</h3>
          <p className="text-muted-foreground max-w-md">
            You're all caught up! New notifications will appear here when actions require your attention.
          </p>
        </div>
      ) : (
        <DataTable table={table} />
      )}
    </ListView>
  );
}
