import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany, type HttpError } from "@refinedev/core";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import { DataTableFilterDropdownText } from "@/components/refine-ui/data-table/data-table-filter";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { DeleteButton } from "@/components/refine-ui/buttons/delete";
import { CreateButton } from "@/components/refine-ui/buttons/create";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Contractor, Department, Manager } from "@/types";
import { useNavigate } from "react-router";

export function ContractorsListPage() {
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<Contractor>[]>(
    () => [
      {
        id: "firstName",
        accessorKey: "firstName",
        header: ({ column }) => <DataTableSorter column={column} title="First Name" />,
        meta: {
          filterOperator: "contains",
        },
        cell: ({ row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/contractors/show/${row.original.id}`)}>
              {row.getValue("firstName")}
            </span>
          );
        },
      },
      {
        id: "lastName",
        accessorKey: "lastName",
        header: ({ column }) => <DataTableSorter column={column} title="Last Name" />,
        meta: {
          filterOperator: "contains",
        },
        cell: ({ row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/contractors/show/${row.original.id}`)}>
              {row.getValue("lastName")}
            </span>
          );
        },
      },
      {
        id: "email",
        accessorKey: "email",
        header: "Email",
        meta: {
          filterOperator: "contains",
        },
      },
      {
        id: "location",
        accessorKey: "location",
        header: ({ column }) => <DataTableSorter column={column} title="Location" />,
        meta: {
          filterOperator: "eq",
        },
      },
      {
        id: "departmentId",
        accessorKey: "departmentId",
        header: "Department",
        cell: ({ row, table }) => {
          const departmentId = row.getValue("departmentId") as number;
          const departments = (table.options.meta as any)?.departments as Department[] | undefined;
          const department = departments?.find((d) => d.id === departmentId);
          return department?.name || "-";
        },
        meta: {
          filterOperator: "eq",
        },
      },
      {
        id: "hiringManagerId",
        accessorKey: "hiringManagerId",
        header: "Hiring Manager",
        cell: ({ row, table }) => {
          const managerId = row.getValue("hiringManagerId") as number;
          const managers = (table.options.meta as any)?.managers as Manager[] | undefined;
          const manager = managers?.find((m) => m.id === managerId);
          return manager ? `${manager.firstName} ${manager.lastName}` : "-";
        },
        meta: {
          filterOperator: "eq",
        },
      },
      {
        id: "status",
        accessorKey: "status",
        header: ({ column }) => <DataTableSorter column={column} title="Status" />,
        cell: ({ row }) => {
          const status = row.getValue("status") as string;
          const variant = status === "Active" ? "default" : status === "Inactive" ? "secondary" : "outline";
          return <Badge variant={variant}>{status}</Badge>;
        },
        meta: {
          filterOperator: "eq",
        },
      },
      {
        id: "payRate",
        accessorKey: "payRate",
        header: ({ column }) => <DataTableSorter column={column} title="Pay Rate" />,
        cell: ({ row }) => {
          const payRate = row.getValue("payRate") as number;
          return `${payRate.toFixed(2)}/hr`;
        },
      },
      {
        id: "poFundsRemaining",
        accessorKey: "poFundsRemaining",
        header: ({ column }) => <DataTableSorter column={column} title="PO Funds Remaining" />,
        cell: ({ row }) => {
          const funds = row.getValue("poFundsRemaining") as number;
          return `${funds.toLocaleString()}`;
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          const id = row.original.id;
          return (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/contractors/show/${id}`);
                }}>
                View
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/contractors/edit/${id}`);
                }}>
                Edit
              </Button>
            </div>
          );
        },
        enableSorting: false,
        enableColumnFilter: false,
      },
    ],
    [navigate],
  );

  const table = useTable<Contractor, HttpError>({
    columns,
    refineCoreProps: {
      resource: "contractors",
    },
  });

  const departmentIds = table.getRowModel().rows.map((row) => row.original.departmentId);
  const managerIds = [
    ...table.getRowModel().rows.map((row) => row.original.hiringManagerId),
    ...table.getRowModel().rows.map((row) => row.original.assignedManagerId),
  ].filter((id, index, self) => self.indexOf(id) === index);

  const { data: departmentsData } = useMany<Department>({
    resource: "departments",
    ids: departmentIds,
    queryOptions: {
      enabled: departmentIds.length > 0,
    },
  });

  const { data: managersData } = useMany<Manager>({
    resource: "managers",
    ids: managerIds,
    queryOptions: {
      enabled: managerIds.length > 0,
    },
  });

  table.options.meta = {
    ...table.options.meta,
    departments: departmentsData?.data || [],
    managers: managersData?.data || [],
  };

  return (
    <ListView>
      <ListViewHeader title="Contractors">
        <CreateButton resource="contractors" />
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
