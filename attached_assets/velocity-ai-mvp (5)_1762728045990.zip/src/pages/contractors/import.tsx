import { useState } from "react";
import { useCustom, useNotification, useList, useGo } from "@refinedev/core";
import { useImport } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Upload, FileText, CheckCircle, AlertCircle, Download } from "lucide-react";
import type { Contractor, Department, Manager } from "@/types";

export function ImportContractorsPage() {
  const go = useGo();
  const { open } = useNotification();
  const [importProgress, setImportProgress] = useState({ processed: 0, total: 0 });
  const [importErrors, setImportErrors] = useState<string[]>([]);

  const { data: departmentsData } = useList<Department>({ resource: "departments" });
  const { data: managersData } = useList<Manager>({ resource: "managers" });

  const departments = departmentsData?.data || [];
  const managers = managersData?.data || [];

  const { inputProps, isLoading } = useImport<any>({
    onFinish: (results) => {
      open?.({
        type: "success",
        message: "Import completed",
        description: `Successfully imported ${results.succeeded.length} contractor${results.succeeded.length !== 1 ? "s" : ""}`,
      });

      if (results.errored.length > 0) {
        setImportErrors(results.errored.map((err, idx) => `Row ${idx + 1}: Import failed`));
      }

      // Redirect to list after 2 seconds
      setTimeout(() => {
        go({ to: "/contractors" });
      }, 2000);
    },
    onProgress: (progress) => {
      setImportProgress({
        processed: progress.processedAmount,
        total: progress.totalAmount,
      });
    },
    mapData: (item) => {
      // Map CSV data to contractor format
      const departmentId = departments.find((d) => d.name === item.department)?.id;
      const hiringManagerId = managers.find((m) => `${m.firstName} ${m.lastName}` === item.hiringManager)?.id;
      const assignedManagerId = managers.find((m) => `${m.firstName} ${m.lastName}` === item.assignedManager)?.id;

      return {
        firstName: item.firstName,
        lastName: item.lastName,
        email: item.email,
        phone: item.phone,
        payRate: parseFloat(item.payRate) || 0,
        location: item.location,
        jobDescription: item.jobDescription,
        hiringManagerId: hiringManagerId || 1,
        assignedManagerId: assignedManagerId || 1,
        departmentId: departmentId || 1,
        status: item.status || "Active",
        startDate: item.startDate || new Date().toISOString().split("T")[0],
        poFundsRemaining: parseFloat(item.poFundsRemaining) || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    },
  });

  const downloadTemplate = () => {
    const csvContent = `firstName,lastName,email,phone,payRate,location,jobDescription,department,hiringManager,assignedManager,status,startDate,poFundsRemaining
John,Doe,john.doe@example.com,+1-555-123-4567,85,San Francisco,Senior Software Engineer,Engineering,Sarah Johnson,Mike Williams,Active,2024-01-15,50000
Jane,Smith,jane.smith@example.com,+1-555-987-6543,75,New York,UI/UX Designer,Design,John Smith,Emily Johnson,Active,2024-02-01,45000`;

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "contractor_import_template.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const progressPercentage = importProgress.total > 0 ? (importProgress.processed / importProgress.total) * 100 : 0;

  return (
    <ListView>
      <ListViewHeader canCreate={false} />

      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Import Contractors from CSV
            </CardTitle>
            <CardDescription>
              Upload a CSV file to bulk import contractor profiles. The file must include required fields: firstName,
              lastName, email, phone, payRate, location, jobDescription.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center gap-4">
              <Button onClick={downloadTemplate} variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Download Template
              </Button>
              <span className="text-sm text-muted-foreground">Start with our CSV template</span>
            </div>

            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <div className="flex flex-col items-center gap-4">
                <div className="rounded-full bg-primary/10 p-4">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <label htmlFor="csv-upload">
                    <Button disabled={isLoading} className="cursor-pointer gap-2">
                      <Upload className="h-4 w-4" />
                      {isLoading ? "Importing..." : "Select CSV File"}
                    </Button>
                    <input id="csv-upload" className="hidden" {...inputProps} />
                  </label>
                  <p className="text-sm text-muted-foreground mt-2">CSV files only (max 10MB)</p>
                </div>
              </div>
            </div>

            {isLoading && importProgress.total > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Import Progress</span>
                  <span className="text-muted-foreground">
                    {importProgress.processed} / {importProgress.total}
                  </span>
                </div>
                <Progress value={progressPercentage} className="h-2" />
              </div>
            )}

            {importErrors.length > 0 && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Import Errors</AlertTitle>
                <AlertDescription>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    {importErrors.slice(0, 5).map((error, index) => (
                      <li key={index} className="text-sm">
                        {error}
                      </li>
                    ))}
                    {importErrors.length > 5 && <li className="text-sm">... and {importErrors.length - 5} more</li>}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>CSV Format Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Required Fields</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>firstName</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>lastName</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>email</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>phone</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>payRate</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>location</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Optional Fields</h4>
                <div className="flex flex-wrap gap-2">
                  {["department", "hiringManager", "assignedManager", "status", "startDate", "poFundsRemaining"].map(
                    (field) => (
                      <Badge key={field} variant="secondary">
                        {field}
                      </Badge>
                    ),
                  )}
                </div>
              </div>

              <Alert>
                <AlertTitle>Data Validation</AlertTitle>
                <AlertDescription className="text-sm">
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Email addresses must be unique and valid</li>
                    <li>Pay rate must be a positive number</li>
                    <li>Status must be: Active, Inactive, or On Leave</li>
                    <li>Department and manager names must match existing records</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>
      </div>
    </ListView>
  );
}
