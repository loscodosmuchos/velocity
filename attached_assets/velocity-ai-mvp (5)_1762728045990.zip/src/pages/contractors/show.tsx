import { useShow, useMany, type HttpError } from "@refinedev/core";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { Contractor, Department, Manager, Equipment } from "@/types";

export function ContractorsShowPage() {
  const { query } = useShow<Contractor, HttpError>();
  const contractor = query.data?.data;

  const { data: departmentData } = useMany<Department>({
    resource: "departments",
    ids: contractor?.departmentId ? [contractor.departmentId] : [],
    queryOptions: {
      enabled: !!contractor?.departmentId,
    },
  });

  const { data: hiringManagerData } = useMany<Manager>({
    resource: "managers",
    ids: contractor?.hiringManagerId ? [contractor.hiringManagerId] : [],
    queryOptions: {
      enabled: !!contractor?.hiringManagerId,
    },
  });

  const { data: assignedManagerData } = useMany<Manager>({
    resource: "managers",
    ids: contractor?.assignedManagerId ? [contractor.assignedManagerId] : [],
    queryOptions: {
      enabled: !!contractor?.assignedManagerId,
    },
  });

  const { data: equipmentData } = useMany<Equipment>({
    resource: "equipment",
    ids: [],
    queryOptions: {
      enabled: false,
    },
    meta: {
      filters: contractor?.id ? [{ field: "contractorId", operator: "eq", value: contractor.id }] : [],
    },
  });

  const department = departmentData?.data?.[0];
  const hiringManager = hiringManagerData?.data?.[0];
  const assignedManager = assignedManagerData?.data?.[0];
  const equipment = equipmentData?.data || [];

  return (
    <ShowView>
      <ShowViewHeader title={contractor ? `${contractor.firstName} ${contractor.lastName}` : "Contractor Details"} />
      <LoadingOverlay loading={query.isLoading}>
        <div className="p-4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">First Name</p>
                  <p className="text-base">{contractor?.firstName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Last Name</p>
                  <p className="text-base">{contractor?.lastName}</p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Email</p>
                  <p className="text-base">{contractor?.email}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Phone</p>
                  <p className="text-base">{contractor?.phone}</p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Location</p>
                  <p className="text-base">{contractor?.location}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge variant={contractor?.status === "Active" ? "default" : "secondary"}>
                    {contractor?.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Employment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Job Description</p>
                <p className="text-base whitespace-pre-wrap">{contractor?.jobDescription}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pay Rate</p>
                  <p className="text-base">${contractor?.payRate.toFixed(2)}/hr</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Start Date</p>
                  <p className="text-base">
                    {contractor?.startDate ? new Date(contractor.startDate).toLocaleDateString() : "-"}
                  </p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p className="text-base">{department?.name || "-"}</p>
                  {department?.division && (
                    <p className="text-sm text-muted-foreground">Division: {department.division}</p>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">PO Funds Remaining</p>
                  <p className="text-base font-semibold">${contractor?.poFundsRemaining.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Hiring Manager</p>
                  <p className="text-base">
                    {hiringManager ? `${hiringManager.firstName} ${hiringManager.lastName}` : "-"}
                  </p>
                  {hiringManager?.email && <p className="text-sm text-muted-foreground">{hiringManager.email}</p>}
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Assigned Manager</p>
                  <p className="text-base">
                    {assignedManager ? `${assignedManager.firstName} ${assignedManager.lastName}` : "-"}
                  </p>
                  {assignedManager?.email && <p className="text-sm text-muted-foreground">{assignedManager.email}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Equipment Inventory</CardTitle>
            </CardHeader>
            <CardContent>
              {equipment.length > 0 ? (
                <div className="space-y-3">
                  {equipment.map((item: Equipment) => (
                    <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="space-y-1">
                        <p className="font-medium">{item.type}</p>
                        <p className="text-sm text-muted-foreground">{item.model}</p>
                        <p className="text-xs text-muted-foreground">S/N: {item.serialNumber}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <Badge variant={item.status === "Active" ? "default" : "secondary"}>{item.status}</Badge>
                        <p className="text-xs text-muted-foreground">
                          Assigned: {new Date(item.assignedDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-4">No equipment assigned</p>
              )}
            </CardContent>
          </Card>
        </div>
      </LoadingOverlay>
    </ShowView>
  );
}
