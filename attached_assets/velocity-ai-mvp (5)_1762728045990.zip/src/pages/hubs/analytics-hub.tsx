import { useList } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useGo } from "@refinedev/core";
import { TrendingUp, DollarSign, Users, FileText, AlertTriangle, BarChart3, PieChart, Activity } from "lucide-react";
import type { PurchaseOrder, Timecard, Invoice, Contractor, Expense, StatementOfWork } from "@/types";

export function AnalyticsHub() {
  const go = useGo();

  const { data: posData } = useList<PurchaseOrder>({ resource: "purchaseorders" });
  const { data: timecardsData } = useList<Timecard>({ resource: "timecards" });
  const { data: invoicesData } = useList<Invoice>({ resource: "invoices" });
  const { data: contractorsData } = useList<Contractor>({ resource: "contractors" });
  const { data: expensesData } = useList<Expense>({ resource: "expenses" });
  const { data: sowsData } = useList<StatementOfWork>({ resource: "statementofworks" });

  const pos = posData?.data || [];
  const timecards = timecardsData?.data || [];
  const invoices = invoicesData?.data || [];
  const contractors = contractorsData?.data || [];
  const expenses = expensesData?.data || [];
  const sows = sowsData?.data || [];

  // Financial Metrics
  const totalPOBudget = pos.reduce((sum, po) => sum + po.totalAmount, 0);
  const totalSpent = pos.reduce((sum, po) => sum + po.spentAmount, 0);
  const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.actualAmount, 0);
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const utilizationRate = totalPOBudget > 0 ? (totalSpent / totalPOBudget) * 100 : 0;

  // Workforce Metrics
  const activeContractors = contractors.filter((c) => c.status === "Active").length;
  const totalHours = timecards.reduce((sum, tc) => sum + tc.hours, 0);
  const avgHourlyRate =
    timecards.length > 0 ? timecards.reduce((sum, tc) => sum + tc.hourlyRate, 0) / timecards.length : 0;

  // Operational Metrics
  const pendingApprovals = timecards.filter((tc) => tc.status === "Pending").length;
  const pendingInvoices = invoices.filter((inv) => inv.status === "Submitted").length;
  const activeSows = sows.filter((sow) => sow.status === "Active").length;

  // Risk Indicators
  const overBudgetPOs = pos.filter((po) => po.spentAmount > po.totalAmount).length;
  const invoicesWithVariance = invoices.filter((inv) => inv.hasVariance).length;
  const grPendingAmount = invoices.reduce((sum, inv) => sum + inv.grBalance, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analytics Hub</h1>
          <p className="text-muted-foreground mt-1">Unified intelligence center for all system metrics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => go({ to: "/budget/forecasting" })}>
            <BarChart3 className="h-4 w-4 mr-2" />
            Budget Forecast
          </Button>
          <Button variant="outline" onClick={() => go({ to: "/expenses/reports" })}>
            <FileText className="h-4 w-4 mr-2" />
            Reports
          </Button>
        </div>
      </div>

      {/* Executive Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
              }).format(totalPOBudget)}
            </div>
            <p className="text-xs text-muted-foreground">Across {pos.length} purchase orders</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilization Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{utilizationRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
              }).format(totalSpent)}{" "}
              spent
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Workforce</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeContractors}</div>
            <p className="text-xs text-muted-foreground">
              {totalHours.toLocaleString()} hours • ${avgHourlyRate.toFixed(2)}/hr avg
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Actions</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingApprovals + pendingInvoices}</div>
            <p className="text-xs text-muted-foreground">
              {pendingApprovals} timecards, {pendingInvoices} invoices
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Financial Health */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Spend Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">PO Expenditures</span>
              <span className="font-bold">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                  notation: "compact",
                }).format(totalSpent)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Invoiced Amount</span>
              <span className="font-bold">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                  notation: "compact",
                }).format(totalInvoiced)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Total Expenses</span>
              <span className="font-bold">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                  notation: "compact",
                }).format(totalExpenses)}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Operational Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Active Purchase Orders</span>
              <span className="font-bold">{pos.filter((po) => po.status === "Active").length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Active SOWs</span>
              <span className="font-bold">{activeSows}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Total Timecards</span>
              <span className="font-bold">{timecards.length}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="h-5 w-5" />
              Risk Indicators
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Over-Budget POs</span>
              <span className="font-bold text-orange-600">{overBudgetPOs}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Invoice Variances</span>
              <span className="font-bold text-orange-600">{invoicesWithVariance}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">GR Pending</span>
              <span className="font-bold text-orange-600">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                  notation: "compact",
                }).format(grPendingAmount)}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Access Dashboards */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Access Dashboards</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/pc2-purchase-orders" })}>
              <FileText className="h-6 w-6 mb-2" />
              <span>PC2 Procurement Hub</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/pc3-workforce-home" })}>
              <Users className="h-6 w-6 mb-2" />
              <span>PC3 Workforce Hub</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/admin/dashboard" })}>
              <Activity className="h-6 w-6 mb-2" />
              <span>Admin Dashboard</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/ai/insights" })}>
              <BarChart3 className="h-6 w-6 mb-2" />
              <span>AI Insights</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/admin/data-quality" })}>
              <Activity className="h-6 w-6 mb-2" />
              <span>Data Quality</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col" onClick={() => go({ to: "/admin/exceptions" })}>
              <AlertTriangle className="h-6 w-6 mb-2" />
              <span>System Exceptions</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Contractor Performance (Top 5) */}
      <Card>
        <CardHeader>
          <CardTitle>Top Contractors by Hours</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {contractors
              .map((contractor) => {
                const contractorTimecards = timecards.filter((tc) => tc.contractorId === contractor.id);
                const hours = contractorTimecards.reduce((sum, tc) => sum + tc.hours, 0);
                const value = contractorTimecards.reduce((sum, tc) => sum + tc.totalAmount, 0);
                return { contractor, hours, value };
              })
              .sort((a, b) => b.hours - a.hours)
              .slice(0, 5)
              .map(({ contractor, hours, value }) => (
                <div key={contractor.id} className="flex items-center justify-between p-3 bg-muted rounded-md">
                  <div>
                    <p className="font-medium">
                      {contractor.firstName} {contractor.lastName}
                    </p>
                    <p className="text-sm text-muted-foreground">{contractor.jobDescription}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{hours}h</p>
                    <p className="text-sm text-muted-foreground">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                        notation: "compact",
                      }).format(value)}
                    </p>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
