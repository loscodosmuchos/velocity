import { useList } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useGo } from "@refinedev/core";
import {
  Users,
  AlertTriangle,
  Database,
  FileText,
  Settings,
  Shield,
  Activity,
  TrendingUp,
  Mail,
  Bot,
} from "lucide-react";
import type { User, SystemException, DataQualityMetric, AuditLog } from "@/types";

export function AdminHub() {
  const go = useGo();

  const { data: usersData } = useList<User>({ resource: "users", pagination: { pageSize: 100 } });
  const { data: exceptionsData } = useList<SystemException>({ resource: "exceptions" });
  const { data: auditLogsData } = useList<AuditLog>({ resource: "auditlogs", pagination: { pageSize: 100 } });
  const { data: metricsData } = useList<DataQualityMetric>({ resource: "dataqualitymetrics" });

  const users = usersData?.data || [];
  const exceptions = exceptionsData?.data || [];
  const auditLogs = auditLogsData?.data || [];
  const metrics = metricsData?.data || [];

  // User metrics
  const activeUsers = users.length;
  const adminUsers = users.filter((u) => u.role === "Admin").length;
  const managerUsers = users.filter((u) => u.role === "Manager").length;

  // Exception metrics
  const openExceptions = exceptions.filter((e) => e.status === "Open").length;
  const criticalExceptions = exceptions.filter((e) => e.severity === "Critical").length;

  // Data quality
  const criticalMetrics = metrics.filter((m) => m.status === "Critical").length;
  const avgQualityScore =
    metrics.length > 0
      ? metrics.reduce((sum, m) => sum + (m.currentValue / m.targetValue) * 100, 0) / metrics.length
      : 0;

  // Recent activity
  const recentActions = auditLogs.slice(0, 10);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">System management, user administration, and monitoring</p>
        </div>
        <Button onClick={() => go({ to: "/admin/users" })}>
          <Settings className="h-4 w-4 mr-2" />
          System Settings
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeUsers}</div>
            <p className="text-xs text-muted-foreground">
              {adminUsers} admins, {managerUsers} managers
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Exceptions</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openExceptions}</div>
            <p className="text-xs text-muted-foreground">{criticalExceptions} critical</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Quality</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgQualityScore.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">{criticalMetrics} critical issues</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Audit Logs</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{auditLogs.length}</div>
            <p className="text-xs text-muted-foreground">Total actions logged</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Administrative Tools</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/admin/users" })}>
              <Users className="h-6 w-6 mb-2" />
              <span className="font-medium">User Management</span>
              <span className="text-xs text-muted-foreground">{activeUsers} users</span>
            </Button>

            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/admin/exceptions" })}>
              <AlertTriangle className="h-6 w-6 mb-2" />
              <span className="font-medium">System Exceptions</span>
              <span className="text-xs text-muted-foreground">{openExceptions} open</span>
            </Button>

            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/admin/data-quality" })}>
              <Database className="h-6 w-6 mb-2" />
              <span className="font-medium">Data Quality</span>
              <span className="text-xs text-muted-foreground">{avgQualityScore.toFixed(0)}% avg</span>
            </Button>

            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/admin/audit-logs" })}>
              <FileText className="h-6 w-6 mb-2" />
              <span className="font-medium">Audit Logs</span>
              <span className="text-xs text-muted-foreground">{auditLogs.length} entries</span>
            </Button>

            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/admin/chatbots-customize" })}>
              <Bot className="h-6 w-6 mb-2" />
              <span className="font-medium">AI Chatbot Manager</span>
              <span className="text-xs text-muted-foreground">Customize widgets</span>
            </Button>

            <Button variant="outline" className="h-24 flex-col" onClick={() => go({ to: "/approvals/email-logs" })}>
              <Mail className="h-6 w-6 mb-2" />
              <span className="font-medium">Email Logs</span>
              <span className="text-xs text-muted-foreground">Monitor delivery</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* System Health */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Recent Exceptions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {exceptions.slice(0, 5).map((exception) => (
                <div
                  key={exception.id}
                  className="flex items-center justify-between p-2 border rounded-md hover:bg-muted cursor-pointer"
                  onClick={() => go({ to: "/admin/exceptions" })}>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{exception.exceptionType}</p>
                    <p className="text-xs text-muted-foreground">{exception.entityName}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-medium ${
                        exception.severity === "Critical"
                          ? "text-red-600"
                          : exception.severity === "High"
                            ? "text-orange-600"
                            : "text-yellow-600"
                      }`}>
                      {exception.severity}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {recentActions.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-2 border rounded-md text-sm">
                  <div className="flex-1">
                    <p className="font-medium">
                      {log.action} {log.entityType}
                    </p>
                    <p className="text-xs text-muted-foreground">{log.performedByName}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Quality Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Data Quality Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {["Completeness", "Accuracy", "Consistency", "Timeliness"].map((category) => {
              const categoryMetrics = metrics.filter((m) => m.category === category);
              const avgScore =
                categoryMetrics.length > 0
                  ? categoryMetrics.reduce((sum, m) => sum + (m.currentValue / m.targetValue) * 100, 0) /
                    categoryMetrics.length
                  : 0;
              const status = avgScore > 90 ? "Good" : avgScore > 70 ? "Warning" : "Critical";
              return (
                <div key={category} className="p-4 border rounded-lg">
                  <p className="text-sm font-medium mb-2">{category}</p>
                  <p className="text-2xl font-bold">{avgScore.toFixed(1)}%</p>
                  <p
                    className={`text-xs mt-1 ${
                      status === "Good" ? "text-green-600" : status === "Warning" ? "text-orange-600" : "text-red-600"
                    }`}>
                    {status}
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
