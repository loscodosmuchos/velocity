import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, X } from "lucide-react";
import type { ApprovalRequest } from "@/types";

export function ApprovalRequestsPage() {
  const columns = useMemo<ColumnDef<ApprovalRequest>[]>(
    () => [
      {
        accessorKey: "id",
        header: "ID",
      },
      {
        accessorKey: "entityType",
        header: "Type",
        cell: ({ getValue }) => {
          const type = getValue<string>();
          return <Badge variant="outline">{type}</Badge>;
        },
      },
      {
        accessorKey: "entityName",
        header: "Item",
      },
      {
        accessorKey: "requestedByName",
        header: "Requested By",
      },
      {
        accessorKey: "currentApproverName",
        header: "Current Approver",
      },
      {
        accessorKey: "approvalChainStep",
        header: "Step",
        cell: ({ getValue, row }) => {
          const current = getValue<number>();
          const total = row.original.totalChainSteps;
          return `${current} of ${total}`;
        },
      },
      {
        accessorKey: "slaStatus",
        header: "SLA Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return (
            <Badge variant={status === "On Time" ? "default" : status === "At Risk" ? "secondary" : "destructive"}>
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return (
            <Badge
              variant={
                status === "Approved"
                  ? "default"
                  : status === "Rejected"
                    ? "destructive"
                    : status === "Escalated"
                      ? "secondary"
                      : "outline"
              }>
              {status}
            </Badge>
          );
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => {
          if (row.original.status !== "Pending") return null;
          return (
            <div className="flex gap-1">
              <Button size="sm" variant="default">
                <Check className="h-3 w-3 mr-1" />
                Approve
              </Button>
              <Button size="sm" variant="destructive">
                <X className="h-3 w-3 mr-1" />
                Reject
              </Button>
            </div>
          );
        },
      },
    ],
    [],
  );

  const table = useTable<ApprovalRequest>({
    columns,
    refineCoreProps: {
      resource: "approval_requests",
    },
  });

  return (
    <ListView>
      <ListViewHeader title="Approval Requests" />
      <DataTable table={table} />
    </ListView>
  );
}
