import { useOne, useUpdate } from "@refinedev/core";
import { useParams, useNavigate } from "react-router";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Check, X, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState } from "react";
import type { ChangeOrder, StatementOfWork } from "../../types";

export function ChangeOrderShowPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [rejectionReason, setRejectionReason] = useState("");

  const { data, isLoading } = useOne<ChangeOrder>({
    resource: "changeorders",
    id: id,
  });

  const changeOrder = data?.data;

  const { data: sowData } = useOne<StatementOfWork>({
    resource: "statementofworks",
    id: changeOrder?.sowId,
    queryOptions: {
      enabled: !!changeOrder?.sowId,
    },
  });

  const { mutate: updateChangeOrder, isLoading: updating } = useUpdate();

  const sow = sowData?.data;

  const handleApprove = () => {
    if (!changeOrder) return;
    updateChangeOrder(
      {
        resource: "changeorders",
        id: changeOrder.id,
        values: {
          ...changeOrder,
          status: "Approved",
          approvedBy: 1, // Mock manager ID
          approvedDate: new Date().toISOString().split("T")[0],
          updatedAt: new Date().toISOString(),
        },
      },
      {
        onSuccess: () => {
          // Update SOW total value
          if (sow) {
            updateChangeOrder({
              resource: "statementofworks",
              id: sow.id,
              values: {
                ...sow,
                totalValue: changeOrder.newTotalValue,
                remainingValue: changeOrder.newTotalValue - sow.invoicedAmount,
                updatedAt: new Date().toISOString(),
              },
            });
          }
        },
      },
    );
  };

  const handleReject = () => {
    if (!changeOrder || !rejectionReason.trim()) return;
    updateChangeOrder({
      resource: "changeorders",
      id: changeOrder.id,
      values: {
        ...changeOrder,
        status: "Rejected",
        approvedBy: 1, // Mock manager ID
        rejectionReason,
        updatedAt: new Date().toISOString(),
      },
    });
  };

  const isIncrease = (changeOrder?.requestedChange || 0) > 0;

  return (
    <ShowView>
      <ShowViewHeader title={`Change Order: ${changeOrder?.changeOrderNumber || id}`} />
      <LoadingOverlay loading={isLoading}>
        <div className="space-y-6 p-4">
          {/* Status Alert */}
          {changeOrder?.status === "Pending" && (
            <Alert>
              <AlertDescription>
                This change order is pending approval. Review the details and approve or reject below.
              </AlertDescription>
            </Alert>
          )}

          {/* Main Info */}
          <Card>
            <CardHeader>
              <CardTitle>Change Order Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">CO Number</div>
                  <div className="font-medium text-lg">{changeOrder?.changeOrderNumber}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Status</div>
                  <Badge
                    variant={
                      changeOrder?.status === "Approved"
                        ? "default"
                        : changeOrder?.status === "Pending"
                          ? "secondary"
                          : "destructive"
                    }>
                    {changeOrder?.status}
                  </Badge>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">SOW</div>
                  <div className="font-medium">{sow?.sowNumber || "-"}</div>
                  {sow && (
                    <Button
                      variant="link"
                      size="sm"
                      className="p-0 h-auto"
                      onClick={() => navigate(`/statement-of-works/${sow.id}`)}>
                      View SOW
                    </Button>
                  )}
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Requested By</div>
                  <div className="font-medium">Manager #{changeOrder?.requestedBy}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Requested Date</div>
                  <div className="font-medium">
                    {changeOrder && new Date(changeOrder.requestedDate).toLocaleDateString()}
                  </div>
                </div>
                {changeOrder?.approvedDate && (
                  <div>
                    <div className="text-sm text-muted-foreground">
                      {changeOrder.status === "Approved" ? "Approved" : "Rejected"} Date
                    </div>
                    <div className="font-medium">{new Date(changeOrder.approvedDate).toLocaleDateString()}</div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Financial Impact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Financial Impact
                {isIncrease ? (
                  <ArrowUpCircle className="h-5 w-5 text-orange-600" />
                ) : (
                  <ArrowDownCircle className="h-5 w-5 text-green-600" />
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <div className="text-sm text-muted-foreground">Original Value</div>
                  <div className="text-2xl font-bold">${changeOrder?.originalValue.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Requested Change</div>
                  <div className={`text-2xl font-bold ${isIncrease ? "text-orange-600" : "text-green-600"}`}>
                    {isIncrease ? "+" : ""}${changeOrder?.requestedChange.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">New Total Value</div>
                  <div className="text-2xl font-bold text-blue-600">${changeOrder?.newTotalValue.toLocaleString()}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Justification */}
          <Card>
            <CardHeader>
              <CardTitle>Business Justification</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap">{changeOrder?.justification}</p>
            </CardContent>
          </Card>

          {/* Rejection Reason (if rejected) */}
          {changeOrder?.status === "Rejected" && changeOrder.rejectionReason && (
            <Card>
              <CardHeader>
                <CardTitle>Rejection Reason</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-destructive whitespace-pre-wrap">{changeOrder.rejectionReason}</p>
              </CardContent>
            </Card>
          )}

          {/* Approval Actions */}
          {changeOrder?.status === "Pending" && (
            <Card>
              <CardHeader>
                <CardTitle>Approval Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <Button onClick={handleApprove} disabled={updating} className="flex-1">
                    <Check className="h-4 w-4 mr-2" />
                    Approve Change Order
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={handleReject}
                    disabled={updating || !rejectionReason.trim()}
                    className="flex-1">
                    <X className="h-4 w-4 mr-2" />
                    Reject Change Order
                  </Button>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Rejection Reason (required to reject)</label>
                  <Textarea
                    placeholder="Provide reason for rejection..."
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </LoadingOverlay>
    </ShowView>
  );
}
