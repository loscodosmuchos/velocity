import { type HttpError, useBack } from "@refinedev/core";
import { useForm } from "@refinedev/react-hook-form";
import { useSelect } from "@refinedev/core";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Loader2, ChevronsUpDown, Check } from "lucide-react";
import { useSearchParams } from "react-router";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { cn } from "@/lib/utils";
import type { ChangeOrder, StatementOfWork } from "../../types";
import { useEffect } from "react";
import { useOne } from "@refinedev/core";

const changeOrderFormSchema = z.object({
  changeOrderNumber: z.string().min(1, { message: "Change order number is required." }),
  sowId: z.number({ required_error: "SOW is required." }),
  requestedBy: z.number({ required_error: "Requester is required." }),
  justification: z.string().min(20, { message: "Justification must be at least 20 characters." }),
  requestedChange: z
    .number({ required_error: "Change amount is required." })
    .refine((val) => val !== 0, "Change amount cannot be zero."),
});

type ChangeOrderFormValues = z.infer<typeof changeOrderFormSchema>;

export function CreateChangeOrderPage() {
  const back = useBack();
  const [searchParams] = useSearchParams();
  const sowIdParam = searchParams.get("sowId");

  const {
    refineCore: { onFinish, formLoading },
    ...form
  } = useForm<ChangeOrder, HttpError, ChangeOrderFormValues>({
    resolver: zodResolver(changeOrderFormSchema),
    defaultValues: {
      changeOrderNumber: `CO-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999)).padStart(4, "0")}`,
      requestedBy: 1, // Default to manager ID 1
      requestedChange: 0,
      sowId: sowIdParam ? parseInt(sowIdParam) : undefined,
    },
    refineCoreProps: {
      resource: "changeorders",
      action: "create",
      redirect: "list",
    },
  });

  const { options: sowOptions, queryResult: sowsQuery } = useSelect<StatementOfWork>({
    resource: "statementofworks",
    optionValue: "id",
    optionLabel: "sowNumber",
  });

  const selectedSowId = form.watch("sowId");

  const { data: selectedSowData } = useOne<StatementOfWork>({
    resource: "statementofworks",
    id: selectedSowId,
    queryOptions: {
      enabled: !!selectedSowId,
    },
  });

  const selectedSow = selectedSowData?.data;

  function onSubmit(values: ChangeOrderFormValues) {
    const originalValue = selectedSow?.totalValue || 0;
    const payload = {
      ...values,
      originalValue,
      newTotalValue: originalValue + values.requestedChange,
      requestedDate: new Date().toISOString().split("T")[0],
      status: "Pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onFinish(payload as any);
  }

  return (
    <CreateView>
      <CreateViewHeader title="Request Change Order" />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="changeOrderNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Change Order Number</FormLabel>
                  <FormControl>
                    <Input placeholder="CO-2024-0001" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="sowId"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Statement of Work</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          role="combobox"
                          className={cn("justify-between", !field.value && "text-muted-foreground")}
                          type="button"
                          disabled={sowsQuery.isLoading}>
                          {field.value
                            ? sowOptions?.find(
                                (option: { value: number; label: string }) => option.value === field.value,
                              )?.label
                            : "Select SOW..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0">
                      <Command>
                        <CommandInput placeholder="Search SOW..." />
                        <CommandList>
                          <CommandEmpty>No SOW found.</CommandEmpty>
                          <CommandGroup>
                            {sowOptions?.map((option: { value: number; label: string }) => (
                              <CommandItem
                                value={option.label}
                                key={option.value}
                                onSelect={() => {
                                  form.setValue("sowId", option.value);
                                }}>
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    option.value === field.value ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                {option.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  {selectedSow && (
                    <FormDescription>Current SOW Value: ${selectedSow.totalValue.toLocaleString()}</FormDescription>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="requestedBy"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Requested By (Manager ID)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="1"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormDescription>Manager requesting this change</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="requestedChange"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Change Amount ($)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="10000"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormDescription>Use positive for increase, negative for decrease</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {selectedSow && form.watch("requestedChange") !== 0 && (
            <div className="p-4 bg-muted rounded-lg">
              <div className="text-sm font-medium mb-2">Impact Summary</div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Original Value</div>
                  <div className="font-medium">${selectedSow.totalValue.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Change</div>
                  <div
                    className={cn(
                      "font-bold",
                      (form.watch("requestedChange") || 0) > 0 ? "text-orange-600" : "text-green-600",
                    )}>
                    {(form.watch("requestedChange") || 0) > 0 ? "+" : ""}$
                    {(form.watch("requestedChange") || 0).toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">New Total</div>
                  <div className="font-bold">
                    ${(selectedSow.totalValue + (form.watch("requestedChange") || 0)).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          )}

          <FormField
            control={form.control}
            name="justification"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Business Justification</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Provide detailed business justification for this change order..."
                    className="resize-none"
                    rows={5}
                    {...field}
                  />
                </FormControl>
                <FormDescription>Explain why this change is necessary and how it impacts the project</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => back()} disabled={formLoading}>
              Cancel
            </Button>
            <Button type="submit" disabled={formLoading}>
              {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Change Order
            </Button>
          </div>
        </form>
      </Form>
    </CreateView>
  );
}
