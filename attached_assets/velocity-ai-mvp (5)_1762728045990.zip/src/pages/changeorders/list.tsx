import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useList } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import {
  DataTableFilterDropdownText,
  DataTableFilterCombobox,
  DataTableFilterDropdownNumeric,
} from "@/components/refine-ui/data-table/data-table-filter";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { ChangeOrder, StatementOfWork } from "../../types";

export function ChangeOrdersListPage() {
  const { data: sowsData } = useList<StatementOfWork>({
    resource: "statementofworks",
  });
  const sows = sowsData?.data ?? [];

  const columns = useMemo<ColumnDef<ChangeOrder>[]>(
    () => [
      {
        id: "changeOrderNumber",
        accessorKey: "changeOrderNumber",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>CO Number</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownText
                  defaultOperator="contains"
                  column={column}
                  table={table}
                  placeholder="Filter by CO number"
                />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="font-medium text-blue-600">{row.original.changeOrderNumber}</div>;
        },
      },
      {
        id: "sowId",
        accessorKey: "sowId",
        size: 160,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>SOW</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={sows.map((item) => ({
                  label: item.sowNumber,
                  value: item.id.toString(),
                }))}
              />
            </div>
          );
        },
        cell: ({ getValue }) => {
          const sowId = getValue<number>();
          const sow = sows.find((item) => item.id === sowId);
          return sow ? <div>{sow.sowNumber}</div> : <div className="text-muted-foreground">-</div>;
        },
      },
      {
        id: "requestedChange",
        accessorKey: "requestedChange",
        size: 140,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Change Amount</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownNumeric
                  defaultOperator="eq"
                  column={column}
                  table={table}
                  placeholder="Filter by amount"
                />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          const change = row.original.requestedChange;
          return (
            <div className={cn("font-bold", change > 0 ? "text-orange-600" : "text-green-600")}>
              {change > 0 ? "+" : ""}${change.toLocaleString()}
            </div>
          );
        },
      },
      {
        id: "originalValue",
        accessorKey: "originalValue",
        size: 130,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Original</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="text-muted-foreground">${row.original.originalValue.toLocaleString()}</div>;
        },
      },
      {
        id: "newTotalValue",
        accessorKey: "newTotalValue",
        size: 130,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>New Total</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="font-medium">${row.original.newTotalValue.toLocaleString()}</div>;
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Status</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Pending", value: "Pending" },
                  { label: "Approved", value: "Approved" },
                  { label: "Rejected", value: "Rejected" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          const status = row.original.status;
          const variant = status === "Approved" ? "default" : status === "Pending" ? "secondary" : "destructive";
          return <Badge variant={variant}>{status}</Badge>;
        },
      },
      {
        id: "requestedDate",
        accessorKey: "requestedDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Requested</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="text-sm">{new Date(row.original.requestedDate).toLocaleDateString()}</div>;
        },
      },
      {
        id: "justification",
        accessorKey: "justification",
        size: 300,
        header: "Justification",
        enableSorting: false,
        cell: ({ row }) => {
          const text = row.original.justification;
          return (
            <div className="text-sm text-muted-foreground">
              {text.length > 80 ? `${text.substring(0, 80)}...` : text}
            </div>
          );
        },
      },
      {
        id: "actions",
        size: 84,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => {
          return <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>;
        },
        cell: ({ row }) => {
          const co = row.original;
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className={cn(
                    "flex",
                    "size-8",
                    "border",
                    "rounded-full",
                    "text-muted-foreground",
                    "data-[state=open]:bg-muted",
                    "data-[state=open]:text-foreground",
                    "mx-auto",
                  )}>
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="flex flex-col gap-2 p-2">
                <ShowButton
                  variant="ghost"
                  size="sm"
                  className="w-full items-center justify-start"
                  resource="changeorders"
                  recordItemId={co.id}
                />
              </DropdownMenuContent>
            </DropdownMenu>
          );
        },
      },
    ],
    [sows],
  );

  const table = useTable<ChangeOrder>({
    columns,
    refineCoreProps: {},
    initialState: {
      columnPinning: {
        left: [],
        right: ["actions"],
      },
    },
  });

  return (
    <ListView>
      <ListViewHeader canCreate={true} />
      <DataTable table={table} />
    </ListView>
  );
}
