import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Phone, MessageSquare, Star, TrendingUp, Activity, Zap, Settings, PhoneCall } from "lucide-react";
import { getMockChatbots, getMockConversations, VELOCITY_SYSTEM_PROMPTS } from "@/utils/elevenlabs-integration";

export default function ChatbotsPage() {
  const [selectedChatbot, setSelectedChatbot] = useState<number | null>(null);
  const [showSystemPrompt, setShowSystemPrompt] = useState(false);
  const chatbots = getMockChatbots();

  const selectedBot = chatbots.find((c) => c.id === selectedChatbot);
  const conversations = selectedChatbot ? getMockConversations(selectedChatbot) : [];

  const promptMap: Record<number, string> = {
    1: VELOCITY_SYSTEM_PROMPTS.timecardBot,
    2: VELOCITY_SYSTEM_PROMPTS.equipmentBot,
    3: VELOCITY_SYSTEM_PROMPTS.statusBot,
    4: VELOCITY_SYSTEM_PROMPTS.approvalBot,
    5: VELOCITY_SYSTEM_PROMPTS.helpBot,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">🎙️ ElevenLabs Conversational AI</h1>
        <p className="text-muted-foreground mt-2">Voice-powered workforce management. No forms. Just conversations.</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Conversations</p>
                <p className="text-2xl font-bold mt-1">
                  {chatbots.reduce((acc, c) => acc + c.conversationCount, 0).toLocaleString()}
                </p>
              </div>
              <MessageSquare className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Response Time</p>
                <p className="text-2xl font-bold mt-1">
                  {(chatbots.reduce((acc, c) => acc + c.avgResponseTime, 0) / chatbots.length).toFixed(1)}s
                </p>
              </div>
              <Zap className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Satisfaction Score</p>
                <p className="text-2xl font-bold mt-1">
                  {(chatbots.reduce((acc, c) => acc + c.satisfactionScore, 0) / chatbots.length).toFixed(1)}
                  /5
                </p>
              </div>
              <Star className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Agents</p>
                <p className="text-2xl font-bold mt-1">
                  {chatbots.filter((c) => c.status === "Active").length}/{chatbots.length}
                </p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chatbot List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {chatbots.map((chatbot) => (
          <Card
            key={chatbot.id}
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setSelectedChatbot(chatbot.id)}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg">
                    <Phone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{chatbot.name}</CardTitle>
                    <CardDescription className="mt-1">{chatbot.description}</CardDescription>
                  </div>
                </div>
                <Badge variant={chatbot.status === "Active" ? "default" : "secondary"}>{chatbot.status}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Metrics */}
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Conversations</p>
                  <p className="font-semibold text-lg">{chatbot.conversationCount}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Avg Response</p>
                  <p className="font-semibold text-lg">{chatbot.avgResponseTime}s</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Rating</p>
                  <p className="font-semibold text-lg flex items-center gap-1">
                    {chatbot.satisfactionScore} <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  </p>
                </div>
              </div>

              {/* Capabilities */}
              <div>
                <p className="text-sm font-medium mb-2">Capabilities:</p>
                <div className="flex flex-wrap gap-1">
                  {chatbot.capabilities.slice(0, 3).map((cap, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {cap}
                    </Badge>
                  ))}
                  {chatbot.capabilities.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{chatbot.capabilities.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedChatbot(chatbot.id);
                    setShowSystemPrompt(true);
                  }}>
                  <Settings className="h-4 w-4 mr-2" />
                  View Prompt
                </Button>
                <Button
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    alert(`Initiating test call with ${chatbot.name}...`);
                  }}>
                  <PhoneCall className="h-4 w-4 mr-2" />
                  Test Call
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Chatbot Detail Dialog */}
      {selectedBot && (
        <Dialog open={!!selectedChatbot && !showSystemPrompt} onOpenChange={() => setSelectedChatbot(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg">
                  <Phone className="h-5 w-5 text-white" />
                </div>
                {selectedBot.name}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="conversations" className="mt-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="conversations">Conversations</TabsTrigger>
                <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
                <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
              </TabsList>

              <TabsContent value="conversations" className="space-y-4">
                <ScrollArea className="h-[400px] pr-4">
                  {conversations.length > 0 ? (
                    <div className="space-y-3">
                      {conversations.map((conv) => (
                        <Card key={conv.id}>
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                  <p className="font-semibold">{conv.userName}</p>
                                  {conv.resolved && <Badge variant="outline">Resolved</Badge>}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {conv.messageCount} messages • Started {new Date(conv.startTime).toLocaleString()}
                                </p>
                                {conv.context && (
                                  <div className="text-xs text-muted-foreground">
                                    {Object.entries(conv.context).map(([key, value]) => (
                                      <span key={key} className="mr-3">
                                        <strong>{key}:</strong> {String(value)}
                                      </span>
                                    ))}
                                  </div>
                                )}
                                {conv.feedback && <p className="text-sm italic">"{conv.feedback}"</p>}
                              </div>
                              {conv.rating && (
                                <div className="flex items-center gap-1">
                                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                  <span className="font-semibold">{conv.rating}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">No conversations yet</div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="capabilities" className="space-y-4">
                <div className="space-y-2">
                  {selectedBot.capabilities.map((cap, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-3 bg-muted rounded-lg">
                      <div className="mt-1">✅</div>
                      <p className="text-sm">{cap}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="knowledge" className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {selectedBot.knowledgeSources.map((source, idx) => (
                    <Badge key={idx} variant="secondary" className="justify-center py-2">
                      {source}
                    </Badge>
                  ))}
                </div>
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">
                    This chatbot has access to live data from these Velocity modules, enabling context-aware
                    conversations.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {/* System Prompt Dialog */}
      {selectedBot && (
        <Dialog open={showSystemPrompt} onOpenChange={() => setShowSystemPrompt(false)}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>System Prompt: {selectedBot.name}</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[500px] mt-4">
              <pre className="text-xs bg-muted p-4 rounded-lg whitespace-pre-wrap">{promptMap[selectedBot.id]}</pre>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      )}

      {/* Usage Guide */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500 text-white font-bold">
                  1
                </div>
                <h3 className="font-semibold">Call or Text</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Contractors call a dedicated number or text "CALLBACK" to trigger VINessa
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500 text-white font-bold">
                  2
                </div>
                <h3 className="font-semibold">Natural Conversation</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                VINessa asks questions naturally, capturing data through voice in 2-3 minutes
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-500 text-white font-bold">
                  3
                </div>
                <h3 className="font-semibold">Auto-Process</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Data flows into Velocity automatically. No forms. No typing. Just done.
              </p>
            </div>
          </div>

          <div className="mt-4 p-4 bg-white dark:bg-gray-900 rounded-lg">
            <p className="text-sm font-semibold mb-2">Real-World Examples:</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• "I worked 8 hours on Building B today" → Timecard created, manager notified</li>
              <li>• "Check out laptop and phone for new hire John" → Equipment assigned, email sent</li>
              <li>• "Building B network upgrade on track but worried about vendors" → Status captured, risk flagged</li>
              <li>• "Approve all my pending timecards" → 12 timecards approved in 30 seconds</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
