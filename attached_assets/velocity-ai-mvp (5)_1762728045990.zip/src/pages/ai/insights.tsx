import { useState } from "react";
import { useList } from "@refinedev/core";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Brain,
  Shield,
  Sparkles,
  Clock,
  DollarSign,
  Download,
} from "lucide-react";
import type { PurchaseOrder, Timecard, Invoice, StatementOfWork } from "@/types";
import { analyzeContract, getRiskColor, getRiskVariant, type ContractAnalysisResult } from "@/utils/contract-analyzer";
import { generatePredictiveAlerts, getSeverityColor, type PredictiveAlert } from "@/utils/predictive-alerts";
import { getSampleContract, getAllSampleContracts } from "@/utils/sample-contracts";
import { getTestContract, getAllTestContracts } from "@/utils/test-contracts";
import { MultiLensAnalyzer } from "./multi-lens-analyzer";

export function AIInsightsPage() {
  const [analysisResult, setAnalysisResult] = useState<ContractAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [documentContent, setDocumentContent] = useState("");
  const [documentType, setDocumentType] = useState<"SOW" | "PO" | "Agreement">("SOW");
  const [selectedSample, setSelectedSample] = useState<string>("");
  const [analysisMode, setAnalysisMode] = useState<"standard" | "multi-lens">("standard");

  // Fetch data for predictive alerts
  const { data: purchaseOrdersData } = useList<PurchaseOrder>({
    resource: "purchaseorders",
    pagination: { mode: "off" },
  });

  const { data: timecardsData } = useList<Timecard>({
    resource: "timecards",
    pagination: { mode: "off" },
  });

  const { data: invoicesData } = useList<Invoice>({
    resource: "invoices",
    pagination: { mode: "off" },
  });

  const { data: sowsData } = useList<StatementOfWork>({
    resource: "statementofworks",
    pagination: { mode: "off" },
  });

  const purchaseOrders = purchaseOrdersData?.data || [];
  const timecards = timecardsData?.data || [];
  const invoices = invoicesData?.data || [];
  const sows = sowsData?.data || [];

  // Generate predictive alerts
  const predictiveAlerts = generatePredictiveAlerts({
    purchaseOrders,
    timecards,
    invoices,
    sows,
  });

  const topAlerts = predictiveAlerts.slice(0, 5);

  const handleAnalyzeContract = async () => {
    if (!documentContent.trim()) return;

    setIsAnalyzing(true);
    try {
      const result = await analyzeContract(documentContent, documentType);
      setAnalysisResult(result);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setDocumentContent(text);
    };
    reader.readAsText(file);
  };

  const handleLoadSample = (sampleKey: string) => {
    // Try test contracts first (for multi-lens)
    const testContracts = getAllTestContracts();
    const testContract = testContracts.find((c) => c.key === sampleKey);

    if (testContract) {
      setDocumentContent(testContract.content);
      setDocumentType(testContract.type);
      setSelectedSample(sampleKey);
      setAnalysisResult(null);
      return;
    }

    // Fall back to original sample contracts
    const sample = getSampleContract(sampleKey as any);
    if (sample) {
      setDocumentContent(sample.content);
      setDocumentType(sample.type);
      setSelectedSample(sampleKey);
      setAnalysisResult(null);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            AI Intelligence Center
          </h2>
          <p className="text-muted-foreground">
            AI-powered contract analysis, predictive alerts, and intelligent insights
          </p>
        </div>
        <Badge variant="secondary" className="text-sm">
          <Sparkles className="h-3 w-3 mr-1" />
          Powered by AI
        </Badge>
      </div>

      <Tabs defaultValue="alerts" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="alerts">Predictive Alerts</TabsTrigger>
          <TabsTrigger value="analysis">Contract Analysis</TabsTrigger>
        </TabsList>

        {/* Predictive Alerts Tab */}
        <TabsContent value="alerts" className="space-y-6">
          {/* Alert Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{predictiveAlerts.length}</div>
                <p className="text-xs text-muted-foreground">AI-generated insights</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Critical Risks</CardTitle>
                <XCircle className="h-4 w-4 text-destructive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {predictiveAlerts.filter((a) => a.severity === "Critical").length}
                </div>
                <p className="text-xs text-muted-foreground">Immediate action needed</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Budget Alerts</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {predictiveAlerts.filter((a) => a.type === "Budget Overrun").length}
                </div>
                <p className="text-xs text-muted-foreground">Overrun predictions</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Timeline Risks</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {predictiveAlerts.filter((a) => a.type === "Timeline Risk").length}
                </div>
                <p className="text-xs text-muted-foreground">Delivery concerns</p>
              </CardContent>
            </Card>
          </div>

          {/* Top AI-Generated Risks */}
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Top 5 Predictive Risks
                  </CardTitle>
                  <CardDescription>AI-powered predictions based on current data patterns</CardDescription>
                </div>
                <Badge variant="outline" className="text-xs">
                  Updated in real-time
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {topAlerts.length === 0 ? (
                <Alert>
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  <AlertDescription>
                    No critical risks detected. All systems operating within normal parameters.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-4">
                  {topAlerts.map((alert) => (
                    <Card
                      key={alert.id}
                      className="border-l-4 hover:shadow-md transition-shadow"
                      style={{ borderLeftColor: getSeverityColor(alert.severity) }}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant={alert.severity === "Critical" ? "destructive" : "secondary"}>
                                {alert.severity}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {alert.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground">{alert.confidence}% confidence</span>
                            </div>
                            <h4 className="font-semibold text-sm">{alert.title}</h4>
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground mb-2">{alert.description}</p>

                        <div className="bg-muted/50 p-3 rounded-md mb-2 space-y-1">
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                            <div>
                              <p className="text-xs font-medium">Predicted Impact:</p>
                              <p className="text-xs text-muted-foreground">{alert.predictedImpact}</p>
                            </div>
                          </div>
                        </div>

                        <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-md">
                          <div className="flex items-start gap-2">
                            <Shield className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                            <div>
                              <p className="text-xs font-medium text-blue-900 dark:text-blue-100">
                                Recommended Action:
                              </p>
                              <p className="text-xs text-blue-700 dark:text-blue-300">{alert.recommendedAction}</p>
                            </div>
                          </div>
                        </div>

                        {alert.estimatedCost && (
                          <div className="mt-2 flex items-center gap-2 text-xs">
                            <DollarSign className="h-3 w-3" />
                            <span className="font-medium">
                              Estimated Impact: ${new Intl.NumberFormat("en-US").format(alert.estimatedCost)}
                            </span>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contract Analysis Tab */}
        <TabsContent value="analysis" className="space-y-6">
          {/* Analysis Mode Selector */}
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Select Analysis Type
              </CardTitle>
              <CardDescription>Choose between standard analysis or comprehensive multi-lens analysis</CardDescription>
            </CardHeader>
            <CardContent className="flex gap-4">
              <Button
                variant={analysisMode === "standard" ? "default" : "outline"}
                onClick={() => setAnalysisMode("standard")}
                className="flex-1">
                <FileText className="mr-2 h-4 w-4" />
                Standard Analysis
              </Button>
              <Button
                variant={analysisMode === "multi-lens" ? "default" : "outline"}
                onClick={() => setAnalysisMode("multi-lens")}
                className="flex-1 gap-2">
                <Sparkles className="h-4 w-4" />
                Multi-Lens Analysis (v2.0)
                <Badge variant="secondary" className="text-xs">
                  NEW
                </Badge>
              </Button>
            </CardContent>
          </Card>

          {analysisMode === "multi-lens" && documentContent.trim() && (
            <MultiLensAnalyzer
              contractContent={documentContent}
              contractName={selectedSample || "Contract"}
              contractId="SOW-DEMO"
              documentType={documentType}
            />
          )}

          {analysisMode === "standard" && (
            <div className="grid gap-6 md:grid-cols-2">
              {/* Upload/Input Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Upload Contract for Analysis
                  </CardTitle>
                  <CardDescription>AI will extract terms, identify risks, and provide recommendations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Document Type</label>
                    <div className="flex gap-2">
                      <Button
                        variant={documentType === "SOW" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setDocumentType("SOW")}>
                        SOW
                      </Button>
                      <Button
                        variant={documentType === "PO" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setDocumentType("PO")}>
                        Purchase Order
                      </Button>
                      <Button
                        variant={documentType === "Agreement" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setDocumentType("Agreement")}>
                        Agreement
                      </Button>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Upload Document</label>
                    <label className="text-sm font-medium mb-2 block">Quick Demo Samples</label>
                    <Select value={selectedSample} onValueChange={handleLoadSample}>
                      <SelectTrigger>
                        <SelectValue placeholder="Load sample contract for demo..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="SOW-0005">SOW-0005 (High Risk - Missing Clauses)</SelectItem>
                        <SelectItem value="SOW-SAMPLE-GOOD">Sample Good Contract (Medium Risk)</SelectItem>
                        <SelectItem value="SOW-SAMPLE-EXCELLENT">Sample Excellent Contract (Low Risk)</SelectItem>
                        <SelectItem value="SOW-HIGH-RISK">Critical Risk Contract (Timeline + Financial)</SelectItem>
                        {getAllSampleContracts().map((sample) => (
                          <SelectItem key={sample.key} value={sample.key}>
                            {sample.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground mt-1">
                      Select a pre-loaded contract to see instant AI analysis
                    </p>
                  </div>

                  <div className="relative">
                    <label className="text-sm font-medium mb-2 block">Or upload your document</label>
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                      <input
                        type="file"
                        accept=".txt,.pdf,.doc,.docx"
                        onChange={handleFileUpload}
                        className="hidden"
                        id="file-upload"
                      />
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                        <p className="text-sm font-medium">Click to upload or drag and drop</p>
                        <p className="text-xs text-muted-foreground">TXT, PDF, DOC up to 10MB</p>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Or paste contract text:</label>
                    <Textarea
                      placeholder="Paste your contract text here for instant AI analysis..."
                      value={documentContent}
                      onChange={(e) => setDocumentContent(e.target.value)}
                      rows={8}
                      className="font-mono text-sm"
                    />
                  </div>

                  <Button
                    onClick={handleAnalyzeContract}
                    disabled={isAnalyzing || !documentContent.trim()}
                    className="w-full"
                    size="lg">
                    {isAnalyzing ? (
                      <>
                        <span className="animate-spin mr-2">⚡</span>
                        Analyzing with AI...
                      </>
                    ) : (
                      <>
                        <Brain className="mr-2 h-4 w-4" />
                        Analyze Contract
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Analysis Results */}
              <Card className={analysisResult ? "border-2 border-primary/20" : ""}>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>AI-powered risk assessment and recommendations</CardDescription>
                </CardHeader>
                <CardContent>
                  {!analysisResult ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <Brain className="h-16 w-16 text-muted-foreground/30 mb-4" />
                      <p className="text-sm text-muted-foreground">
                        Upload a contract or paste text to see AI analysis results
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Risk Score */}
                      <div
                        className="text-center p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg border-2"
                        style={{ borderColor: getRiskColor(analysisResult.riskLevel) }}>
                        <div
                          className="inline-flex items-center justify-center w-24 h-24 rounded-full mb-3"
                          style={{ backgroundColor: `${getRiskColor(analysisResult.riskLevel)}15` }}>
                          <span
                            className="text-3xl font-bold"
                            style={{ color: getRiskColor(analysisResult.riskLevel) }}>
                            {analysisResult.riskScore}
                          </span>
                        </div>
                        <p className="text-sm font-medium mb-1">Risk Score</p>
                        <Badge variant={getRiskVariant(analysisResult.riskLevel)} className="text-xs">
                          {analysisResult.riskLevel} Risk
                        </Badge>
                      </div>

                      {/* Summary */}
                      <Alert>
                        <AlertDescription className="text-sm">{analysisResult.summary}</AlertDescription>
                      </Alert>

                      {/* Extracted Terms */}
                      <div>
                        <h4 className="text-sm font-semibold mb-2">Extracted Terms</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Payment Schedule:</span>
                            <span className="font-medium">{analysisResult.extractedTerms.paymentSchedule}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Contract Period:</span>
                            <span className="font-medium">
                              {analysisResult.extractedTerms.startDate} to {analysisResult.extractedTerms.endDate}
                            </span>
                          </div>
                          {analysisResult.extractedTerms.totalValue && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Total Value:</span>
                              <span className="font-medium">
                                ${new Intl.NumberFormat("en-US").format(analysisResult.extractedTerms.totalValue)}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Progress indicator */}
                      <div>
                        <div className="flex justify-between text-xs mb-2">
                          <span>Risk Level</span>
                          <span>{analysisResult.riskScore}/100</span>
                        </div>
                        <Progress value={analysisResult.riskScore} className="h-2" />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
