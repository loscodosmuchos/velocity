import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import { useGetIdentity } from "@refinedev/core";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { UploadCloud } from "lucide-react";
import type { ContractorDocument } from "@/types";
import { Link } from "react-router";

export function ContractorDocumentsPage() {
  const { data: identity } = useGetIdentity<{ id: number }>();

  const columns = useMemo<ColumnDef<ContractorDocument>[]>(
    () => [
      {
        accessorKey: "documentType",
        header: "Document Type",
      },
      {
        accessorKey: "fileName",
        header: "File Name",
      },
      {
        accessorKey: "uploadedDate",
        header: "Uploaded",
        cell: ({ getValue }) => {
          const date = getValue<string>();
          return new Date(date).toLocaleDateString();
        },
      },
      {
        accessorKey: "expirationDate",
        header: "Expires",
        cell: ({ getValue }) => {
          const date = getValue<string | undefined>();
          if (!date) return "N/A";
          const expDate = new Date(date);
          const today = new Date();
          const daysUntil = Math.floor((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

          if (daysUntil < 0) {
            return <span className="text-red-600">Expired</span>;
          }
          if (daysUntil <= 30) {
            return <span className="text-amber-600">{expDate.toLocaleDateString()}</span>;
          }
          return expDate.toLocaleDateString();
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return (
            <Badge variant={status === "Valid" ? "default" : status === "Expired" ? "destructive" : "secondary"}>
              {status}
            </Badge>
          );
        },
      },
      {
        id: "actions",
        header: "Actions",
        cell: ({ row }) => (
          <Button variant="link" size="sm" asChild>
            <a href={row.original.fileUrl} target="_blank" rel="noopener noreferrer">
              Download
            </a>
          </Button>
        ),
      },
    ],
    [],
  );

  const table = useTable<ContractorDocument>({
    columns,
    refineCoreProps: {
      resource: "contractor_documents",
      filters: {
        permanent: identity?.id ? [{ field: "contractorId", operator: "eq", value: identity.id }] : [],
      },
    },
  });

  return (
    <ListView>
      <ListViewHeader title="My Documents">
        <Link to="/contractor-portal/documents/upload">
          <Button>
            <UploadCloud className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        </Link>
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
