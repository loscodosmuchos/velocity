import { useGetIdentity, useList } from "@refinedev/core";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, FileText, Receipt, Upload, MessageSquare, AlertCircle } from "lucide-react";
import { Link } from "react-router";
import type { Contractor, Timecard, Invoice, PurchaseOrder, ContractorDocument } from "@/types";

export function ContractorPortalDashboard() {
  const { data: identity } = useGetIdentity<{ id: number; email: string }>();

  const { data: contractorData } = useList<Contractor>({
    resource: "contractors",
    filters: identity?.id ? [{ field: "id", operator: "eq", value: identity.id }] : [],
  });

  const contractor = contractorData?.data[0];

  const { data: timecardsData } = useList<Timecard>({
    resource: "timecards",
    filters: contractor ? [{ field: "contractorId", operator: "eq", value: contractor.id }] : [],
    pagination: { pageSize: 5, current: 1 },
    sorters: [{ field: "date", order: "desc" }],
  });

  const { data: invoicesData } = useList<Invoice>({
    resource: "invoices",
    filters: contractor ? [{ field: "contractorId", operator: "eq", value: contractor.id }] : [],
    pagination: { pageSize: 5, current: 1 },
    sorters: [{ field: "invoiceDate", order: "desc" }],
  });

  const { data: posData } = useList<PurchaseOrder>({
    resource: "purchaseorders",
    pagination: { pageSize: 10, current: 1 },
  });

  const { data: documentsData } = useList<ContractorDocument>({
    resource: "contractor_documents",
    filters: contractor ? [{ field: "contractorId", operator: "eq", value: contractor.id }] : [],
  });

  const activePOs = posData?.data.filter((po) => po.status === "Active") || [];
  const pendingTimecards = timecardsData?.data.filter((tc) => tc.status === "Pending") || [];
  const expiringSoonDocs =
    documentsData?.data.filter((doc) => {
      if (!doc.expirationDate) return false;
      const daysUntilExpiry = Math.floor(
        (new Date(doc.expirationDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
      );
      return daysUntilExpiry <= 30 && daysUntilExpiry >= 0;
    }) || [];

  if (!contractor) {
    return (
      <div className="p-8">
        <div className="flex items-center gap-2 text-amber-600">
          <AlertCircle className="h-5 w-5" />
          <p>Loading contractor profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">
          Welcome, {contractor.firstName} {contractor.lastName}
        </h1>
        <p className="text-muted-foreground mt-1">{contractor.jobDescription}</p>
      </div>

      {expiringSoonDocs.length > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-900">
              <AlertCircle className="h-5 w-5" />
              Documents Expiring Soon
            </CardTitle>
            <CardDescription>You have {expiringSoonDocs.length} document(s) expiring within 30 days</CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/contractor-portal/documents">
              <Button variant="outline" className="border-amber-600 text-amber-900 hover:bg-amber-100">
                Review Documents
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active POs</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activePOs.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Purchase orders assigned to you</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Timecards</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingTimecards.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting manager approval</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Invoices</CardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{invoicesData?.data.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">Total invoices this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hourly Rate</CardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${contractor.payRate}</div>
            <p className="text-xs text-muted-foreground mt-1">Current contract rate</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Timecards</CardTitle>
            <CardDescription>Your latest time submissions</CardDescription>
          </CardHeader>
          <CardContent>
            {timecardsData?.data.length ? (
              <div className="space-y-3">
                {timecardsData.data.map((timecard) => (
                  <div key={timecard.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{new Date(timecard.date).toLocaleDateString()}</p>
                      <p className="text-sm text-muted-foreground">
                        {timecard.hours} hours - ${timecard.totalAmount.toFixed(2)}
                      </p>
                    </div>
                    <Badge
                      variant={
                        timecard.status === "Approved"
                          ? "default"
                          : timecard.status === "Rejected"
                            ? "destructive"
                            : "secondary"
                      }>
                      {timecard.status}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No timecards submitted yet</p>
            )}
            <div className="mt-4 flex gap-2">
              <Link to="/contractor-portal/timecards/create">
                <Button>Submit Timecard</Button>
              </Link>
              <Link to="/contractor-portal/timecards">
                <Button variant="outline">View All</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link to="/contractor-portal/timecards/create" className="block">
              <Button variant="outline" className="w-full justify-start">
                <Clock className="h-4 w-4 mr-2" />
                Submit Timecard
              </Button>
            </Link>
            <Link to="/contractor-portal/expenses/create" className="block">
              <Button variant="outline" className="w-full justify-start">
                <Receipt className="h-4 w-4 mr-2" />
                Submit Expense
              </Button>
            </Link>
            <Link to="/contractor-portal/documents" className="block">
              <Button variant="outline" className="w-full justify-start">
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
            </Link>
            <Link to="/contractor-portal/messages" className="block">
              <Button variant="outline" className="w-full justify-start">
                <MessageSquare className="h-4 w-4 mr-2" />
                Message Manager
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
