import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import { useGetIdentity } from "@refinedev/core";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageSquare } from "lucide-react";
import type { ContractorMessage } from "@/types";
import { Link } from "react-router";

export function ContractorMessagesPage() {
  const { data: identity } = useGetIdentity<{ id: number }>();

  const columns = useMemo<ColumnDef<ContractorMessage>[]>(
    () => [
      {
        accessorKey: "subject",
        header: "Subject",
      },
      {
        accessorKey: "senderName",
        header: "From",
      },
      {
        accessorKey: "receiverName",
        header: "To",
      },
      {
        accessorKey: "relatedEntityType",
        header: "Related To",
        cell: ({ getValue }) => {
          const type = getValue<string | undefined>();
          return type ? <Badge variant="outline">{type}</Badge> : "—";
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ getValue }) => {
          const status = getValue<string>();
          return <Badge variant={status === "Unread" ? "default" : "secondary"}>{status}</Badge>;
        },
      },
      {
        accessorKey: "sentAt",
        header: "Sent",
        cell: ({ getValue }) => {
          const date = getValue<string>();
          return new Date(date).toLocaleString();
        },
      },
    ],
    [],
  );

  const table = useTable<ContractorMessage>({
    columns,
    refineCoreProps: {
      resource: "contractor_messages",
      filters: {
        permanent: identity?.id
          ? [
              {
                operator: "or",
                value: [
                  { field: "contractorId", operator: "eq", value: identity.id },
                  { field: "receiverId", operator: "eq", value: identity.id },
                ],
              },
            ]
          : [],
      },
    },
  });

  return (
    <ListView>
      <ListViewHeader title="Messages">
        <Link to="/contractor-portal/messages/new">
          <Button>
            <MessageSquare className="h-4 w-4 mr-2" />
            New Message
          </Button>
        </Link>
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
