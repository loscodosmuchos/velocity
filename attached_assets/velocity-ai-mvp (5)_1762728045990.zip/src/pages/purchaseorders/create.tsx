import { type HttpError, useBack, useSelect } from "@refinedev/core";
import { useForm } from "@refinedev/react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Loader2 } from "lucide-react";

import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import type { PurchaseOrder, Buyer } from "../../types";

const poFormSchema = z.object({
  poNumber: z.string().min(1, { message: "PO Number is required" }),
  totalAmount: z.coerce
    .number({ required_error: "Total amount is required" })
    .positive("Total amount must be positive"),
  grAmount: z.coerce.number().optional().default(0),
  startDate: z.string().min(1, { message: "Start date is required" }),
  endDate: z.string().min(1, { message: "End date is required" }),
  status: z.enum(["Draft", "Pending", "Active", "Completed", "Cancelled"], {
    required_error: "Please select a status",
  }),
  type: z.enum(["Time and Materials", "Fixed Fee"], {
    required_error: "Please select a type",
  }),
  departmentId: z.coerce.number({ required_error: "Department is required" }),
  buyerId: z.coerce.number().optional(),
  tpscStatus: z.enum(["Not Started", "In Progress", "Completed"], {
    required_error: "TPSC status is required",
  }),
  fiscalYear: z.string().min(1, { message: "Fiscal year is required" }),
  fiscalPeriod: z.string().min(1, { message: "Fiscal period is required" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
});

type POFormValues = z.infer<typeof poFormSchema>;

export function CreatePurchaseOrderPage() {
  const back = useBack();

  const {
    refineCore: { onFinish, formLoading },
    ...form
  } = useForm<PurchaseOrder, HttpError, PurchaseOrder>({
    refineCoreProps: {
      resource: "purchaseorders",
      action: "create",
      redirect: "list",
    },
  });

  const { options: departmentOptions } = useSelect({
    resource: "departments",
    optionValue: "id",
    optionLabel: "name",
  });

  const { options: buyerOptions } = useSelect<Buyer>({
    resource: "buyers",
    optionValue: "id",
    optionLabel: (item) => `${item.firstName} ${item.lastName}`,
  });

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const poData = {
      poNumber: formData.get("poNumber") as string,
      totalAmount: Number(formData.get("totalAmount")),
      grAmount: Number(formData.get("grAmount")) || 0,
      remainingFunds: Number(formData.get("totalAmount")),
      spentAmount: 0,
      grBalance: Number(formData.get("grAmount")) || 0,
      startDate: formData.get("startDate") as string,
      endDate: formData.get("endDate") as string,
      status: formData.get("status") as "Draft" | "Pending" | "Active" | "Completed" | "Cancelled",
      type: formData.get("type") as "Time and Materials" | "Fixed Fee",
      departmentId: Number(formData.get("departmentId")),
      buyerId: formData.get("buyerId") ? Number(formData.get("buyerId")) : undefined,
      tpscStatus: formData.get("tpscStatus") as "Not Started" | "In Progress" | "Completed",
      fiscalYear: formData.get("fiscalYear") as string,
      fiscalPeriod: formData.get("fiscalPeriod") as string,
      description: formData.get("description") as string,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onFinish(poData as any);
  }

  return (
    <CreateView>
      <CreateViewHeader title="Create Purchase Order" />
      <form onSubmit={onSubmit} className="space-y-6 p-4 max-w-3xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="poNumber" className="text-sm font-medium">
              PO Number
            </label>
            <Input id="poNumber" name="poNumber" placeholder="PO-2024-0001" required />
            <p className="text-sm text-muted-foreground">Unique purchase order identifier</p>
          </div>

          <div className="space-y-2">
            <label htmlFor="totalAmount" className="text-sm font-medium">
              Total Amount ($)
            </label>
            <Input id="totalAmount" name="totalAmount" type="number" placeholder="100000" required />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="grAmount" className="text-sm font-medium">
              GR Amount ($)
            </label>
            <Input id="grAmount" name="grAmount" type="number" placeholder="0" defaultValue="0" />
            <p className="text-sm text-muted-foreground">Goods Receipt authorization amount</p>
          </div>

          <div className="space-y-2">
            <label htmlFor="buyerId" className="text-sm font-medium">
              Buyer
            </label>
            <select
              id="buyerId"
              name="buyerId"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
              <option value="">Select buyer</option>
              {buyerOptions?.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <p className="text-sm text-muted-foreground">Responsible for approval routing</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="startDate" className="text-sm font-medium">
              Start Date
            </label>
            <Input id="startDate" name="startDate" type="date" required />
          </div>

          <div className="space-y-2">
            <label htmlFor="endDate" className="text-sm font-medium">
              End Date
            </label>
            <Input id="endDate" name="endDate" type="date" required />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="fiscalYear" className="text-sm font-medium">
              Fiscal Year
            </label>
            <Input
              id="fiscalYear"
              name="fiscalYear"
              placeholder="2024"
              defaultValue={new Date().getFullYear().toString()}
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="fiscalPeriod" className="text-sm font-medium">
              Fiscal Period
            </label>
            <select
              id="fiscalPeriod"
              name="fiscalPeriod"
              defaultValue="Q1"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              required>
              <option value="Q1">Q1</option>
              <option value="Q2">Q2</option>
              <option value="Q3">Q3</option>
              <option value="Q4">Q4</option>
            </select>
            <p className="text-sm text-muted-foreground">For year-end closing compliance</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="status" className="text-sm font-medium">
              Status
            </label>
            <select
              id="status"
              name="status"
              defaultValue="Draft"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              required>
              <option value="Draft">Draft</option>
              <option value="Pending">Pending</option>
              <option value="Active">Active</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div className="space-y-2">
            <label htmlFor="type" className="text-sm font-medium">
              PO Type
            </label>
            <select
              id="type"
              name="type"
              defaultValue="Time and Materials"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              required>
              <option value="Time and Materials">Time and Materials</option>
              <option value="Fixed Fee">Fixed Fee</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="departmentId" className="text-sm font-medium">
              Department
            </label>
            <select
              id="departmentId"
              name="departmentId"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              required>
              <option value="">Select department</option>
              {departmentOptions?.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label htmlFor="tpscStatus" className="text-sm font-medium">
              TPSC Status
            </label>
            <select
              id="tpscStatus"
              name="tpscStatus"
              defaultValue="Not Started"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              required>
              <option value="Not Started">Not Started</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
            <p className="text-sm text-muted-foreground">Temporary Personnel Services Engagement</p>
          </div>
        </div>

        <div className="space-y-2">
          <label htmlFor="description" className="text-sm font-medium">
            Description
          </label>
          <Textarea
            id="description"
            name="description"
            placeholder="Enter purchase order description and purpose"
            className="resize-none"
            rows={4}
            required
          />
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button type="button" variant="outline" onClick={() => back()}>
            Cancel
          </Button>
          <Button type="submit" disabled={formLoading}>
            {formLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Purchase Order
          </Button>
        </div>
      </form>
    </CreateView>
  );
}
