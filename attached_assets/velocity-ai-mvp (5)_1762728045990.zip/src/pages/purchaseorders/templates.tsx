import { useMemo, useState } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useCreate, useNotification, useGo } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { ListView, ListViewHeader } from "@/components/refine-ui/views/list-view";
import { FileText, Copy, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PurchaseOrder } from "@/types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function POTemplatesPage() {
  const go = useGo();
  const { open } = useNotification();
  const [showCloneDialog, setShowCloneDialog] = useState(false);
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);
  const [cloneCount, setCloneCount] = useState(1);

  const { mutate: createPO } = useCreate();

  const columns = useMemo<ColumnDef<PurchaseOrder>[]>(
    () => [
      {
        id: "poNumber",
        accessorKey: "poNumber",
        size: 150,
        header: "PO Number",
        cell: ({ row }) => <span className="font-medium">{row.original.poNumber}</span>,
      },
      {
        id: "type",
        accessorKey: "type",
        size: 150,
        header: "Type",
        cell: ({ row }) => <Badge variant="outline">{row.original.type}</Badge>,
      },
      {
        id: "totalAmount",
        accessorKey: "totalAmount",
        size: 150,
        header: "Amount",
        cell: ({ row }) =>
          new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
          }).format(row.original.totalAmount),
      },
      {
        id: "description",
        accessorKey: "description",
        size: 300,
        header: "Description",
        enableSorting: false,
        cell: ({ row }) => {
          const desc = row.original.description;
          return desc.length > 60 ? `${desc.substring(0, 60)}...` : desc;
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 120,
        header: "Status",
        cell: ({ row }) => {
          const status = row.original.status;
          const variant =
            status === "Active"
              ? "default"
              : status === "Completed"
                ? "secondary"
                : status === "Draft"
                  ? "outline"
                  : "destructive";
          return <Badge variant={variant}>{status}</Badge>;
        },
      },
      {
        id: "createdAt",
        accessorKey: "createdAt",
        size: 150,
        header: "Created",
        cell: ({ row }) => new Date(row.original.createdAt).toLocaleDateString(),
      },
      {
        id: "actions",
        size: 200,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>,
        cell: ({ row }) => {
          const po = row.original;
          return (
            <div className="flex justify-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => {
                  setSelectedPO(po);
                  setShowCloneDialog(true);
                }}>
                <Copy className="h-3 w-3" />
                Clone
              </Button>
              <Button
                variant="default"
                size="sm"
                className="gap-2"
                onClick={() => {
                  // Create new PO based on template
                  const newPO = {
                    poNumber: `PO-${Date.now()}`,
                    type: po.type,
                    totalAmount: po.totalAmount,
                    remainingFunds: po.totalAmount,
                    spentAmount: 0,
                    grAmount: 0,
                    grBalance: 0,
                    description: po.description,
                    departmentId: po.departmentId,
                    buyerId: po.buyerId,
                    tpscStatus: "Not Started",
                    fiscalYear: new Date().getFullYear().toString(),
                    fiscalPeriod: `Q${Math.ceil((new Date().getMonth() + 1) / 3)}`,
                    startDate: new Date().toISOString().split("T")[0],
                    endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
                    status: "Draft",
                  };

                  createPO(
                    {
                      resource: "purchaseorders",
                      values: newPO,
                    },
                    {
                      onSuccess: (data) => {
                        open?.({
                          type: "success",
                          message: "PO created from template",
                          description: `Created new PO: ${newPO.poNumber}`,
                        });
                        go({ to: `/purchase-orders/${data.data.id}/edit` });
                      },
                    },
                  );
                }}>
                <Plus className="h-3 w-3" />
                Use Template
              </Button>
            </div>
          );
        },
      },
    ],
    [createPO, go, open],
  );

  const table = useTable<PurchaseOrder>({
    columns,
    refineCoreProps: {
      resource: "purchaseorders",
      filters: {
        permanent: [
          {
            field: "status",
            operator: "in",
            value: ["Active", "Completed"],
          },
        ],
      },
    },
  });

  const handleBulkClone = () => {
    if (!selectedPO || cloneCount < 1 || cloneCount > 10) {
      open?.({
        type: "error",
        message: "Invalid clone count",
        description: "Please enter a number between 1 and 10",
      });
      return;
    }

    // Create multiple POs based on template
    for (let i = 0; i < cloneCount; i++) {
      const newPO = {
        poNumber: `${selectedPO.poNumber}-COPY-${i + 1}`,
        type: selectedPO.type,
        totalAmount: selectedPO.totalAmount,
        remainingFunds: selectedPO.totalAmount,
        spentAmount: 0,
        grAmount: 0,
        grBalance: 0,
        description: `${selectedPO.description} (Copy ${i + 1})`,
        departmentId: selectedPO.departmentId,
        buyerId: selectedPO.buyerId,
        tpscStatus: "Not Started",
        fiscalYear: new Date().getFullYear().toString(),
        fiscalPeriod: `Q${Math.ceil((new Date().getMonth() + 1) / 3)}`,
        startDate: new Date().toISOString().split("T")[0],
        endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        status: "Draft",
      };

      createPO({
        resource: "purchaseorders",
        values: newPO,
      });
    }

    open?.({
      type: "success",
      message: "POs created",
      description: `Created ${cloneCount} PO${cloneCount > 1 ? "s" : ""} from template`,
    });

    setShowCloneDialog(false);
    setSelectedPO(null);
    setCloneCount(1);
    table.refineCore.tableQuery.refetch();
  };

  return (
    <ListView>
      <ListViewHeader canCreate={false} title="Purchase Order Templates">
        <Button onClick={() => go({ to: "/purchase-orders/create" })} className="gap-2">
          <Plus className="h-4 w-4" />
          Create New PO
        </Button>
      </ListViewHeader>

      <div className="mb-4 p-4 bg-muted rounded-lg">
        <div className="flex items-start gap-3">
          <FileText className="h-5 w-5 text-primary mt-0.5" />
          <div>
            <h3 className="font-semibold mb-1">PO Templates</h3>
            <p className="text-sm text-muted-foreground">
              Reuse existing purchase orders as templates to quickly create new POs with similar terms and structure.
              This saves time when creating recurring or similar orders.
            </p>
          </div>
        </div>
      </div>

      <DataTable table={table} />

      <Dialog open={showCloneDialog} onOpenChange={setShowCloneDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bulk Clone Purchase Order</DialogTitle>
            <DialogDescription>
              Create multiple purchase orders based on: <strong>{selectedPO?.poNumber}</strong>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="clone-count">Number of Copies (1-10)</Label>
              <Input
                id="clone-count"
                type="number"
                min={1}
                max={10}
                value={cloneCount}
                onChange={(e) => setCloneCount(parseInt(e.target.value) || 1)}
                placeholder="Enter number of copies"
              />
            </div>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Each new PO will be created with:</p>
              <ul className="list-disc list-inside pl-4">
                <li>Same type and amount as the template</li>
                <li>Draft status (ready for customization)</li>
                <li>Current fiscal period</li>
                <li>Unique PO number with -COPY suffix</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCloneDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleBulkClone}>Create {cloneCount} PO(s)</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ListView>
  );
}
