import { useState } from "react";
import { useShow, useList, useCreate, useDelete, useMany } from "@refinedev/core";
import { useParams, useNavigate } from "react-router";
import { Loader2, Plus, Trash2 } from "lucide-react";

import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import type { PurchaseOrder, POContractor, Contractor } from "../../types";

export function ManagePOContractorsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedContractorId, setSelectedContractorId] = useState<number | undefined>();
  const [allocatedAmount, setAllocatedAmount] = useState<string>("");

  const { queryResult: poQueryResult } = useShow<PurchaseOrder>({
    resource: "purchaseorders",
    id,
  });

  const po = poQueryResult?.data?.data;

  const { data: poContractorsData, refetch: refetchPOContractors } = useList<POContractor>({
    resource: "pocontractors",
    filters: [
      {
        field: "purchaseOrderId",
        operator: "eq",
        value: id,
      },
    ],
    queryOptions: {
      enabled: !!id,
    },
  });

  const poContractors = poContractorsData?.data || [];
  const assignedContractorIds = poContractors.map((pc) => pc.contractorId);

  const { data: allContractorsData } = useList<Contractor>({
    resource: "contractors",
    pagination: {
      current: 1,
      pageSize: 100,
    },
    filters: [
      {
        field: "status",
        operator: "eq",
        value: "Active",
      },
    ],
  });

  const availableContractors = allContractorsData?.data?.filter((c) => !assignedContractorIds.includes(c.id)) || [];

  const { data: assignedContractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: assignedContractorIds,
    queryOptions: {
      enabled: assignedContractorIds.length > 0,
    },
  });

  const assignedContractors = assignedContractorsData?.data || [];

  const { mutate: createAssignment, isLoading: isCreating } = useCreate();
  const { mutate: deleteAssignment } = useDelete();

  const handleAddContractor = () => {
    if (!selectedContractorId || !allocatedAmount || !id) return;

    createAssignment(
      {
        resource: "pocontractors",
        values: {
          purchaseOrderId: Number(id),
          contractorId: selectedContractorId,
          allocatedAmount: Number(allocatedAmount),
          createdAt: new Date().toISOString(),
        },
      },
      {
        onSuccess: () => {
          setIsAddDialogOpen(false);
          setSelectedContractorId(undefined);
          setAllocatedAmount("");
          refetchPOContractors();
        },
      },
    );
  };

  const handleRemoveContractor = (poContractorId: number) => {
    deleteAssignment(
      {
        resource: "pocontractors",
        id: poContractorId,
      },
      {
        onSuccess: () => {
          refetchPOContractors();
        },
      },
    );
  };

  if (poQueryResult?.isLoading) {
    return (
      <ShowView>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </ShowView>
    );
  }

  if (!po) {
    return (
      <ShowView>
        <div className="flex items-center justify-center h-96">
          <p>Purchase order not found</p>
        </div>
      </ShowView>
    );
  }

  const totalAllocated = poContractors.reduce((sum, pc) => sum + pc.allocatedAmount, 0);
  const unallocatedFunds = po.totalAmount - totalAllocated;

  return (
    <ShowView>
      <ShowViewHeader title={`Manage Contractors - PO ${po.poNumber}`} />
      <div className="p-4 space-y-6 max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total PO Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${po.totalAmount.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Allocated</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">${totalAllocated.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Unallocated Funds</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${unallocatedFunds.toLocaleString()}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Assigned Contractors</CardTitle>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" disabled={availableContractors.length === 0}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Contractor
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Assign Contractor to PO</DialogTitle>
                  <DialogDescription>
                    Select a contractor and allocate funds from this purchase order.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="contractor">Contractor</Label>
                    <Select
                      value={selectedContractorId?.toString()}
                      onValueChange={(value) => setSelectedContractorId(Number(value))}>
                      <SelectTrigger id="contractor">
                        <SelectValue placeholder="Select a contractor" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableContractors.map((contractor) => (
                          <SelectItem key={contractor.id} value={contractor.id.toString()}>
                            {contractor.firstName} {contractor.lastName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount">Allocated Amount ($)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="50000"
                      value={allocatedAmount}
                      onChange={(e) => setAllocatedAmount(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Available to allocate: ${unallocatedFunds.toLocaleString()}
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} disabled={isCreating}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleAddContractor}
                    disabled={!selectedContractorId || !allocatedAmount || Number(allocatedAmount) <= 0 || isCreating}>
                    {isCreating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Assign Contractor
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            {poContractors.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">
                No contractors assigned to this purchase order yet.
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contractor Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Pay Rate</TableHead>
                    <TableHead className="text-right">Allocated Amount</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {poContractors.map((poContractor) => {
                    const contractor = assignedContractors.find((c) => c.id === poContractor.contractorId);
                    return (
                      <TableRow key={poContractor.id}>
                        <TableCell className="font-medium">
                          {contractor ? `${contractor.firstName} ${contractor.lastName}` : "Loading..."}
                        </TableCell>
                        <TableCell>{contractor?.email || "-"}</TableCell>
                        <TableCell>${contractor?.payRate || 0}/hr</TableCell>
                        <TableCell className="text-right font-medium">
                          ${poContractor.allocatedAmount.toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => handleRemoveContractor(poContractor.id)}>
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={() => navigate(`/purchase-orders/${id}`)}>Back to PO Details</Button>
        </div>
      </div>
    </ShowView>
  );
}
