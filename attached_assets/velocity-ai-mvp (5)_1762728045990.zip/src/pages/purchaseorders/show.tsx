import { useShow, useMany, useList } from "@refinedev/core";
import { useParams } from "react-router";
import { Loader2, Users } from "lucide-react";

import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import type { PurchaseOrder, Department, POContractor, Contractor, Buyer } from "../../types";

const statusColors: Record<PurchaseOrder["status"], string> = {
  Draft: "bg-gray-100 text-gray-800 hover:bg-gray-100",
  Pending: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
  Active: "bg-green-100 text-green-800 hover:bg-green-100",
  Completed: "bg-blue-100 text-blue-800 hover:bg-blue-100",
  Cancelled: "bg-red-100 text-red-800 hover:bg-red-100",
};

export function PurchaseOrderShowPage() {
  const { id } = useParams();

  const { queryResult } = useShow<PurchaseOrder>({
    resource: "purchaseorders",
    id,
  });

  const po = queryResult?.data?.data;

  const { data: departmentData } = useMany<Department>({
    resource: "departments",
    ids: po?.departmentId ? [po.departmentId] : [],
    queryOptions: {
      enabled: !!po?.departmentId,
    },
  });

  const department = departmentData?.data?.[0];

  const { data: buyerData } = useMany<Buyer>({
    resource: "buyers",
    ids: po?.buyerId ? [po.buyerId] : [],
    queryOptions: {
      enabled: !!po?.buyerId,
    },
  });

  const buyer = buyerData?.data?.[0];

  // Fetch contractors assigned to this PO
  const { data: poContractorsData } = useList<POContractor>({
    resource: "pocontractors",
    filters: [
      {
        field: "purchaseOrderId",
        operator: "eq",
        value: id,
      },
    ],
    queryOptions: {
      enabled: !!id,
    },
  });

  const poContractors = poContractorsData?.data || [];
  const contractorIds = poContractors.map((pc) => pc.contractorId);

  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: {
      enabled: contractorIds.length > 0,
    },
  });

  const contractors = contractorsData?.data || [];

  if (queryResult?.isLoading) {
    return (
      <ShowView>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </ShowView>
    );
  }

  if (!po) {
    return (
      <ShowView>
        <div className="flex items-center justify-center h-96">
          <p>Purchase order not found</p>
        </div>
      </ShowView>
    );
  }

  const budgetPercentage = (po.remainingFunds / po.totalAmount) * 100;
  const grPercentage = po.grAmount > 0 ? (po.grBalance / po.grAmount) * 100 : 0;

  return (
    <ShowView>
      <ShowViewHeader title={`Purchase Order ${po.poNumber}`}>
        <Button
          variant="outline"
          size="sm"
          onClick={() => (window.location.href = `/purchase-orders/${id}/contractors`)}>
          <Users className="h-4 w-4 mr-2" />
          Manage Contractors
        </Button>
      </ShowViewHeader>
      <div className="p-4 space-y-6 max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${po.totalAmount.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Remaining Funds</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${po.remainingFunds.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">{budgetPercentage.toFixed(1)}% remaining</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Spent Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">${po.spentAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {((po.spentAmount / po.totalAmount) * 100).toFixed(1)}% spent
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">GR Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">${po.grBalance.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">{grPercentage.toFixed(1)}% of GR amount</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Purchase Order Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">PO Number</label>
                <p className="mt-1 font-medium">{po.poNumber}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Status</label>
                <div className="mt-1">
                  <Badge className={statusColors[po.status]} variant="secondary">
                    {po.status}
                  </Badge>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Type</label>
                <p className="mt-1">{po.type}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Department</label>
                <p className="mt-1">{department?.name || "-"}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Buyer</label>
                <p className="mt-1">{buyer ? `${buyer.firstName} ${buyer.lastName}` : "Not Assigned"}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">TPSC Status</label>
                <p className="mt-1">{po.tpscStatus}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Start Date</label>
                <p className="mt-1">{new Date(po.startDate).toLocaleDateString()}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">End Date</label>
                <p className="mt-1">{new Date(po.endDate).toLocaleDateString()}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Fiscal Year</label>
                <p className="mt-1">{po.fiscalYear}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Fiscal Period</label>
                <p className="mt-1">{po.fiscalPeriod}</p>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">GR Amount</label>
                <p className="mt-1 font-medium">${po.grAmount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Goods Receipt authorization</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">GR Balance</label>
                <p className="mt-1 font-medium">${po.grBalance.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Remaining GR authorization</p>
              </div>
            </div>

            <Separator />

            <div>
              <label className="text-sm font-medium text-muted-foreground">Description</label>
              <p className="mt-1">{po.description}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Assigned Contractors</CardTitle>
          </CardHeader>
          <CardContent>
            {poContractors.length === 0 ? (
              <p className="text-muted-foreground text-sm">No contractors assigned to this purchase order yet.</p>
            ) : (
              <div className="space-y-3">
                {poContractors.map((poContractor) => {
                  const contractor = contractors.find((c) => c.id === poContractor.contractorId);
                  return (
                    <div key={poContractor.id} className="flex items-center justify-between border rounded-lg p-3">
                      <div>
                        <p className="font-medium">
                          {contractor ? `${contractor.firstName} ${contractor.lastName}` : "Loading..."}
                        </p>
                        <p className="text-sm text-muted-foreground">{contractor?.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${poContractor.allocatedAmount.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">Allocated</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </ShowView>
  );
}
