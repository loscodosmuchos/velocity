import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany } from "@refinedev/core";
import { MoreHorizontal, Download } from "lucide-react";
import { useNavigate } from "react-router";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import {
  DataTableFilterDropdownText,
  DataTableFilterCombobox,
  DataTableFilterDropdownNumeric,
} from "@/components/refine-ui/data-table/data-table-filter";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { DeleteButton } from "@/components/refine-ui/buttons/delete";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { exportToCSV, exportToJSON } from "@/utils/export";
import type { PurchaseOrder, Department, Buyer } from "../../types";

const statusColors: Record<PurchaseOrder["status"], string> = {
  Draft: "bg-gray-100 text-gray-800 hover:bg-gray-100",
  Pending: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100",
  Active: "bg-green-100 text-green-800 hover:bg-green-100",
  Completed: "bg-blue-100 text-blue-800 hover:bg-blue-100",
  Cancelled: "bg-red-100 text-red-800 hover:bg-red-100",
};

export function PurchaseOrdersListPage() {
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<PurchaseOrder>[]>(
    () => [
      {
        id: "id",
        accessorKey: "id",
        size: 80,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>ID</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownNumeric
                  defaultOperator="eq"
                  column={column}
                  table={table}
                  placeholder="Filter by ID"
                />
              </div>
            </div>
          );
        },
      },
      {
        id: "poNumber",
        accessorKey: "poNumber",
        size: 150,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>PO Number</span>
              <div>
                <DataTableSorter column={column} />
                <DataTableFilterDropdownText
                  defaultOperator="contains"
                  column={column}
                  table={table}
                  placeholder="Filter by PO number"
                />
              </div>
            </div>
          );
        },
        cell: ({ row }) => {
          return (
            <div
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/purchase-orders/show/${row.original.id}`)}>
              {row.original.poNumber}
            </div>
          );
        },
      },
      {
        id: "description",
        accessorKey: "description",
        size: 300,
        header: "Description",
        enableSorting: false,
        cell: ({ row }) => {
          return (
            <div className="max-w-[300px] truncate" title={row.original.description}>
              {row.original.description}
            </div>
          );
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Status</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Draft", value: "Draft" },
                  { label: "Pending", value: "Pending" },
                  { label: "Active", value: "Active" },
                  { label: "Completed", value: "Completed" },
                  { label: "Cancelled", value: "Cancelled" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          const status = row.original.status;
          return (
            <Badge className={statusColors[status]} variant="secondary">
              {status}
            </Badge>
          );
        },
      },
      {
        id: "type",
        accessorKey: "type",
        size: 180,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Type</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Time and Materials", value: "Time and Materials" },
                  { label: "Fixed Fee", value: "Fixed Fee" },
                ]}
              />
            </div>
          );
        },
      },
      {
        id: "buyerId",
        accessorKey: "buyerId",
        size: 160,
        header: "Buyer",
        cell: ({ getValue, table }) => {
          const buyerId = getValue<number | undefined>();
          if (!buyerId) return <span className="text-muted-foreground">Not Assigned</span>;
          const buyers = (table.options.meta as any)?.buyers || [];
          const buyer = buyers.find((b: Buyer) => b.id === buyerId);
          return buyer ? `${buyer.firstName} ${buyer.lastName}` : "-";
        },
      },
      {
        id: "departmentId",
        accessorKey: "departmentId",
        size: 180,
        header: ({ column, table }) => {
          const departments = (table.options.meta as any)?.departments || [];
          return (
            <div className="flex items-center gap-1">
              <span>Department</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={departments.map((dept: Department) => ({
                  label: dept.name,
                  value: dept.id.toString(),
                }))}
              />
            </div>
          );
        },
        cell: ({ getValue, table }) => {
          const departmentId = getValue<number>();
          const departments = (table.options.meta as any)?.departments || [];
          const department = departments.find((d: Department) => d.id === departmentId);
          return department?.name || "-";
        },
      },
      {
        id: "totalAmount",
        accessorKey: "totalAmount",
        size: 140,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Total Amount</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return <div className="font-medium">${row.original.totalAmount.toLocaleString()}</div>;
        },
      },
      {
        id: "grBalance",
        accessorKey: "grBalance",
        size: 140,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>GR Balance</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          const grBalance = row.original.grBalance;
          const grAmount = row.original.grAmount;
          const hasGR = grAmount > 0;

          if (!hasGR) return <span className="text-muted-foreground">No GR</span>;

          const percentage = (grBalance / grAmount) * 100;
          const colorClass = percentage > 50 ? "text-green-600" : percentage > 20 ? "text-yellow-600" : "text-red-600";

          return <div className={cn("font-medium", colorClass)}>${grBalance.toLocaleString()}</div>;
        },
      },
      {
        id: "remainingFunds",
        accessorKey: "remainingFunds",
        size: 140,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Remaining</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          const remaining = row.original.remainingFunds;
          const total = row.original.totalAmount;
          const percentage = (remaining / total) * 100;
          const colorClass = percentage > 50 ? "text-green-600" : percentage > 20 ? "text-yellow-600" : "text-red-600";

          return <div className={cn("font-medium", colorClass)}>${remaining.toLocaleString()}</div>;
        },
      },
      {
        id: "fiscalPeriod",
        accessorKey: "fiscalPeriod",
        size: 120,
        header: "Fiscal Period",
        cell: ({ row }) => {
          return `${row.original.fiscalYear} ${row.original.fiscalPeriod}`;
        },
      },
      {
        id: "startDate",
        accessorKey: "startDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Start Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return new Date(row.original.startDate).toLocaleDateString();
        },
      },
      {
        id: "endDate",
        accessorKey: "endDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>End Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return new Date(row.original.endDate).toLocaleDateString();
        },
      },
      {
        id: "actions",
        size: 84,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => {
          return <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>;
        },
        cell: ({ row }) => {
          const po = row.original;
          return (
            <div className="flex items-center gap-2 justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/purchase-orders/show/${po.id}`);
                }}>
                View
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/purchase-orders/edit/${po.id}`);
                }}>
                Edit
              </Button>
            </div>
          );
        },
      },
    ],
    [navigate],
  );

  const table = useTable<PurchaseOrder>({
    columns,
    refineCoreProps: {
      meta: {
        populate: ["department", "buyer"],
      },
    },
    initialState: {
      columnPinning: {
        left: [],
        right: ["actions"],
      },
    },
  });

  // Fetch departments for filtering
  const departmentIds = table.getRowModel().rows.map((row) => row.original.departmentId);
  const { data: departmentsData } = useMany<Department>({
    resource: "departments",
    ids: departmentIds,
    queryOptions: {
      enabled: departmentIds.length > 0,
    },
  });

  // Fetch buyers for display
  const buyerIds = table
    .getRowModel()
    .rows.map((row) => row.original.buyerId)
    .filter((id): id is number => !!id);
  const { data: buyersData } = useMany<Buyer>({
    resource: "buyers",
    ids: buyerIds,
    queryOptions: {
      enabled: buyerIds.length > 0,
    },
  });

  // Set departments and buyers in table meta
  table.options.meta = {
    ...table.options.meta,
    departments: departmentsData?.data || [],
    buyers: buyersData?.data || [],
  };

  const handleExportCSV = () => {
    const rows = table.getFilteredRowModel().rows.map((row) => {
      const po = row.original;
      const departments = (table.options.meta as any)?.departments || [];
      const buyers = (table.options.meta as any)?.buyers || [];
      const department = departments.find((d: Department) => d.id === po.departmentId);
      const buyer = buyers.find((b: Buyer) => b.id === po.buyerId);

      return {
        id: po.id,
        poNumber: po.poNumber,
        description: po.description,
        status: po.status,
        type: po.type,
        buyer: buyer ? `${buyer.firstName} ${buyer.lastName}` : "Not Assigned",
        department: department?.name || "",
        totalAmount: po.totalAmount,
        spentAmount: po.spentAmount,
        remainingFunds: po.remainingFunds,
        grAmount: po.grAmount,
        grBalance: po.grBalance,
        fiscalYear: po.fiscalYear,
        fiscalPeriod: po.fiscalPeriod,
        startDate: new Date(po.startDate).toLocaleDateString(),
        endDate: new Date(po.endDate).toLocaleDateString(),
        tpscStatus: po.tpscStatus,
      };
    });

    exportToCSV(rows, `purchase-orders-${new Date().toISOString().split("T")[0]}`, {
      id: "ID",
      poNumber: "PO Number",
      description: "Description",
      status: "Status",
      type: "Type",
      buyer: "Buyer",
      department: "Department",
      totalAmount: "Total Amount",
      spentAmount: "Spent Amount",
      remainingFunds: "Remaining Funds",
      grAmount: "GR Amount",
      grBalance: "GR Balance",
      fiscalYear: "Fiscal Year",
      fiscalPeriod: "Fiscal Period",
      startDate: "Start Date",
      endDate: "End Date",
      tpscStatus: "TPSC Status",
    });
  };

  const handleExportJSON = () => {
    const rows = table.getFilteredRowModel().rows.map((row) => row.original);
    exportToJSON(rows, `purchase-orders-${new Date().toISOString().split("T")[0]}`);
  };

  return (
    <ListView>
      <ListViewHeader canCreate={true}>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleExportCSV}>Export as CSV</DropdownMenuItem>
            <DropdownMenuItem onClick={handleExportJSON}>Export as JSON</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
