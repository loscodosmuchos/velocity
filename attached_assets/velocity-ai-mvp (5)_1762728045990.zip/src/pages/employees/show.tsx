import { useShow } from "@refinedev/core";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import dayjs from "dayjs";

import type { Employee } from "../../types";

export const EmployeesShowPage = () => {
  const { queryResult } = useShow<Employee>();
  const { data, isLoading } = queryResult;

  const record = data?.data;

  return (
    <ShowView>
      <ShowViewHeader title={record ? `${record.firstName} ${record.lastName}` : "Employee Details"} />
      <LoadingOverlay loading={isLoading}>
        {record && (
          <Tabs defaultValue="information" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="information">Employee Information</TabsTrigger>
              <TabsTrigger value="expenses">Expenses</TabsTrigger>
            </TabsList>
            <TabsContent value="information">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold">Profile Information</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center gap-4">
                    <Avatar className="w-32 h-32">
                      <AvatarImage src={record.avatarUrl} alt={`${record.firstName} ${record.lastName}`} />
                      <AvatarFallback>
                        {record.firstName[0]}
                        {record.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <h2 className="text-xl font-semibold">
                        {record.firstName} {record.lastName}
                      </h2>
                      <p className="text-muted-foreground">{record.jobTitle}</p>
                      <Badge variant="secondary" className="mt-2">
                        {record.role}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="col-span-1 lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold">Contact Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Email</p>
                        <p className="font-medium">{record.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Phone</p>
                        <p className="font-medium">{record.phone}</p>
                      </div>
                      <div className="md:col-span-2">
                        <p className="text-sm text-muted-foreground">Address</p>
                        <p className="font-medium">{record.address}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold">Personal Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Birthdate</p>
                      <p className="font-medium">{dayjs(record.birthdate).format("MMMM D, YYYY")}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Annual Leave Days</p>
                      <p className="font-medium">{record.availableAnnualLeaveDays} days</p>
                    </div>
                    {record.links.length > 0 && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Social Links</p>
                        <div className="space-y-1">
                          {record.links.map((link, index) => (
                            <a
                              key={index}
                              href={link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="block text-sm text-blue-600 hover:underline dark:text-blue-400">
                              {link}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="col-span-1 lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold">Custom Fields</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px] pr-4">
                      <div className="space-y-4">
                        {record.customFields.map((field, index) => (
                          <div key={index}>
                            <p className="text-sm text-muted-foreground">{field.key}</p>
                            <p className="font-medium">{field.value}</p>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="expenses">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">Employee Expenses</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Expense tracking functionality will be implemented here.</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </LoadingOverlay>
    </ShowView>
  );
};
