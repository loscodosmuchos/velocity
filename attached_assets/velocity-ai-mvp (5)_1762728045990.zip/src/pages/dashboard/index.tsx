import { useList, useGo } from "@refinedev/core";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DollarSign,
  Users,
  FileText,
  TrendingUp,
  Clock,
  Receipt,
  AlertTriangle,
  CheckCircle,
  TrendingDown,
  ArrowUpRight,
  UserCheck,
  Package,
  Brain,
  Sparkles,
} from "lucide-react";
import type {
  Contractor,
  PurchaseOrder,
  Timecard,
  Invoice,
  Department,
  StatementOfWork,
  ChangeOrder,
  Buyer,
} from "@/types";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts";
import { Progress } from "@/components/ui/progress";

export function DashboardPage() {
  const go = useGo();

  // Fetch contractors
  const { data: contractorsData } = useList<Contractor>({
    resource: "contractors",
    pagination: { mode: "off" },
  });

  // Fetch purchase orders
  const { data: purchaseOrdersData } = useList<PurchaseOrder>({
    resource: "purchaseorders",
    pagination: { mode: "off" },
  });

  // Fetch timecards
  const { data: timecardsData } = useList<Timecard>({
    resource: "timecards",
    pagination: { mode: "off" },
  });

  // Fetch invoices
  const { data: invoicesData } = useList<Invoice>({
    resource: "invoices",
    pagination: { mode: "off" },
  });

  // Fetch departments
  const { data: departmentsData } = useList<Department>({
    resource: "departments",
    pagination: { mode: "off" },
  });

  // Fetch SOWs
  const { data: sowsData } = useList<StatementOfWork>({
    resource: "statementofworks",
    pagination: { mode: "off" },
  });

  // Fetch change orders
  const { data: changeOrdersData } = useList<ChangeOrder>({
    resource: "changeorders",
    pagination: { mode: "off" },
  });

  // Fetch buyers
  const { data: buyersData } = useList<Buyer>({
    resource: "buyers",
    pagination: { mode: "off" },
  });

  const contractors = contractorsData?.data || [];
  const purchaseOrders = purchaseOrdersData?.data || [];
  const timecards = timecardsData?.data || [];
  const invoices = invoicesData?.data || [];
  const departments = departmentsData?.data || [];
  const sows = sowsData?.data || [];
  const changeOrders = changeOrdersData?.data || [];
  const buyers = buyersData?.data || [];

  // Calculate statistics
  const activeContractors = contractors.filter((c) => c.status === "Active").length;
  const activePOs = purchaseOrders.filter((po) => po.status === "Active").length;
  const totalPOValue = purchaseOrders.reduce((sum, po) => sum + po.totalAmount, 0);
  const remainingPOFunds = purchaseOrders.reduce((sum, po) => sum + po.remainingFunds, 0);

  // PO Buyer and GR tracking
  const posWithoutBuyer = purchaseOrders.filter((po) => po.status === "Active" && !po.buyerId).length;
  const totalGRAmount = purchaseOrders.reduce((sum, po) => sum + po.grAmount, 0);
  const totalGRBalance = purchaseOrders.reduce((sum, po) => sum + po.grBalance, 0);
  const grUtilization = totalGRAmount > 0 ? ((totalGRAmount - totalGRBalance) / totalGRAmount) * 100 : 0;

  // Fiscal period tracking
  const currentFiscalYear = new Date().getFullYear().toString();
  const currentQuarter = `Q${Math.ceil((new Date().getMonth() + 1) / 3)}`;
  const posInCurrentPeriod = purchaseOrders.filter(
    (po) => po.fiscalYear === currentFiscalYear && po.fiscalPeriod === currentQuarter,
  ).length;

  // Timecard statistics
  const pendingTimecards = timecards.filter((t) => t.status === "Pending").length;
  const approvedTimecards = timecards.filter((t) => t.status === "Approved").length;

  // Invoice statistics
  const pendingInvoices = invoices.filter((i) => i.status === "Submitted").length;
  const grApprovedInvoices = invoices.filter((i) => i.status === "GR Approved").length;
  const paidInvoices = invoices.filter((i) => i.status === "Paid").length;
  const invoicesWithVariance = invoices.filter((i) => i.hasVariance).length;
  const totalInvoiceValue = invoices.reduce((sum, i) => sum + i.actualAmount, 0);

  // Department spend analysis
  const departmentSpend = departments
    .map((dept) => {
      const deptPOs = purchaseOrders.filter((po) => po.departmentId === dept.id);
      const spent = deptPOs.reduce((sum, po) => sum + po.spentAmount, 0);
      const budget = dept.budget;
      const utilization = budget > 0 ? (spent / budget) * 100 : 0;
      return {
        name: dept.name,
        division: dept.division,
        budget,
        spent,
        remaining: budget - spent,
        utilization,
        status: utilization > 90 ? "critical" : utilization > 75 ? "warning" : "good",
      };
    })
    .sort((a, b) => b.spent - a.spent);

  // Top contractors by spend
  const contractorSpend = contractors
    .map((contractor) => {
      const contractorInvoices = invoices.filter((inv) => inv.contractorId === contractor.id);
      const totalSpend = contractorInvoices.reduce((sum, inv) => sum + inv.actualAmount, 0);
      const department = departments.find((d) => d.id === contractor.departmentId);
      return {
        id: contractor.id,
        name: `${contractor.firstName} ${contractor.lastName}`,
        department: department?.name || "Unknown",
        totalSpend,
        status: contractor.status,
      };
    })
    .sort((a, b) => b.totalSpend - a.totalSpend)
    .slice(0, 10);

  // SOW variance analysis
  const sowVariance = sows
    .map((sow) => {
      const variance = sow.invoicedAmount - sow.totalValue;
      const variancePercent = sow.totalValue > 0 ? (variance / sow.totalValue) * 100 : 0;
      const contractor = contractors.find((c) => c.id === sow.contractorId);

      // Get change orders for this SOW
      const sowChangeOrders = changeOrders.filter((co) => co.sowId === sow.id && co.status === "Approved");
      const totalChangeOrderImpact = sowChangeOrders.reduce((sum, co) => sum + co.requestedChange, 0);

      return {
        sowNumber: sow.sowNumber,
        contractorName: contractor ? `${contractor.firstName} ${contractor.lastName}` : "Unknown",
        totalValue: sow.totalValue,
        invoicedAmount: sow.invoicedAmount,
        variance,
        variancePercent,
        status: sow.status,
        changeOrderCount: sowChangeOrders.length,
        changeOrderImpact: totalChangeOrderImpact,
        hasIssue: variance > 0 || variancePercent > 10,
      };
    })
    .filter((s) => s.hasIssue && s.status === "Active")
    .sort((a, b) => Math.abs(b.variancePercent) - Math.abs(a.variancePercent));

  // Change order statistics
  const approvedChangeOrders = changeOrders.filter((co) => co.status === "Approved").length;
  const pendingChangeOrders = changeOrders.filter((co) => co.status === "Pending").length;
  const totalChangeOrderImpact = changeOrders
    .filter((co) => co.status === "Approved")
    .reduce((sum, co) => sum + co.requestedChange, 0);

  // Chart configuration
  const chartConfig = {
    spent: {
      label: "Spent",
      color: "hsl(var(--chart-1))",
    },
    budget: {
      label: "Budget",
      color: "hsl(var(--chart-2))",
    },
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Executive Dashboard</h2>
        <p className="text-muted-foreground">Velocity Workforce Management System - Strategic Overview</p>
      </div>

      {/* AI-Generated Top Risks - NEW SECTION */}
      {(invoicesWithVariance > 0 || sowVariance.length > 0) && (
        <Card className="border-2 border-primary/30 shadow-lg bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Brain className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="flex items-center gap-2">
                    AI-Generated Insights
                    <Badge variant="secondary" className="text-xs">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Live
                    </Badge>
                  </CardTitle>
                  <CardDescription>Top risks detected by AI analysis - Requires immediate attention</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => go({ to: "/ai/insights" })}>
                View All Insights
                <ArrowUpRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {/* Budget Overrun Alert */}
              {purchaseOrders.some((po) => (po.spentAmount / po.totalAmount) * 100 > 85) && (
                <div className="bg-white dark:bg-gray-900 border-l-4 border-red-500 p-4 rounded-lg shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="destructive">Critical</Badge>
                        <span className="text-xs text-muted-foreground">Budget Overrun Prediction</span>
                      </div>
                      <h4 className="font-semibold text-sm mb-1">Multiple POs At Risk of Budget Exhaustion</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        {purchaseOrders.filter((po) => (po.spentAmount / po.totalAmount) * 100 > 85).length} purchase
                        orders have consumed &gt;85% of budget with significant time remaining.
                      </p>
                      <div className="bg-blue-50 dark:bg-blue-950/20 p-2 rounded text-xs">
                        <span className="font-medium">💡 Recommended: </span>
                        Review contractor hours immediately. Consider rate negotiation or budget increase requests.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Invoice Variance Alert */}
              {invoicesWithVariance > 0 && (
                <div className="bg-white dark:bg-gray-900 border-l-4 border-orange-500 p-4 rounded-lg shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary">High</Badge>
                        <span className="text-xs text-muted-foreground">Variance Detection</span>
                      </div>
                      <h4 className="font-semibold text-sm mb-1">
                        {invoicesWithVariance} Invoices with Variances Detected
                      </h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        System detected discrepancies between requested and actual invoice amounts. Pattern suggests
                        timecard review process gaps.
                      </p>
                      <div className="bg-blue-50 dark:bg-blue-950/20 p-2 rounded text-xs">
                        <span className="font-medium">💡 Recommended: </span>
                        Implement pre-approval for contractor hours before timecard submission.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SOW Timeline Risk */}
              {sowVariance.length > 0 && (
                <div className="bg-white dark:bg-gray-900 border-l-4 border-orange-500 p-4 rounded-lg shadow-sm">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary">High</Badge>
                        <span className="text-xs text-muted-foreground">Timeline Risk</span>
                      </div>
                      <h4 className="font-semibold text-sm mb-1">{sowVariance.length} SOWs Showing Budget Overruns</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Invoiced amounts exceed original SOW values. Likely delivery delays or scope creep.
                      </p>
                      <div className="bg-blue-50 dark:bg-blue-950/20 p-2 rounded text-xs">
                        <span className="font-medium">💡 Recommended: </span>
                        Schedule urgent review meetings. Assess scope changes and timeline impacts.
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="cursor-pointer hover:bg-muted/50" onClick={() => go({ to: "/contractors" })}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Contractors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeContractors}</div>
            <p className="text-xs text-muted-foreground">of {contractors.length} total</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:bg-muted/50" onClick={() => go({ to: "/purchase-orders" })}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(totalPOValue)}
            </div>
            <p className="text-xs text-muted-foreground">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(totalPOValue - remainingPOFunds)}{" "}
              spent
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Budget Utilization</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalPOValue > 0 ? Math.round(((totalPOValue - remainingPOFunds) / totalPOValue) * 100) : 0}%
            </div>
            <Progress
              value={totalPOValue > 0 ? ((totalPOValue - remainingPOFunds) / totalPOValue) * 100 : 0}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card className={`${invoicesWithVariance > 0 || sowVariance.length > 0 ? "border-orange-200" : ""}`}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
            <AlertTriangle
              className={`h-4 w-4 ${invoicesWithVariance > 0 || sowVariance.length > 0 ? "text-orange-500" : "text-muted-foreground"}`}
            />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{invoicesWithVariance + sowVariance.length}</div>
            <p className="text-xs text-muted-foreground">
              {invoicesWithVariance} invoice + {sowVariance.length} SOW issues
            </p>
          </CardContent>
        </Card>
      </div>

      {/* PO Control Metrics - New Section */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className={posWithoutBuyer > 0 ? "border-orange-200" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Buyer Assignment</CardTitle>
            <UserCheck className={`h-4 w-4 ${posWithoutBuyer > 0 ? "text-orange-500" : "text-green-500"}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activePOs - posWithoutBuyer}</div>
            <p className="text-xs text-muted-foreground">of {activePOs} active POs</p>
            {posWithoutBuyer > 0 && (
              <Badge variant="secondary" className="mt-2 text-xs">
                {posWithoutBuyer} unassigned
              </Badge>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">GR Authorization</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(totalGRAmount)}
            </div>
            <p className="text-xs text-muted-foreground">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(totalGRBalance)}{" "}
              remaining
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">GR Utilization</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{grUtilization.toFixed(0)}%</div>
            <Progress value={grUtilization} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Period POs</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{posInCurrentPeriod}</div>
            <p className="text-xs text-muted-foreground">
              {currentFiscalYear} {currentQuarter}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Department Budget vs Spend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Department Budget Analysis</CardTitle>
          <CardDescription>Spend vs Budget by Department (Top 6)</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentSpend.slice(0, 6)}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} />
                <YAxis
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="spent" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]}>
                  {departmentSpend.slice(0, 6).map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        entry.status === "critical"
                          ? "hsl(var(--destructive))"
                          : entry.status === "warning"
                            ? "hsl(var(--warning))"
                            : "hsl(var(--chart-1))"
                      }
                    />
                  ))}
                </Bar>
                <Bar dataKey="budget" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} fillOpacity={0.3} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
          <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
            {departmentSpend.slice(0, 3).map((dept) => (
              <div key={dept.name} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium truncate">{dept.name}</span>
                  <Badge
                    variant={
                      dept.status === "critical" ? "destructive" : dept.status === "warning" ? "secondary" : "outline"
                    }>
                    {dept.utilization.toFixed(0)}%
                  </Badge>
                </div>
                <Progress value={dept.utilization} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact" }).format(
                    dept.spent,
                  )}{" "}
                  /
                  {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact" }).format(
                    dept.budget,
                  )}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Contractors and SOW Alerts */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Top Contractors by Spend */}
        <Card>
          <CardHeader>
            <CardTitle>Top Contractors by Spend</CardTitle>
            <CardDescription>Highest spending contractors across all departments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {contractorSpend.slice(0, 8).map((contractor, index) => (
                <div
                  key={contractor.id}
                  className="flex items-center justify-between cursor-pointer hover:bg-muted/50 p-2 rounded-md transition-colors"
                  onClick={() => go({ to: `/contractors/show/${contractor.id}` })}>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{contractor.name}</p>
                      <p className="text-xs text-muted-foreground">{contractor.department}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                        notation: "compact",
                        maximumFractionDigits: 1,
                      }).format(contractor.totalSpend)}
                    </p>
                    <Badge variant={contractor.status === "Active" ? "default" : "secondary"} className="text-xs">
                      {contractor.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* SOW Variance Alerts */}
        <Card className={sowVariance.length > 0 ? "border-orange-200" : ""}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>SOW Variance Alerts</CardTitle>
                <CardDescription>Active SOWs with budget overruns or significant variance</CardDescription>
              </div>
              {sowVariance.length > 0 && <AlertTriangle className="h-5 w-5 text-orange-500" />}
            </div>
          </CardHeader>
          <CardContent>
            {sowVariance.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-2" />
                <p className="text-sm font-medium">All SOWs Within Budget</p>
                <p className="text-xs text-muted-foreground">No active variance issues detected</p>
              </div>
            ) : (
              <div className="space-y-3">
                {sowVariance.slice(0, 6).map((sow) => (
                  <div
                    key={sow.sowNumber}
                    className="border rounded-lg p-3 hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => go({ to: "/statement-of-works" })}>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-sm">{sow.sowNumber}</p>
                        <p className="text-xs text-muted-foreground">{sow.contractorName}</p>
                      </div>
                      <Badge variant="destructive" className="text-xs">
                        {sow.variancePercent > 0 ? "+" : ""}
                        {sow.variancePercent.toFixed(1)}%
                      </Badge>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Value:</span>
                        <span className="font-medium">
                          {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
                            sow.totalValue,
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Invoiced:</span>
                        <span className="font-medium text-orange-600">
                          {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
                            sow.invoicedAmount,
                          )}
                        </span>
                      </div>
                      {sow.changeOrderCount > 0 && (
                        <div className="flex justify-between items-center pt-1 border-t">
                          <span className="text-muted-foreground">{sow.changeOrderCount} change orders:</span>
                          <span
                            className={`font-medium ${sow.changeOrderImpact > 0 ? "text-orange-600" : "text-green-600"}`}>
                            {sow.changeOrderImpact > 0 ? "+" : ""}
                            {new Intl.NumberFormat("en-US", {
                              style: "currency",
                              currency: "USD",
                              notation: "compact",
                            }).format(sow.changeOrderImpact)}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Change Orders and Time/Invoice Summary */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="cursor-pointer hover:bg-muted/50" onClick={() => go({ to: "/change-orders" })}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Change Orders</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{changeOrders.length}</div>
            <div className="flex gap-2 mt-2 mb-3">
              <Badge variant="secondary" className="text-xs">
                {pendingChangeOrders} pending
              </Badge>
              <Badge variant="default" className="text-xs">
                {approvedChangeOrders} approved
              </Badge>
            </div>
            <div className="pt-2 border-t">
              <p className="text-xs text-muted-foreground mb-1">Total Impact</p>
              <p
                className={`text-sm font-semibold ${totalChangeOrderImpact > 0 ? "text-orange-600" : "text-green-600"}`}>
                {totalChangeOrderImpact > 0 ? "+" : ""}
                {new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact" }).format(
                  totalChangeOrderImpact,
                )}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card
          className={`cursor-pointer hover:bg-muted/50 ${pendingTimecards > 0 ? "border-orange-200" : ""}`}
          onClick={() => go({ to: "/timecards/pending" })}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Timecard Status</CardTitle>
            <Clock className={`h-4 w-4 ${pendingTimecards > 0 ? "text-orange-500" : "text-muted-foreground"}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingTimecards}</div>
            <p className="text-xs text-muted-foreground mb-3">pending approval</p>
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Approved</span>
                <span className="font-medium">{approvedTimecards}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Total Submitted</span>
                <span className="font-medium">{timecards.length}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:bg-muted/50" onClick={() => go({ to: "/invoices" })}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Invoice Pipeline</CardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
                notation: "compact",
                maximumFractionDigits: 1,
              }).format(totalInvoiceValue)}
            </div>
            <p className="text-xs text-muted-foreground mb-3">total invoiced</p>
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Pending GR</span>
                <Badge variant="secondary" className="text-xs">
                  {pendingInvoices}
                </Badge>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Paid</span>
                <Badge variant="default" className="text-xs">
                  {paidInvoices}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and workflows</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
          <Button variant="outline" onClick={() => go({ to: "/timecards/create" })}>
            <Clock className="mr-2 h-4 w-4" />
            Submit Timecard
          </Button>
          <Button variant="outline" onClick={() => go({ to: "/timecards/pending" })}>
            <CheckCircle className="mr-2 h-4 w-4" />
            Approve Timecards
          </Button>
          <Button variant="outline" onClick={() => go({ to: "/invoices/generate" })}>
            <Receipt className="mr-2 h-4 w-4" />
            Generate Invoice
          </Button>
          <Button variant="outline" onClick={() => go({ to: "/purchase-orders/create" })}>
            <FileText className="mr-2 h-4 w-4" />
            Create Purchase Order
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
