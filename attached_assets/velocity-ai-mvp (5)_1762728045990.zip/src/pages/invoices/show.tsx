import { useShow, useOne, useMany, useUpdate } from "@refinedev/core";
import { useParams } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ShowView, ShowViewHeader } from "@/components/refine-ui/views/show-view";
import { LoadingOverlay } from "@/components/refine-ui/layout/loading-overlay";
import { ListButton } from "@/components/refine-ui/buttons/list";
import { EditButton } from "@/components/refine-ui/buttons/edit";
import { CheckCircle, FileText, AlertTriangle, DollarSign, Download } from "lucide-react";
import { useState } from "react";
import { exportInvoiceDetailed } from "@/utils/export-invoices";
import type { Invoice, Contractor, PurchaseOrder, Timecard } from "@/types";

export function InvoiceShowPage() {
  const { id } = useParams();
  const [notes, setNotes] = useState("");

  const { queryResult } = useShow<Invoice>({
    resource: "invoices",
    id,
  });

  const { data, isLoading } = queryResult;
  const invoice = data?.data;

  const { data: contractorData } = useOne<Contractor>({
    resource: "contractors",
    id: invoice?.contractorId || 0,
    queryOptions: {
      enabled: !!invoice?.contractorId,
    },
  });

  const { data: purchaseOrderData } = useOne<PurchaseOrder>({
    resource: "purchaseorders",
    id: invoice?.purchaseOrderId || 0,
    queryOptions: {
      enabled: !!invoice?.purchaseOrderId,
    },
  });

  const { data: timecardsData } = useMany<Timecard>({
    resource: "timecards",
    ids: invoice?.timecardIds || [],
    queryOptions: {
      enabled: !!invoice?.timecardIds && invoice.timecardIds.length > 0,
    },
  });

  const { mutate: updateInvoice, isLoading: isUpdating } = useUpdate();

  const handleStatusChange = (newStatus: Invoice["status"]) => {
    if (!invoice) return;
    updateInvoice({
      resource: "invoices",
      id: invoice.id,
      values: {
        ...invoice,
        status: newStatus,
        notes: notes || invoice.notes,
        ...(newStatus === "Paid" && { paidDate: new Date().toISOString().split("T")[0] }),
      },
      successNotification: {
        message: `Invoice ${newStatus.toLowerCase()} successfully`,
        type: "success",
      },
    });
  };

  const contractor = contractorData?.data;
  const purchaseOrder = purchaseOrderData?.data;
  const timecards = timecardsData?.data || [];

  const statusVariant =
    invoice?.status === "Paid"
      ? "default"
      : invoice?.status === "GR Approved"
        ? "outline"
        : invoice?.status === "Disputed"
          ? "destructive"
          : "secondary";

  const handleExport = () => {
    if (!invoice || !contractor || !purchaseOrder) return;
    exportInvoiceDetailed(invoice, timecards, contractor, purchaseOrder);
  };

  return (
    <ShowView>
      <ShowViewHeader>
        <ListButton />
        <EditButton />
        <Button variant="outline" onClick={handleExport} disabled={isLoading}>
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </ShowViewHeader>
      <LoadingOverlay loading={isLoading}>
        <div className="p-4 space-y-6">
          {/* Invoice Header */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">{invoice?.invoiceNumber}</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {contractor ? `${contractor.firstName} ${contractor.lastName}` : "Loading..."}
                  </p>
                </div>
                <Badge variant={statusVariant} className="text-sm px-3 py-1">
                  {invoice?.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-muted-foreground">Invoice Date</Label>
                  <p className="font-medium">{invoice?.invoiceDate}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Due Date</Label>
                  <p className="font-medium">{invoice?.dueDate}</p>
                </div>
                {invoice?.paidDate && (
                  <div>
                    <Label className="text-muted-foreground">Paid Date</Label>
                    <p className="font-medium">{invoice.paidDate}</p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Purchase Order</Label>
                  <p className="font-medium">{purchaseOrder?.poNumber || "Loading..."}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Contractor</Label>
                  <p className="font-medium">
                    {contractor ? `${contractor.firstName} ${contractor.lastName}` : "Loading..."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Amount Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Amount Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <Label className="text-muted-foreground">Requested Amount</Label>
                  <p className="text-2xl font-bold">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(invoice?.requestedAmount || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Actual Invoice Amount</Label>
                  <p className="text-2xl font-bold">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(invoice?.actualAmount || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">GR Amount</Label>
                  <p className="text-xl font-semibold">
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(invoice?.grAmount || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">GR Balance (Pending Release)</Label>
                  <p
                    className={`text-xl font-semibold ${
                      (invoice?.grBalance || 0) > 0 ? "text-orange-600" : "text-green-600"
                    }`}>
                    {new Intl.NumberFormat("en-US", {
                      style: "currency",
                      currency: "USD",
                    }).format(invoice?.grBalance || 0)}
                  </p>
                </div>
              </div>

              {invoice?.hasVariance && (
                <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-md">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-orange-900">Variance Detected</p>
                      <p className="text-sm text-orange-700 mt-1">
                        The actual invoice amount differs from the requested amount by{" "}
                        <span className="font-bold">
                          {invoice.varianceAmount > 0 ? "+" : ""}
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(invoice.varianceAmount)}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Timecards */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Associated Timecards ({timecards.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {timecards.length === 0 ? (
                <p className="text-muted-foreground">No timecards associated</p>
              ) : (
                <div className="space-y-3">
                  {timecards.map((timecard) => (
                    <div key={timecard.id} className="flex items-center justify-between p-3 border rounded-md">
                      <div>
                        <p className="font-medium">Timecard #{timecard.id}</p>
                        <p className="text-sm text-muted-foreground">
                          {timecard.date} - {timecard.hours}h - {timecard.taskDescription.substring(0, 50)}...
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(timecard.totalAmount)}
                        </p>
                        <Badge variant={timecard.status === "Approved" ? "default" : "secondary"} className="text-xs">
                          {timecard.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* PO Budget Impact */}
          {purchaseOrder && (
            <Card>
              <CardHeader>
                <CardTitle>PO Budget Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label className="text-muted-foreground">PO Total</Label>
                    <p className="font-medium">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.totalAmount)}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Current Remaining</Label>
                    <p className="font-medium">
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.remainingFunds)}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">After This Invoice</Label>
                    <p
                      className={`font-medium ${
                        purchaseOrder.remainingFunds - (invoice?.actualAmount || 0) < 0
                          ? "text-destructive"
                          : "text-green-600"
                      }`}>
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(purchaseOrder.remainingFunds - (invoice?.actualAmount || 0))}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes */}
          {invoice?.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{invoice.notes}</p>
              </CardContent>
            </Card>
          )}

          {/* Action Panel */}
          {invoice?.status !== "Paid" && (
            <Card>
              <CardHeader>
                <CardTitle>Invoice Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="actionNotes">Notes / Comments</Label>
                  <Textarea
                    id="actionNotes"
                    placeholder="Add notes or comments..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {invoice?.status === "Submitted" && (
                    <Button onClick={() => handleStatusChange("GR Approved")} disabled={isUpdating}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Approve GR (Goods Receipt)
                    </Button>
                  )}

                  {invoice?.status === "GR Approved" && (
                    <Button onClick={() => handleStatusChange("Paid")} disabled={isUpdating}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Mark as Paid
                    </Button>
                  )}

                  {(invoice?.status === "Draft" || invoice?.status === "Submitted") && (
                    <Button onClick={() => handleStatusChange("Disputed")} disabled={isUpdating} variant="destructive">
                      <AlertTriangle className="mr-2 h-4 w-4" />
                      Mark as Disputed
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </LoadingOverlay>
    </ShowView>
  );
}
