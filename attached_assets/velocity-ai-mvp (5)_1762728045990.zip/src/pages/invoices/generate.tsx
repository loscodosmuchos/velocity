import { useState, useEffect } from "react";
import { useGo, useCreate, useList, useOne } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { AlertTriangle, CheckCircle, FileText } from "lucide-react";
import { generateInvoiceFromTimecards, validateInvoiceAgainstPO } from "@/utils/invoice-generator";
import type { Timecard, PurchaseOrder, Contractor, Invoice } from "@/types";

export function GenerateInvoicePage() {
  const go = useGo();
  const [selectedTimecards, setSelectedTimecards] = useState<number[]>([]);
  const [selectedContractorId, setSelectedContractorId] = useState<number | null>(null);
  const [selectedPOId, setSelectedPOId] = useState<number | null>(null);

  // Fetch approved timecards
  const { data: timecardsData, isLoading: timecardsLoading } = useList<Timecard>({
    resource: "timecards",
    filters: [
      {
        field: "status",
        operator: "eq",
        value: "Approved",
      },
    ],
  });

  const timecards = timecardsData?.data || [];

  // Group timecards by contractor and PO
  const groupedTimecards = timecards.reduce(
    (acc, timecard) => {
      const key = `${timecard.contractorId}-${timecard.purchaseOrderId}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(timecard);
      return acc;
    },
    {} as Record<string, Timecard[]>,
  );

  const groups = Object.entries(groupedTimecards);

  // Get selected group timecards
  const selectedGroup =
    selectedContractorId && selectedPOId
      ? timecards.filter((t) => t.contractorId === selectedContractorId && t.purchaseOrderId === selectedPOId)
      : [];

  const selectedTimecardsData = selectedGroup.filter((t) => selectedTimecards.includes(t.id));

  // Fetch contractor and PO for selected group
  const { data: contractorData } = useOne<Contractor>({
    resource: "contractors",
    id: selectedContractorId || 0,
    queryOptions: {
      enabled: !!selectedContractorId,
    },
  });

  const { data: poData } = useOne<PurchaseOrder>({
    resource: "purchaseorders",
    id: selectedPOId || 0,
    queryOptions: {
      enabled: !!selectedPOId,
    },
  });

  const contractor = contractorData?.data;
  const purchaseOrder = poData?.data;

  // Calculate totals
  const totalAmount = selectedTimecardsData.reduce((sum, t) => sum + t.totalAmount, 0);

  // Validate against PO
  const poValidation = purchaseOrder
    ? validateInvoiceAgainstPO(totalAmount, purchaseOrder.remainingFunds)
    : { isValid: true };

  const { mutate: createInvoice, isLoading: isCreating } = useCreate();

  const handleGenerateInvoice = () => {
    if (selectedTimecardsData.length === 0) return;

    try {
      const invoiceData = generateInvoiceFromTimecards(selectedTimecardsData);

      createInvoice(
        {
          resource: "invoices",
          values: invoiceData,
        },
        {
          onSuccess: (data) => {
            if (data.data?.id) {
              go({
                to: {
                  resource: "invoices",
                  action: "show",
                  id: data.data.id,
                },
              });
            }
          },
        },
      );
    } catch (error) {
      console.error("Error generating invoice:", error);
    }
  };

  return (
    <CreateView>
      <CreateViewHeader title="Generate Invoice from Timecards" />
      <div className="p-4 space-y-6">
        {groups.length === 0 ? (
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription>
              No approved timecards available. Timecards must be approved before invoices can be generated.
            </AlertDescription>
          </Alert>
        ) : (
          <>
            {/* Step 1: Select Contractor/PO Group */}
            <Card>
              <CardHeader>
                <CardTitle>Step 1: Select Contractor & Purchase Order</CardTitle>
                <CardDescription>Choose a contractor and PO combination to generate an invoice</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {groups.map(([key, groupTimecards]) => {
                  const firstTimecard = groupTimecards[0];
                  const isSelected =
                    selectedContractorId === firstTimecard.contractorId &&
                    selectedPOId === firstTimecard.purchaseOrderId;

                  return (
                    <div
                      key={key}
                      className={`p-4 border rounded-md cursor-pointer transition-colors ${
                        isSelected ? "border-primary bg-primary/5" : "hover:bg-muted"
                      }`}
                      onClick={() => {
                        setSelectedContractorId(firstTimecard.contractorId);
                        setSelectedPOId(firstTimecard.purchaseOrderId);
                        setSelectedTimecards([]);
                      }}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Contractor #{firstTimecard.contractorId}</p>
                          <p className="text-sm text-muted-foreground">PO #{firstTimecard.purchaseOrderId}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="secondary">{groupTimecards.length} timecards</Badge>
                          <p className="text-sm font-medium mt-1">
                            {new Intl.NumberFormat("en-US", {
                              style: "currency",
                              currency: "USD",
                            }).format(groupTimecards.reduce((sum, t) => sum + t.totalAmount, 0))}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Step 2: Select Timecards */}
            {selectedContractorId && selectedPOId && (
              <Card>
                <CardHeader>
                  <CardTitle>Step 2: Select Timecards to Include</CardTitle>
                  <CardDescription>
                    {contractor && `${contractor.firstName} ${contractor.lastName}`} - {purchaseOrder?.poNumber}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 mb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedTimecards(selectedGroup.map((t) => t.id))}>
                      Select All
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setSelectedTimecards([])}>
                      Clear All
                    </Button>
                    <div className="ml-auto">
                      <Badge variant="secondary">{selectedTimecards.length} selected</Badge>
                    </div>
                  </div>

                  {selectedGroup.map((timecard) => (
                    <div key={timecard.id} className="flex items-center gap-3 p-3 border rounded-md">
                      <Checkbox
                        id={`timecard-${timecard.id}`}
                        checked={selectedTimecards.includes(timecard.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedTimecards([...selectedTimecards, timecard.id]);
                          } else {
                            setSelectedTimecards(selectedTimecards.filter((id) => id !== timecard.id));
                          }
                        }}
                      />
                      <Label htmlFor={`timecard-${timecard.id}`} className="flex-1 cursor-pointer">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">Timecard #{timecard.id}</p>
                            <p className="text-sm text-muted-foreground">
                              {timecard.date} - {timecard.hours}h - {timecard.taskDescription.substring(0, 50)}...
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">
                              {new Intl.NumberFormat("en-US", {
                                style: "currency",
                                currency: "USD",
                              }).format(timecard.totalAmount)}
                            </p>
                          </div>
                        </div>
                      </Label>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Step 3: Review & Generate */}
            {selectedTimecards.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Step 3: Review & Generate Invoice</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Total Timecards</Label>
                      <p className="text-2xl font-bold">{selectedTimecards.length}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Invoice Amount</Label>
                      <p className="text-2xl font-bold">
                        {new Intl.NumberFormat("en-US", {
                          style: "currency",
                          currency: "USD",
                        }).format(totalAmount)}
                      </p>
                    </div>
                  </div>

                  {purchaseOrder && (
                    <div className="p-3 bg-muted rounded-md">
                      <p className="text-sm font-medium mb-2">PO Budget Check</p>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">PO Remaining Funds:</span>
                        <span className="font-medium">
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(purchaseOrder.remainingFunds)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm mt-1">
                        <span className="text-muted-foreground">After Invoice:</span>
                        <span className={`font-medium ${poValidation.isValid ? "text-green-600" : "text-destructive"}`}>
                          {new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(purchaseOrder.remainingFunds - totalAmount)}
                        </span>
                      </div>
                    </div>
                  )}

                  {!poValidation.isValid && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        Warning: This invoice exceeds the PO budget by{" "}
                        {new Intl.NumberFormat("en-US", {
                          style: "currency",
                          currency: "USD",
                        }).format(poValidation.exceedsBy || 0)}
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => go({ to: "/invoices" })}>
                      Cancel
                    </Button>
                    <Button onClick={handleGenerateInvoice} disabled={isCreating}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      {isCreating ? "Generating..." : "Generate Invoice"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </CreateView>
  );
}
