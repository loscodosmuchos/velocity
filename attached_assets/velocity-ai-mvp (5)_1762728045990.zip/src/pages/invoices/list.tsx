import { useMemo } from "react";
import { useTable } from "@refinedev/react-table";
import type { ColumnDef } from "@tanstack/react-table";
import { useMany } from "@refinedev/core";
import { useGo } from "@refinedev/core";
import { useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal, AlertTriangle, Download, Plus } from "lucide-react";
import { DataTable } from "@/components/refine-ui/data-table/data-table";
import { DataTableSorter } from "@/components/refine-ui/data-table/data-table-sorter";
import {
  DataTableFilterDropdownText,
  DataTableFilterCombobox,
} from "@/components/refine-ui/data-table/data-table-filter";
import { ShowButton } from "@/components/refine-ui/buttons/show";
import { ListViewHeader, ListView } from "@/components/refine-ui/views/list-view";
import { cn } from "@/lib/utils";
import { exportInvoicesToCSV, exportInvoicesForBalanceStaffing } from "@/utils/export-invoices";
import type { Invoice, Contractor, PurchaseOrder } from "@/types";

export function InvoicesListPage() {
  const go = useGo();
  const navigate = useNavigate();

  const columns = useMemo<ColumnDef<Invoice>[]>(
    () => [
      {
        id: "invoiceNumber",
        accessorKey: "invoiceNumber",
        size: 150,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Invoice #</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return (
            <span
              className="font-medium cursor-pointer hover:underline"
              onClick={() => navigate(`/invoices/show/${row.original.id}`)}>
              {row.original.invoiceNumber}
            </span>
          );
        },
      },
      {
        id: "contractorId",
        accessorKey: "contractorId",
        size: 200,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Contractor</span>
              <DataTableFilterDropdownText
                defaultOperator="eq"
                column={column}
                table={table}
                placeholder="Filter by contractor ID"
              />
            </div>
          );
        },
        cell: ({ row, table }) => {
          const contractorId = row.original.contractorId;
          const contractors = (table.options.meta as any)?.contractors || [];
          const contractor = contractors.find((c: Contractor) => c.id === contractorId);
          return contractor ? `${contractor.firstName} ${contractor.lastName}` : `Contractor #${contractorId}`;
        },
      },
      {
        id: "purchaseOrderId",
        accessorKey: "purchaseOrderId",
        size: 150,
        header: ({ column, table }) => {
          return (
            <div className="flex items-center gap-1">
              <span>PO</span>
              <DataTableFilterDropdownText
                defaultOperator="eq"
                column={column}
                table={table}
                placeholder="Filter by PO ID"
              />
            </div>
          );
        },
        cell: ({ row, table }) => {
          const poId = row.original.purchaseOrderId;
          const purchaseOrders = (table.options.meta as any)?.purchaseOrders || [];
          const po = purchaseOrders.find((p: PurchaseOrder) => p.id === poId);
          return po ? po.poNumber : `PO #${poId}`;
        },
      },
      {
        id: "invoiceDate",
        accessorKey: "invoiceDate",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Invoice Date</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
      },
      {
        id: "actualAmount",
        accessorKey: "actualAmount",
        size: 140,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Amount</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
          }).format(row.original.actualAmount);
        },
      },
      {
        id: "variance",
        accessorKey: "hasVariance",
        size: 120,
        header: "Variance",
        cell: ({ row }) => {
          if (!row.original.hasVariance) return <span className="text-muted-foreground">-</span>;
          const isPositive = row.original.varianceAmount > 0;
          return (
            <div className="flex items-center gap-1">
              <AlertTriangle className={cn("h-4 w-4", isPositive ? "text-orange-500" : "text-blue-500")} />
              <span className={cn("font-medium", isPositive ? "text-orange-600" : "text-blue-600")}>
                {isPositive ? "+" : ""}
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: "USD",
                }).format(row.original.varianceAmount)}
              </span>
            </div>
          );
        },
      },
      {
        id: "grBalance",
        accessorKey: "grBalance",
        size: 120,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>GR Balance</span>
              <DataTableSorter column={column} />
            </div>
          );
        },
        cell: ({ row }) => {
          const balance = row.original.grBalance;
          return (
            <span className={cn("font-medium", balance > 0 ? "text-orange-600" : "text-green-600")}>
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
              }).format(balance)}
            </span>
          );
        },
      },
      {
        id: "status",
        accessorKey: "status",
        size: 140,
        header: ({ column }) => {
          return (
            <div className="flex items-center gap-1">
              <span>Status</span>
              <DataTableFilterCombobox
                column={column}
                defaultOperator="in"
                multiple={true}
                options={[
                  { label: "Draft", value: "Draft" },
                  { label: "Submitted", value: "Submitted" },
                  { label: "GR Approved", value: "GR Approved" },
                  { label: "Paid", value: "Paid" },
                  { label: "Disputed", value: "Disputed" },
                ]}
              />
            </div>
          );
        },
        cell: ({ row }) => {
          const status = row.original.status;
          let variant: "default" | "secondary" | "destructive" | "outline" = "secondary";
          if (status === "Paid") variant = "default";
          if (status === "GR Approved") variant = "outline";
          if (status === "Disputed") variant = "destructive";
          return <Badge variant={variant}>{status}</Badge>;
        },
      },
      {
        id: "actions",
        size: 84,
        enableSorting: false,
        enableColumnFilter: false,
        header: () => {
          return <div className={cn("flex", "w-full", "items-center", "justify-center")}>Actions</div>;
        },
        cell: ({ row }) => {
          const invoice = row.original;
          return (
            <div className="flex items-center gap-2 justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/invoices/show/${invoice.id}`);
                }}>
                View
              </Button>
            </div>
          );
        },
      },
    ],
    [navigate],
  );

  const table = useTable<Invoice>({
    columns,
    refineCoreProps: {
      resource: "invoices",
    },
    initialState: {
      columnPinning: {
        left: [],
        right: ["actions"],
      },
    },
  });

  // Fetch related contractors
  const contractorIds = table.getRowModel().rows.map((row) => row.original.contractorId);
  const { data: contractorsData } = useMany<Contractor>({
    resource: "contractors",
    ids: contractorIds,
    queryOptions: {
      enabled: contractorIds.length > 0,
    },
  });

  // Fetch related purchase orders
  const poIds = table.getRowModel().rows.map((row) => row.original.purchaseOrderId);
  const { data: purchaseOrdersData } = useMany<PurchaseOrder>({
    resource: "purchaseorders",
    ids: poIds,
    queryOptions: {
      enabled: poIds.length > 0,
    },
  });

  // Update table meta with related data
  table.options.meta = {
    ...table.options.meta,
    contractors: contractorsData?.data || [],
    purchaseOrders: purchaseOrdersData?.data || [],
  };

  const handleExportCSV = () => {
    const exportData = table.getRowModel().rows.map((row) => {
      const invoice = row.original;
      const contractors = (table.options.meta as any)?.contractors || [];
      const purchaseOrders = (table.options.meta as any)?.purchaseOrders || [];

      const contractor = contractors.find((c: Contractor) => c.id === invoice.contractorId);
      const po = purchaseOrders.find((p: PurchaseOrder) => p.id === invoice.purchaseOrderId);

      return {
        ...invoice,
        contractorName: contractor ? `${contractor.firstName} ${contractor.lastName}` : undefined,
        poNumber: po?.poNumber,
      };
    });

    exportInvoicesToCSV(exportData);
  };

  const handleExportBalanceStaffing = () => {
    const exportData = table.getRowModel().rows.map((row) => {
      const invoice = row.original;
      const purchaseOrders = (table.options.meta as any)?.purchaseOrders || [];
      const po = purchaseOrders.find((p: PurchaseOrder) => p.id === invoice.purchaseOrderId);

      return {
        ...invoice,
        poNumber: po?.poNumber,
      };
    });

    exportInvoicesForBalanceStaffing(exportData);
  };

  return (
    <ListView>
      <ListViewHeader canCreate={true}>
        <Button onClick={() => go({ to: "/invoices/generate" })}>
          <Plus className="h-4 w-4 mr-2" />
          Generate Invoice
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="flex flex-col gap-2 p-2">
            <Button variant="ghost" size="sm" className="justify-start" onClick={handleExportCSV}>
              Export to CSV
            </Button>
            <Button variant="ghost" size="sm" className="justify-start" onClick={handleExportBalanceStaffing}>
              Balance Staffing Format
            </Button>
          </DropdownMenuContent>
        </DropdownMenu>
      </ListViewHeader>
      <DataTable table={table} />
    </ListView>
  );
}
