import { useForm } from "@refinedev/react-hook-form";
import { useSelect } from "@refinedev/core";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useGo } from "@refinedev/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreateView, CreateViewHeader } from "@/components/refine-ui/views/create-view";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";
import type { Invoice, Contractor, PurchaseOrder } from "@/types";
import type { HttpError } from "@refinedev/core";

const invoiceFormSchema = z.object({
  contractorId: z.number({ required_error: "Contractor is required" }),
  purchaseOrderId: z.number({ required_error: "Purchase Order is required" }),
  requestedAmount: z.number().min(0.01, "Amount must be greater than 0"),
  actualAmount: z.number().min(0.01, "Amount must be greater than 0"),
  grAmount: z.number().min(0, "GR Amount cannot be negative"),
  invoiceDate: z.string().min(1, "Invoice date is required"),
  dueDate: z.string().min(1, "Due date is required"),
  notes: z.string().optional(),
});

type InvoiceFormValues = z.infer<typeof invoiceFormSchema>;

export function CreateInvoicePage() {
  const go = useGo();

  const {
    refineCore: { onFinish, formLoading },
    ...form
  } = useForm<Invoice, HttpError, InvoiceFormValues>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      requestedAmount: 0,
      actualAmount: 0,
      grAmount: 0,
      invoiceDate: new Date().toISOString().split("T")[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 30 days from now
      notes: "",
    },
    refineCoreProps: {
      resource: "invoices",
      action: "create",
      redirect: "list",
    },
  });

  // Fetch contractors for select
  const { options: contractorOptions } = useSelect<Contractor>({
    resource: "contractors",
    optionLabel: (item) => `${item.firstName} ${item.lastName}`,
    optionValue: "id",
  });

  // Fetch purchase orders for select
  const { options: poOptions } = useSelect<PurchaseOrder>({
    resource: "purchaseorders",
    optionLabel: "poNumber",
    optionValue: "id",
    filters: [
      {
        field: "status",
        operator: "in",
        value: ["Active", "Pending"],
      },
    ],
  });

  function onSubmit(values: InvoiceFormValues) {
    // Generate invoice number (in real app, this would be server-generated)
    const invoiceNumber = `INV-${Date.now()}`;

    // Calculate variance
    const varianceAmount = values.actualAmount - values.requestedAmount;
    const hasVariance = Math.abs(varianceAmount) > 0.01;

    // Calculate GR balance
    const grBalance = values.actualAmount - values.grAmount;

    const invoiceData: Partial<Invoice> = {
      ...values,
      invoiceNumber,
      status: "Draft",
      varianceAmount,
      hasVariance,
      grBalance,
      timecardIds: [], // Manual invoices don't have associated timecards
    };

    onFinish(invoiceData as any);
  }

  const requestedAmount = form.watch("requestedAmount") || 0;
  const actualAmount = form.watch("actualAmount") || 0;
  const grAmount = form.watch("grAmount") || 0;
  const variance = actualAmount - requestedAmount;
  const hasVariance = Math.abs(variance) > 0.01;
  const grBalance = actualAmount - grAmount;

  return (
    <CreateView>
      <CreateViewHeader title="Create Manual Invoice" />
      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle>Invoice Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="contractorId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contractor *</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(Number(value))}
                          value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select contractor" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {contractorOptions?.map((option) => (
                              <SelectItem key={option.value} value={option.value.toString()}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="purchaseOrderId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchase Order *</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(Number(value))}
                          value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select PO" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {poOptions?.map((option) => (
                              <SelectItem key={option.value} value={option.value.toString()}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="invoiceDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Invoice Date *</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Due Date *</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="requestedAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Requested Amount *</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="actualAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Actual Invoice Amount *</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="grAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GR Approved Amount</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Variance Alert */}
                {hasVariance && (
                  <Alert variant={variance > 0 ? "default" : "destructive"}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Variance Detected:</strong> Actual amount differs from requested by{" "}
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(Math.abs(variance))}
                      {variance > 0 ? " over" : " under"}
                    </AlertDescription>
                  </Alert>
                )}

                {/* GR Balance Info */}
                {grBalance !== 0 && (
                  <div className="p-3 bg-muted rounded-md">
                    <p className="text-sm">
                      <strong>GR Balance (Pending Release):</strong>{" "}
                      {new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(grBalance)}
                    </p>
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Add any notes or comments..." rows={4} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => go({ to: "/invoices" })}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={formLoading}>
                    {formLoading ? "Creating..." : "Create Invoice"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </CreateView>
  );
}
